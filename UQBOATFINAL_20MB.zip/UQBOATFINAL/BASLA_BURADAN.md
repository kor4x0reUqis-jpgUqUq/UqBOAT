# UqBOAT × Roblox Studio — Tam Paket (v1.6.0.0 — Tam HTML Skill + Görseller + Otomatik Studio Modülleri + Sesli Captcha Buster & Yenile Döngüsü)

Bu paket içerisinde tüm güncellemeler uygulanmış ve doğrulanmıştır:

## 1. Tüm Skill Dosyaları, Örnekler ve Görseller (%100 Eksiksiz + HTML + Otomatik Studio Kurulumu)
Yapay zekaların skill paketlerine "bozuk" demesine yol açan 3 temel sorun tamamen giderildi ve her iki GitHub reposundaki (`TemporaryLooker22/Stud-UI-Clean-Roblox` ve `kor4x0reUqis-jpgUqUq/Test`) **303 dosyanın tamamı** eklenti içine gömüldü:
1. **`Stud-UI-Clean-Roblox` (`stud_ui` — 37 Dosya):**
   - `src/StudUI.luau`, `src/StudMotion.luau`, `src/CheckUIIcons.luau`
   - 7 Referans Dosyası: `components.md`, `design-tokens.md`, `layouts-and-archetypes.md`, `icons-and-assets.md`, `motion-and-sound.md`, `checklist.md`, `icon-catalog.md`
   - 6 Tam Örnek: `01_ShopWindow.luau` .. `06_MenuController.client.luau`
   - 14 Ekran Görüntüsü: `assets/screenshots/01-hud-overview.jpg` .. `22-validation-generated-daily-and-index.jpg`
2. **`ModelMakerSkills_4.1_ReferansStudio.zip` (`referans_studio` — 191 Dosya):**
   - `SKILL.md`, `OKU_ONCE.html`, `HIZLI_BASLANGIC.md`
   - 18 Mühendislik Referansı (`00_son_sozlesme.md` .. `17_olumlu_eslestirmeler.md`)
   - 5 Hazır Luau Aracı (`StudioKit.luau`, `Math3.luau`, `GuvenliCSG.luau`, `CameraGuard.luau`, `Acceptance.luau`)
   - 4 Pozitif Eşleşme (`blue_roof_hut`, `red_gantry_container`, `warehouse_interior`, `yellow_crane_payload` — `Builder.luau`, `Installer_CommandBar.luau` ve kırpılmış referans/çıktı görselleri) + 18 eğitim görseli (`training/images/*`)
3. **`ModelMakerSkills.zip` (`modelmaker` — 73 Dosya):**
   - `SKILL.md`, 22 Referans Belgesi, `GeometriAraclari.luau`, `GuvenliCSG.luau`, Sahne Kurulum Örnekleri (`Karakarga_TamIcMekan_Kurulum.luau`, `KorsanLobisi_Kurulum.luau`, `Production_Hazirla.luau`, `Seri01_Kurulum.luau`) ve 21 Görsel Kanıt (`png`)
4. **Görsel İncelemeli 263 VFX Asset ID Kataloğu (`vfx_pack` — 2 Dosya):**
   - 263 adet Roblox VFX Asset ID'sinin tek tek görsellerine bakılarak isimlendirilmiş tam listesi (`vfx_pack/SKILL.md`) ve hazır `UqVFXLibrary.luau` modülü.
5. **Neden AI'lar Önceden "Skill Bozuk" Diyordu? (Çözülen Kök Nedenler):**
   - **Otomatik Modül Kurulumunda `datamodel_type: "Edit"` Eksikliği Giderildi:** Önceden `StudUI` kurulurken `datamodel_type: "Edit"` gönderilmediği için Roblox Studio MCP kurulumu reddediyor ve AI `require(game.ReplicatedStorage.StudUI)` yazdığında modülü bulamıyordu. Artık oturum başlar başlamaz (`list_commands` anında) `StudUI`, `StudMotion`, `CheckUIIcons`, `StudExamples`, `StudioKit`, `Math3`, `GeometriAraclari`, `GuvenliCSG` ve `UqVFXLibrary` doğrudan `datamodel_type: "Edit"` ile `game.ReplicatedStorage` içine kurulur!
   - **`execute_luau` Bloklama Kaldırıldı:** Önceden otomatik skill yüklendiğinde AI'ın ilk `execute_luau` komutu iptal edilip sadece metin döndürülüyordu. Artık önce modüller Studio'ya kurulur, ardından AI'ın `execute_luau` kodu gerçekten çalıştırılır ve hem kod sonucu hem de HTML skill rehberi + ekli referans görselleri (`jpg`/`png`) aynı anda AI'a verilir.

## 2. Captcha "Press PLAY to listen" Döngüsü + 5 Aşamalı Görünürlük, Ekran Bölme (Split-Screen) Otomatik Kaydırma ve `elementFromPoint` Doğrulaması
- **Captcha Yokken Ekrana Tıklama Sorunu Tamamen Kaldırıldı:**
  - Google reCAPTCHA, sayfada Captcha açık olmasa bile arka planda gizli bir `bframe` iframe'i ve sağ altta görünmez `.grecaptcha-badge` rozeti tutar. Önceden bu gizli çerçeveler algılanıp ekrana tıklanabiliyordu.
  - Artık **5 aşamalı doğrulama** var:
    1. `.grecaptcha-badge` (sağ alttaki küçük reCAPTCHA rozeti) tamamen yoksayılır; yalnızca gerçek Captcha doğrulama penceresi (`bframe`, en az `220x220` piksel) kontrol edilir.
    2. Captcha `iframe`'inin kendisi ve **tüm üst kapsayıcı `<div>` elementleri** (`display: none`, `visibility: hidden`, `opacity < 0.15`, `pointer-events: none`) tek tek kontrol edilir; pencere kapalıysa **kesinlikle tıklama yapılmaz**.
    3. `bframe` içindeki çözücü, tıklamadan önce üst sayfaya (`check_bframe_visible`) Captcha penceresinin gerçekten ekranda açık olup olmadığını sorar.
- **Ekran Bölündüğünde (Split-Screen / Küçük Pencere) Otomatik Aşağı Kaydırma ve Yeni Konum Hesaplama:**
  - Ekranı ikiye böldüğünüzde (ör. bir tarafta Roblox Studio, diğer tarafta tarayıcı) Captcha penceresi veya altındaki turuncu Buster / Yenile butonları ekranın alt sınırının altında kalabiliyordu.
  - Artık her tıklamadan hemen önce:
    1. Hedef butonun (`localX, localY`) bölünmüş ekrandaki anlık konumu ölçülür.
    2. Eğer buton görünür ekranın dışında veya alt sınırındaysa, sayfa ve kaydırılabilir kapsayıcılar **otomatik olarak aşağı/yukarı/yana kaydırılır (`scrollIntoView` + `scrollBy`)**.
    3. Kaydırma tamamlandıktan sonra eski konum değil, **yeni (güncel) koordinatlar tekrar ölçülür (`getBoundingClientRect`)**.
    4. Son olarak **`document.elementFromPoint(tabX, tabY) === captchaIframe`** testi yapılır: o noktada gerçekten Captcha penceresi yoksa (ör. başka bir alan varsa) **asla tıklama yapılmaz**.

## 3. Kurulum
1. Chrome'da `chrome://extensions` adresini açın.
2. Sağ üstten **Geliştirici modu (Developer mode)** seçeneğini açın.
3. **Paketlenmemiş öğe yükle (Load unpacked)** butonuna tıklayıp bu klasörün içindeki **`uqboat-extension`** klasörünü seçin (veya mevcut eklentinin üzerinde **Yenile / Reload** ikonuna basın).
4. Açık olan Arena.ai sekmelerinizi **F5** ile yenileyin.
