// Automated verification for runTool routing, Direct vs Agent snapshot behavior,
// Direct mode 0.5s post-reply delay, and automatic "Atla" / "Skip" button clicking.
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const ROOT = __dirname;
let pass = 0, fail = 0;
function ok(name, cond, detail = "") {
  if (cond) { pass++; console.log("  ✓", name); }
  else { fail++; console.error("  ✗", name, detail); }
}

(async () => {
  console.log("── Arena Provider: Direct 0.5s timing & Auto Skip ('Atla') button tests ──");

  let mockPathname = "/text/direct";
  let mockButtons = [];
  let stopBtnPresent = false;
  let assistantReplyText = '{"command": "list_commands"}';

  function makeButton({ text = "", aria = "", title = "", disabled = false, inHeader = false, hasSvgTitle = "" }) {
    const b = {
      nodeType: 1,
      tagName: "BUTTON",
      textContent: (hasSvgTitle ? hasSvgTitle : "") + text,
      innerText: text,
      disabled,
      offsetParent: {},
      clicked: 0,
      childNodes: [
        ...(hasSvgTitle ? [{ nodeType: 1, tagName: "SVG", matches: (sel) => sel.includes("svg"), childNodes: [{ nodeType: 3, nodeValue: hasSvgTitle }] }] : []),
        { nodeType: 3, nodeValue: text },
      ],
      matches: () => false,
      closest: (sel) => (inHeader && /header|nav|aside/.test(sel) ? {} : null),
      getAttribute: (k) => (k === "aria-label" ? aria : k === "title" ? title : k === "aria-disabled" ? (disabled ? "true" : "false") : null),
      hasAttribute: (k) => (k === "disabled" ? disabled : false),
      getBoundingClientRect: () => ({ width: 80, height: 32, top: 400, left: 400, right: 480, bottom: 432 }),
      click() { this.clicked++; },
    };
    return b;
  }

  const arenaSandbox = {
    console: { log: () => {}, warn: () => {}, error: console.error },
    setTimeout,
    clearTimeout,
    setInterval: () => 1,
    clearInterval: () => {},
    window: { getComputedStyle: () => ({}) },
    getComputedStyle: () => ({ display: "block", visibility: "visible", opacity: "1" }),
    innerHeight: 900,
    innerWidth: 1400,
    location: { get pathname() { return mockPathname; } },
    ZS: { SYS_MARKER: "⟦ZS-SYS⟧" },
    ZSParse: {
      isInjectedFeedback: () => false,
      hasCommandShape: () => false,
      hasToolSignature: () => false,
    },
    document: {
      documentElement: {},
      body: {},
      addEventListener: () => {},
      querySelector: () => null,
      querySelectorAll: (sel) => {
        if (sel.includes("button")) return mockButtons;
        return [];
      },
    },
  };

  vm.runInNewContext(fs.readFileSync(path.join(ROOT, "providers", "arena.js"), "utf8") + "\n;this.ZSProvider = ZSProvider;", arenaSandbox);
  const ArenaP = arenaSandbox.ZSProvider;

  ok("Arena provider exposes paced directReplyDelayMs === 5000 (5s anti-ratelimit/captcha)", ArenaP.directReplyDelayMs === 5000, `got ${ArenaP.directReplyDelayMs}`);
  ok("Arena provider isAgentMode() is false on /text/direct", ArenaP.isAgentMode() === false);
  mockPathname = "/agent/12345678-1234-1234-1234-123456789abc";
  ok("Arena provider isAgentMode() is true on /agent/<uuid>", ArenaP.isAgentMode() === true);
  mockPathname = "/text/direct";

  // Test Skip / Atla buttons
  const atlaBtn = makeButton({ text: "Atla", hasSvgTitle: "SkipIcon" });
  const a11ySkip = makeButton({ text: "Skip to main content" });
  const headerAtla = makeButton({ text: "Atla", inHeader: true });
  mockButtons = [a11ySkip, headerAtla, atlaBtn];

  const found = ArenaP.findSkipBtn();
  ok("findSkipBtn finds Turkish 'Atla' button (ignoring SVG title & a11y Skip to content & header)", found === atlaBtn);
  const clicked = ArenaP.resolveBattle();
  ok("resolveBattle automatically clicks 'Atla' button", clicked === true && atlaBtn.clicked === 1 && a11ySkip.clicked === 0 && headerAtla.clicked === 0);

  // Test English 'Skip' button on next turn immediately
  const skipBtn = makeButton({ text: "Skip" });
  mockButtons = [skipBtn];
  const clickedEn = ArenaP.resolveBattle();
  ok("resolveBattle automatically clicks English 'Skip' button on new element", clickedEn === true && skipBtn.clicked === 1);

  // Test 'Oylamayı atla' button
  const oylamaAtlaBtn = makeButton({ text: "Oylamayı atla" });
  mockButtons = [oylamaAtlaBtn];
  const clickedOylama = ArenaP.resolveBattle();
  ok("resolveBattle automatically clicks 'Oylamayı atla' button", clickedOylama === true && oylamaAtlaBtn.clicked === 1);

  // Test Rate Limit detection and auto-clicking 'Clear' button
  const clearBtn = makeButton({ text: "Clear" });
  mockButtons = [clearBtn];
  const origQSA = arenaSandbox.document.querySelectorAll;
  arenaSandbox.document.querySelectorAll = (sel) => {
    if (sel.includes("div, p, span")) {
      return [
        {
          nodeType: 1,
          offsetParent: {},
          innerText: "You've reached a rate limit. Please try again in a moment.",
          textContent: "You've reached a rate limit. Please try again in a moment.",
          closest: () => null,
          parentElement: { querySelectorAll: () => [clearBtn] },
        },
      ];
    }
    return origQSA(sel);
  };
  const rlCheck = ArenaP.detectAndClearRateLimit();
  ok("detectAndClearRateLimit detects Arena rate-limit banner and clicks 'Clear' button automatically",
    rlCheck.rateLimited === true && rlCheck.cleared === true && clearBtn.clicked === 1);
  arenaSandbox.document.querySelectorAll = origQSA;

  // Test Arena getModelName() detection for Multi-Tab Team Mode
  const modelBtn = makeButton({ text: "claude-sonnet-5-5-high" });
  mockButtons = [modelBtn];
  ok("Arena getModelName() detects active model ('claude-sonnet-5-5-high')", ArenaP.getModelName() === "claude-sonnet-5-5-high", `got ${ArenaP.getModelName()}`);
  const lunaBtn = makeButton({ text: "gpt-6-luna-max" });
  mockButtons = [lunaBtn];
  ok("Arena getModelName() detects active model ('gpt-6-luna-max')", ArenaP.getModelName() === "gpt-6-luna-max", `got ${ArenaP.getModelName()}`);
  const terraBtn = makeButton({ text: "gpt-terra-6.1-low" });
  mockButtons = [terraBtn];
  ok("Arena getModelName() detects active model ('gpt-terra-6.1-low')", ArenaP.getModelName() === "gpt-terra-6.1-low", `got ${ArenaP.getModelName()}`);

  // Test Buster Captcha Solver helper (core/captcha-buster.js & ArenaP.triggerBusterCaptcha)
  const busterSolverBtn = makeButton({ text: "", title: "Solve the challenge" });
  busterSolverBtn.id = "solver-button";
  const busterSandbox = {
    window: { getComputedStyle: () => ({ display: "block", visibility: "visible", opacity: "1" }) },
    location: { href: "https://www.google.com/recaptcha/api2/bframe" },
    setTimeout,
    clearTimeout,
    setInterval: () => 1,
    clearInterval: () => {},
    document: {
      querySelector: (sel) => (sel.includes("solver-button") ? busterSolverBtn : null),
      querySelectorAll: (sel) => (sel.includes("solver-button") || sel.includes("Solve") ? [busterSolverBtn] : []),
    },
    chrome: { runtime: { onMessage: { addListener: () => {} } } },
  };
  vm.runInNewContext(fs.readFileSync(path.join(ROOT, "core", "captcha-buster.js"), "utf8"), busterSandbox);
  const busterRes = busterSandbox.__zsBusterHelper.trySolveCaptcha(true);
  ok("core/captcha-buster.js automatically detects and clicks Buster '#solver-button' inside reCAPTCHA frame",
    busterRes.acted === true && busterRes.kind === "buster-button" && busterSolverBtn.clicked >= 1);

  mockButtons = [busterSolverBtn];
  const arenaBusterClicked = ArenaP.triggerBusterCaptcha(true);
  ok("ArenaP.triggerBusterCaptcha() automatically clicks Buster solver button when Captcha appears",
    arenaBusterClicked === true && busterSolverBtn.clicked >= 2);

  console.log("\n── Core main.js: runTool routing, Direct vs Agent snapshot, and 0.5s settle ──");
  const configCode = fs.readFileSync(path.join(ROOT, "core", "config.js"), "utf8");
  const parserCode = fs.readFileSync(path.join(ROOT, "core", "parser.js"), "utf8");
  const mainCode = fs.readFileSync(path.join(ROOT, "core", "main.js"), "utf8");

  // Expose internal runTool and waitForResponse from core/main.js for direct testing
  const instrumentedMain = mainCode.replace(
    "log(`UqBOAT content script ready (provider: ${P.id})`);",
    "globalThis.__testHooks = { runTool, waitForResponse, A }; log(`UqBOAT content script ready (provider: ${P.id})`);"
  );

  let bgCalls = [];
  let bridgeConnected = true;
  let isAgent = false;
  let supportsVision = true;
  let genState = false;
  let skipClicksInLoop = 0;

  function makeMockEl() {
    return {
      style: {},
      dataset: {},
      innerHTML: "",
      textContent: "",
      classList: { add: () => {}, remove: () => {}, toggle: () => {}, contains: () => false },
      appendChild: () => {},
      insertBefore: () => {},
      remove: () => {},
      setAttribute: () => {},
      getAttribute: () => null,
      addEventListener: () => {},
      querySelector: () => makeMockEl(),
      querySelectorAll: () => [],
      getBoundingClientRect: () => ({ width: 100, height: 40, top: 0, left: 0, right: 100, bottom: 40 }),
    };
  }

  const mainSandbox = {
    console: { log: () => {}, warn: () => {}, error: console.error },
    setTimeout,
    clearTimeout,
    setInterval: () => 1,
    clearInterval: () => {},
    requestAnimationFrame: (fn) => setTimeout(fn, 0),
    cancelAnimationFrame: (id) => clearTimeout(id),
    MutationObserver: function () { this.observe = () => {}; },
    document: {
      hidden: false,
      documentElement: makeMockEl(),
      body: makeMockEl(),
      getElementById: () => null,
      createElement: () => makeMockEl(),
      addEventListener: () => {},
      querySelector: () => null,
      querySelectorAll: () => [],
    },
    location: { pathname: "/text/direct" },
    getComputedStyle: () => ({ colorScheme: "dark", backgroundColor: "rgb(15, 15, 20)" }),
    matchMedia: () => ({ matches: true, addEventListener: () => {} }),
    window: {
      getComputedStyle: () => ({ colorScheme: "dark", backgroundColor: "rgb(15, 15, 20)" }),
      matchMedia: () => ({ matches: true, addEventListener: () => {} }),
      addEventListener: () => {},
    },
    chrome: {
      storage: { local: { get: (_k, cb) => cb && cb({}), set: () => {} } },
      runtime: {
        getManifest: () => ({ version: "1.5.6.1" }),
        onMessage: { addListener: () => {} },
        sendMessage: (msg, cb) => {
          bgCalls.push(msg);
          if (msg.type === "get_auto_skill_bundle") {
            const cats = (msg.arguments && msg.arguments.categories) || [];
            return cb({
              ok: true,
              categories: cats,
              text: cats.map((c) => c === "ui" ? "[stud_ui/SKILL.md]\n# Stud UI Rules" : "[modelmaker/sonskills/SKILL.md]\n# 3D ModelMaker Rules").join("\n\n"),
            });
          }
          if (msg.type === "list_offline_skills") {
            return cb({ ok: true, text: "Bundled offline skill packages (3 packages, 301 total files)" });
          }
          if (msg.type === "read_offline_skill") {
            if (msg.arguments && /image/i.test(msg.arguments.path || "")) {
              return cb({
                ok: true,
                kind: "image",
                text: "Offline skill image: test.png",
                images: [{ mimeType: "image/png", data: "iVBORw0KGgo=" }],
              });
            }
            return cb({ ok: true, kind: "text", text: "File: stud_ui/SKILL.md (chars 0..100 of 100, complete)\n\n# Stud UI" });
          }
          if (!bridgeConnected) {
            return cb({ ok: false, kind: "disconnected", error: "bridge not connected" });
          }
          if (msg.type === "list_tools") {
            return cb({
              ok: true,
              tools: [
                { name: "execute_luau", server: "roblox", description: "Run Luau", inputSchema: { properties: { code: { type: "string" } }, required: ["code"] } },
              ],
            });
          }
          if (msg.type === "call_tool" && msg.name === "list_roblox_studios") {
            return cb({ ok: true, text: '{"studios":[{"id":"studio-1","name":"TestPlace"}]}' });
          }
          if (msg.type === "call_tool" && msg.name === "execute_luau") {
            return cb({ ok: true, text: "PlaceId: 123 | Name: TestPlace\nWorkspace (1 items):\n  - Part [Part]" });
          }
          return cb({ ok: true, text: "ok" });
        },
      },
    },
    ZSProvider: {
      id: "arena",
      displayName: "Arena",
      directReplyDelayMs: 500,
      isAgentMode: () => isAgent,
      get supportsVision() { return supportsVision; },
      timings: {
        GEN_IDLE_MS: 1500,
        REASON_IDLE_MS: 12000,
        WARMUP_MS: 45000,
        REASON_NOREPLY_MS: 90000,
        STABLE_MS: 9000,
        RESPONSE_TIMEOUT_MS: 300000,
      },
      promptExtra: "",
      reliableCounts: true,
      init: () => {},
      allItems: () => [],
      isUserItem: () => false,
      isAssistantItem: () => true,
      itemText: () => assistantReplyText,
      classifyText: () => assistantReplyText,
      assistantCount: () => 1,
      userCount: () => 1,
      lastAssistant: () => ({ dataset: {}, classList: { contains: () => false, add: () => {}, remove: () => {} }, querySelector: () => null, querySelectorAll: () => [] }),
      lastAssistantId: () => 2,
      readAssistant: () => ({ present: true, reply: assistantReplyText, thinking: "", item: {} }),
      streamLen: () => assistantReplyText.length,
      snapshot: () => ({ th: 0, rp: assistantReplyText.length }),
      getEditor: () => makeMockEl(),
      editorText: () => "",
      chatIsEmpty: () => false,
      isFreshChat: () => false,
      composerFrame: () => null,
      barAnchor: () => null,
      setInputLock: () => {},
      typeAndSend: async () => {},
      stopGeneration: () => {},
      isGenerating: () => genState,
      isBusyNow: () => genState,
      isHardGenerating: () => genState,
      enforceComposer: () => ({ ready: true }),
      ensureComposerReady: async () => ({ ready: true }),
      modeWarning: () => "",
      captchaPresent: () => false,
      overlayBlocking: () => false,
      turnHalted: () => false,
      findContinueBtn: () => null,
      clickContinueBtn: () => false,
      resolveBattle: () => { skipClicksInLoop++; return false; },
      scanError: () => null,
      isTooLongMsg: () => false,
      isBusyMsg: () => false,
      attachImages: async () => true,
      clearAttachments: () => {},
      conversationKey: () => "/c/test-uuid",
      installSendHooks: () => {},
      findToolBlockSpot: () => null,
    },
  };

  vm.runInNewContext(configCode + "\n" + parserCode + "\n" + instrumentedMain, mainSandbox);
  const { runTool, waitForResponse, A } = mainSandbox.__testHooks;
  A.bridge = { connected: true, mcpAlive: true, studio: true, servers: [{ id: "roblox", alive: true, tools: 1 }] };

  // 1. Offline skills work even when bridge is offline
  bridgeConnected = false;
  A.bridge.connected = false;
  const offList = await runTool({ tool: "list_offline_skills", arguments: {} });
  ok("runTool('list_offline_skills') works when bridge is offline", /Bundled offline skill packages/.test(offList));

  const offRead = await runTool({ tool: "read_offline_skill", arguments: { path: "stud_ui/SKILL.md" } });
  ok("runTool('read_offline_skill') reads text when bridge is offline", /# Stud UI/.test(offRead));

  // 2. Vision vs non-vision image handling on read_offline_skill
  supportsVision = true;
  A.pendingImages = null;
  const imgVis = await runTool({ tool: "read_offline_skill", arguments: { path: "test_image.png" } });
  ok("read_offline_skill attaches image on vision-enabled provider", /image is attached to THIS message/.test(imgVis) && A.pendingImages && A.pendingImages.length === 1);

  supportsVision = false;
  A.pendingImages = null;
  const imgNoVis = await runTool({ tool: "read_offline_skill", arguments: { path: "test_image.png" } });
  ok("read_offline_skill skips image attachment on non-vision provider", /skipped because vision/.test(imgNoVis) && A.pendingImages === null);
  supportsVision = true;

  // 3. Direct mode skips project tree execute_luau snapshot on list_commands; Agent mode keeps it
  bridgeConnected = true;
  A.bridge = { connected: true, mcpAlive: true, studio: true, servers: [{ id: "roblox", alive: true, tools: 1 }] };
  bgCalls = [];
  isAgent = false;
  const directCmds = await runTool({ tool: "list_commands", arguments: {} });
  const directSnapCalls = bgCalls.filter((c) => c.type === "call_tool" && c.name === "execute_luau");
  ok("Direct mode list_commands skips execute_luau project-tree snapshot & includes offline skills",
    directSnapCalls.length === 0 && /list_offline_skills/.test(directCmds) && /read_offline_skill/.test(directCmds));

  bgCalls = [];
  isAgent = true;
  const agentCmds = await runTool({ tool: "list_commands", arguments: {} });
  const agentSnapCalls = bgCalls.filter((c) => c.type === "call_tool" && c.name === "execute_luau");
  ok("Agent mode list_commands preserves execute_luau project-tree snapshot",
    agentSnapCalls.length === 1 && /LIVE ROBLOX STUDIO PLACE SNAPSHOT/.test(agentCmds));

  // 4. Direct mode 0.5s (500ms) settle timing after AI reply finishes
  isAgent = false;
  genState = false;
  A.sendToken = 1;
  skipClicksInLoop = 0;
  const t0 = Date.now();
  const resp = await waitForResponse(0);
  const elapsed = Date.now() - t0;
  ok("Direct mode waitForResponse resolves ~0.5s (500ms) after AI reply finishes",
    resp.kind === "tool" && elapsed >= 480 && elapsed <= 750, `elapsed=${elapsed}ms`);
  ok("Direct mode waitForResponse checks resolveBattle (Atla/Skip) while waiting", skipClicksInLoop > 0);

  // 5. Team Mode in core/main.js: background tab (document.hidden=true) does NOT park when A.team.enabled=true
  A.team.enabled = true;
  mainSandbox.document.hidden = true;
  A.sendToken = 1;
  const hiddenT0 = Date.now();
  const hiddenResp = await waitForResponse(0);
  const hiddenElapsed = Date.now() - hiddenT0;
  ok("Team Mode background tab (document.hidden=true) continues without parking when A.team.enabled=true",
    hiddenResp.kind === "tool" && hiddenElapsed < 800, `elapsed=${hiddenElapsed}ms`);
  mainSandbox.document.hidden = false;

  // 5b. Automatic UI ('stud_ui') and Modeling ('modelmaker' & 'referans_studio') Skill Enforcement
  A.loadedSkills.clear();
  A.lastUserPromptText = "Bana bir shop menüsü ve envanter UI yap";
  const uiEnforced = await runTool({
    tool: "execute_luau",
    arguments: { code: 'local sg = Instance.new("ScreenGui", game.StarterGui)' },
  });
  ok("When user requests UI and AI hasn't read 'stud_ui', runTool automatically loads & enforces StudUI skill",
    /OTOMATİK SKILL YÜKLENDİ.*stud_ui/i.test(uiEnforced) && /# Stud UI Rules/.test(uiEnforced) && A.loadedSkills.has("ui"));

  const uiSecondCall = await runTool({
    tool: "execute_luau",
    arguments: { code: 'local sg = Instance.new("ScreenGui", game.StarterGui)' },
  });
  ok("Once 'stud_ui' skill is loaded in session, subsequent execute_luau runs directly in Studio",
    /Output of 'execute_luau'/.test(uiSecondCall) && !/OTOMATİK SKILL YÜKLENDİ/.test(uiSecondCall));

  A.loadedSkills.clear();
  A.lastUserPromptText = "Bana detaylı bir 3D araba ve kule modeli yap";
  const modelEnforced = await runTool({
    tool: "execute_luau",
    arguments: { code: 'local m = Instance.new("Model", workspace); local p = Instance.new("Part", m)' },
  });
  ok("When user requests 3D Modeling and AI hasn't read 'modelmaker', runTool automatically loads & enforces ModelMaker skill",
    /OTOMATİK SKILL YÜKLENDİ.*modelmaker/i.test(modelEnforced) && /# 3D ModelMaker Rules/.test(modelEnforced) && A.loadedSkills.has("model"));

  // 6. Background Worker: Multi-AI Team Coordinator & Sequential FIFO Studio Tool Queue
  console.log("\n── Background Worker: Multi-Tab Team Coordinator & FIFO Studio Lock ──");
  let bgMessageListener = null;
  let dispatchedToTabs = [];
  let activeInFlightTools = 0;
  let maxConcurrentTools = 0;
  const executionOrder = [];

  class MockWebSocket {
    constructor() {
      this.readyState = 1; // OPEN
      setTimeout(() => {
        if (this.onopen) this.onopen();
      }, 0);
    }
    send(raw) {
      const payload = JSON.parse(raw);
      if (payload.type === "call_tool") {
        (async () => {
          activeInFlightTools++;
          if (activeInFlightTools > maxConcurrentTools) maxConcurrentTools = activeInFlightTools;
          executionOrder.push(`start:${payload.arguments.tag}`);
          await new Promise((r) => setTimeout(r, 40));
          executionOrder.push(`end:${payload.arguments.tag}`);
          activeInFlightTools--;
          if (this.onmessage) {
            this.onmessage({
              data: JSON.stringify({
                type: "tool_result",
                id: payload.id,
                ok: true,
                text: `Executed ${payload.arguments.tag}`,
              }),
            });
          }
        })();
      } else if (payload.type === "studio_status") {
        if (this.onmessage) {
          this.onmessage({ data: JSON.stringify({ type: "studio_status", id: payload.id, studio: true }) });
        }
      }
    }
    close() {}
  }
  MockWebSocket.OPEN = 1;
  MockWebSocket.CONNECTING = 0;

  const bgSandbox = {
    console: { log: () => {}, warn: () => {}, error: console.error },
    setTimeout,
    clearTimeout,
    setInterval: () => 1,
    clearInterval: () => {},
    Uint8Array,
    ArrayBuffer,
    String,
    Number,
    Boolean,
    Object,
    Array,
    Map,
    Set,
    Promise,
    Date,
    Math,
    JSON,
    RegExp,
    Error,
    WebSocket: MockWebSocket,
    btoa: (str) => Buffer.from(str, "binary").toString("base64"),
    fetch: async () => ({ ok: true, json: async () => ({ ok: true }) }),
    AbortController: class {
      constructor() { this.signal = {}; }
      abort() {}
    },
    chrome: {
      runtime: {
        getURL: (p) => p,
        sendMessage: () => Promise.resolve(),
        onInstalled: { addListener: () => {} },
        onStartup: { addListener: () => {} },
        onMessage: { addListener: (fn) => { bgMessageListener = fn; } },
      },
      tabs: {
        onRemoved: { addListener: () => {} },
        query: (_q, cb) => cb && cb([
          { id: 101, url: "https://arena.ai/text/direct", title: "Tab 1" },
          { id: 102, url: "https://arena.ai/text/direct", title: "Tab 2" },
          { id: 103, url: "https://arena.ai/text/direct", title: "Tab 3" },
          { id: 104, url: "https://arena.ai/text/direct", title: "Tab 4" },
          { id: 105, url: "https://arena.ai/text/direct", title: "Tab 5" },
        ]),
        sendMessage: (tabId, msg, cb) => {
          if (msg && msg.type === "zs-team-run-task") {
            dispatchedToTabs.push({ tabId, task: msg.task, member: msg.member });
          }
          if (cb) cb({ ok: true });
          return Promise.resolve({ ok: true });
        },
      },
      action: { setBadgeText: () => {}, setBadgeBackgroundColor: () => {} },
    },
  };

  vm.runInNewContext(fs.readFileSync(path.join(ROOT, "background.js"), "utf8"), bgSandbox);
  await new Promise((r) => setTimeout(r, 15));

  function callBgFromTab(tabId, msg) {
    return new Promise((resolve) => {
      bgMessageListener(msg, { tab: { id: tabId, title: `Tab ${tabId}` } }, resolve);
    });
  }

  // Register 5 tabs in AUTO role mode (unlimited tabs):
  // Tab 101 (gpt-6.1-terra-low -> GT1), Tab 102 (claude-sonnet-5-5-high -> SH1),
  // Tab 103 (gpt-6-luna-max -> GL1), Tab 104 (gpt-6-luna-max -> GL2), Tab 105 (claude-sonnet-5-5-high -> SH2)
  const r1 = await callBgFromTab(101, { type: "team_register", enabled: true, provider: "Arena", modelName: "gpt-6.1-terra-low", roleMode: "auto" });
  const r2 = await callBgFromTab(102, { type: "team_register", enabled: true, provider: "Arena", modelName: "claude-sonnet-5-5-high", roleMode: "auto" });
  const r3 = await callBgFromTab(103, { type: "team_register", enabled: true, provider: "Arena", modelName: "gpt-6-luna-max", roleMode: "auto" });
  const r4 = await callBgFromTab(104, { type: "team_register", enabled: true, provider: "Arena", modelName: "gpt-6-luna-max", roleMode: "auto" });
  const r5 = await callBgFromTab(105, { type: "team_register", enabled: true, provider: "Arena", modelName: "claude-sonnet-5-5-high", roleMode: "auto" });

  ok("5+ tabs registered with model-based Agent IDs (GT1, SH1, GL1, GL2, SH2)",
    r1.member.agentId === "GT1" &&
    r2.member.agentId === "SH1" &&
    r3.member.agentId === "GL1" &&
    r4.member.agentId === "GL2" &&
    r5.member.agentId === "SH2",
    `got ${r1.member.agentId}, ${r2.member.agentId}, ${r3.member.agentId}, ${r4.member.agentId}, ${r5.member.agentId}`);

  const st = await callBgFromTab(101, { type: "team_status" });
  ok("team_status lists all 5 connected tabs and their model-based IDs (GT1, SH1, GL1, GL2, SH2)",
    st.state.members.length === 5 &&
    /GT1/.test(st.text) && /SH1/.test(st.text) && /GL1/.test(st.text) && /GL2/.test(st.text) && /SH2/.test(st.text));

  const autoLeader = st.state.members.find((m) => m.isLeader);
  const workerRoles = st.state.members.filter((m) => !m.isLeader).map((m) => m.role);
  ok("Auto role assignment picks strongest model (claude-sonnet-5-5-high) as Leader and gives distinct specialist roles to all 4 workers",
    autoLeader && /sonnet/i.test(autoLeader.modelName) && new Set(workerRoles).size === 4,
    `leader=${autoLeader && autoLeader.agentId} (${autoLeader && autoLeader.modelName}), workers=${workerRoles.join(",")}`);

  // Test manual Leader override via team_set_member_role
  const manualRes = await callBgFromTab(101, { type: "team_set_member_role", targetTabId: 101, role: "leader", roleMode: "manual" });
  const manualLeader = manualRes.state.members.find((m) => m.isLeader);
  ok("Manual role selection sets Tab 101 (GT1 · gpt-6.1-terra-low) as Leader and rebalances remaining 4 tabs",
    manualLeader && manualLeader.tabId === 101 && manualLeader.agentId === "GT1" && manualLeader.roleMode === "manual");

  // Test team_auto_assign_roles returning all tabs to automatic model-based role distribution
  const reAutoRes = await callBgFromTab(102, { type: "team_auto_assign_roles" });
  const reAutoLeader = reAutoRes.state.members.find((m) => m.isLeader);
  ok("team_auto_assign_roles restores automatic model-based role distribution (SH1 as Leader)",
    reAutoLeader && reAutoLeader.tabId === 102 && reAutoLeader.agentId === "SH1");

  // Test FIFO Studio Tool Lock: 3 tabs call execute_luau at the exact same instant!
  const [c1, c2, c3] = await Promise.all([
    callBgFromTab(101, { type: "call_tool", name: "execute_luau", arguments: { tag: "GT1_terra" } }),
    callBgFromTab(102, { type: "call_tool", name: "execute_luau", arguments: { tag: "SH1_sonnet" } }),
    callBgFromTab(103, { type: "call_tool", name: "execute_luau", arguments: { tag: "GL1_luna" } }),
  ]);
  ok("Concurrent Studio tool calls from multiple tabs are serialized strictly one-by-one (maxConcurrentTools === 1)",
    maxConcurrentTools === 1 && c1.ok && c2.ok && c3.ok &&
    executionOrder.join(",") === "start:GT1_terra,end:GT1_terra,start:SH1_sonnet,end:SH1_sonnet,start:GL1_luna,end:GL1_luna",
    `order=${executionOrder.join(",")}`);

  // Test Leader (Tab 102, SH1) assigning tasks by model-based ID (GL1, GL2, GT1) with wait:true
  dispatchedToTabs = [];
  const assignPromise = callBgFromTab(102, {
    type: "team_assign_task",
    arguments: {
      wait: true,
      tasks: [
        { target: "GL1", title: "Build Shop UI", instructions: "Create StarterGui.ShopGui using StudUI" },
        { target: "GT1", title: "Build Shop 3D Building", instructions: "Create Workspace.ShopBuilding" },
        { target: "GL2", title: "Build Shop Animations", instructions: "Create ReplicatedStorage.ShopAnim" },
      ],
    },
  });

  // Give pumpWorkerQueues a tick to dispatch zs-team-run-task to Tab 101 (GT1), Tab 103 (GL1), Tab 104 (GL2)
  await new Promise((r) => setTimeout(r, 30));
  const dispatchedTabIds = dispatchedToTabs.map((d) => d.tabId).sort();
  ok("Leader's team_assign_task dispatches tasks by model-based IDs to GT1 (101), GL1 (103), and GL2 (104)",
    dispatchedToTabs.length === 3 &&
    dispatchedTabIds[0] === 101 &&
    dispatchedTabIds[1] === 103 &&
    dispatchedTabIds[2] === 104);

  // Worker tabs complete their tasks
  for (const d of dispatchedToTabs) {
    const resMsg =
      d.tabId === 103 ? "Created StarterGui.ShopGui with StudUI" :
      d.tabId === 101 ? "Created Workspace.ShopBuilding model" :
      "Created ReplicatedStorage.ShopAnim";
    await callBgFromTab(d.tabId, { type: "team_complete_task", arguments: { task_id: d.task.id, result: resMsg } });
  }

  const assignRes = await assignPromise;
  ok("Leader's waiting team_assign_task resolves with all 3 worker tabs' completion summaries",
    assignRes.ok &&
    /Created StarterGui\.ShopGui/.test(assignRes.text) &&
    /Created Workspace\.ShopBuilding/.test(assignRes.text) &&
    /Created ReplicatedStorage\.ShopAnim/.test(assignRes.text));

  // Test team_pull_updates so each tab sees what teammates did
  const pull1 = await callBgFromTab(101, { type: "team_pull_updates", sinceId: 0 });
  ok("team_pull_updates returns shared Studio tool actions and task completions from teammates",
    pull1.ok && pull1.updates.length >= 4);

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
