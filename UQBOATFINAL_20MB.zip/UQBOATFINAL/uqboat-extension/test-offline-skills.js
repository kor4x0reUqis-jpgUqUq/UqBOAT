// Automated verification for bundled offline skills in background.js
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const crypto = require("crypto");

const ROOT = __dirname;
let pass = 0, fail = 0;
function ok(name, cond, detail = "") {
  if (cond) { pass++; console.log("  ✓", name); }
  else { fail++; console.error("  ✗", name, detail); }
}

(async () => {
  console.log("── Offline skills index & SHA-256 verification ──");
  const idxPath = path.join(ROOT, "skills", "index.json");
  ok("skills/index.json exists", fs.existsSync(idxPath));
  const idx = JSON.parse(fs.readFileSync(idxPath, "utf8"));
  ok("total indexed skill files === 301", idx.totalFiles === 301 && idx.files.length === 301, `got ${idx.files.length}`);

  let hashMatches = 0;
  for (const f of idx.files) {
    const full = path.join(ROOT, "skills", f.path);
    if (!fs.existsSync(full)) continue;
    const buf = fs.readFileSync(full);
    const sha = crypto.createHash("sha256").update(buf).digest("hex");
    if (sha === f.sha256 && buf.length === f.size) hashMatches++;
  }
  ok("all 301 skill files match recorded size & SHA-256", hashMatches === 301, `matched ${hashMatches}/301`);

  console.log("\n── Service worker offline skill handlers (background.js) ──");
  let messageListener = null;
  const sandbox = {
    console: { log: () => {}, warn: () => {}, error: console.error },
    setTimeout,
    clearTimeout,
    setInterval: () => 1,
    clearInterval: () => {},
    btoa: (str) => Buffer.from(str, "binary").toString("base64"),
    atob: (b64) => Buffer.from(b64, "base64").toString("binary"),
    Uint8Array,
    WebSocket: function () {
      this.readyState = 3;
      this.close = () => {};
    },
    fetch: async (url) => {
      const rel = url.replace(/^chrome-extension:\/\/test-id\//, "");
      const full = path.join(ROOT, rel);
      if (!fs.existsSync(full)) return { ok: false, status: 404 };
      const buf = fs.readFileSync(full);
      return {
        ok: true,
        status: 200,
        json: async () => JSON.parse(buf.toString("utf8")),
        text: async () => buf.toString("utf8"),
        arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength),
      };
    },
    chrome: {
      runtime: {
        getURL: (p) => `chrome-extension://test-id/${p.replace(/^\/+/, "")}`,
        sendMessage: () => Promise.resolve(),
        onMessage: { addListener: (fn) => { messageListener = fn; } },
        onStartup: { addListener: () => {} },
        onInstalled: { addListener: () => {} },
      },
      tabs: { query: (_q, cb) => cb && cb([]) },
    },
  };
  sandbox.WebSocket.OPEN = 1;
  sandbox.WebSocket.CONNECTING = 0;

  vm.runInNewContext(fs.readFileSync(path.join(ROOT, "background.js"), "utf8"), sandbox);
  ok("background.js registered runtime.onMessage listener", typeof messageListener === "function");

  function callBg(msg) {
    return new Promise((resolve) => {
      messageListener(msg, {}, (resp) => resolve(resp));
    });
  }

  const listAll = await callBg({ type: "list_offline_skills", arguments: {} });
  ok("list_offline_skills succeeds when bridge is offline", listAll && listAll.ok && listAll.totalFiles === 301);

  const listStud = await callBg({ type: "list_offline_skills", arguments: { skill: "stud_ui", query: "StudUI" } });
  ok("list_offline_skills filters by skill and query", listStud && listStud.ok && listStud.matchedCount >= 1);

  // Verify paginated reassembly of the 3 SKILL.md files + StudUI.luau, StudMotion.luau, CheckUIIcons.luau
  const targets = [
    "modelmaker/sonskills/SKILL.md",
    "referans_studio/sonskills/SKILL.md",
    "stud_ui/SKILL.md",
    "stud_ui/src/StudUI.luau",
    "stud_ui/src/StudMotion.luau",
    "stud_ui/src/CheckUIIcons.luau",
  ];
  for (const rel of targets) {
    const orig = fs.readFileSync(path.join(ROOT, "skills", rel), "utf8");
    let offset = 0;
    let combined = "";
    let pages = 0;
    while (true) {
      const r = await callBg({ type: "read_offline_skill", arguments: { path: rel, offset, limit: 4096 } });
      if (!r || !r.ok) { combined = "__ERR__"; break; }
      combined += r.chunk;
      pages++;
      if (!r.hasMore) break;
      offset = r.nextOffset;
    }
    ok(`paginated read matches original for ${rel} (${pages} page(s))`, combined === orig, `len ${combined.length} vs ${orig.length}`);
  }

  // Missing file & path traversal checks
  const missing = await callBg({ type: "read_offline_skill", arguments: { path: "stud_ui/DOES_NOT_EXIST.luau" } });
  ok("missing skill file returns ok:false", missing && missing.ok === false && /not found/i.test(missing.error || ""));

  const traversal = await callBg({ type: "read_offline_skill", arguments: { path: "../manifest.json" } });
  ok("path traversal ../ is rejected", traversal && traversal.ok === false && /forbidden|traversal/i.test(traversal.error || ""));

  // Image read check (PNG & JPG)
  const pngTarget = "modelmaker/sonskills/examples/olumsuz_gorsel_kanit/image-1.png";
  const pngOrigB64 = fs.readFileSync(path.join(ROOT, "skills", pngTarget)).toString("base64");
  const pngRes = await callBg({ type: "read_offline_skill", arguments: { path: pngTarget } });
  ok("PNG skill image returns base64 image payload matching bytes",
    pngRes && pngRes.ok && pngRes.images && pngRes.images.length === 1 &&
    pngRes.images[0].mimeType === "image/png" && pngRes.images[0].data === pngOrigB64);

  const jpgTarget = "stud_ui/assets/screenshots/01-hud-overview.jpg";
  const jpgOrigB64 = fs.readFileSync(path.join(ROOT, "skills", jpgTarget)).toString("base64");
  const jpgRes = await callBg({ type: "read_offline_skill", arguments: { path: jpgTarget } });
  ok("JPG skill image returns base64 image payload matching bytes",
    jpgRes && jpgRes.ok && jpgRes.images && jpgRes.images.length === 1 &&
    jpgRes.images[0].mimeType === "image/jpeg" && jpgRes.images[0].data === jpgOrigB64);

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
