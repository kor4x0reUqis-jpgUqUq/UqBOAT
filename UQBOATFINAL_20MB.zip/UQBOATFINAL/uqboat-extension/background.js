// SPDX-License-Identifier: GPL-3.0-or-later
// background.js - service worker.
// Owns ONE resilient WebSocket to the local bridge (ws://127.0.0.1:PORT).
// Keeping the socket here (not in the content script) avoids https→ws mixed
// content issues and centralises reconnect / timeout logic.
//
// Contract with content.js: every sendMessage ALWAYS gets a response object,
// even when the bridge is offline. The agentic loop must never hang waiting.

const PORT = 17613;
const URL = `ws://127.0.0.1:${PORT}`;

// Chat sites where a UqBOAT provider content script runs. Status pushes go
// to every tab matching these. Add the new provider's URL pattern here (and in
// manifest.json content_scripts + host_permissions) when integrating another AI.
const PROVIDER_URLS = [
  "https://chat.deepseek.com/*",
  "https://chatgpt.com/*",
  "https://chat.openai.com/*",
  "https://gemini.google.com/*",
  "https://www.kimi.ai/*",
  "https://kimi.ai/*",
  "https://chat.z.ai/*",
  "https://chat.qwen.ai/*",
  "https://arena.ai/*",
  "https://*.arena.ai/*",
  "https://lmarena.ai/*",
  "https://*.lmarena.ai/*",
  "https://www.meta.ai/*",
  "https://meta.ai/*",
];

const RECONNECT_MIN = 500;
const RECONNECT_MAX = 2500;
const HEARTBEAT_MS = 8000;
// If no message (incl. pong) arrives within this window while we believe we're
// connected, the socket is half-open: force a reconnect instead of letting
// pending requests slowly time out.
const STALE_SOCKET_MS = 25000;
const REQUEST_TIMEOUT_DEFAULT = 130000; // a bit above the 120s tool timeout

let ws = null;
let connected = false;
let reconnectDelay = RECONNECT_MIN;
let reconnectTimer = null;
let heartbeatTimer = null;
let lastMessageAt = 0; // timestamp of the last frame received from the bridge
let nextId = 1;
const pending = new Map(); // id -> {resolve, timer}
let toolsCache = [];
let mcpAlive = false;
let serversCache = [];
// true/false = a PLACE is loaded and usable in Roblox Studio; null = unknown.
// The MCP process stays alive when Studio is closed or its MCP option is off,
// so this is probed separately (bridge "studio_status").
let studioConnected = null;
// true/false = a Roblox Studio app is connected to the MCP server at all; null =
// unknown. studioApp=true with studioConnected=false means "Studio open but no
// place"; studioApp=false means "Studio closed OR its MCP option disabled".
let studioApp = null;
// true/false = a Roblox Studio WINDOW/PROCESS exists on this machine (checked
// bridge-side via tasklist); null = unknown/old bridge. Distinguishes the two
// studioApp=false sub-cases the UI must word differently: Studio genuinely not
// launched ("open Roblox Studio") vs Studio OPEN but its MCP plugin never
// registered with the bridge - the documented fix for the latter is opening
// Assistant Settings > MCP Servers inside Studio (validated live 3x), which
// "open Roblox Studio" wording completely fails to convey.
let studioProc = null;

function log(...a) {
  console.log("[zs-bg]", ...a);
}

// ── WebSocket lifecycle ─────────────────────────────────────────────────
function connect() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }
  clearTimeout(reconnectTimer);
  try {
    ws = new WebSocket(URL);
  } catch (e) {
    log("WebSocket ctor failed", e);
    scheduleReconnect();
    return;
  }

  ws.onopen = () => {
    connected = true;
    reconnectDelay = RECONNECT_MIN;
    lastMessageAt = Date.now();
    log("connected to bridge");
    startHeartbeat();
    broadcastStatus();
  };

  ws.onmessage = (ev) => {
    lastMessageAt = Date.now();
    let msg;
    try {
      msg = JSON.parse(ev.data);
    } catch {
      return;
    }
    handleBridgeMessage(msg);
  };

  ws.onclose = () => {
    connected = false;
    mcpAlive = false;
    studioConnected = null;
    studioApp = null;
    studioProc = null;
    serversCache = [];
    stopHeartbeat();
    failAllPending("bridge connection closed");
    broadcastStatus();
    scheduleReconnect();
  };

  ws.onerror = () => {
    // onclose will follow; nothing to do here but avoid an unhandled error.
    try { ws.close(); } catch {}
  };
}

function scheduleReconnect() {
  clearTimeout(reconnectTimer);
  reconnectTimer = setTimeout(connect, reconnectDelay);
  reconnectDelay = Math.min(reconnectDelay * 1.7, RECONNECT_MAX);
}

function startHeartbeat() {
  stopHeartbeat();
  heartbeatTimer = setInterval(() => {
    if (connected) {
      // Half-open socket: the WS still reports OPEN but nothing comes through.
      // The pong (and every other frame) refreshes lastMessageAt; if it has
      // gone stale, drop the dead socket so onclose triggers a reconnect.
      if (lastMessageAt && Date.now() - lastMessageAt > STALE_SOCKET_MS) {
        log("socket stale, forcing reconnect");
        try { ws.close(); } catch {}
        return;
      }
      // Keeps the MV3 service worker alive AND detects a half-open socket.
      send({ type: "ping" }).catch(() => {});
      refreshStudioStatus();
    }
  }, HEARTBEAT_MS);
}

function stopHeartbeat() {
  clearInterval(heartbeatTimer);
  heartbeatTimer = null;
}

// Resolve once the socket is OPEN, or false after `timeout` ms.
function waitForConnection(timeout = 8000) {
  return new Promise((resolve) => {
    if (connected && ws && ws.readyState === WebSocket.OPEN) return resolve(true);
    connect(); // nudge a (re)connection - important after a worker wake-up
    const t0 = Date.now();
    const iv = setInterval(() => {
      if (connected && ws && ws.readyState === WebSocket.OPEN) {
        clearInterval(iv);
        resolve(true);
      } else if (Date.now() - t0 > timeout) {
        clearInterval(iv);
        resolve(false);
      }
    }, 100);
  });
}

// ── request/response over the socket ────────────────────────────────────
async function send(obj, timeout = REQUEST_TIMEOUT_DEFAULT) {
  // The MV3 service worker can be suspended; the first message after a wake-up
  // arrives before the socket has re-opened. Wait for it instead of failing -
  // otherwise Kimi wrongly hears "bridge offline".
  if (!connected || !ws || ws.readyState !== WebSocket.OPEN) {
    await waitForConnection(8000);
  }
  return new Promise((resolve) => {
    if (!connected || !ws || ws.readyState !== WebSocket.OPEN) {
      resolve({ ok: false, kind: "disconnected", error: "bridge not connected" });
      return;
    }
    const id = nextId++;
    const payload = { ...obj, id };
    const timer = setTimeout(() => {
      if (pending.has(id)) {
        pending.delete(id);
        resolve({ ok: false, kind: "timeout", error: "bridge did not respond in time" });
      }
    }, timeout);
    pending.set(id, { resolve, timer });
    try {
      ws.send(JSON.stringify(payload));
    } catch (e) {
      clearTimeout(timer);
      pending.delete(id);
      resolve({ ok: false, kind: "disconnected", error: String(e) });
    }
  });
}

// Ask the bridge whether a Roblox Studio instance is actually connected to the
// MCP server. Broadcasts only on change so the UI updates promptly but quietly.
let studioProbing = false;
async function refreshStudioStatus() {
  if (studioProbing || !connected) return;
  studioProbing = true;
  try {
    const r = await send({ type: "studio_status" }, 12000);
    const v = r && r.ok && typeof r.studio === "boolean" ? r.studio : null;
    if (v !== studioConnected) {
      studioConnected = v;
      broadcastStatus();
    }
  } finally {
    studioProbing = false;
  }
}

function handleBridgeMessage(msg) {
  if ("studio" in msg && (typeof msg.studio === "boolean" || msg.studio === null)) {
    studioConnected = msg.studio;
  }
  if ("studio_app" in msg && (typeof msg.studio_app === "boolean" || msg.studio_app === null)) {
    studioApp = msg.studio_app;
  }
  if ("studio_proc" in msg && (typeof msg.studio_proc === "boolean" || msg.studio_proc === null)) {
    studioProc = msg.studio_proc;
  }
  if (msg.type === "studio_status") {
    resolvePending(msg.id, { ok: true, studio: studioConnected });
    broadcastStatus();
    return;
  }
  if (msg.type === "connected") {
    mcpAlive = !!msg.mcp_alive;
    if (Array.isArray(msg.tools)) toolsCache = msg.tools;
    if (Array.isArray(msg.servers)) serversCache = msg.servers;
    broadcastStatus();
    return;
  }
  if (msg.type === "pong") {
    resolvePending(msg.id, { ok: true });
    return;
  }
  if (msg.type === "tools") {
    if (Array.isArray(msg.tools)) toolsCache = msg.tools;
    if (Array.isArray(msg.servers)) serversCache = msg.servers;
    mcpAlive = !!msg.mcp_alive;
    resolvePending(msg.id, { ok: true, tools: toolsCache });
    broadcastStatus();
    return;
  }
  if (msg.type === "tool_result") {
    resolvePending(msg.id, msg.ok
      ? { ok: true, text: msg.text, images: msg.images || [] }
      : { ok: false, kind: msg.kind, error: msg.error });
    return;
  }
  if (msg.type === "mcp_status") {
    mcpAlive = !!msg.alive;
    if (Array.isArray(msg.tools)) toolsCache = msg.tools;
    if (Array.isArray(msg.servers)) serversCache = msg.servers;
    resolvePending(msg.id, { ok: !!msg.ok, alive: msg.alive, error: msg.error });
    broadcastStatus();
    return;
  }
  if (msg.type === "server_changed") {
    // The bridge acks, then restarts itself to reload config.json. The socket
    // will drop right after this - the content script shows a spinner until the
    // reconnect lands and a fresh status arrives.
    resolvePending(msg.id, { ok: !!msg.ok, error: msg.error, restarting: !!msg.restarting });
    return;
  }
  if (msg.type === "error") {
    resolvePending(msg.id, { ok: false, error: msg.error });
    return;
  }
}

function resolvePending(id, value) {
  const p = pending.get(id);
  if (!p) return;
  clearTimeout(p.timer);
  pending.delete(id);
  p.resolve(value);
}

function failAllPending(reason) {
  for (const [, p] of pending) {
    clearTimeout(p.timer);
    p.resolve({ ok: false, kind: "disconnected", error: reason });
  }
  pending.clear();
}

// ── status push to any open DeepSeek tab + popup ─────────────────────────
function statusObj() {
  return { type: "zs-status", connected, mcpAlive, studio: studioConnected, studioApp, studioProc, tools: toolsCache.length, servers: serversCache };
}

function broadcastStatus() {
  chrome.runtime.sendMessage(statusObj()).catch(() => {});
  chrome.tabs.query({ url: PROVIDER_URLS }, (tabs) => {
    for (const t of tabs) chrome.tabs.sendMessage(t.id, statusObj()).catch(() => {});
  });
}

// ── Offline bundled skills (read-only inside extension, no Bridge/GitHub needed) ──
let offlineSkillsIndex = null;
let lastKnownStudioId = null;
const OFFLINE_SKILL_ALIASES = {
  modelmaker: "modelmaker/sonskills/SKILL.md",
  model: "modelmaker/sonskills/SKILL.md",
  "modelmaker/SKILL.md": "modelmaker/sonskills/SKILL.md",
  referans_studio: "referans_studio/sonskills/SKILL.md",
  referans: "referans_studio/sonskills/SKILL.md",
  "referans_studio/SKILL.md": "referans_studio/sonskills/SKILL.md",
  "OKU_ONCE.html": "referans_studio/sonskills/OKU_ONCE.html",
  "HIZLI_BASLANGIC.md": "referans_studio/sonskills/HIZLI_BASLANGIC.md",
  "StudioKit.luau": "referans_studio/sonskills/tools/StudioKit.luau",
  "Math3.luau": "referans_studio/sonskills/tools/Math3.luau",
  "GeometriAraclari.luau": "modelmaker/sonskills/tools/GeometriAraclari.luau",
  "GuvenliCSG.luau": "referans_studio/sonskills/tools/GuvenliCSG.luau",
  "CameraGuard.luau": "referans_studio/sonskills/tools/CameraGuard.luau",
  "Acceptance.luau": "referans_studio/sonskills/tools/Acceptance.luau",
  "Depo_Iskele_Builder.luau": "referans_studio/sonskills/examples/Depo_Iskele_Builder.luau",
  "blue_roof_hut": "referans_studio/sonskills/training/positive_pairs/blue_roof_hut/Builder.luau",
  "red_gantry_container": "referans_studio/sonskills/training/positive_pairs/red_gantry_container/Builder.luau",
  "warehouse_interior": "referans_studio/sonskills/training/positive_pairs/warehouse_interior/Builder.luau",
  "yellow_crane_payload": "referans_studio/sonskills/training/positive_pairs/yellow_crane_payload/Builder.luau",
  stud_ui: "stud_ui/SKILL.md",
  ui: "stud_ui/SKILL.md",
  studui: "stud_ui/SKILL.md",
  "StudUI.luau": "stud_ui/src/StudUI.luau",
  "StudMotion.luau": "stud_ui/src/StudMotion.luau",
  "CheckUIIcons.luau": "stud_ui/src/CheckUIIcons.luau",
  "components.md": "stud_ui/references/components.md",
  "design-tokens.md": "stud_ui/references/design-tokens.md",
  "layouts-and-archetypes.md": "stud_ui/references/layouts-and-archetypes.md",
  "icons-and-assets.md": "stud_ui/references/icons-and-assets.md",
  "motion-and-sound.md": "stud_ui/references/motion-and-sound.md",
  "checklist.md": "stud_ui/references/checklist.md",
  "icon-catalog.md": "stud_ui/references/icon-catalog.md",
  "01_ShopWindow.luau": "stud_ui/examples/01_ShopWindow.luau",
  "02_Hud.luau": "stud_ui/examples/02_Hud.luau",
  "03_Rebirth.luau": "stud_ui/examples/03_Rebirth.luau",
  "04_DailyRewards.luau": "stud_ui/examples/04_DailyRewards.luau",
  "05_IndexWithTabs.luau": "stud_ui/examples/05_IndexWithTabs.luau",
  "06_MenuController.client.luau": "stud_ui/examples/06_MenuController.client.luau",
  vfx: "vfx_pack/SKILL.md",
  vfx_pack: "vfx_pack/SKILL.md",
  fx_pack: "vfx_pack/SKILL.md",
  "vfx/SKILL.md": "vfx_pack/SKILL.md",
  "UqVFXLibrary.luau": "vfx_pack/UqVFXLibrary.luau",
  "assestvfxx.txt": "modelmaker/sonskills/examples/inceleme_kaynaklari/assestvfxx.txt",
  assestvfxx: "modelmaker/sonskills/examples/inceleme_kaynaklari/assestvfxx.txt",
  html: "skills_rehberi.html",
  rehber: "skills_rehberi.html",
  "skills_rehberi.html": "skills_rehberi.html",
};

async function loadOfflineSkillsIndex() {
  if (offlineSkillsIndex) return offlineSkillsIndex;
  const url = chrome.runtime.getURL("skills/index.json");
  const resp = await fetch(url);
  if (!resp.ok) throw new Error(`Failed to load skills/index.json (${resp.status})`);
  offlineSkillsIndex = await resp.json();
  return offlineSkillsIndex;
}

function normalizeSkillPath(rawPath, rawSkill) {
  let p = String(rawPath || "").trim().replace(/\\/g, "/");
  const sk = String(rawSkill || "").trim().replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
  if (!p && sk) p = sk;
  if (!p) return { ok: false, error: "path parameter is required (e.g. \"stud_ui/SKILL.md\", \"modelmaker/sonskills/SKILL.md\", \"vfx_pack/SKILL.md\", or \"skills_rehberi.html\")." };
  if (/(?:^|\/)\.\.(?:\/|$)/.test(p) || p.includes("\0") || /^[a-zA-Z]:/.test(p)) {
    return { ok: false, kind: "invalid_path", error: `Invalid skill path "${rawPath}": path traversal outside skills/ is forbidden.` };
  }
  p = p.replace(/^\/+/, "");
  if (p.startsWith("skills/")) p = p.slice("skills/".length);
  if (OFFLINE_SKILL_ALIASES[p]) p = OFFLINE_SKILL_ALIASES[p];
  else if (OFFLINE_SKILL_ALIASES[p.toLowerCase()]) p = OFFLINE_SKILL_ALIASES[p.toLowerCase()];
  else if (sk && !p.startsWith(sk + "/") && (OFFLINE_SKILL_ALIASES[sk] || OFFLINE_SKILL_ALIASES[sk.toLowerCase()])) {
    const mapped = OFFLINE_SKILL_ALIASES[sk] || OFFLINE_SKILL_ALIASES[sk.toLowerCase()];
    const basePkg = mapped.split("/")[0];
    if (p.toLowerCase() === "skill.md") p = mapped;
    else if (!p.startsWith(basePkg + "/")) p = `${basePkg}/${p}`;
  }
  if (/(?:^|\/)\.\.(?:\/|$)/.test(p)) {
    return { ok: false, kind: "invalid_path", error: `Invalid skill path "${rawPath}": path traversal outside skills/ is forbidden.` };
  }
  return { ok: true, path: p };
}

function arrayBufferToBase64(buf) {
  const bytes = new Uint8Array(buf);
  let binary = "";
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

async function handleListOfflineSkills(args = {}) {
  try {
    const idx = await loadOfflineSkillsIndex();
    const pkgFilter = String(args.skill || args.package || args.category || "").trim().toLowerCase();
    const query = String(args.query || args.filter || args.path || "").trim().toLowerCase();
    const files = (idx.files || []).filter((f) => {
      const fPkg = String(f.package || "").toLowerCase();
      if (pkgFilter && fPkg !== pkgFilter && !f.path.toLowerCase().startsWith(pkgFilter)) return false;
      if (query && !f.path.toLowerCase().includes(query)) return false;
      return true;
    });
    const pkgLines = (idx.packages || []).map(
      (p) => `- ${p.id}: ${p.title}\n  Entry: ${p.entry} | HTML Section: ${p.html_section || "skills_rehberi.html"}\n  ${p.description || ""}`
    );
    const maxListed = 140;
    const shown = files.slice(0, maxListed).map((f) => `  - ${f.path} (${f.kind || f.type || "text"}, ${f.size} bytes)`);
    const moreNote = files.length > maxListed
      ? `\n  ... and ${files.length - maxListed} more files (pass "skill" or "query" to filter).`
      : "";
    const text =
      `Bundled offline skill packages (${(idx.packages || []).length} packages, ${(idx.files || []).length} total files):\n` +
      `${pkgLines.join("\n")}\n\n` +
      `Key files to read with read_offline_skill (or install into Studio with install_offline_skill):\n` +
      `  - skills_rehberi.html (Full HTML guide with all UI, Modeling & 263 VFX examples)\n` +
      `  - stud_ui/SKILL.md\n` +
      `  - stud_ui/src/StudUI.luau\n` +
      `  - stud_ui/src/StudMotion.luau\n` +
      `  - stud_ui/src/CheckUIIcons.luau\n` +
      `  - stud_ui/examples/01_ShopWindow.luau .. 06_MenuController.client.luau\n` +
      `  - modelmaker/sonskills/SKILL.md\n` +
      `  - referans_studio/sonskills/SKILL.md\n` +
      `  - vfx_pack/SKILL.md (Visually inspected & named 263 VFX Asset ID catalog)\n` +
      `  - vfx_pack/UqVFXLibrary.luau\n\n` +
      `Matching files (${files.length}):\n${shown.join("\n")}${moreNote}`;
    return {
      ok: true,
      text,
      packages: idx.packages || [],
      totalFiles: (idx.files || []).length,
      matchedCount: files.length,
      files: files.slice(0, maxListed),
    };
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
}

async function handleReadOfflineSkill(args = {}) {
  try {
    const idx = await loadOfflineSkillsIndex();
    const rawPath = args.path || args.file || args.file_path || args.target_file || args.name || args.query || "";
    const norm = normalizeSkillPath(rawPath, args.skill || args.package || args.category);
    if (!norm.ok) return norm;
    let relPath = norm.path;
    const files = idx.files || [];
    let entry = files.find((f) => f.path === relPath) ||
                files.find((f) => f.path.toLowerCase() === relPath.toLowerCase());
    if (!entry) {
      const lowerRel = relPath.toLowerCase();
      const suffixHits = files.filter(
        (f) => f.path.toLowerCase().endsWith("/" + lowerRel) || f.path.toLowerCase() === lowerRel
      );
      if (suffixHits.length >= 1) {
        entry = suffixHits[0];
        relPath = entry.path;
      } else {
        const baseToken = lowerRel.split("/").pop().replace(/\.(luau|lua|md|txt|html)$/, "");
        const fuzzyHits = files.filter((f) => f.path.toLowerCase().includes(baseToken));
        if (fuzzyHits.length === 1) {
          entry = fuzzyHits[0];
          relPath = entry.path;
        } else {
          const suggestions = fuzzyHits.slice(0, 8).map((f) => f.path);
          const hint = suggestions.length ? ` Did you mean: ${suggestions.join(", ")}?` : " Call list_offline_skills to see valid paths.";
          return { ok: false, kind: "not_found", error: `Offline skill file not found: "${rawPath}".${hint}` };
        }
      }
    } else {
      relPath = entry.path;
    }

    const url = chrome.runtime.getURL("skills/" + relPath);
    const entryKind = entry.kind || (/\.(png|jpg|jpeg|webp|gif)$/i.test(relPath) ? "image" : "text");
    if (entryKind === "image") {
      const resp = await fetch(url);
      if (!resp.ok) return { ok: false, error: `Failed to fetch skill image "${relPath}" (${resp.status})` };
      const buf = await resp.arrayBuffer();
      const b64 = arrayBufferToBase64(buf);
      const text =
        `Offline skill image: ${relPath} (${entry.mimeType || "image/png"}, ${entry.size} bytes, sha256=${entry.sha256})`;
      return {
        ok: true,
        kind: "image",
        path: relPath,
        mimeType: entry.mimeType || "image/png",
        size: entry.size,
        sha256: entry.sha256,
        text,
        images: [{ mimeType: entry.mimeType || "image/png", data: b64 }],
      };
    }

    if (entryKind !== "text") {
      return {
        ok: false,
        kind: "binary",
        error: `Offline skill file "${relPath}" is a binary file (${entry.size} bytes) and cannot be read as text.`,
      };
    }

    const resp = await fetch(url);
    if (!resp.ok) return { ok: false, error: `Failed to read offline skill "${relPath}" (${resp.status})` };
    let fullText = await resp.text();
    const rawOffset = Number(args.offset != null ? args.offset : 0);
    const offset = Number.isFinite(rawOffset) && rawOffset > 0 ? Math.floor(rawOffset) : 0;
    let attachedImages = [];

    // When the AI reads an entry SKILL.md (and raw_file !== true, offset === 0),
    // automatically install any corresponding Studio modules AND append the HTML-structured
    // references, tools, examples, and visual reference images so the AI sees 100% of the skill!
    if (!args.raw_file && offset === 0 && args.limit == null) {
      if (relPath === "stud_ui/SKILL.md") {
        const bundle = await buildAutoSkillBundle({ categories: ["stud_ui"] });
        if (bundle && bundle.ok && bundle.text) {
          fullText = bundle.text;
          attachedImages = bundle.images || [];
        }
      } else if (
        relPath === "modelmaker/sonskills/SKILL.md" ||
        relPath === "referans_studio/sonskills/SKILL.md" ||
        relPath === "referans_studio/sonskills/OKU_ONCE.html" ||
        relPath === "referans_studio/sonskills/HIZLI_BASLANGIC.md"
      ) {
        const bundle = await buildAutoSkillBundle({ categories: ["referans_studio"] });
        if (bundle && bundle.ok && bundle.text) {
          fullText = bundle.text;
          attachedImages = bundle.images || [];
        }
      } else if (relPath === "vfx_pack/SKILL.md" || relPath.endsWith("assestvfxx.txt")) {
        const bundle = await buildAutoSkillBundle({ categories: ["vfx_pack"] });
        if (bundle && bundle.ok && bundle.text) {
          fullText = bundle.text;
          attachedImages = bundle.images || [];
        }
      }
    }

    const totalLength = fullText.length;
    const rawLimit = Number(args.limit != null ? args.limit : (args.max_chars != null ? args.max_chars : 500000));
    const limit = Number.isFinite(rawLimit) && rawLimit > 0 ? Math.min(Math.max(Math.floor(rawLimit), 64), 600000) : 500000;
    const endOffset = Math.min(offset + limit, totalLength);
    const chunk = fullText.slice(offset, endOffset);
    const hasMore = endOffset < totalLength;
    const nextOffset = hasMore ? endOffset : null;
    const header =
      `File: ${relPath} (chars ${offset}..${endOffset} of ${totalLength}` +
      (hasMore ? `, hasMore=true, nextOffset=${nextOffset}` : `, complete`) +
      `)`;
    const footer = hasMore
      ? `\n\n[...more content available: call read_offline_skill with {"path": "${relPath}", "offset": ${nextOffset}, "limit": ${limit}} to continue reading...]`
      : "";
    return {
      ok: true,
      kind: "text",
      path: relPath,
      totalLength,
      offset,
      endOffset,
      hasMore,
      nextOffset,
      chunk,
      images: attachedImages,
      text: `${header}\n\n${chunk}${footer}`,
    };
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
}

async function fetchSkillTextSafe(relPath) {
  try {
    const r = await fetch(chrome.runtime.getURL("skills/" + relPath));
    if (!r.ok) return "";
    const txt = await r.text();
    if (relPath.endsWith(".html")) {
      return txt.replace(/data:image\/[a-zA-Z0-9+.-]+;base64,[A-Za-z0-9+/=\s]+/g, "referans_studio/sonskills/training/positive_pairs/overview.jpg");
    }
    return txt;
  } catch {
    return "";
  }
}

async function loadSkillImagesBundle(relPaths) {
  const out = [];
  for (const rp of relPaths || []) {
    try {
      const r = await fetch(chrome.runtime.getURL("skills/" + rp));
      if (!r.ok) continue;
      const buf = await r.arrayBuffer();
      const b64 = arrayBufferToBase64(buf);
      const ext = rp.split(".").pop().toLowerCase();
      const mimeType = ext === "png" ? "image/png" : ext === "webp" ? "image/webp" : "image/jpeg";
      out.push({
        mimeType,
        data: b64,
        name: rp.split("/").pop(),
        path: rp,
      });
    } catch {}
  }
  return out;
}

async function discoverActiveStudioId() {
  if (lastKnownStudioId) return lastKnownStudioId;
  if (!connected) return null;
  try {
    const r = await send({ type: "call_tool", name: "list_roblox_studios", arguments: {}, timeout: 8000 }, 10000);
    if (r && r.ok && r.text) {
      const m = String(r.text).match(/"studio_id"\s*:\s*"([^"]+)"|studio_id\s*[=:]\s*([A-Za-z0-9_-]+)/i);
      if (m) {
        lastKnownStudioId = m[1] || m[2];
        return lastKnownStudioId;
      }
    }
  } catch {}
  return null;
}

// Install full skill ModuleScripts (StudUI, StudMotion, CheckUIIcons, StudioKit, Math3,
// GeometriAraclari, GuvenliCSG, UqVFXLibrary) directly into game.ReplicatedStorage in
// Roblox Studio via the local bridge so the AI never hits chat truncation and can immediately
// `require(game.ReplicatedStorage.StudUI)` or `require(game.ReplicatedStorage.StudioKit)`.
async function installStudioModuleFromSkill(modName, relSkillPath, parentExpr = "game:GetService('ReplicatedStorage')") {
  const src = await fetchSkillTextSafe(relSkillPath);
  if (!src) {
    return { ok: false, error: `Could not read ${relSkillPath}` };
  }
  const studioId = await discoverActiveStudioId();
  const chunkSize = 32000;
  const totalChunks = Math.max(1, Math.ceil(src.length / chunkSize));
  for (let i = 0; i < totalChunks; i++) {
    const piece = src.slice(i * chunkSize, (i + 1) * chunkSize);
    const safePiece = piece.replace(/\]===\]/g, "]=== ]");
    const isFirst = i === 0;
    const luauCode = isFirst
      ? `local parent = ${parentExpr}\n` +
        `local mod = parent:FindFirstChild(${JSON.stringify(modName)})\n` +
        `if not mod or not mod:IsA("ModuleScript") then\n` +
        `  if mod then mod:Destroy() end\n` +
        `  mod = Instance.new("ModuleScript")\n` +
        `  mod.Name = ${JSON.stringify(modName)}\n` +
        `  mod.Parent = parent\n` +
        `end\n` +
        `mod.Source = [===[${safePiece}]===]\n` +
        `return "OK_INIT_" .. tostring(#mod.Source)`
      : `local parent = ${parentExpr}\n` +
        `local mod = parent:FindFirstChild(${JSON.stringify(modName)})\n` +
        `if not mod then error("Module missing: " .. ${JSON.stringify(modName)}) end\n` +
        `mod.Source = mod.Source .. [===[${safePiece}]===]\n` +
        `return "OK_APPEND_" .. tostring(#mod.Source)`;
    const callArgs = { code: luauCode, datamodel_type: "Edit" };
    if (studioId) callArgs.studio_id = studioId;
    const r = await enqueueStudioToolCall(() =>
      send({ type: "call_tool", name: "execute_luau", arguments: callArgs, timeout: 25000 }, 30000)
    );
    if (!r || !r.ok) {
      return { ok: false, error: (r && r.error) || `Failed to inject ${modName} chunk ${i + 1}/${totalChunks}` };
    }
  }
  return { ok: true, module: modName, bytes: src.length };
}

async function handleInstallOfflineSkill(args = {}) {
  const target = String(args.skill || args.package || args.category || args.name || "all").toLowerCase();
  const installed = [];
  const errors = [];
  if (!connected) {
    return {
      ok: false,
      error: "Bridge/Studio bağlı değil; modüller Studio bağlandığında otomatik kurulacak.",
    };
  }
  if (target === "all" || target === "ui" || target === "stud_ui" || target === "studui") {
    const r1 = await installStudioModuleFromSkill("StudUI", "stud_ui/src/StudUI.luau", "game:GetService('ReplicatedStorage')");
    if (r1.ok) installed.push(`ReplicatedStorage.StudUI (${r1.bytes} bytes)`);
    else errors.push(r1.error);

    const r2 = await installStudioModuleFromSkill("StudMotion", "stud_ui/src/StudMotion.luau", "game:GetService('ReplicatedStorage')");
    if (r2.ok) installed.push(`ReplicatedStorage.StudMotion (${r2.bytes} bytes)`);
    else errors.push(r2.error);

    const r3 = await installStudioModuleFromSkill("CheckUIIcons", "stud_ui/src/CheckUIIcons.luau", "game:GetService('ReplicatedStorage')");
    if (r3.ok) installed.push(`ReplicatedStorage.CheckUIIcons (${r3.bytes} bytes)`);
    else errors.push(r3.error);

    const exFolderExpr = "(function() local ss = game:GetService('ServerStorage'); local f = ss:FindFirstChild('StudExamples'); if not f then f = Instance.new('Folder'); f.Name = 'StudExamples'; f.Parent = ss end; return f end)()";
    const exampleModules = [
      ["ShopWindow", "stud_ui/examples/01_ShopWindow.luau"],
      ["Hud", "stud_ui/examples/02_Hud.luau"],
      ["Rebirth", "stud_ui/examples/03_Rebirth.luau"],
      ["DailyRewards", "stud_ui/examples/04_DailyRewards.luau"],
      ["IndexWithTabs", "stud_ui/examples/05_IndexWithTabs.luau"],
    ];
    for (const [mName, mPath] of exampleModules) {
      const rx = await installStudioModuleFromSkill(mName, mPath, exFolderExpr);
      if (rx.ok) installed.push(`ServerStorage.StudExamples.${mName} (${rx.bytes} bytes)`);
      else errors.push(rx.error);
    }
  }
  if (target === "all" || target === "model" || target === "modelmaker" || target === "referans_studio" || target === "referans") {
    const kitFolderExpr = "(function() local rs = game:GetService('ReplicatedStorage'); local f = rs:FindFirstChild('UqModelKit'); if not f then f = Instance.new('Folder'); f.Name = 'UqModelKit'; f.Parent = rs end; return f end)()";
    const modelTools = [
      ["StudioKit", "referans_studio/sonskills/tools/StudioKit.luau"],
      ["Math3", "referans_studio/sonskills/tools/Math3.luau"],
      ["GeometriAraclari", "modelmaker/sonskills/tools/GeometriAraclari.luau"],
      ["GuvenliCSG", "referans_studio/sonskills/tools/GuvenliCSG.luau"],
      ["CameraGuard", "referans_studio/sonskills/tools/CameraGuard.luau"],
      ["Acceptance", "referans_studio/sonskills/tools/Acceptance.luau"],
    ];
    for (const [mName, mPath] of modelTools) {
      const rm1 = await installStudioModuleFromSkill(mName, mPath, kitFolderExpr);
      await installStudioModuleFromSkill(mName, mPath, "game:GetService('ReplicatedStorage')");
      if (rm1.ok) installed.push(`ReplicatedStorage.${mName} & ReplicatedStorage.UqModelKit.${mName} (${rm1.bytes} bytes)`);
      else errors.push(rm1.error);
    }
  }
  if (target === "all" || target === "vfx" || target === "vfx_pack" || target === "fx_pack") {
    const rv = await installStudioModuleFromSkill("UqVFXLibrary", "vfx_pack/UqVFXLibrary.luau", "game:GetService('ReplicatedStorage')");
    if (rv.ok) installed.push(`ReplicatedStorage.UqVFXLibrary (${rv.bytes} bytes)`);
    else errors.push(rv.error);
  }
  return {
    ok: installed.length > 0 && errors.length === 0,
    installed,
    errors,
    text:
      installed.length > 0
        ? `Roblox Studio içine tam modüller ve örnekler kuruldu:\n- ${installed.join("\n- ")}\nArtık doğrudan require(game.ReplicatedStorage.StudUI), require(game.ReplicatedStorage.StudMotion), require(game.ReplicatedStorage.StudioKit), require(game.ReplicatedStorage.Math3), require(game.ReplicatedStorage.GeometriAraclari), require(game.ReplicatedStorage.GuvenliCSG) ve require(game.ReplicatedStorage.UqVFXLibrary) kullanabilirsin.`
        : `Modül kurulum hatası: ${errors.join("; ")}`,
  };
}

async function buildAutoSkillBundle(args = {}) {
  const cats = Array.isArray(args.categories)
    ? args.categories
    : [args.category || args.skill || "ui"];
  const blocks = [];
  const loaded = [];
  const installedModules = [];
  const bundleImages = [];

  for (const rawCat of cats) {
    const c = String(rawCat || "").toLowerCase();
    if (c === "ui" || c === "stud_ui" || c === "studui") {
      let studioInstallNote = "Not: `install_offline_skill` komutu ile `StudUI`, `StudMotion` ve `CheckUIIcons` modüllerini tek komutla `game.ReplicatedStorage` içine kurabilirsin.";
      if (connected) {
        try {
          const instRes = await handleInstallOfflineSkill({ skill: "stud_ui" });
          if (instRes && instRes.installed && instRes.installed.length) {
            installedModules.push(...instRes.installed);
            studioInstallNote = `OTOMATİK KURULUM TAMAMLANDI: ${instRes.installed.join(", ")} doğrudan Roblox Studio 'game.ReplicatedStorage' içine eksiksiz (100% tam kaynak kodlarıyla) yüklendi! Kodunda doğrudan \`local StudUI = require(game.ReplicatedStorage:WaitForChild("StudUI"))\` ve \`local StudMotion = require(game.ReplicatedStorage:WaitForChild("StudMotion"))\` olarak çağırabilirsin!`;
          }
        } catch {}
      }

      const [
        skillMd,
        compMd,
        tokensMd,
        layoutsMd,
        iconsMd,
        motionMd,
        checklistMd,
        screenshotsReadme,
        ex1,
        ex2,
        ex3,
        ex4,
        ex5,
        ex6,
        uiImgs,
      ] = await Promise.all([
        fetchSkillTextSafe("stud_ui/SKILL.md"),
        fetchSkillTextSafe("stud_ui/references/components.md"),
        fetchSkillTextSafe("stud_ui/references/design-tokens.md"),
        fetchSkillTextSafe("stud_ui/references/layouts-and-archetypes.md"),
        fetchSkillTextSafe("stud_ui/references/icons-and-assets.md"),
        fetchSkillTextSafe("stud_ui/references/motion-and-sound.md"),
        fetchSkillTextSafe("stud_ui/references/checklist.md"),
        fetchSkillTextSafe("stud_ui/assets/screenshots/README.md"),
        fetchSkillTextSafe("stud_ui/examples/01_ShopWindow.luau"),
        fetchSkillTextSafe("stud_ui/examples/02_Hud.luau"),
        fetchSkillTextSafe("stud_ui/examples/03_Rebirth.luau"),
        fetchSkillTextSafe("stud_ui/examples/04_DailyRewards.luau"),
        fetchSkillTextSafe("stud_ui/examples/05_IndexWithTabs.luau"),
        fetchSkillTextSafe("stud_ui/examples/06_MenuController.client.luau"),
        loadSkillImagesBundle([
          "stud_ui/assets/screenshots/01-hud-overview.jpg",
          "stud_ui/assets/screenshots/02-nest-shop-window.jpg",
          "stud_ui/assets/screenshots/21-validation-generated-hud-and-rebirth.jpg",
          "stud_ui/assets/screenshots/22-validation-generated-daily-and-index.jpg",
        ]),
      ]);
      bundleImages.push(...uiImgs);

      blocks.push(
        `<article class="uqboat-skill-html" id="stud-ui-skill" data-skill="stud_ui">\n` +
        `  <h2>[OTOMATİK YÜKLENEN SKILL (TAM HTML PAKETİ + 7 REFERANS + 6 ÖRNEK + 14 EKRAN GÖRÜNTÜSÜ): STUD UI (stud_ui)]</h2>\n` +
        `  <p><strong>ZORUNLU KURAL:</strong> Kullanıcı UI / Menü / HUD / Arayüz istediği için UqBOAT yerel <code>stud_ui</code> (Stud-UI-Clean-Roblox) paketinin tüm dosyalarını, referans belgelerini, örnek kodlarını ve görsellerini HTML formatında eksiksiz yükledi.</p>\n` +
        `  <p><strong>${studioInstallNote}</strong></p>\n` +
        `  <section data-file="stud_ui/SKILL.md">\n` +
        `    <h3>1. StudUI Ana Rehberi (stud_ui/SKILL.md)</h3>\n` +
        `    <pre><code>${skillMd}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-file="stud_ui/references/components.md">\n` +
        `    <h3>2. Bileşen API Referansı (stud_ui/references/components.md)</h3>\n` +
        `    <pre><code>${compMd}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-file="stud_ui/references/design-tokens.md">\n` +
        `    <h3>3. Renk Paleti, Tipografi ve Tasarım Tokenları (stud_ui/references/design-tokens.md)</h3>\n` +
        `    <pre><code>${tokensMd}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-file="stud_ui/references/layouts-and-archetypes.md">\n` +
        `    <h3>4. Ekran Arketipleri ve Yerleşim Şablonları (stud_ui/references/layouts-and-archetypes.md)</h3>\n` +
        `    <pre><code>${layoutsMd}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-file="stud_ui/references/icons-and-assets.md">\n` +
        `    <h3>5. İkonlar, Stud Dokuları ve Görsel Varlıklar (stud_ui/references/icons-and-assets.md)</h3>\n` +
        `    <pre><code>${iconsMd}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-file="stud_ui/references/motion-and-sound.md">\n` +
        `    <h3>6. StudMotion Animasyon ve Ses Rehberi (stud_ui/references/motion-and-sound.md)</h3>\n` +
        `    <pre><code>${motionMd}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-file="stud_ui/references/checklist.md">\n` +
        `    <h3>7. Kalite Kontrol Listesi (stud_ui/references/checklist.md)</h3>\n` +
        `    <pre><code>${checklistMd}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-file="stud_ui/assets/screenshots/README.md">\n` +
        `    <h3>8. Görsel Referans Ekran Görüntüleri Galerisi (14 Görsel + Ekteki Referans Fotoğraflar)</h3>\n` +
        `    <div class="img-gallery">\n` +
        `      <img src="stud_ui/assets/screenshots/01-hud-overview.jpg" alt="01-hud-overview.jpg" />\n` +
        `      <img src="stud_ui/assets/screenshots/02-nest-shop-window.jpg" alt="02-nest-shop-window.jpg" />\n` +
        `      <img src="stud_ui/assets/screenshots/06-daily-rewards.jpg" alt="06-daily-rewards.jpg" />\n` +
        `      <img src="stud_ui/assets/screenshots/07-rebirth.jpg" alt="07-rebirth.jpg" />\n` +
        `      <img src="stud_ui/assets/screenshots/20-validation-original-vs-generated-shop.jpg" alt="20-validation-original-vs-generated-shop.jpg" />\n` +
        `      <img src="stud_ui/assets/screenshots/21-validation-generated-hud-and-rebirth.jpg" alt="21-validation-generated-hud-and-rebirth.jpg" />\n` +
        `      <img src="stud_ui/assets/screenshots/22-validation-generated-daily-and-index.jpg" alt="22-validation-generated-daily-and-index.jpg" />\n` +
        `    </div>\n` +
        `    <pre><code>${screenshotsReadme}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-example="01_ShopWindow.luau">\n` +
        `    <h3>Örnek 1: stud_ui/examples/01_ShopWindow.luau (Sekmeli Mağaza Penceresi)</h3>\n` +
        `    <pre><code class="language-luau">${ex1}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-example="02_Hud.luau">\n` +
        `    <h3>Örnek 2: stud_ui/examples/02_Hud.luau (HUD, Para Gösterimi ve Aksiyon Butonları)</h3>\n` +
        `    <pre><code class="language-luau">${ex2}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-example="03_Rebirth.luau">\n` +
        `    <h3>Örnek 3: stud_ui/examples/03_Rebirth.luau (Rebirth Penceresi &amp; ProgressBar)</h3>\n` +
        `    <pre><code class="language-luau">${ex3}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-example="04_DailyRewards.luau">\n` +
        `    <h3>Örnek 4: stud_ui/examples/04_DailyRewards.luau (7 Günlük Ödül Gridi)</h3>\n` +
        `    <pre><code class="language-luau">${ex4}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-example="05_IndexWithTabs.luau">\n` +
        `    <h3>Örnek 5: stud_ui/examples/05_IndexWithTabs.luau (Kategori Sekmeli Pet/Eşya İndeksi)</h3>\n` +
        `    <pre><code class="language-luau">${ex5}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-example="06_MenuController.client.luau">\n` +
        `    <h3>Örnek 6: stud_ui/examples/06_MenuController.client.luau (Tüm Pencereleri ve HUD'ı Bağlayan Ana LocalScript)</h3>\n` +
        `    <pre><code class="language-luau">${ex6}</code></pre>\n` +
        `  </section>\n` +
        `</article>`
      );
      loaded.push("ui");
    } else if (c === "model" || c === "modelmaker" || c === "referans_studio" || c === "referans") {
      let modelInstallNote = "Not: `StudioKit`, `Math3`, `GeometriAraclari` ve `GuvenliCSG` modülleri `ReplicatedStorage` içine kurulabilir.";
      if (connected) {
        try {
          const instRes = await handleInstallOfflineSkill({ skill: "referans_studio" });
          if (instRes && instRes.installed && instRes.installed.length) {
            installedModules.push(...instRes.installed);
            modelInstallNote = `OTOMATİK KURULUM TAMAMLANDI: ${instRes.installed.join(", ")} doğrudan Roblox Studio 'game.ReplicatedStorage' içine yüklendi! Kodunda doğrudan \`local StudioKit = require(game.ReplicatedStorage.StudioKit)\`, \`local Math3 = require(game.ReplicatedStorage.Math3)\`, \`local GeometriAraclari = require(game.ReplicatedStorage.GeometriAraclari)\`, \`local GuvenliCSG = require(game.ReplicatedStorage.GuvenliCSG)\` olarak çağırabilirsin!`;
          }
        } catch {}
      }

      const [
        refSkillMd,
        refHizliMd,
        refOkuHtml,
        ref00,
        ref01,
        ref04,
        ref15,
        ref16,
        ref17,
        mmSkillMd,
        mmSozlesme,
        mmSiluet,
        studioKitLuau,
        math3Luau,
        geometriLuau,
        csgLuau,
        blueHutLuau,
        redGantryLuau,
        warehouseLuau,
        yellowCraneLuau,
        depoIskeleLuau,
        modelImgs,
      ] = await Promise.all([
        fetchSkillTextSafe("referans_studio/sonskills/SKILL.md"),
        fetchSkillTextSafe("referans_studio/sonskills/HIZLI_BASLANGIC.md"),
        fetchSkillTextSafe("referans_studio/sonskills/OKU_ONCE.html"),
        fetchSkillTextSafe("referans_studio/sonskills/references/00_son_sozlesme.md"),
        fetchSkillTextSafe("referans_studio/sonskills/references/01_stud_fizigi_ve_malzeme.md"),
        fetchSkillTextSafe("referans_studio/sonskills/references/04_parca_secim_matrisi.md"),
        fetchSkillTextSafe("referans_studio/sonskills/references/15_matematiksel_yuzeyler_ve_loft.md"),
        fetchSkillTextSafe("referans_studio/sonskills/references/16_editablemesh_rig_ve_animasyon.md"),
        fetchSkillTextSafe("referans_studio/sonskills/references/17_olumlu_eslestirmeler.md"),
        fetchSkillTextSafe("modelmaker/sonskills/SKILL.md"),
        fetchSkillTextSafe("modelmaker/sonskills/references/son_kullanici_sozlesmesi.md"),
        fetchSkillTextSafe("modelmaker/sonskills/references/siluet_anatomi_ve_detay_kapilari.md"),
        fetchSkillTextSafe("referans_studio/sonskills/tools/StudioKit.luau"),
        fetchSkillTextSafe("referans_studio/sonskills/tools/Math3.luau"),
        fetchSkillTextSafe("modelmaker/sonskills/tools/GeometriAraclari.luau"),
        fetchSkillTextSafe("referans_studio/sonskills/tools/GuvenliCSG.luau"),
        fetchSkillTextSafe("referans_studio/sonskills/training/positive_pairs/blue_roof_hut/Builder.luau"),
        fetchSkillTextSafe("referans_studio/sonskills/training/positive_pairs/red_gantry_container/Builder.luau"),
        fetchSkillTextSafe("referans_studio/sonskills/training/positive_pairs/warehouse_interior/Builder.luau"),
        fetchSkillTextSafe("referans_studio/sonskills/training/positive_pairs/yellow_crane_payload/Builder.luau"),
        fetchSkillTextSafe("referans_studio/sonskills/examples/Depo_Iskele_Builder.luau"),
        loadSkillImagesBundle([
          "referans_studio/sonskills/training/positive_pairs/overview.jpg",
          "referans_studio/sonskills/training/images/liman_studio_01.jpg",
          "referans_studio/sonskills/training/positive_pairs/blue_roof_hut/user_output_crop.jpg",
          "referans_studio/sonskills/training/positive_pairs/red_gantry_container/user_output_crop.jpg",
        ]),
      ]);
      bundleImages.push(...modelImgs);

      blocks.push(
        `<article class="uqboat-skill-html" id="modelmaker-skill" data-skill="modelmaker_referans_studio">\n` +
        `  <h2>[OTOMATİK YÜKLENEN SKILL (TAM HTML PAKETİ + STUDIOKIT/MATH3 ARAÇLARI + POZİTİF ÖRNEKLER + GÖRSELLER): 3D MODELLEME (referans_studio 4.1 &amp; modelmaker 3.0.1)]</h2>\n` +
        `  <p><strong>ZORUNLU KURAL:</strong> Kullanıcı 3D Modelleme / Yapı / Araç / Yaratık / Eşya istediği için UqBOAT yerel <code>ModelMakerSkills_4.1_ReferansStudio.zip</code> ve <code>ModelMakerSkills.zip</code> paketlerinin tamamını, Luau araçlarını (<code>StudioKit</code>, <code>Math3</code>, <code>GeometriAraclari</code>, <code>GuvenliCSG</code>), pozitif referans builder kodlarını ve görsellerini HTML formatında eksiksiz yükledi.</p>\n` +
        `  <p><strong>${modelInstallNote}</strong></p>\n` +
        `  <section data-file="referans_studio/sonskills/OKU_ONCE.html">\n` +
        `    <h3>1. Referans Studio 4.1 Görsel Özet &amp; OKU_ONCE.html</h3>\n` +
        `    <div class="img-gallery">\n` +
        `      <img src="referans_studio/sonskills/training/positive_pairs/overview.jpg" alt="positive_pairs/overview.jpg" />\n` +
        `      <img src="referans_studio/sonskills/training/images/liman_studio_01.jpg" alt="liman_studio_01.jpg" />\n` +
        `      <img src="referans_studio/sonskills/training/positive_pairs/blue_roof_hut/user_output_crop.jpg" alt="blue_roof_hut" />\n` +
        `      <img src="referans_studio/sonskills/training/positive_pairs/red_gantry_container/user_output_crop.jpg" alt="red_gantry_container" />\n` +
        `      <img src="referans_studio/sonskills/training/positive_pairs/warehouse_interior/user_output_crop.jpg" alt="warehouse_interior" />\n` +
        `      <img src="referans_studio/sonskills/training/positive_pairs/yellow_crane_payload/user_output_crop.jpg" alt="yellow_crane_payload" />\n` +
        `    </div>\n` +
        `    ${refOkuHtml}\n` +
        `  </section>\n` +
        `  <section data-file="referans_studio/sonskills/SKILL.md">\n` +
        `    <h3>2. Referans Studio 4.1 Ana Skill Rehberi (referans_studio/sonskills/SKILL.md)</h3>\n` +
        `    <pre><code>${refSkillMd}\n\n${refHizliMd}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-file="referans_studio/sonskills/references/00..17">\n` +
        `    <h3>3. Referans Studio 4.1 Mühendislik Sözleşmeleri (00, 01, 04, 15, 16, 17)</h3>\n` +
        `    <pre><code>${[ref00, ref01, ref04, ref15, ref16, ref17].join("\n\n---\n\n")}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-file="modelmaker/sonskills/SKILL.md">\n` +
        `    <h3>4. ModelMaker 3.0.1 Rehberi &amp; Silüet/Anatomi Kapıları</h3>\n` +
        `    <pre><code>${[mmSkillMd, mmSozlesme, mmSiluet].join("\n\n---\n\n")}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-example="StudioKit.luau">\n` +
        `    <h3>5. Hazır Araç 1: ReplicatedStorage.StudioKit (referans_studio/sonskills/tools/StudioKit.luau)</h3>\n` +
        `    <pre><code class="language-luau">${studioKitLuau}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-example="Math3.luau">\n` +
        `    <h3>6. Hazır Araç 2: ReplicatedStorage.Math3 (referans_studio/sonskills/tools/Math3.luau)</h3>\n` +
        `    <pre><code class="language-luau">${math3Luau}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-example="GeometriAraclari.luau">\n` +
        `    <h3>7. Hazır Araç 3: ReplicatedStorage.GeometriAraclari (modelmaker/sonskills/tools/GeometriAraclari.luau)</h3>\n` +
        `    <pre><code class="language-luau">${geometriLuau}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-example="GuvenliCSG.luau">\n` +
        `    <h3>8. Hazır Araç 4: ReplicatedStorage.GuvenliCSG (referans_studio/sonskills/tools/GuvenliCSG.luau)</h3>\n` +
        `    <pre><code class="language-luau">${csgLuau}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-example="PositivePairs_Builders.luau">\n` +
        `    <h3>9. Pozitif Eşleşme Örnek Builder Kodları (blue_roof_hut, red_gantry_container, warehouse_interior, yellow_crane_payload, Depo_Iskele_Builder)</h3>\n` +
        `    <pre><code class="language-luau">-- [1] blue_roof_hut/Builder.luau\n${blueHutLuau}\n\n-- [2] red_gantry_container/Builder.luau\n${redGantryLuau}\n\n-- [3] warehouse_interior/Builder.luau\n${warehouseLuau}\n\n-- [4] yellow_crane_payload/Builder.luau\n${yellowCraneLuau}\n\n-- [5] Depo_Iskele_Builder.luau\n${depoIskeleLuau}</code></pre>\n` +
        `  </section>\n` +
        `</article>`
      );
      loaded.push("model");
    } else if (c === "vfx" || c === "vfx_pack" || c === "fx_pack") {
      let vfxInstallNote = "Not: `install_offline_skill` komutu ile `UqVFXLibrary` modülünü `game.ReplicatedStorage` içine kurabilirsin.";
      if (connected) {
        try {
          const instRes = await handleInstallOfflineSkill({ skill: "vfx_pack" });
          if (instRes && instRes.installed && instRes.installed.length) {
            installedModules.push(...instRes.installed);
            vfxInstallNote = `OTOMATİK KURULUM TAMAMLANDI: ${instRes.installed.join(", ")} doğrudan Roblox Studio 'game.ReplicatedStorage' içine yüklendi! Kodunda doğrudan \`local UqVFX = require(game.ReplicatedStorage:WaitForChild("UqVFXLibrary"))\` ve \`UqVFX.Spawn("SlashGenshin", targetPart)\` kullanabilirsin!`;
          }
        } catch {}
      }
      const [vfxMd, vfxLuau] = await Promise.all([
        fetchSkillTextSafe("vfx_pack/SKILL.md"),
        fetchSkillTextSafe("vfx_pack/UqVFXLibrary.luau"),
      ]);
      blocks.push(
        `<article class="uqboat-skill-html" id="vfx-pack-skill" data-skill="vfx_pack">\n` +
        `  <h2>[OTOMATİK YÜKLENEN SKILL (HTML REHBER + 263 GÖRSEL VFX ASSET ID): FX PACK (vfx_pack)]</h2>\n` +
        `  <p><strong>ZORUNLU KURAL:</strong> Kullanıcı VFX / Efekt / Aura / Kılıç Kesik (Slash) / Vuruş (Hit) / Yıldırım / Ateş / Blok istediği için UqBOAT görsel incelemeli 263 VFX Asset ID kataloğunu ve hazır Luau VFX kütüphanesini HTML formatında yükledi. Rastgele veya uydurma rbxassetid KULLANMA; yalnızca aşağıdaki katalogdaki doğrulanmış rbxassetid://ID değerlerini kullan ve siyah arka planlı dokularda mutlaka <code>LightEmission = 1</code> ayarla!</p>\n` +
        `  <p><strong>${vfxInstallNote}</strong></p>\n` +
        `  <section data-example="UqVFXLibrary.luau">\n` +
        `    <h3>Hazır Modül ve Örnek VFX Kodları (vfx_pack/UqVFXLibrary.luau)</h3>\n` +
        `    <pre><code class="language-luau">${vfxLuau}</code></pre>\n` +
        `  </section>\n` +
        `  <section data-file="vfx_pack/SKILL.md">\n` +
        `    <h3>Görsel İncelemeli 263 VFX Asset ID Kataloğu ve Tam FX Pack Listesi</h3>\n` +
        `    <pre><code>${vfxMd}</code></pre>\n` +
        `  </section>\n` +
        `</article>`
      );
      loaded.push("vfx");
    }
  }
  return {
    ok: true,
    categories: loaded,
    installedModules,
    images: bundleImages,
    text: blocks.join("\n\n"),
  };
}

// ── Multi-AI Team Coordinator & Sequential Studio Execution Queue ───────
// Allows multiple open AI tabs (e.g. Tab 1: Sonnet 5.5 High, Tab 2: GPT 6 Luna Max,
// Tab 3: GPT Terra 6.1 Low) to work together on the same Roblox Studio place:
//  - All tabs can think/stream in parallel.
//  - Studio MCP tool calls run through a strict FIFO queue (studioCallQueue) so
//    simultaneous execute_luau / multi_edit calls never collide in Studio.
//  - Shared message log, role assignments, task board, and automatic task
//    dispatch from Leader -> Worker tabs with live completion callbacks.

let studioCallQueue = Promise.resolve();
let studioQueueDepth = 0;

function enqueueStudioToolCall(fn) {
  studioQueueDepth++;
  const run = studioCallQueue.then(
    async () => {
      try {
        return await fn();
      } finally {
        studioQueueDepth = Math.max(0, studioQueueDepth - 1);
      }
    },
    async () => {
      try {
        return await fn();
      } finally {
        studioQueueDepth = Math.max(0, studioQueueDepth - 1);
      }
    }
  );
  studioCallQueue = run.catch(() => {});
  return run;
}

// Global Cross-Tab Send Pacer: enforces at least 5 seconds (5000ms) between
// outgoing Arena messages so Captcha and rate-limit prompts are prevented.
let sendSlotQueue = Promise.resolve();
let lastGlobalSendAt = 0;

function acquireSendSlot() {
  const run = sendSlotQueue.then(async () => {
    if (lastGlobalSendAt > 0) {
      const activeTeamSize = teamState.members.size;
      const minGap = 5000;
      const jitter = activeTeamSize > 1 ? Math.floor(Math.random() * 600) : 0;
      const elapsed = Date.now() - lastGlobalSendAt;
      const waitMs = Math.max(0, minGap + jitter - elapsed);
      if (waitMs > 0) {
        await new Promise((r) => setTimeout(r, waitMs));
      }
      lastGlobalSendAt = Date.now();
      return { ok: true, waitedMs: waitMs };
    }
    lastGlobalSendAt = Date.now();
    return { ok: true, waitedMs: 0 };
  });
  sendSlotQueue = run.catch(() => {});
  return run;
}

const ROLE_LABELS = {
  leader: "Lider / Planlayıcı",
  general: "Genel Uzman",
  builder: "3D Model / Mimari",
  ui: "UI / StudUI Uzmanı",
  scripter: "Luau Script / Sistem",
  animator: "Animasyon & Efekt (VFX)",
  combat: "Savaş & Fizik Sistemleri",
  world: "Harita & Çevre Tasarımı",
};

// Derive a 2-letter uppercase prefix from the AI model's name:
//  - "gpt-6-luna-max" / "gpt luna" -> "GL" (GL1, GL2, ...)
//  - "gpt-6.1-terra-low" / "gpt terra" -> "GT" (GT1, GT2, ...)
//  - "claude-sonnet-5-5-high" / "sonnet high" -> "SH" (SH1, SH2, ...)
function deriveModelPrefix(modelName) {
  const m = String(modelName || "").toLowerCase();
  if (/\bgpt\b/.test(m) && /\bluna\b/.test(m)) return "GL";
  if (/\bluna\b/.test(m)) return "GL";
  if (/\bgpt\b/.test(m) && /\bterra\b/.test(m)) return "GT";
  if (/\bterra\b/.test(m)) return "GT";
  if (/\bsonnet\b/.test(m) && /\bhigh\b/.test(m)) return "SH";
  if (/\bsonnet\b/.test(m) && /\blow\b/.test(m)) return "SL";
  if (/\bsonnet\b/.test(m) && /\bmax\b/.test(m)) return "SM";
  if (/\bsonnet\b/.test(m)) return "CS";
  if (/\bopus\b/.test(m) && /\bhigh\b/.test(m)) return "OH";
  if (/\bopus\b/.test(m)) return "CO";
  if (/\bhaiku\b/.test(m)) return "CH";
  if (/\bgemini\b/.test(m) && /\bpro\b/.test(m)) return "GP";
  if (/\bgemini\b/.test(m) && /\bflash\b/.test(m)) return "GF";
  if (/\bgemini\b/.test(m)) return "GM";
  if (/\bdeepseek\b/.test(m) && /\br1\b/.test(m)) return "DR";
  if (/\bdeepseek\b/.test(m)) return "DS";
  if (/\bqwen\b/.test(m)) return "QW";
  if (/\bkimi\b/.test(m)) return "KM";
  if (/\bglm\b/.test(m)) return "GM";
  if (/\bgrok\b/.test(m)) return "GK";
  const words = (m.match(/[a-z]+/g) || []).filter(
    (w) => !/^(arena|direct|agent|model|chat|ai|the|v)$/i.test(w)
  );
  if (words.length >= 2) {
    return (words[0][0] + words[1][0]).toUpperCase();
  }
  if (words.length === 1 && words[0].length >= 2) {
    return words[0].slice(0, 2).toUpperCase();
  }
  return "AI";
}

function allocateAgentId(tabId, modelName, existingId = "") {
  const prefix = deriveModelPrefix(modelName);
  if (existingId && new RegExp(`^${prefix}\\d+$`).test(existingId)) {
    const collision = [...teamState.members.values()].some(
      (m) => m.tabId !== tabId && m.agentId === existingId
    );
    if (!collision) return existingId;
  }
  const used = new Set(
    [...teamState.members.values()]
      .filter((m) => m.tabId !== tabId)
      .map((m) => m.agentId)
  );
  let n = 1;
  while (used.has(`${prefix}${n}`)) n++;
  return `${prefix}${n}`;
}

// Score an AI model name for each role so UqBOAT can automatically assign the
// optimal Leader and specialist roles across all connected tabs (unlimited tabs!)
// when the user leaves role selection on "Otomatik (Modele Göre)".
function scoreModelForRole(modelName, role) {
  const m = String(modelName || "").toLowerCase();
  if (role === "leader") {
    let s = 50;
    if (/opus|sonnet[- .]?5|sonnet[- .]?4|gpt[- .]?6[- .]?luna[- .]?max|gpt[- .]?5|o3|o1|gemini[- .]?2\.5[- .]?pro/i.test(m)) s += 38;
    else if (/sonnet|luna|gpt[- .]?6|claude|gemini|deepseek[- .]?r1/i.test(m)) s += 25;
    if (/\b(high|max|pro|thinking|ultra)\b/i.test(m)) s += 16;
    if (/\b(low|mini|nano|flash|lite)\b/i.test(m)) s -= 12;
    return s;
  }
  if (role === "ui") {
    let s = 50;
    if (/luna|sonnet|claude|gemini|gpt[- .]?4o|gpt[- .]?5/i.test(m)) s += 30;
    if (/\b(max|high|pro)\b/i.test(m)) s += 12;
    return s;
  }
  if (role === "builder" || role === "world") {
    let s = 50;
    if (/terra|sonnet|deepseek|qwen|gpt[- .]?6/i.test(m)) s += 30;
    if (/\b(low|fast|flash|high)\b/i.test(m)) s += 10;
    return s;
  }
  if (role === "scripter" || role === "combat" || role === "animator") {
    let s = 50;
    if (/sonnet|claude|codex|deepseek|qwen|luna|terra|gpt/i.test(m)) s += 28;
    if (/\b(high|max|coder)\b/i.test(m)) s += 14;
    return s;
  }
  return 50;
}

const teamState = {
  nextAgentSeq: 1,
  nextTaskSeq: 1,
  nextMsgSeq: 1,
  nextWaiterSeq: 1,
  members: new Map(), // tabId -> { tabId, agentId, modelName, role, roleMode, isLeader, started, busy, currentTaskId, lastAction, updatedAt }
  tasks: [],          // [{ id, title, instructions, assignedTo, assignedTabId, role, createdBy, status, result, createdAt, updatedAt }]
  messages: [],       // [{ id, ts, fromAgentId, fromModel, fromRole, toAgentId, kind, text }]
  waiters: new Map(), // waiterId -> { taskIds, resolve, timer }
};

function saveTeamStateSnapshot() {
  try {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({
        zsTeamStateSnapshot: {
          nextAgentSeq: teamState.nextAgentSeq,
          nextTaskSeq: teamState.nextTaskSeq,
          nextMsgSeq: teamState.nextMsgSeq,
          members: [...teamState.members.entries()],
          tasks: teamState.tasks.slice(-30),
          messages: teamState.messages.slice(-40),
        },
      });
    }
  } catch {}
}

try {
  if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get("zsTeamStateSnapshot", (r) => {
      const snap = r && r.zsTeamStateSnapshot;
      if (!snap || teamState.members.size > 0) return;
      if (snap.nextAgentSeq) teamState.nextAgentSeq = snap.nextAgentSeq;
      if (snap.nextTaskSeq) teamState.nextTaskSeq = snap.nextTaskSeq;
      if (snap.nextMsgSeq) teamState.nextMsgSeq = snap.nextMsgSeq;
      if (Array.isArray(snap.members)) {
        for (const [tid, mem] of snap.members) {
          teamState.members.set(tid, mem);
        }
      }
      if (Array.isArray(snap.tasks)) teamState.tasks = snap.tasks;
      if (Array.isArray(snap.messages)) teamState.messages = snap.messages;
    });
  }
} catch {}

function pushTeamMessage({ fromAgentId = "SYS", fromModel = "System", fromRole = "system", toAgentId = "ALL", kind = "info", text = "" }) {
  const clean = String(text || "").trim();
  if (!clean) return null;
  const entry = {
    id: teamState.nextMsgSeq++,
    ts: Date.now(),
    iso: new Date().toISOString().slice(11, 19),
    fromAgentId,
    fromModel,
    fromRole,
    toAgentId,
    kind,
    text: clean.slice(0, 4000),
  };
  teamState.messages.push(entry);
  if (teamState.messages.length > 120) {
    teamState.messages.splice(0, teamState.messages.length - 120);
  }
  broadcastTeamState();
  return entry;
}

// Rebalance roles across all connected members:
// - Respects any member with roleMode === "manual".
// - If no manual leader exists, picks the highest-scoring model for "leader".
// - Assigns complementary specialist roles ("builder", "ui", "scripter", "general")
//   to remaining "auto" members based on their model's strengths!
function autoAssignTeamRoles() {
  const list = [...teamState.members.values()];
  if (!list.length) return null;

  // 1. Determine the Leader
  let leader = list.find((m) => m.roleMode === "manual" && (m.role === "leader" || m.isLeader));
  if (!leader) {
    // Score all candidates (prefer auto members or highest leader score)
    const candidates = list.filter((m) => m.roleMode !== "manual" || m.role === "leader");
    const pool = candidates.length ? candidates : list;
    leader = pool.slice().sort((a, b) => scoreModelForRole(b.modelName, "leader") - scoreModelForRole(a.modelName, "leader"))[0];
  }
  for (const m of list) {
    m.isLeader = (m === leader);
    if (m === leader && m.roleMode !== "manual") {
      m.role = "leader";
    } else if (m !== leader && m.role === "leader" && m.roleMode !== "manual") {
      m.role = "general";
    }
  }

  // 2. Assign complementary specialist roles to non-leader auto members (supports unlimited tabs!)
  const specialistRoles = ["builder", "ui", "scripter", "animator", "combat", "world", "general"];
  const usedRoles = new Set(
    list.filter((m) => m !== leader && m.roleMode === "manual").map((m) => m.role)
  );
  const autoWorkers = list.filter((m) => m !== leader && m.roleMode !== "manual");

  for (const w of autoWorkers) {
    // Rank specialist roles not yet used, weighted by this model's affinity;
    // if more tabs are connected than unique roles, cycle cleanly across all roles!
    let available = specialistRoles.filter((r) => !usedRoles.has(r));
    if (!available.length) {
      usedRoles.clear();
      available = specialistRoles.slice();
    }
    const bestRole = available
      .slice()
      .sort((r1, r2) => scoreModelForRole(w.modelName, r2) - scoreModelForRole(w.modelName, r1))[0];
    w.role = bestRole || "general";
    usedRoles.add(w.role);
  }

  saveTeamStateSnapshot();
  return leader;
}

function ensureTeamLeader() {
  return autoAssignTeamRoles();
}

function serializeTeamPublicState() {
  ensureTeamLeader();
  return {
    type: "zs-team-state",
    queueDepth: studioQueueDepth,
    members: [...teamState.members.values()].map((m) => ({
      tabId: m.tabId,
      agentId: m.agentId,
      enabled: m.enabled !== false,
      provider: m.provider || "Arena",
      modelName: m.modelName,
      role: m.role,
      roleMode: m.roleMode || "auto",
      roleLabel: ROLE_LABELS[m.role] || m.role,
      isLeader: !!m.isLeader,
      started: !!m.started,
      busy: !!m.busy,
      status: m.busy ? "busy" : "idle",
      currentTask: m.currentTask || m.lastAction || "",
      currentTaskId: m.currentTaskId || null,
      lastAction: m.lastAction || "",
    })),
    tasks: teamState.tasks.slice(-100),
    messages: teamState.messages.slice(-80),
    latestMsgId: teamState.messages.length ? teamState.messages[teamState.messages.length - 1].id : 0,
  };
}

function broadcastTeamState() {
  const pub = serializeTeamPublicState();
  const payload = { ...pub, state: pub };
  try { chrome.runtime.sendMessage(payload).catch(() => {}); } catch {}
  try {
    if (chrome.tabs && chrome.tabs.query) {
      chrome.tabs.query({ url: PROVIDER_URLS }, (tabs) => {
        for (const t of tabs || []) {
          try { chrome.tabs.sendMessage(t.id, payload).catch(() => {}); } catch {}
        }
      });
    }
  } catch {}
}

function getOrRegisterMember(tabId, info = {}) {
  if (tabId == null) tabId = info.tabId != null ? info.tabId : 1;
  let m = teamState.members.get(tabId);
  const isNew = !m;
  const busyFlag = info.busy != null ? !!info.busy : (info.status ? info.status === "busy" : undefined);
  const explicitManual =
    info.roleMode === "manual" ||
    info.makeLeader === true ||
    info.isLeader === true ||
    (info.role && info.role !== "auto" && info.roleMode !== "auto" && isNew);

  if (!m) {
    const modelName = info.modelName || "Arena Direct";
    const agentId = allocateAgentId(tabId, modelName, "");
    const reqRole = info.role && info.role !== "auto" ? info.role : "general";
    m = {
      tabId,
      agentId,
      enabled: info.enabled !== undefined ? !!info.enabled : true,
      provider: info.provider || "Arena",
      modelName,
      role: reqRole,
      roleMode: explicitManual ? "manual" : "auto",
      isLeader: !!(info.makeLeader || info.isLeader === true || reqRole === "leader"),
      started: !!info.started,
      busy: !!busyFlag,
      status: busyFlag ? "busy" : "idle",
      currentTask: info.currentTask || "",
      currentTaskId: null,
      lastAction: "Takıma katıldı",
      updatedAt: Date.now(),
    };
    if (m.isLeader && m.roleMode === "manual") {
      for (const other of teamState.members.values()) {
        other.isLeader = false;
        if (other.role === "leader") {
          other.role = "general";
          other.roleMode = "auto";
        }
      }
      m.role = "leader";
    }
    teamState.members.set(tabId, m);
  } else {
    if (info.enabled !== undefined) m.enabled = !!info.enabled;
    if (info.provider) m.provider = info.provider;
    if (info.modelName && info.modelName !== "Arena Direct") {
      m.modelName = info.modelName;
      m.agentId = allocateAgentId(tabId, m.modelName, m.agentId);
    } else if (info.modelName && !m.modelName) {
      m.modelName = info.modelName;
      m.agentId = allocateAgentId(tabId, m.modelName, m.agentId);
    }
    if (info.roleMode === "auto" || info.role === "auto") {
      m.roleMode = "auto";
    } else if (info.roleMode === "manual") {
      m.roleMode = "manual";
      if (info.role) m.role = info.role;
    } else if (info.role && m.roleMode === "manual") {
      m.role = info.role;
    }
    if (typeof info.started === "boolean") m.started = info.started;
    if (busyFlag !== undefined) {
      m.busy = busyFlag;
      m.status = busyFlag ? "busy" : "idle";
    }
    if (info.currentTask !== undefined) m.currentTask = info.currentTask;
    if (info.lastAction) m.lastAction = info.lastAction;
    if (info.makeLeader || (info.roleMode === "manual" && (info.isLeader === true || info.role === "leader"))) {
      for (const other of teamState.members.values()) {
        other.isLeader = false;
        if (other !== m && other.role === "leader") {
          other.role = "general";
          other.roleMode = "auto";
        }
      }
      m.isLeader = true;
      m.role = "leader";
      m.roleMode = "manual";
    }
    m.updatedAt = Date.now();
  }
  autoAssignTeamRoles();
  if (isNew) {
    pushTeamMessage({
      fromAgentId: m.agentId,
      fromModel: m.modelName,
      fromRole: m.role,
      kind: "join",
      text: `${m.agentId} (${m.modelName} · ${ROLE_LABELS[m.role] || m.role}${m.isLeader ? " · LİDER" : ""}) takıma katıldı.`,
    });
  } else {
    broadcastTeamState();
  }
  return m;
}

function findTargetMember(targetSpec, excludeTabId = null) {
  const members = [...teamState.members.values()];
  if (!members.length) return null;
  const pendingCountFor = (tabId) =>
    teamState.tasks.filter((t) => t.assignedTabId === tabId && (t.status === "pending" || t.status === "in_progress")).length;
  const pickLeastLoaded = (list) => {
    if (!list.length) return null;
    return list.slice().sort((a, b) => {
      const loadA = (a.busy ? 1 : 0) + pendingCountFor(a.tabId);
      const loadB = (b.busy ? 1 : 0) + pendingCountFor(b.tabId);
      return loadA - loadB;
    })[0];
  };
  const spec = String(targetSpec || "").trim().toLowerCase();
  if (spec && spec !== "auto" && spec !== "any") {
    // 1. Exact agentId match (e.g. "GL1", "GT1", "SH1", "GL2")
    const byId = members.find((m) => m.agentId.toLowerCase() === spec);
    if (byId) return byId;
    // 2. Prefix match (e.g. "GL", "GT", "SH") -> least loaded tab with that model prefix
    const byPrefix = members.filter((m) => m.agentId.toLowerCase().replace(/\d+$/, "") === spec && m.tabId !== excludeTabId);
    if (byPrefix.length) return pickLeastLoaded(byPrefix);
    // 3. Role match (e.g. "ui", "builder", "scripter", "animator", "combat", "world")
    const roleAlias =
      spec.includes("ui") || spec.includes("stud") || spec.includes("hud") ? "ui" :
      spec.includes("anim") || spec.includes("vfx") || spec.includes("efekt") ? "animator" :
      spec.includes("combat") || spec.includes("sava") || spec.includes("dövü") || spec.includes("fizik") ? "combat" :
      spec.includes("world") || spec.includes("map") || spec.includes("harita") || spec.includes("çevre") ? "world" :
      spec.includes("model") || spec.includes("build") || spec.includes("mimar") ? "builder" :
      spec.includes("script") || spec.includes("lua") || spec.includes("kod") ? "scripter" :
      spec.includes("lead") || spec.includes("lider") ? "leader" : null;
    if (roleAlias) {
      const byRole = members.filter((m) => m.role === roleAlias && m.tabId !== excludeTabId);
      if (byRole.length) return pickLeastLoaded(byRole);
      const byRoleAny = members.filter((m) => m.role === roleAlias);
      if (byRoleAny.length) return pickLeastLoaded(byRoleAny);
    }
    // 4. Model name substring match (e.g. "sonnet", "luna", "terra", "gpt")
    const byModel = members.filter((m) => m.modelName.toLowerCase().includes(spec) && m.tabId !== excludeTabId);
    if (byModel.length) return pickLeastLoaded(byModel);
    const byModelAny = members.filter((m) => m.modelName.toLowerCase().includes(spec));
    if (byModelAny.length) return pickLeastLoaded(byModelAny);
  }
  // Auto-pick across ALL connected tabs (unlimited tabs): prefer non-leader least-loaded workers
  const workers = members.filter((m) => m.tabId !== excludeTabId);
  if (!workers.length) return members[0];
  const nonLeaderWorkers = workers.filter((m) => !m.isLeader);
  return pickLeastLoaded(nonLeaderWorkers.length ? nonLeaderWorkers : workers);
}

function checkWaiters() {
  for (const [wid, w] of teamState.waiters.entries()) {
    const tracked = w.taskIds.map((id) => teamState.tasks.find((t) => t.id === id)).filter(Boolean);
    if (tracked.length && tracked.every((t) => t.status === "done" || t.status === "failed")) {
      clearTimeout(w.timer);
      teamState.waiters.delete(wid);
      w.resolve(tracked);
    }
  }
}

function pumpWorkerQueues() {
  for (const m of teamState.members.values()) {
    if (m.busy || m.currentTaskId) continue;
    const nextTask = teamState.tasks.find(
      (t) => t.status === "pending" && (t.assignedTabId === m.tabId || (!t.assignedTabId && t.assignedTo === m.agentId))
    );
    if (!nextTask) continue;
    nextTask.assignedTabId = m.tabId;
    nextTask.assignedTo = `${m.agentId} (${m.modelName})`;
    nextTask.status = "in_progress";
    nextTask.updatedAt = Date.now();
    m.busy = true;
    m.currentTaskId = nextTask.id;
    m.lastAction = `Görev #${nextTask.id}: ${nextTask.title}`;
    broadcastTeamState();
    const payload = {
      type: "zs-team-run-task",
      task: nextTask,
      member: {
        agentId: m.agentId,
        modelName: m.modelName,
        role: m.role,
        roleLabel: ROLE_LABELS[m.role] || m.role,
      },
      teamSummary: formatTeamSummaryText(m.tabId),
    };
    (async () => {
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          if (chrome.tabs && chrome.tabs.sendMessage) {
            await chrome.tabs.sendMessage(m.tabId, payload);
            break;
          }
        } catch {
          await new Promise((r) => setTimeout(r, 650 * (attempt + 1)));
        }
      }
    })();
  }
}

function formatTeamSummaryText(forTabId = null) {
  ensureTeamLeader();
  const members = [...teamState.members.values()];
  const memberLines = members.length
    ? members.map((m) => {
        const meTag = m.tabId === forTabId ? " [BU SEKME / SEN]" : "";
        const leadTag = m.isLeader ? " [LİDER]" : "";
        const stateTag = m.busy ? `ÇALIŞIYOR (${m.lastAction || "meşgul"})` : "HAZIR (idle)";
        return `  - ${m.agentId}: Model="${m.modelName}" | Rol=${ROLE_LABELS[m.role] || m.role}${leadTag}${meTag} | Durum=${stateTag}`;
      })
    : ["  (Henüz aktif takım sekmesi yok)"];

  const taskLines = teamState.tasks.length
    ? teamState.tasks.slice(-15).map((t) =>
        `  - [Görev #${t.id}] (${t.status.toUpperCase()}) -> ${t.assignedTo}: ${t.title}` +
        (t.result ? `\n      Sonuç: ${String(t.result).slice(0, 300)}` : "")
      )
    : ["  (Henüz atanmış görev yok)"];

  const msgLines = teamState.messages.length
    ? teamState.messages.slice(-15).map((msg) =>
        `  - [${msg.iso}] ${msg.fromAgentId} (${msg.fromModel}): ${msg.text.slice(0, 260)}`
      )
    : ["  (Henüz takım mesajı yok)"];

  return (
    `━━━ UqBOAT MULTI-AI TAKIM DURUMU (${members.length} Sekme Bağlı) ━━━\n` +
    `Aktif AI Sekmeleri:\n${memberLines.join("\n")}\n\n` +
    `Görev Panosu:\n${taskLines.join("\n")}\n\n` +
    `Son Takım Mesajları & Studio İşlemleri:\n${msgLines.join("\n")}`
  );
}

async function handleTeamAssignTask(senderTabId, args = {}) {
  const caller = getOrRegisterMember(senderTabId, {});
  const rawList = Array.isArray(args.tasks) && args.tasks.length
    ? args.tasks
    : [{
        target: args.target || args.agent || args.to || args.model || args.role || "auto",
        title: args.title || args.task || "Alt Görev",
        instructions: args.instructions || args.prompt || args.description || args.task || "",
        role: args.role || "",
      }];

  const created = [];
  for (const item of rawList) {
    const targetSpec = item.target || item.agent || item.to || item.model || item.role || "auto";
    const targetMember = findTargetMember(targetSpec, senderTabId);
    const id = teamState.nextTaskSeq++;
    const title = String(item.title || item.task || `Görev #${id}`).trim();
    const instructions = String(item.instructions || item.prompt || item.description || title).trim();
    const assignedTabId = targetMember ? targetMember.tabId : null;
    const assignedTo = targetMember
      ? `${targetMember.agentId} (${targetMember.modelName})`
      : String(targetSpec || "auto");
    const taskObj = {
      id,
      title,
      instructions,
      assignedTo,
      assignedAgentId: targetMember ? targetMember.agentId : String(targetSpec || "auto"),
      assignedModel: targetMember ? targetMember.modelName : "",
      assignedTabId,
      role: item.role || (targetMember && targetMember.role) || "general",
      createdBy: `${caller.agentId} (${caller.modelName})`,
      status: "pending",
      result: "",
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    teamState.tasks.push(taskObj);
    created.push(taskObj);
    pushTeamMessage({
      fromAgentId: caller.agentId,
      fromModel: caller.modelName,
      fromRole: caller.role,
      toAgentId: targetMember ? targetMember.agentId : "ALL",
      kind: "task_assigned",
      text: `Görev #${id} atandı -> ${assignedTo}: "${title}"`,
    });
  }

  pumpWorkerQueues();

  // If wait === true (and tasks are assigned to OTHER active tabs), wait for completion up to timeout
  const otherTabTasks = created.filter((t) => t.assignedTabId && t.assignedTabId !== senderTabId);
  const shouldWait = args.wait === true && otherTabTasks.length > 0;
  if (shouldWait) {
    const waitTimeoutMs = Math.min(Math.max(Number(args.timeout_ms || 180000), 5000), 300000);
    const doneTasks = await new Promise((resolve) => {
      const wid = teamState.nextWaiterSeq++;
      const timer = setTimeout(() => {
        teamState.waiters.delete(wid);
        resolve(otherTabTasks);
      }, waitTimeoutMs);
      teamState.waiters.set(wid, {
        taskIds: otherTabTasks.map((t) => t.id),
        resolve,
        timer,
      });
      checkWaiters();
    });
    const summary = doneTasks.map(
      (t) => `- [Görev #${t.id}] ${t.assignedTo} (${t.status}): ${t.result || "(henüz tamamlanmadı)"}`
    ).join("\n");
    return {
      ok: true,
      tasks: created,
      text:
        `${created.length} görev takıma dağıtıldı ve sonuçlar toplandı:\n${summary}\n\n` +
        formatTeamSummaryText(senderTabId),
    };
  }

  const createdLines = created.map(
    (t) => `- Görev #${t.id} -> ${t.assignedTo}: "${t.title}" (Durum: ${t.status})`
  ).join("\n");
  return {
    ok: true,
    tasks: created,
    text:
      `${created.length} görev başarıyla atandı ve ilgili AI sekmelerine otomatik iletildi:\n${createdLines}\n\n` +
      `(Diğer sekmeler görevlerini paralel olarak çalıştırıyor ve Studio komutlarını sırayla uyguluyor. Sonuçları beklemek için team_wait_tasks veya team_status kullanabilirsin.)`,
  };
}

function handleTeamCompleteTask(senderTabId, args = {}) {
  const caller = getOrRegisterMember(senderTabId, {});
  const taskId = Number(args.task_id || args.id || caller.currentTaskId || 0);
  let task = teamState.tasks.find((t) => t.id === taskId);
  if (!task) {
    task = [...teamState.tasks].reverse().find(
      (t) => t.assignedTabId === senderTabId && (t.status === "in_progress" || t.status === "pending")
    );
  }
  const summary = String(args.result || args.summary || args.text || "Görev tamamlandı.").trim();
  const failed = args.status === "failed" || args.ok === false;
  if (task) {
    task.status = failed ? "failed" : "done";
    task.result = summary;
    task.updatedAt = Date.now();
  }
  caller.busy = false;
  caller.currentTaskId = null;
  caller.lastAction = task ? `Görev #${task.id} bitti` : "Hazır";
  pushTeamMessage({
    fromAgentId: caller.agentId,
    fromModel: caller.modelName,
    fromRole: caller.role,
    kind: "task_done",
    text: task
      ? `Görev #${task.id} (${task.title}) ${failed ? "BAŞARISIZ" : "TAMAMLANDI"}: ${summary}`
      : `${caller.agentId} görev sonucunu bildirdi: ${summary}`,
  });
  checkWaiters();
  pumpWorkerQueues();
  return {
    ok: true,
    task: task || null,
    text: task
      ? `Görev #${task.id} ("${task.title}") tamamlandı olarak işaretlendi ve tüm takım sekmelerine duyuruldu.`
      : `Durum güncellendi ve tüm takım sekmelerine duyuruldu.`,
  };
}

async function handleTeamWaitTasks(senderTabId, args = {}) {
  const ids = Array.isArray(args.task_ids) && args.task_ids.length
    ? args.task_ids.map(Number)
    : teamState.tasks
        .filter((t) => t.assignedTabId !== senderTabId && (t.status === "pending" || t.status === "in_progress"))
        .map((t) => t.id);

  if (!ids.length) {
    return {
      ok: true,
      text: `Bekleyen aktif takım görevi yok.\n\n${formatTeamSummaryText(senderTabId)}`,
    };
  }
  const waitTimeoutMs = Math.min(Math.max(Number(args.timeout_ms || 180000), 2000), 300000);
  await new Promise((resolve) => {
    const wid = teamState.nextWaiterSeq++;
    const timer = setTimeout(() => {
      teamState.waiters.delete(wid);
      resolve();
    }, waitTimeoutMs);
    teamState.waiters.set(wid, { taskIds: ids, resolve, timer });
    checkWaiters();
  });
  return {
    ok: true,
    text: `Takım görevleri güncellendi:\n\n${formatTeamSummaryText(senderTabId)}`,
  };
}

if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.onRemoved) {
  chrome.tabs.onRemoved.addListener((tabId) => {
    if (teamState.members.has(tabId)) {
      const m = teamState.members.get(tabId);
      teamState.members.delete(tabId);
      ensureTeamLeader();
      pushTeamMessage({
        fromAgentId: m.agentId,
        fromModel: m.modelName,
        fromRole: m.role,
        kind: "leave",
        text: `${m.agentId} (${m.modelName}) sekmesi kapandı.`,
      });
    }
  });
}

// ── messages from content.js / popup.js ─────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const senderTabId = (_sender && _sender.tab && _sender.tab.id != null) ? _sender.tab.id : (msg && msg.tabId != null ? msg.tabId : 1);
  (async () => {
    switch (msg.type) {
      case "status":
        if (!connected) {
          connect(); // self-heal after a worker wake-up
          await waitForConnection(1500);
        }
        sendResponse(statusObj());
        break;
      case "acquire_send_slot": {
        const slot = await acquireSendSlot();
        sendResponse(slot);
        break;
      }
      case "team_register": {
        const m = getOrRegisterMember(senderTabId, msg);
        if (!m.busy) pumpWorkerQueues();
        sendResponse({ ok: true, member: m, state: serializeTeamPublicState() });
        break;
      }
      case "team_set_member_role": {
        const targetTabId = Number(msg.targetTabId != null ? msg.targetTabId : senderTabId);
        const target = teamState.members.get(targetTabId);
        if (target) {
          if (msg.role === "auto" || msg.roleMode === "auto") {
            target.roleMode = "auto";
          } else if (msg.role) {
            target.roleMode = "manual";
            target.role = msg.role;
            if (msg.role === "leader") {
              for (const other of teamState.members.values()) {
                other.isLeader = false;
                if (other !== target && other.role === "leader") {
                  other.role = "general";
                  other.roleMode = "auto";
                }
              }
              target.isLeader = true;
            } else if (target.isLeader) {
              target.isLeader = false;
            }
          }
          autoAssignTeamRoles();
          broadcastTeamState();
        }
        sendResponse({ ok: true, state: serializeTeamPublicState() });
        break;
      }
      case "team_auto_assign_roles": {
        for (const m of teamState.members.values()) {
          m.roleMode = "auto";
        }
        autoAssignTeamRoles();
        broadcastTeamState();
        sendResponse({ ok: true, state: serializeTeamPublicState() });
        break;
      }
      case "team_leave": {
        if (teamState.members.has(senderTabId)) {
          const m = teamState.members.get(senderTabId);
          teamState.members.delete(senderTabId);
          autoAssignTeamRoles();
          pushTeamMessage({
            fromAgentId: m.agentId,
            fromModel: m.modelName,
            fromRole: m.role,
            kind: "leave",
            text: `${m.agentId} (${m.modelName}) takımdan ayrıldı.`,
          });
        }
        sendResponse({ ok: true, state: serializeTeamPublicState() });
        break;
      }
      case "team_join_all_tabs": {
        getOrRegisterMember(senderTabId, { ...msg, roleMode: msg.roleMode || "auto" });
        if (chrome.tabs && chrome.tabs.query) {
          chrome.tabs.query({ url: PROVIDER_URLS }, (tabs) => {
            for (const t of tabs || []) {
              try {
                chrome.tabs.sendMessage(t.id, { type: "zs-team-autojoin", leaderTabId: senderTabId }).catch(() => {});
              } catch {}
            }
          });
        }
        sendResponse({ ok: true, state: serializeTeamPublicState() });
        break;
      }
      case "team_status": {
        const text = formatTeamSummaryText(senderTabId);
        sendResponse({ ok: true, text, state: serializeTeamPublicState() });
        break;
      }
      case "team_broadcast": {
        const m = getOrRegisterMember(senderTabId, {});
        const a = msg.arguments || msg;
        const body = a.message || a.text || a.content || "";
        const to = a.to || a.target || "ALL";
        pushTeamMessage({
          fromAgentId: m.agentId,
          fromModel: m.modelName,
          fromRole: m.role,
          toAgentId: to,
          kind: a.kind || "chat",
          text: body,
        });
        sendResponse({
          ok: true,
          text: `Mesaj tüm takım sekmelerine (${teamState.members.size} AI) iletildi: "${String(body).slice(0, 160)}"`,
          state: serializeTeamPublicState(),
        });
        break;
      }
      case "team_assign_task": {
        const r = await handleTeamAssignTask(senderTabId, msg.arguments || msg);
        sendResponse(r);
        break;
      }
      case "team_complete_task": {
        const r = handleTeamCompleteTask(senderTabId, msg.arguments || msg);
        sendResponse(r);
        break;
      }
      case "team_wait_tasks": {
        const r = await handleTeamWaitTasks(senderTabId, msg.arguments || msg);
        sendResponse(r);
        break;
      }
      case "team_pull_updates": {
        const sinceId = Number(msg.sinceId || 0);
        const me = teamState.members.get(senderTabId);
        const myAgentId = me ? me.agentId : "";
        const unread = teamState.messages
          .filter((e) => e.id > sinceId && e.fromAgentId !== myAgentId)
          .map((e) => ({
            ...e,
            from: e.fromAgentId,
            modelName: e.fromModel,
          }));
        const myTasks = teamState.tasks.filter(
          (t) => t.assignedTabId === senderTabId && (t.status === "pending" || t.status === "in_progress")
        );
        const latestId = teamState.messages.length ? teamState.messages[teamState.messages.length - 1].id : sinceId;
        sendResponse({
          ok: true,
          latestId,
          latestMsgId: latestId,
          unread,
          updates: unread,
          myTasks,
          memberCount: teamState.members.size,
          me: me || null,
          member: me || null,
        });
        break;
      }
      case "trigger_captcha_buster": {
        try {
          if (chrome.tabs && chrome.tabs.sendMessage && senderTabId != null) {
            chrome.tabs.sendMessage(senderTabId, { type: "zs-trigger-buster" }, () => {
              try { void chrome.runtime.lastError; } catch {}
            });
          }
        } catch {}
        sendResponse({ ok: true, triggered: true });
        break;
      }
      case "check_bframe_visible": {
        const checkRes = await new Promise((resolve) => {
          if (!chrome.tabs || !chrome.tabs.sendMessage || senderTabId == null) {
            return resolve({ ok: false, visible: false });
          }
          try {
            chrome.tabs.sendMessage(
              senderTabId,
              { type: "zs-check-bframe-visible" },
              { frameId: 0 },
              (resp) => {
                try { void chrome.runtime.lastError; } catch {}
                resolve(resp && resp.ok ? resp : { ok: false, visible: false });
              }
            );
          } catch {
            resolve({ ok: false, visible: false });
          }
        });
        sendResponse(checkRes);
        break;
      }
      case "trusted_click_in_bframe": {
        let clickedViaDebugger = false;
        let tabX = -1;
        let tabY = -1;
        let rejectReason = "no-visible-captcha";
        try {
          const localX = Number(msg.localX || 0);
          const localY = Number(msg.localY || 0);
          // Ask the top frame (frameId: 0) to verify the reCAPTCHA bframe is truly visible,
          // scroll it into view if the screen is split/resized, re-measure its fresh rect,
          // and confirm via document.elementFromPoint(tabX, tabY) === iframe that the target
          // pixel physically hits the Captcha iframe (never the page underneath!).
          const bframeRect = await new Promise((resolve) => {
            if (!chrome.tabs || !chrome.tabs.sendMessage || senderTabId == null) return resolve(null);
            try {
              chrome.tabs.sendMessage(
                senderTabId,
                { type: "zs-get-bframe-rect", localX, localY },
                { frameId: 0 },
                (resp) => {
                  try { void chrome.runtime.lastError; } catch {}
                  resolve(resp || null);
                }
              );
            } catch {
              resolve(null);
            }
          });
          if (
            bframeRect &&
            bframeRect.ok === true &&
            bframeRect.hitVerified === true &&
            Number.isFinite(bframeRect.tabX) &&
            Number.isFinite(bframeRect.tabY) &&
            bframeRect.tabX > 4 &&
            bframeRect.tabY > 4
          ) {
            tabX = Math.round(bframeRect.tabX);
            tabY = Math.round(bframeRect.tabY);
            rejectReason = "";
            if (chrome.debugger && senderTabId != null) {
              const target = { tabId: senderTabId };
              await new Promise((res) => {
                try {
                  chrome.debugger.attach(target, "1.3", () => {
                    try { void chrome.runtime.lastError; } catch {}
                    res();
                  });
                } catch {
                  res();
                }
              });
              const sendCmd = (method, params) =>
                new Promise((res) => {
                  try {
                    chrome.debugger.sendCommand(target, method, params, () => {
                      try { void chrome.runtime.lastError; } catch {}
                      res();
                    });
                  } catch {
                    res();
                  }
                });
              await sendCmd("Input.dispatchMouseEvent", {
                type: "mouseMoved",
                x: tabX,
                y: tabY,
                button: "none",
                modifiers: 0,
              });
              await sendCmd("Input.dispatchMouseEvent", {
                type: "mousePressed",
                x: tabX,
                y: tabY,
                button: "left",
                buttons: 1,
                clickCount: 1,
                modifiers: 0,
              });
              await new Promise((r) => setTimeout(r, 45));
              await sendCmd("Input.dispatchMouseEvent", {
                type: "mouseReleased",
                x: tabX,
                y: tabY,
                button: "left",
                buttons: 0,
                clickCount: 1,
                modifiers: 0,
              });
              await new Promise((res) => {
                try {
                  chrome.debugger.detach(target, () => {
                    try { void chrome.runtime.lastError; } catch {}
                    res();
                  });
                } catch {
                  res();
                }
              });
              clickedViaDebugger = true;
            }
          } else if (bframeRect && bframeRect.reason) {
            rejectReason = bframeRect.reason;
          }
        } catch (err) {
          rejectReason = String((err && err.message) || err);
        }
        sendResponse({ ok: clickedViaDebugger, clickedViaDebugger, tabX, tabY, reason: rejectReason });
        break;
      }
      case "get_auto_skill_bundle": {
        const r = await buildAutoSkillBundle(msg.arguments || msg);
        sendResponse(r);
        break;
      }
      case "install_offline_skill": {
        const r = await handleInstallOfflineSkill(msg.arguments || msg);
        sendResponse(r);
        break;
      }
      case "list_offline_skills": {
        const r = await handleListOfflineSkills(msg.arguments || msg);
        sendResponse(r);
        break;
      }
      case "read_offline_skill": {
        const r = await handleReadOfflineSkill(msg.arguments || msg);
        sendResponse(r);
        break;
      }
      case "list_tools": {
        // Prefer a live refresh; fall back to cache so the loop never stalls.
        // 10s, not 25s: a catalogue request only blocks this long when one of the
        // MCP servers is dead (typically Roblox in a degraded, Blender-only
        // session), and in that exact case we already hold a perfectly good cached
        // catalogue. Waiting the full 25s just froze the boot for no new data.
        const r = await send({ type: "list_tools" }, 10000);
        if (r.ok) sendResponse({ ok: true, tools: r.tools });
        else sendResponse({ ok: toolsCache.length > 0, tools: toolsCache, error: r.error });
        break;
      }
      case "call_tool": {
        const timeout = (msg.timeout || 120000) + 10000;
        const r = await enqueueStudioToolCall(async () => {
          const member = teamState.members.get(senderTabId);
          if (member) {
            member.lastAction = `Studio: ${msg.name}`;
            broadcastTeamState();
          }
          const callArgs = Object.assign({}, msg.arguments || {});
          if (callArgs.studio_id) {
            lastKnownStudioId = callArgs.studio_id;
          }
          // Ensure Roblox Studio MCP tools never fail if the AI forgot datamodel_type or studio_id
          if (/^(execute_luau|multi_edit|grep_scripts|edit_script_lines|create_or_update_script|delete_script|get_console_output|get_studio_mode)$/.test(String(msg.name || ""))) {
            if (!callArgs.datamodel_type) callArgs.datamodel_type = "Edit";
            if (!callArgs.studio_id && lastKnownStudioId) callArgs.studio_id = lastKnownStudioId;
          }
          let res = await send(
            { type: "call_tool", name: msg.name, arguments: callArgs, timeout: msg.timeout },
            timeout
          );
          if (msg.name === "list_roblox_studios" && res && res.ok && res.text) {
            const m = String(res.text).match(/"studio_id"\s*:\s*"([^"]+)"|studio_id\s*[=:]\s*([A-Za-z0-9_-]+)/i);
            if (m) lastKnownStudioId = m[1] || m[2];
          }
          // Auto-reconnect & retry once if the bridge WebSocket had a momentary drop
          if (res && !res.ok && res.kind === "disconnected") {
            const reconnected = await waitForConnection(3500);
            if (reconnected) {
              res = await send(
                { type: "call_tool", name: msg.name, arguments: callArgs, timeout: msg.timeout },
                timeout
              );
            }
          }
          if (member && /^(execute_luau|multi_edit|insert_from_creator_store|generate_mesh|generate_procedural_model|store_image)$/.test(String(msg.name || ""))) {
            const outPreview = res && res.ok
              ? String(res.text || "OK").replace(/\s+/g, " ").trim().slice(0, 180)
              : `HATA: ${String((res && res.error) || "failed").slice(0, 120)}`;
            pushTeamMessage({
              fromAgentId: member.agentId,
              fromModel: member.modelName,
              fromRole: member.role,
              kind: "tool",
              text: `[Studio ${msg.name}] -> ${outPreview}`,
            });
          }
          return res;
        });
        sendResponse(r);
        break;
      }
      case "restart_mcp": {
        const r = await send({ type: "restart_mcp" }, 30000);
        sendResponse(r);
        break;
      }
      case "add_server": {
        const r = await send({
          type: "add_server", server_id: msg.server_id,
          command: msg.command, args: msg.args, env: msg.env,
        }, 15000);
        sendResponse(r);
        break;
      }
      case "remove_server": {
        const r = await send({ type: "remove_server", server_id: msg.server_id }, 15000);
        sendResponse(r);
        break;
      }
      case "reconnect":
        reconnectDelay = RECONNECT_MIN;
        connect();
        sendResponse({ ok: true });
        break;
      default:
        sendResponse({ ok: false, error: "unknown message" });
    }
  })();
  return true; // async sendResponse
});

// Persistent keepalive port from content scripts so Chrome MV3 never suspends
// the background worker while AI tabs are open or running long Team tasks.
if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onConnect) {
  chrome.runtime.onConnect.addListener((port) => {
    if (!port || port.name !== "zs-keepalive") return;
    port.onMessage.addListener((msg) => {
      if (msg && msg.type === "ping") {
        if (!connected) connect();
        try {
          port.postMessage({
            type: "pong",
            status: statusObj(),
            teamState: serializeTeamPublicState(),
          });
        } catch {}
      }
    });
  });
}

// Wake/keepalive hooks.
chrome.runtime.onStartup.addListener(connect);
chrome.runtime.onInstalled.addListener(connect);

connect();
