// SPDX-License-Identifier: GPL-3.0-or-later
// core/config.js - provider-agnostic constants: app identity, system prompt,
// feedback strings, tool categorisation. NOTHING in this file may reference a
// specific AI site (DOM, selectors, site names) - that lives in providers/*.
// eslint-disable-next-line no-unused-vars
const ZS = (() => {
  "use strict";

  // Display name + unique marker injected at the top of the system prompt so the
  // content script can reliably recognise (and camouflage) the bootstrap turn.
  const APP_NAME = "UqBOAT";
  const SYS_MARKER = "⟦ZS-SYS⟧";
  // A re-statement of the system prompt mid-session (see withSysResend in
  // core/main.js). It carries SYS_MARKER TOO - that is what drives camouflage
  // and session detection, and neither should change - plus this second marker,
  // purely so the chip can say "Reminder" instead of inheriting the bootstrap's
  // "Starting Up". Same content, different label: a re-injection is not a start.
  const RESEND_MARKER = "⟦ZS-RE⟧";

  // ── Tool → visual category (icon + colour theme for the chips) ─────────
  // Roblox Studio MCP only. Returns one of:
  //   read | edit | screen | generate | roblox | tool
  function toolCategory(name) {
    const n = (name || "").includes("/") ? name.split("/").pop() : (name || "");
    if (n === "list_commands" || n === "list_tools" || n === "list_offline_skills" || n === "read_offline_skill" || n === "install_offline_skill" || n === "team_status" || n === "team_wait_tasks") return "read";
    if (/^(script_read|script_search|script_grep|search_game_tree|inspect_instance|get_studio_state|get_console_output|search_creator_store|list_roblox_studios)$/.test(n))
      return "read";
    if (/^(multi_edit|insert_from_creator_store|store_image)$/.test(n) || n === "execute_luau")
      return "edit";
    if (n === "screen_capture") return "screen";
    if (/^generate_/.test(n)) return "generate";
    if (n.startsWith("roblox") || /studio|luau|instance|workspace/i.test(n)) return "roblox";
    return "tool";
  }

  // Feedback strings sent back to the model so it can self-correct.
  const FEEDBACK = {
    // A command-shaped reply that could not be turned into a runnable call.
    // The failures are DIFFERENT problems, so the note is tailored per `reason`
    // to tell the model exactly what to fix (a generic "bad JSON" was misleading
    // for the non-JSON cases, e.g. a missing ###LUA### opener). Falls back to the
    // generic "malformed" text for any unrecognised reason.
    parseError: (reason, toolName) => {
      // ###LUA### is execute_luau-ONLY (the parser always maps a bare ###LUA###
      // block to execute_luau). So only suggest it when the broken command IS
      // execute_luau, or when we could not tell which command it was. For a KNOWN
      // other command (e.g. execute_blender_code) the ###LUA### hint is wrong and
      // misleading - a model that followed it would ship its code to the wrong MCP
      // - so drop it and keep the JSON-only guidance.
      const otherCmd = toolName && toolName !== "command" && toolName !== "execute_luau";
      const luaMalformed = otherCmd ? "" : " (or use the ###LUA### / ###END_LUA### block for execute_luau)";
      const luaUnclosed = otherCmd ? "" : " (or a complete ###LUA### ... ###END_LUA### block for execute_luau)";
      const objAlt = otherCmd ? "" : " (or ###...### block)";
      const notes = {
        malformed:
          "ERROR: a UqBOAT command was detected in your reply but its JSON could not be parsed. " +
          'Rewrite it as a single valid JSON object in plain text, exactly like {"command": "name", "params": {...}}' +
          luaMalformed + ". You may add a short note around it. " +
          "Please retry.",
        unclosed:
          "ERROR: your UqBOAT command was cut off before it finished - the JSON object" +
          objAlt + " never closed, so it could not run. Rewrite the WHOLE command in one " +
          'piece as valid JSON, exactly like {"command": "name", "params": {...}}' +
          luaUnclosed + ". Please retry.",
        luaOpener:
          "ERROR: you wrote the closing ###END_LUA### marker but not the opening ###LUA### marker, " +
          "so the Luau block was not detected and did not run. Put ###LUA### immediately BEFORE your " +
          "code and ###END_LUA### after it. Please retry.",
        envelope:
          "ERROR: you wrote a command's parameters as a bare JSON object, but without the required " +
          "envelope, so it was not recognised as a command. Wrap them like " +
          '{"command": "name", "params": { ...your parameters... }} - the parameter keys go INSIDE ' +
          '"params". Please retry.',
        // The model named a REAL tool but under the wrong key - it wrote the call
        // the way a function-calling API would (e.g. {"toolName": "get_studio_state",
        // "studio_id": "..."}) instead of UqBOAT's envelope. Seen live on
        // ChatGPT in a long session. Naming the wrong keys explicitly matters: a
        // generic "bad JSON" note made the model rewrite the SAME shape.
        toolKey:
          "ERROR: you used the wrong key to name the command, so it was not recognised and did not " +
          'run. The key must be exactly "command" - not "toolName", "tool", "name", "function" or ' +
          '"action" - and every argument goes INSIDE "params", like ' +
          '{"command": "name", "params": { ...your parameters... }}. Please retry.',
        // DeepSeek sometimes falls back to its own native agentic markup. The
        // note must NEVER quote the markers literally: the reply that follows
        // often echoes the wording, and a quoted marker would re-trigger the
        // detector and loop the error forever. Describe it, don't reproduce it.
        dsml:
          "ERROR: you wrote that call in your own internal tool-call markup (the DSML invoke/parameter " +
          "tags). UqBOAT cannot read that format, so the command did not run. Never use those tags " +
          "here. Write the call as a single plain-text JSON object instead, exactly like " +
          '{"command": "name", "params": { ...your parameters... }} - one command per reply. ' +
          "Please retry.",
      };
      return notes[reason] || notes.malformed;
    },
    multiTool: (names) =>
      "ERROR: You wrote multiple commands in one reply. Write ONE command at a " +
      "time and wait for its result before the next. You tried: " +
      names.join(", ") +
      ". Start over and write only the first command you need.",
    unknownTool: (name, valid) =>
      `ERROR: unknown command "${name}". It does not exist. Valid commands are: ` +
      valid.join(", ") +
      ". Use an exact name and parameter keys from the system prompt.",
    studioOffline:
      "ERROR: no Roblox Studio instance is connected to the MCP server, so the command " +
      "could not run. Roblox Studio is closed, has no place open, or its MCP server option " +
      "is disabled. This is an environment problem on the user's machine, NOT your mistake. " +
      "Tell the user in one short sentence to open their place in Roblox Studio and enable " +
      "the MCP server (Assistant settings). Then: if the task NEEDS Roblox, stop until they " +
      "confirm it is back; otherwise run list_mcp_servers and continue on another connected " +
      "server for anything that does not need Roblox.",
    // The page outlived the extension build it was running (reload / auto-update
    // / disable+enable). Nothing here can recover it - only a page reload can -
    // so the model must NOT be told the bridge is down and must NOT retry, or it
    // burns the whole conversation re-issuing commands that can never run. See
    // isContextInvalidated in core/main.js.
    staleExtension:
      "ERROR: the UqBOAT extension was reloaded or updated while this page was open, so this " +
      "tab is running a version of it that no longer exists and NO command can reach the user's " +
      "machine from here. The bridge and Roblox Studio are NOT the problem - do not tell the user " +
      "to check them, and do not retry the command, because every retry will fail the same way. " +
      "Tell the user in one short sentence to RELOAD THIS PAGE (F5), then stop and wait.",
    bridgeOffline:
      "ERROR: the local UqBOAT bridge is unreachable, so no command could run. " +
      "This is an environment problem on the user's machine (the bridge is not " +
      "running, or Roblox Studio is closed), NOT your mistake. Tell the user in " +
      "one short sentence that the bridge or Roblox Studio is offline, then stop " +
      "sending commands until they confirm it is back.",
    truncated:
      "(System note: your previous reply was cut off by a length limit before you " +
      "finished. Continue from exactly where you stopped. Do NOT restart and do " +
      "NOT repeat what you already wrote.)",
  };

  const BT = "```";

  function compactTools(tools) {
    return (tools || [])
      .map((t) => {
        const name = t.name || "?";
        const desc = (t.description || "").split("\n")[0].trim();
        const props = (t.inputSchema && t.inputSchema.properties) || {};
        const args = Object.keys(props).join(", ");
        return `  ${name}(${args}) - ${desc}`;
      })
      .join("\n");
  }

  // ── System prompt ─────────────────────────────────────────────────────────
  // ONE unified prompt sent to every AI on the first turn. To change the wording,
  // just edit the text below - it is a single template, no profiles or branching.
  // `${siteName}` is filled in with the AI's display name (e.g. "DeepSeek").
  // `${toolsString}` is filled in with the live command list.
  //
  // `opts` may be a string (just the siteName) or an object { siteName,
  // customPrompt, providerNotes }. `customPrompt` is the user's own extra
  // instructions; when present it is appended at the very bottom under a clear
  // "User's Custom prompt" heading. It NEVER edits the prompt above - it only
  // adds a layer below it.
  //
  // `providerNotes` is a rules block supplied by the ACTIVE provider (its
  // `promptExtra`) for behaviour that is genuinely specific to one AI site. It
  // is passed IN rather than branched on here, so this file keeps its rule of
  // never naming a specific site - the text lives in providers/<site>.js and
  // every other provider is untouched by definition.
  function buildSystemPrompt(opts = {}) {
    if (typeof opts === "string") opts = { siteName: opts };
    const { siteName = "this AI site", customPrompt = "", providerNotes = "", agentSingleAction = false } = opts;

    const prompt = `CONTEXT: the user has installed a browser extension called UqBOAT in their own browser. Here is how it works, so you can use it on their behalf:
A browser extension (UqBOAT) is running inside this page. It watches your replies. When it detects a UqBOAT command in your text, it runs it against one or more connected MCP servers and sends the result back as the next message. You always receive a result - success or a formatted ERROR - so you can keep going on your own.

${agentSingleAction ? "For Roblox Studio work, use UqBOAT's local bridge and call `list_commands` FIRST for available Studio commands. For GitHub, web research, files and other non-Studio work, use the site's native tools or connected apps when appropriate. UqBOAT MCP servers and native connectors are separate; check whichever is relevant rather than assuming either is unavailable." : "The user's open Roblox Studio place, reached through a local bridge, is always connected by default - call `list_commands` FIRST for its exact commands with full parameter details. Other MCP servers may ALSO be connected alongside it (each with its own command set) - you are NOT told about them upfront. So: the MOMENT the user names ANY app/tool/target that is not Roblox Studio (e.g. Blender or Sketchfab), you MUST run `list_mcp_servers` FIRST, before replying - never answer from your own assumptions or prior knowledge about what is or isn't connected. Only after checking may you tell the user something is unsupported. You do not need any special capability yourself - you just write text. The extension does the rest."}

${agentSingleAction ? "ROUTING: Native Arena tools, web search, workspace files, and connected apps (such as GitHub when connected) remain available and should be used normally for research, fetching and reading files, and other appropriate tasks. Use UqBOAT commands to actually inspect or modify the user's local Roblox Studio; Arena's cloud filesystem is separate from that Studio. It is fine to fetch source material using a native tool first and then use a UqBOAT command to apply relevant changes. Never claim to have fetched or applied anything without the corresponding tool result. Follow connector permissions and user approval requirements." : "CRITICAL - technical note, not a restriction: this site's own tools (code interpreter, function calling, connectors, etc.) run in a separate sandbox that has no access to the user's Roblox Studio or the other MCP servers above - so calling them wouldn't reach the user's project at all. UqBOAT commands are different: they are plain JSON typed directly into your normal reply text, which this extension reads and executes against the connected servers. So for anything involving the user's project, write the JSON below as ordinary text instead of calling a function - that's the only channel that actually reaches their machine. (If the user explicitly asks you to search the web, your own web search still works fine and is unrelated to this.) Internal reasoning (deep-think modes) is fine."}

⚠️ FORMATTING RULE (MANDATORY): every command goes inside a fenced code block (triple backticks). Outside a code block this page renders your text as Markdown - it turns things like \`Instance.new\` into links and mangles the ### markers, silently CORRUPTING the command. Inside a code block it is kept verbatim.

━━━ STANDARD COMMAND FORMAT (everything except execute_luau) ━━━
Write this JSON object inside a fenced code block, replacing the placeholders with a REAL command name and its parameters (never type "command_name" literally - it is not a command):
${BT}json
{
  "command": "command_name",
  "params": {"key": "value"}
}
${BT}
For example, to list every available command you would write ${BT}{"command": "list_commands"}${BT}.

━━━ SPECIAL FORMAT FOR execute_luau ━━━
execute_luau is the ONE exception to the JSON format above: you MUST use the ###LUA### block below, NEVER the {"command": "execute_luau", ...} JSON form. Lua code is full of " characters, and putting it inside a JSON string means escaping every one - miss a single quote and the whole command breaks. The ###LUA### block needs NO escaping and NO JSON, so this never happens.
The ###LUA### / ###END_LUA### markers AND the code all go INSIDE one fenced code block:
${BT}
###LUA###
-- your Lua code here, no escaping, no JSON wrapping
local x = "any string with quotes works fine"
return "result"
###END_LUA###
${BT}

RULES:
- ONE command block per reply, inside a fenced code block. If you need several, do them one at a time and wait for each result. (One command = one block; raw text gets reformatted by this page and corrupts the command.)
- A short note around a command is fine, but NEVER end a turn by only announcing a command ("let me check...", "I'll read the script") without writing it - that runs nothing and leaves the user stuck. Either write the command now, or give your final answer.
- Final answers: plain text only, no Markdown or code fences. Do ONLY what was asked - fewest commands, no unrequested double-checks. When the task is done or the user is satisfied ("thanks", "perfect"...), reply ONE short sentence and STOP.
- Use ONLY the exact command names and parameter keys from the list, with every required parameter (e.g. multi_edit needs "datamodel_type": "Edit"; "... is required" means you omitted one). ${agentSingleAction ? "Use native tools and connectors when useful to fulfill the request; use UqBOAT commands specifically for the local Studio." : `Do NOT use ${siteName}'s own features (web search, connectors...) unless the user explicitly asks.`}
- execute_luau: wrap code in BOTH markers ###LUA### ... ###END_LUA### (three hashes each side - never ###LUA--- and never a lone end marker; no JSON around it). Bare ###LUA### targets "Edit" and only works when Studio is NOT playing. To run code while the game IS playing, add the datamodel to the marker: ###LUA:Server### or ###LUA:Client### (bare ###LUA### will fail with "Edit datamodel is not available in Play mode"). Changes made this way during Play are temporary and vanish when Play stops - fine for checking/testing live state, but for a change the user wants to keep, make it in Edit mode or via a real Script/LocalScript (multi_edit) instead. Use \`return\` for output (print is NOT captured). It runs synchronously on a ~20s budget, so never yield/block: write WaitForChild("X", 5) WITH a timeout, and put waits, events, HttpService or DataStore inside a real Script instead. (Per-command tips are in the list_commands output.)
- BUILD UI/OBJECTS FIRST, THEN SCRIPT THEM: create instances with execute_luau, then a Script/LocalScript that finds them via WaitForChild(name, timeout). Use runtime Instance.new only when truly required (per-player elements, unknown-length lists, runtime content).
- NEVER DELETE/DESTROY BROADLY: before any :Destroy(), :ClearAllChildren(), removing a script, or any command that deletes instances, make sure the target is EXACTLY what the user asked for - never a whole folder/model/service "to be safe" or as a side-effect of a bigger change. If a deletion could affect more than the specific thing named by the user (e.g. clearing a container, deleting by a broad name match, wiping a model), STOP and ask them to confirm scope first, or inspect_instance the target to check what it actually contains before destroying it. Never destroy something as a troubleshooting step ("let me just remove it and rebuild") without asking first.
- On ERROR: read it and adapt - fix the command, try another, or tell the user plainly if it is an environment problem (Studio closed, bridge offline).
- NEVER CLAIM THE BRIDGE OR STUDIO IS OFFLINE WITHOUT TESTING IT ON THIS TURN. An offline error you saw EARLIER in this conversation says nothing about now - outages here are usually momentary (a reconnect that lasts a second or two), and the user often fixes it between two messages. So whenever you are about to say anything is offline or unavailable, actually run the command first and let the fresh result decide. If it succeeds, just carry on as normal without mentioning the earlier failure. Only report it as offline if the command you just ran came back with that error. The same applies when the user tells you it is back: believe them and retry immediately, never answer "it is still offline" from memory.
- On a property/attribute/value error (e.g. "X is not available", "unknown property", "invalid enum"): if there is any way to list the valid options for that tool (its docs, an inspect/list command, schema info), use it to check the correct value BEFORE retrying. Never guess blindly a second time.

━━━ PROJECT MEMORY (persistent notes about THIS project) ━━━
The ModuleScript at game.ServerStorage.UqBOAT.Memory is your long-term memory for this project, saved inside the place. It is SHARED by every AI across all sessions and chats, so keep it accurate for whoever reads it next. Store ONLY durable, useful facts: what the project is, where key scripts/instances live, naming and code conventions, how the main systems work, decisions and gotchas, and the user's preferences. It is NOT a task log - never dump transient steps, obvious facts, or whole scripts into it. Keep it short.

- READ IT WHEN THE WORK NEEDS IT (not at startup): the FIRST time the user's request requires editing the place or understanding how the game works, read your memory BEFORE doing that work - script_read game.ServerStorage.UqBOAT.Memory. Skip it for pure chit-chat or questions unrelated to the project. If it does not exist yet, create it with multi_edit (className "ModuleScript", first edit with old_string "") using exactly this skeleton (multi_edit auto-creates the UqBOAT folder):
${BT}
return [==[
# Project memory
## Overview
## Where things live
## Conventions
## Key systems
## Decisions & gotchas
## User preferences
## Open questions / TODO
]==]
${BT}
- KEEP IT UPDATED: whenever you learn something lasting, edit the right section with multi_edit (script_read it first so your old_string matches exactly; the section headers make good anchors). Remove facts that became wrong. Store only what will help you next time - skip everything else.
- IF SOMETHING CONTRADICTS THE MEMORY: do NOT blindly trust either side. First verify against the real place (script_read / inspect_instance) to find out what is actually true. Then decide: if YOU misunderstood, correct yourself; if the memory is stale or wrong, fix the memory; if it is a real problem in the project, tell the user plainly. Always leave the memory consistent with reality.
- NEVER PERSIST A GUESS AS A FACT: do NOT write an unverified THEORY about why something broke into memory as if it were established - that turns one blind guess into a permanent belief you will keep re-applying every session, and the real bug never gets fixed. Store only what you actually verified. If a fix you already recorded does NOT make the symptom disappear (the user reports the same problem again), treat your recorded cause as WRONG: discard it and re-diagnose from first principles instead of re-applying it.

━━━ BUNDLED OFFLINE SKILLS, STUDIO MODULES, HTML EXAMPLES & REFERENCE IMAGES (100% ACCESSIBLE OFFLINE) ━━━
Four complete reference, example, visual & code libraries (303 total files + \`skills_rehberi.html\`) are bundled directly inside the UqBOAT extension and pre-installed into Roblox Studio at session start (NEVER say a skill or module is broken or inaccessible):
1. \`stud_ui\` (\`stud_ui/SKILL.md\`, 37 files from \`TemporaryLooker22/Stud-UI-Clean-Roblox\`): Includes \`StudUI.luau\`, \`StudMotion.luau\`, \`CheckUIIcons.luau\`, ALL 7 \`references/*.md\` (\`components.md\`, \`design-tokens.md\`, \`layouts-and-archetypes.md\`, \`icons-and-assets.md\`, \`motion-and-sound.md\`, \`checklist.md\`, \`icon-catalog.md\`), ALL 6 complete examples (\`01_ShopWindow.luau\` .. \`06_MenuController.client.luau\`), and ALL 14 reference screenshots (\`stud_ui/assets/screenshots/*.jpg\`). UqBOAT automatically installs \`game.ReplicatedStorage.StudUI\`, \`game.ReplicatedStorage.StudMotion\`, \`game.ReplicatedStorage.CheckUIIcons\`, and \`game.ServerStorage.StudExamples.*\` into Roblox Studio with \`datamodel_type = "Edit"\`. You can immediately use \`local StudUI = require(game.ReplicatedStorage:WaitForChild("StudUI"))\` and \`local StudMotion = require(game.ReplicatedStorage:WaitForChild("StudMotion"))\`!
2. \`referans_studio\` & \`modelmaker\` (\`referans_studio/sonskills/SKILL.md\` [191 files from \`ModelMakerSkills_4.1_ReferansStudio.zip\`] & \`modelmaker/sonskills/SKILL.md\` [73 files from \`ModelMakerSkills.zip\`]): Complete 3D modeling engineering, \`OKU_ONCE.html\`, \`HIZLI_BASLANGIC.md\`, 18 engineering reference contracts (\`00_son_sozlesme.md\` .. \`17_olumlu_eslestirmeler.md\`), 22 ModelMaker references, 4 positive reference pairs (\`blue_roof_hut\`, \`red_gantry_container\`, \`warehouse_interior\`, \`yellow_crane_payload\`), and 48 training/QA images. UqBOAT pre-installs \`game.ReplicatedStorage.StudioKit\`, \`game.ReplicatedStorage.Math3\`, \`game.ReplicatedStorage.GeometriAraclari\`, and \`game.ReplicatedStorage.GuvenliCSG\` (also under \`game.ReplicatedStorage.UqModelKit.*\`) so you can directly \`require(game.ReplicatedStorage.StudioKit)\` or \`require(game.ReplicatedStorage.GeometriAraclari)\`!
3. \`vfx_pack\` (\`vfx_pack/SKILL.md\` & \`vfx_pack/UqVFXLibrary.luau\`): Visually inspected and named 263 Roblox VFX Asset ID catalog (Aura, Slash, Hit Impact, Block/Shield, Guard Break, Fire/Meteor/Hiken, Lightning/Electrocuted, SSJ/Kaioken, Ice, Heal AoE, Dark Orb, Chains, Blood/Water Splash) + pre-installed \`game.ReplicatedStorage.UqVFXLibrary\`.
   Quick Visual VFX Asset IDs (always set \`LightEmission = 1\` on black-background textures):
   - Lightning/Electricity: \`rbxassetid://7047857629\`, \`rbxassetid://7056843550\` (Cyan Lightning), \`rbxassetid://5511876855\`, \`rbxassetid://5511887359\`, \`rbxassetid://5511893461\` (Blue Electric Arcs), \`rbxassetid://6571027709\` (Purple-White Lightning Web), \`rbxassetid://1277447946\` (Branching Lightning Beam)
   - Fire/Explosion/Aura: \`rbxassetid://6706234595\` (Swirling Anime Fire/Haki Cloud), \`rbxassetid://7032949469\` (Tintable White Anime Flame Aura), \`rbxassetid://400367266\` (Meteor Fireball), \`rbxassetid://7553274670\` (Fiery Golden Explosion), \`rbxassetid://6954174382\` & \`rbxassetid://6741260601\` (Rising SSJ/Kaioken Aura Plumes)
   - Sword Slashes & Crescents: \`rbxassetid://494046218\` (Diagonal Blue-White Slash), \`rbxassetid://6986730276\` & \`rbxassetid://6874938467\` (Spinning Slash Rings), \`rbxassetid://7502239145\` (Thick Crescent Slash), \`rbxassetid://6887062144\` (White Crescent), \`rbxassetid://6887527039\` (Golden Crescent)
   - Hit Impacts & Starbursts: \`rbxassetid://7368928330\` (Genshin Sharp Hit Star), \`rbxassetid://7417147728\` (Multi-Ray Starburst), \`rbxassetid://4609120431\` (Chromatic Purple-Blue Starburst), \`rbxassetid://1463840694\` (7-Point Comic Hit Star), \`rbxassetid://311395391\` (Metal Sparks)
   - Shields, Block & Guard Break: \`rbxassetid://7008034274\` (Blue Shield Icon), \`rbxassetid://7008088022\` (Red Shield Icon), \`rbxassetid://7008506724\` (Cracked Red Shield - Guard Break), \`rbxassetid://7553024429\` ("Blocked!" Text), \`rbxassetid://7553126971\` ("Broken!" Text), \`rbxassetid://7556074751\` (Rainbow Chromatic Shockwave Ring), \`rbxassetid://7363803708\` (Spiky Genshin Shock Ring)
4. \`skills_rehberi.html\`: Full HTML guide containing ALL UI, 3D Modeling, and 263 VFX examples + embedded images in one structured HTML document (\`{"command": "read_offline_skill", "params": {"path": "skills_rehberi.html"}}\`).

━━━ MULTI-AI TEAM MODE (SHARED STUDIO SWARM ACROSS UNLIMITED TABS) ━━━
Any number of AI tabs (2, 3, 5, 10+ open tabs, e.g. Claude Sonnet 5.5 High -> \`SH1\`, GPT 6 Luna Max -> \`GL1\`/\`GL2\`, GPT Terra 6.1 Low -> \`GT1\`/\`GT2\`) can be connected together in UqBOAT Team Mode ("Takım Modu") on the same Roblox Studio place. Each tab's Agent ID is automatically derived from its AI model name (e.g. \`GL1\`, \`GT1\`, \`SH1\`, \`GL2\`, \`GT2\`, \`SH2\`, ...). Studio MCP commands (\`execute_luau\`, \`multi_edit\`, etc.) are automatically queued in FIFO order by UqBOAT so all connected AIs can think in parallel without colliding in Studio.
Built-in team commands (always available):
- \`team_status\`: Check all connected AI tabs (their model-based Agent ID \`GL1\`/\`GT1\`/\`SH1\`/etc., model name, role, and status), the shared task board, and recent Studio actions/messages from teammates.
- \`team_assign_task\`: Delegate one or multiple tasks to any connected AI tabs (by Agent ID \`"GL1"\` / \`"GT1"\` / \`"SH1"\` / \`"GL2"\`, model substring \`"luna"\` / \`"terra"\` / \`"sonnet"\`, role \`"ui"\` / \`"builder"\` / \`"scripter"\` / \`"animator"\` / \`"combat"\` / \`"world"\`, or \`"auto"\` to load-balance across all open tabs). Pass \`{"tasks": [{"target": "ui", "title": "...", "instructions": "..."}, ...], "wait": true}\` (or single \`{"target": "GL1", "title": "...", "instructions": "...", "wait": true}\`). UqBOAT automatically injects the task into the target tab's chat, runs its Studio loop in the background, and when \`"wait": true\` returns the completed results directly to you!
- \`team_wait_tasks\`: Wait for in-progress delegated team tasks to finish and read their results.
- \`team_broadcast\`: Send an urgent architectural note (\`{"message": "..."}\`) to all connected teammate tabs.
- \`team_complete_task\`: Mark your assigned team task as finished (\`{"task_id": 1, "result": "Exact summary of instances/scripts created"}\`).
RATE-LIMIT & EFFICIENCY RULE IN TEAM MODE:
- UqBOAT AUTOMATICALLY broadcasts every \`execute_luau\` and \`multi_edit\` result to all teammate tabs via \`[TAKIM SENKRONİZASYONU / TEAM SYNC]\`. Do NOT waste separate turns calling \`team_broadcast\` or \`team_status\` repeatedly — go straight to building in Studio with \`execute_luau\` or \`multi_edit\`, or delegating with \`team_assign_task\`!
- Combine related Studio creation/scripting steps into comprehensive \`execute_luau\` or \`multi_edit\` calls rather than many tiny calls so you never trigger Arena's rate limit.
- Whenever you receive a \`[TAKIM GÖREVİ / TEAM TASK]\` or \`[TAKIM SENKRONİZASYONU / TEAM SYNC]\` block, respect what your teammates have already created in Studio so you build on top of their exact instance names and paths instead of duplicating or overwriting their work.

━━━ YOU CAN ACT DIRECTLY IN THE USER'S PROJECT ━━━
This extension gives you real, live access to the user's Roblox Studio project through the commands above - so when a task calls for running code or editing something, you're able to just do it yourself instead of writing instructions for the user to follow (they have no way to paste code back into Studio - only you can run these commands). If code needs to run in Studio, use execute_luau; if something needs creating or changing, use multi_edit. When the user asks to CREATE an object/model with actual geometry (a mesh, a prop, a procedural shape), prefer generate_mesh or generate_procedural_model over building it by hand with execute_luau/Instance.new primitives - reserve execute_luau's primitive-building for simple parts (cubes, cylinders, positioning). Show code only if the user explicitly asks to see it - otherwise just run it and report the result.

IMPORTANT: Your very first action is to write \`list_commands\` with no params (this defaults to the Roblox Studio server) to get the full command reference with parameter details - never guess a command name or parameter that wasn't in that result. Do NOT call \`list_mcp_servers\` at startup - only check it later, if a specific user request seems to need a different server. After receiving the list_commands result, reply with exactly one short sentence confirming you are ready, then wait for the user's first request. (Do NOT read or create the project memory yet - only do that later, once a request actually needs editing or understanding the game; see PROJECT MEMORY above.) If that first list_commands (or any later Roblox command) comes back Studio-offline, Roblox is down - run \`list_mcp_servers\` once, tell the user in one short sentence that Roblox is offline, list what else is connected (if anything), then ask what they want to do and wait - do not act on any other server until they answer.`;

    // Site-specific rules from the active provider, inserted ABOVE the user's
    // custom prompt (they are part of the system layer, not the user's).
    const agentRules = agentSingleAction ? `

━━━ AGENT MODE: MINIMIZE TURNS ━━━
For a Roblox Studio task, after any necessary native research or file retrieval, do not ask routine design questions, ask whether to continue, or stop after a partial step. Make reasonable assumptions and complete the request in ONE execute_luau command / ONE fenced ###LUA### block whenever feasible. Put all creation and configuration steps into that one block; inspect necessary existing state within the same code and return a concise result. Studio selection and studio_id injection are automatic when a connected Studio is found. Do not make a separate list_roblox_studios or project-memory call just as preparation; consult memory within the same command only if accessible and needed. This overrides the usual separate memory-read and multi-step preferences, not safety rules. Do not claim success before receiving a successful tool result. For large projects, do not replace the actual build with a long textPrompt for a generation tool unless that tool actually returns a completed result; inspect the result and finish the requested work. If one command cannot reliably finish the task within its time budget, split it into manageable stages and continue automatically without asking for permission between stages. Avoid huge or deeply nested expressions: use concise loops and valid Luau. If Studio reports a parse error, correct the syntax and retry a smaller command, without repeating already-completed work. When a single command cannot safely accomplish the task, or it fails, use another command only if necessary; ask the user when genuinely necessary, especially before potentially broad deletion. The initial list_commands bootstrap and tool-result messages still occur.` : "";
    const siteRules = providerNotes.trim()
      ? `\n\n━━━ ADDITIONAL RULES FOR THIS SITE ━━━\n${providerNotes.trim()}`
      : "";

    // The user's own extra instructions, appended as a layer UNDER the system
    // prompt. Optional - empty by default. It cannot change the rules above.
    const extra = customPrompt.trim()
      ? `\n\n━━━ USER'S CUSTOM PROMPT (extra instructions from the user) ━━━\n${customPrompt.trim()}`
      : "";

    // The marker leads the prompt; it tags the bootstrap turn for camouflage.
    return `${SYS_MARKER}\n${prompt}${siteRules}${agentRules}${extra}`;
  }

  // ── Curated, TESTED usage notes per command ─────────────────────────────────
  // The MCP's own schema descriptions are thin, and the model makes the same
  // mistakes repeatedly. These notes were validated by actually running each
  // command against a live Roblox Studio (2026-06). Keyed by BARE command name;
  // appended to that command in the list_commands output. Keep each note tight
  // and concrete - it costs context on every reminder.
  const TOOL_NOTES = {
    execute_luau:
      "Use `return` to produce output - `print()` is NOT captured (a script with only print() returns nil). " +
      "Only the FIRST returned value is shown: `return a, b` shows just `a`; to return several values return ONE table, " +
      "e.g. `return {ok=true, n=3}` (tables come back as JSON). " +
      "Runs synchronously with a ~20s budget: a brief `task.wait(1)` is fine, but anything that can block or never resolve will TIME OUT. " +
      "ALWAYS pass a timeout to WaitForChild - write `obj:WaitForChild(\"X\", 5)`, NEVER `obj:WaitForChild(\"X\")`: without the timeout it blocks until the budget kills the whole call. " +
      "Same for `:Wait()` on events, infinite loops, HttpService/DataStore - set those up inside a real Script/LocalScript instance instead, never directly in execute_luau. " +
      "Property types must match exactly (e.g. Position needs Vector3.new(...), not a string). " +
      "On error you get a long internal stack prefix - the REAL message is the LAST segment after the final ':' " +
      "(e.g. '... : Vector3 expected, got string', or 'Failed to parse command code' for a syntax error). " +
      "Create objects with Instance.new and set .Parent; reach services via game:GetService(\"Name\").",
    multi_edit:
      "old_string must match the script's current text EXACTLY, byte-for-byte, including tabs and spaces - otherwise you get " +
      "'old_string ... not found in current content'. ALWAYS script_read the file FIRST and copy the exact text. " +
      "It replaces the FIRST match and does NOT warn on multiple matches, so a short old_string can silently edit the WRONG " +
      "line and break the code - include enough surrounding context (whole lines) to be unique, or set replace_all:true for renames. " +
      "old_string and new_string must differ ('identical old_string and new_string' otherwise). " +
      "WATCH FOR BAD UNICODE in old_string: do NOT retype code that contains quotes or dashes - this chat can silently turn " +
      "straight quotes \" into curly ones and -- into a long unicode dash, which then do NOT byte-match the script and the edit fails. " +
      "Paste old_string verbatim from script_read. (new_string may contain unicode safely - it is written as-is.) " +
      "Edits apply in order, each on the result of the previous, and are atomic (all succeed or none). " +
      "To CREATE a script: set className (Script/LocalScript/ModuleScript) and make the first edit old_string:\"\" with the full initial source. " +
      "datamodel_type must be \"Edit\".",
    inspect_instance:
      "Path is dot-notation and case-insensitive, e.g. 'Workspace.Model.Part'. Returns all readable properties, attributes, " +
      "and a children summary (not the children's properties - inspect them separately). If several instances share the path, " +
      "up to 20 matches are returned. Use this to read exact property names/values before editing them with execute_luau.",
    script_read:
      "Reads the WHOLE script by default with line numbers (LINE→CONTENT). Use it before multi_edit so your old_string " +
      "matches exactly. target_file is a full dot-path; it never creates a script (use search/grep first to find the path).",
    user_keyboard_input:
      "Simulates a real player typing during PLAY. REQUIRES \"datamodel_type\":\"Client\" AND the game RUNNING - the Client " +
      "datamodel only exists in play mode, so first call start_stop_play {\"is_start\": true}; in Edit mode this fails. " +
      "(UqBOAT auto-fills datamodel_type:\"Client\" if you omit it, but the game must still be running.) " +
      "\"actions\" is an ORDERED array of OBJECTS - each step MUST be {\"action\": ...}, NOT a bare string (a missing/misnamed action " +
      "gives 'Unknown ... action: nil'). action is one of: keyDown | keyUp | keyPress (down+up) | textInput | wait. " +
      "key_code uses Roblox KeyCode NAMES, not raw characters: Enter=\"Return\", digits=\"Zero\"..\"Nine\", letters=single uppercase " +
      "\"A\"..\"Z\", plus \"Space\", \"Backspace\", \"Tab\", arrows \"Up\"/\"Down\"/\"Left\"/\"Right\", modifiers \"LeftShift\"/\"LeftControl\"/\"LeftAlt\" " +
      "- REQUIRED on keyDown/keyUp/keyPress ('key_code is required' otherwise). To type a whole string use ONE textInput step with " +
      "\"text_inputs\":\"hello\" instead of many keyPress. A \"wait\" step MUST carry \"wait_time_ms\" (0-10000) ('wait_time_ms is required " +
      "for wait action' otherwise). Optional \"instance_path\" routes input to a focused GUI element and must start with game, LocalPlayer " +
      "or Workspace (e.g. \"LocalPlayer.PlayerGui.Menu.NameBox\"); omit it to send to whatever currently has focus. " +
      "Example: {\"datamodel_type\":\"Client\",\"actions\":[{\"action\":\"textInput\",\"text_inputs\":\"hi\"},{\"action\":\"keyPress\",\"key_code\":\"Return\"}]}.",
    generate_mesh:
      "Unlike generate_procedural_model, this call YIELDS: it blocks until the AI mesh generation finishes and only then " +
      "returns the result (the finished mesh) - there is no separate poll/wait step needed, just wait for the response.",
    generate_procedural_model:
      "Unlike generate_mesh, this call does NOT yield: it returns immediately with a generationId while the model builds " +
      "in the background and auto-inserts into the workspace once done - do NOT run other commands assuming the model already " +
      "exists yet. Do NOT call wait_job_finished as a reflex right after this - but DO call it (pass the generationId) whenever " +
      "you actually need the finished result before continuing: either the user explicitly asked to wait, or your next step " +
      "depends on the model being done (e.g. editing/coloring it, checking its geometry).",
    user_mouse_input:
      "Simulates real player mouse actions during PLAY. Same requirement as user_keyboard_input: \"datamodel_type\":\"Client\" (auto-filled " +
      "if omitted) AND the game RUNNING (start_stop_play {\"is_start\": true} first; fails in Edit mode). " +
      "\"actions\" is an ORDERED array of OBJECTS - each step MUST be {\"action\": ...}, NOT a bare string (a missing/misnamed action gives " +
      "'Unknown mouse action: nil'). action is one of: moveTo | mouseButtonDown | mouseButtonUp | mouseButtonClick | scrollUp | scrollDown | wait. " +
      "You MUST establish a position BEFORE any click/scroll: the FIRST step needs \"x\"/\"y\" (screen pixels) OR \"instance_path\" " +
      "(starts with game/LocalPlayer/Workspace; if set, x/y are ignored) - else 'Either x and y, instance_path, or a prior action ... is " +
      "required'. Later steps may omit x/y and reuse the last position (click then scroll at the same spot). " +
      "mouseButtonDown/Up/Click need \"mouse_button\":\"left\" or \"right\". A \"wait\" step needs \"wait_time_ms\" (0-10000). " +
      "Example: {\"datamodel_type\":\"Client\",\"actions\":[{\"action\":\"mouseButtonClick\",\"mouse_button\":\"left\",\"instance_path\":\"LocalPlayer.PlayerGui.Menu.PlayBtn\"}]}.",
    list_offline_skills:
      "Read-only built-in extension command (works offline without Studio MCP or GitHub). Optional params: \"skill\" (\"stud_ui\" | \"modelmaker\" | \"referans_studio\" | \"vfx_pack\") and \"query\" (substring filter) to list bundled skill files.",
    read_offline_skill:
      "Built-in extension command to read a bundled skill guide, HTML example showcase, Luau module, or reference image. Params: \"path\" (e.g. \"stud_ui/SKILL.md\", \"modelmaker/sonskills/SKILL.md\", \"referans_studio/sonskills/SKILL.md\", \"vfx_pack/SKILL.md\", \"skills_rehberi.html\"). Reading \"stud_ui/SKILL.md\" or \"vfx_pack/SKILL.md\" returns the full HTML-formatted guide + all examples AND automatically installs the ModuleScripts into game.ReplicatedStorage in Studio!",
    install_offline_skill:
      "Built-in extension command that directly installs full skill ModuleScripts into Roblox Studio (game.ReplicatedStorage.StudUI, StudMotion, CheckUIIcons, ServerStorage.StudExamples.*, and game.ReplicatedStorage.UqVFXLibrary). Params: {\"skill\": \"all\" | \"stud_ui\" | \"vfx_pack\"}.",
    team_status:
      "Built-in multi-tab Team Mode command (supports unlimited open tabs). Lists all connected AI tabs (model-based Agent ID such as GL1/GT1/SH1/GL2, model name, role, busy/idle state), the shared Task Board, and recent team messages / Studio edits.",
    team_assign_task:
      "Built-in Team Mode command to delegate tasks to any connected AI tabs working on the same Studio place. Params: either {\"target\": \"GL1\"|\"GT1\"|\"SH1\"|\"luna\"|\"terra\"|\"ui\"|\"builder\"|\"scripter\"|\"animator\"|\"combat\"|\"world\"|\"auto\", \"title\": \"...\", \"instructions\": \"...\", \"wait\": true} or {\"tasks\": [{\"target\": \"...\", \"title\": \"...\", \"instructions\": \"...\"}], \"wait\": true}. When wait:true, blocks until the teammate tab(s) finish and returns their results.",
    team_wait_tasks:
      "Built-in Team Mode command to wait for all pending/in-progress delegated team tasks to finish and return the updated Task Board.",
    team_broadcast:
      "Built-in Team Mode command to broadcast a message or architectural note to all other connected AI tabs: {\"message\": \"...\", \"to\": \"ALL\"}.",
    team_complete_task:
      "Built-in Team Mode command for a worker tab to mark its assigned task as completed and broadcast the summary: {\"task_id\": 1, \"result\": \"...\"}.",
  };

  // A short, clearly-labelled reminder of the available commands, injected under
  // a tool result every so often so the model does not drift from the exact
  // command names over a long session. It is explicitly framed as an automatic
  // UqBOAT reminder (NOT a user message and NOT a new command to run).
  function toolsReminder(tools) {
    const toolsString =
      "  list_commands() - list all available Roblox Studio commands with full parameter details\n" +
      "  list_offline_skills(skill, query) - list bundled offline skill packages and files (modelmaker, referans_studio, stud_ui)\n" +
      "  read_offline_skill(path, offset, limit) - read a bundled offline skill file or reference image by relative path\n" +
      "  team_status() - inspect connected Multi-AI Team tabs, roles, tasks, and shared messages\n" +
      "  team_assign_task(target, title, instructions, tasks, wait) - delegate work to other connected AI tabs\n" +
      "  team_wait_tasks(task_ids, timeout_ms) - wait for delegated team tasks to finish\n" +
      "  team_broadcast(message, to) - broadcast a note/message to all connected AI tabs\n" +
      "  team_complete_task(task_id, result) - mark an assigned team task as finished\n" +
      compactTools(tools);
    return (
      "\n\n────────────────────────────────\n" +
      "(System note from UqBOAT - this is an automatic REMINDER, not a request and not a new result. " +
      "Do NOT reply to it or run any command because of it; just keep it in mind for your next command.)\n" +
      "Reminder of the Roblox Studio commands (use exact names and parameter keys; " +
      "for other connected apps call list_mcp_servers):\n" +
      toolsString
    );
  }

  // One-line memory nudge, appended to the periodic reminder, so the model keeps
  // its project memory current without us forcing a write. Clearly framed as an
  // optional reminder, NOT a command to run right now.
  function memoryNudge() {
    return (
      "(Reminder: if you've learned anything DURABLE about this project since your last memory update " +
      "(architecture, where things live, conventions, decisions, user preferences), update your shared project memory at " +
      "game.ServerStorage.UqBOAT.Memory with multi_edit - only useful, lasting facts. If nothing changed, ignore this.)"
    );
  }

  return {
    APP_NAME,
    SYS_MARKER,
    RESEND_MARKER,
    FEEDBACK,
    toolCategory,
    buildSystemPrompt,
    compactTools,
    toolsReminder,
    memoryNudge,
    TOOL_NOTES,
  };
})();
