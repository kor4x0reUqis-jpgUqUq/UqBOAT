--!nonstrict
-- Default: do not modify CurrentCamera, type, subject, CFrame, focus or FOV.
-- An explicit optional capture runs in a try/finally-like guard; no render-step binding.
local C = {}
local fields={"CameraType","CameraSubject","CFrame","Focus","FieldOfView"}
function C.snapshot(camera)
    if not camera then return {camera=nil} end
    local s={camera=camera}
    for _,k in ipairs(fields) do s[k]=camera[k] end
    return s
end
function C.unchanged(snapshot,camera)
    if snapshot.camera~=camera then return false,"CurrentCamera object changed" end
    if not camera then return true end
    for _,k in ipairs(fields) do if snapshot[k]~=camera[k] then return false,k.." changed" end end
    return true
end
function C.withPose(getCamera,pose,callback,acknowledgement)
    assert(acknowledgement=="KAMERA_POZUNU_GECICI_KULLAN","Camera changes are opt-in only")
    assert(type(callback)=="function","A bounded capture callback is required")
    local camera=getCamera();assert(camera,"No CurrentCamera")
    local before=C.snapshot(camera)
    local result=table.pack(xpcall(function()
        if pose.CameraType then camera.CameraType=pose.CameraType end
        if pose.CFrame then camera.CFrame=pose.CFrame end
        if pose.Focus then camera.Focus=pose.Focus end
        if pose.FieldOfView then camera.FieldOfView=pose.FieldOfView end
        return callback(camera)
    end,debug.traceback))
    local restoreErrors={}
    -- Never replace workspace.CurrentCamera or overwrite a newly selected camera.
    local stillCurrent=getCamera()==camera
    do
        for _,k in ipairs({"CFrame","Focus","FieldOfView","CameraSubject","CameraType"}) do
            -- CameraSubject cannot be set to nil. Nil is therefore never assigned.
            if before[k]~=nil then
                local ok,err=pcall(function() camera[k]=before[k] end)
                if not ok then table.insert(restoreErrors,k..": "..tostring(err)) end
            end
        end
    end
    if not stillCurrent then table.insert(restoreErrors,"CurrentCamera changed during capture; new camera was not touched") end
    local equal,changed=C.unchanged(before,camera)
    if not equal then table.insert(restoreErrors,"Snapshot not fully restored: "..tostring(changed)) end
    if #restoreErrors>0 then error("Camera restoration requires manual review: "..table.concat(restoreErrors," | ")) end
    if not result[1] then error(result[2],0) end
    return table.unpack(result,2,result.n)
end
return C
