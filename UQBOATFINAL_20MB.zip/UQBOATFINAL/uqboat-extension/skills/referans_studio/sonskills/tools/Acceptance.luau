--!nonstrict
-- Pure, testable acceptance state machine. No Roblox calls. A PASS count is not a visual pass.
local A = {}
function A.new(config)
    assert(type(config)=="table" and type(config.requiresStuds)=="boolean","Explicit style contract required")
    local s={state="NEW",requiresStuds=config.requiresStuds,sourceModelId=config.sourceModelId,candidates={},history={"NEW"}}
    local function move(name) s.state=name;table.insert(s.history,name) end
    function s:Resolved(candidates)
        assert(self.requiresStuds,"Resolution not relevant to explicit no-studs mode")
        assert(#candidates>0,"BLOCKED_ASSET: no real images")
        for _,c in ipairs(candidates) do
            assert(c.assetTypeId==1 and c.id~=self.sourceModelId and type(c.uri)=="string","Model/Decal is not an image")
        end
        self.candidates=candidates;self.selected=nil;self.approved=false;move("SOURCE_RESOLVED")
    end
    function s:Coupon(index,profile,signature,fetched)
        assert(self.requiresStuds and self.candidates[index],"Select a listed image explicitly")
        assert(fetched==true,"BLOCKED_FETCH")
        assert(profile.tileU>0 and profile.tileV>0 and profile.transparency>=0 and profile.transparency<1,"Invalid physical tile/contrast")
        assert(type(signature)=="string" and #signature>0,"Coupon signature required")
        self.selected=self.candidates[index];self.profile=profile;self.signature=signature;self.fetched=true;self.approved=false
        move("COUPON_READY")
    end
    function s:Approve(token,liveSignature)
        assert(self.state=="COUPON_READY","Live coupon required; source resolution is not visual approval")
        assert(token=="KUPONU_GORSEL_OLARAK_ONAYLIYORUM","Human visual acknowledgement required")
        assert(liveSignature==self.signature,"Coupon/image/profile changed; build a new coupon")
        self.approved=true;move("VISUAL_ACKNOWLEDGED")
    end
    function s:ExplicitNoStuds(token,reason)
        assert(not self.requiresStuds,"No-studs cannot bypass a required studs contract")
        assert(token=="KULLANICI_ACIKCA_STUDS_ISTEMIYOR" and type(reason)=="string" and #reason>0,"Explicit user style exception required")
        self.noStudsReason=reason;move("EXPLICIT_NO_STUDS")
    end
    function s:BeginInstall(liveSignature)
        if self.requiresStuds then
            assert(self.approved and self.fetched and self.selected,"BLOCKED: do not install an untextured final model")
            assert(liveSignature==self.signature,"Live coupon became stale")
        else assert(self.noStudsReason,"No implicit texture fallback") end
        self.applied=nil;self.expected=nil
        move("STAGING")
    end
    function s:Applied(actual,expected)
        assert(self.state=="STAGING","Staging required")
        assert(actual==expected,"Texture face omissions/duplicates")
        if self.requiresStuds then assert(expected>0,"Required texture was not actually applied") end
        self.applied=actual;self.expected=expected
    end
    function s:Commit(report)
        assert(self.state=="STAGING" and self.applied~=nil,"Apply/audit actual staged output before commit")
        assert(report.geometryPass==true and report.texturePass==true,"Failed geometry/texture audit")
        assert(report.cameraUntouched==true,"Installer changed user camera")
        assert(report.foreignCode==false and report.primaryInstaller==true,"Unsafe source or wrong delivery")
        self.report=report;move("COMMITTED_REVIEW_PENDING")
    end
    function s:AbortInstall(reason)
        self.lastError=reason;self.applied=nil;self.expected=nil
        move(self.requiresStuds and (self.approved and "VISUAL_ACKNOWLEDGED" or "SOURCE_RESOLVED") or "EXPLICIT_NO_STUDS")
    end
    function s:FinalAcceptance(evidence)
        assert(self.state=="COMMITTED_REVIEW_PENDING","Commit first")
        for _,key in ipairs({"studioOpen","studioAPI","referenceVisual","criticalCloseups","cameraControl","assetAccess"}) do
            assert(evidence[key]=="PASS","Not accepted: "..key)
        end
        assert(evidence.fps=="PASS" or evidence.fps=="NOT_REQUESTED_WITH_DISCLOSURE","Do not invent FPS")
        move("USER_ACCEPTED_SCOPE")
    end
    return s
end
return A
