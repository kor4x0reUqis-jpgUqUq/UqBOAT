--!nonstrict
-- Portable numeric implementation; no Roblox globals, assets or runtime animation.
-- Units: stud; vectors {x,y,z}; row-major 3x3 right-handed rotation matrices.
local M = {}
function M.add(a,b) return {a[1]+b[1],a[2]+b[2],a[3]+b[3]} end
function M.sub(a,b) return {a[1]-b[1],a[2]-b[2],a[3]-b[3]} end
function M.mul(a,s) return {a[1]*s,a[2]*s,a[3]*s} end
function M.dot(a,b) return a[1]*b[1]+a[2]*b[2]+a[3]*b[3] end
function M.cross(a,b) return {a[2]*b[3]-a[3]*b[2],a[3]*b[1]-a[1]*b[3],a[1]*b[2]-a[2]*b[1]} end
function M.length(a) return math.sqrt(M.dot(a,a)) end
function M.unit(a)
    local n=M.length(a);assert(n>1e-12,"Zero-length direction");return M.mul(a,1/n)
end
function M.identity() return {1,0,0,0,1,0,0,0,1} end
function M.transpose(r) return {r[1],r[4],r[7],r[2],r[5],r[8],r[3],r[6],r[9]} end
function M.rotate(r,v)
    return {r[1]*v[1]+r[2]*v[2]+r[3]*v[3],r[4]*v[1]+r[5]*v[2]+r[6]*v[3],r[7]*v[1]+r[8]*v[2]+r[9]*v[3]}
end
function M.matmul(a,b)
    local r={}
    for i=0,2 do for j=0,2 do
        local v=0;for k=0,2 do v=v+a[i*3+k+1]*b[k*3+j+1] end
        r[i*3+j+1]=v
    end end
    return r
end
function M.ry(degrees)
    local a=math.rad(degrees);local c,s=math.cos(a),math.sin(a)
    return {c,0,s,0,1,0,-s,0,c}
end
function M.world(origin,r,localPoint,scale)
    assert(not scale or scale>0,"Positive uniform scale required")
    return M.add(origin,M.rotate(r,M.mul(localPoint,scale or 1)))
end
function M.localPoint(origin,r,worldPoint,scale)
    return M.mul(M.rotate(M.transpose(r),M.sub(worldPoint,origin)),1/(scale or 1))
end
function M.det(r)
    return r[1]*(r[5]*r[9]-r[6]*r[8])-r[2]*(r[4]*r[9]-r[6]*r[7])+r[3]*(r[4]*r[8]-r[5]*r[7])
end
function M.rotationValid(r,tol)
    tol=tol or 1e-6
    local rt=M.matmul(M.transpose(r),r);local id=M.identity()
    for i=1,9 do if math.abs(rt[i]-id[i])>tol then return false end end
    return math.abs(M.det(r)-1)<=tol -- reflections are NOT rotations
end
function M.axes(r) return {{r[1],r[4],r[7]},{r[2],r[5],r[8]},{r[3],r[6],r[9]}} end
function M.obbContact(a,b,tolerance)
    local eps=tolerance or 1e-5;assert(eps>=0,"Negative tolerance")
    local aa,bb=M.axes(a.r),M.axes(b.r);local axes={aa[1],aa[2],aa[3],bb[1],bb[2],bb[3]}
    for i=1,3 do for j=1,3 do table.insert(axes,M.cross(aa[i],bb[j])) end end
    local delta=M.sub(b.p,a.p);local greatestGap=-math.huge
    for _,raw in ipairs(axes) do
        local n=M.length(raw)
        if n>1e-10 then
            local axis=M.mul(raw,1/n);local ra,rb=0,0
            for j=1,3 do ra=ra+math.abs(M.dot(axis,aa[j]))*a.s[j]/2;rb=rb+math.abs(M.dot(axis,bb[j]))*b.s[j]/2 end
            local gap=math.abs(M.dot(delta,axis))-ra-rb;greatestGap=math.max(greatestGap,gap)
            if gap>eps then return false,gap end
        end
    end
    return true,greatestGap
end
function M.segmentOBB(a,b,box,tol)
    local e=tol or 1e-7;local inv=M.transpose(box.r)
    a=M.rotate(inv,M.sub(a,box.p));b=M.rotate(inv,M.sub(b,box.p))
    local d=M.sub(b,a);local lo,hi=0,1
    for j=1,3 do
        local h=box.s[j]/2
        if math.abs(d[j])<1e-12 then
            if math.abs(a[j])>h+e then return false end
        else
            local u,v=(-h-a[j])/d[j],(h-a[j])/d[j]
            lo=math.max(lo,math.min(u,v));hi=math.min(hi,math.max(u,v))
            if lo>hi+e then return false end
        end
    end
    return true,lo,hi
end
function M.segmentTriangle(a,b,v0,v1,v2,tolerance)
    local eps=tolerance or 1e-8;local d=M.sub(b,a);local e1=M.sub(v1,v0);local e2=M.sub(v2,v0)
    local h=M.cross(d,e2);local det=M.dot(e1,h)
    if math.abs(det)<eps then return false end
    local f=1/det;local s=M.sub(a,v0);local u=f*M.dot(s,h)
    if u< -eps or u>1+eps then return false end
    local q=M.cross(s,e1);local v=f*M.dot(d,q)
    if v< -eps or u+v>1+eps then return false end
    local t=f*M.dot(e2,q);return t>=-eps and t<=1+eps,t
end
function M.lookBasis(eye,target,up)
    local forward=M.unit(M.sub(target,eye));up=up or {0,1,0}
    if math.abs(M.dot(forward,M.unit(up)))>.999 then up={0,0,1} end
    if math.abs(M.dot(forward,M.unit(up)))>.999 then up={1,0,0} end
    local right=M.unit(M.cross(forward,up));local actualUp=M.cross(right,forward);local back=M.mul(forward,-1)
    return {right[1],actualUp[1],back[1],right[2],actualUp[2],back[2],right[3],actualUp[3],back[3]}
end
function M.project(point,camera)
    local r=M.lookBasis(camera.eye,camera.target,camera.up)
    local q=M.rotate(M.transpose(r),M.sub(point,camera.eye));local depth=-q[3]
    if depth<=0 then return nil,"BEHIND_CAMERA" end
    local t=math.tan(math.rad(camera.fovY)/2);local aspect=camera.width/camera.height
    return {.5+q[1]/(2*depth*t*aspect),.5-q[2]/(2*depth*t),depth}
end
function M.weightedScreenRMS(samples)
    assert(#samples>0,"No anchors");local total,sum=0,0
    for _,s in ipairs(samples) do
        local w=s.weight or 1;assert(w>0,"Positive weight required")
        local dx,dy=s.actual[1]-s.expected[1],s.actual[2]-s.expected[2]
        sum=sum+w*(dx*dx+dy*dy);total=total+w
    end
    return math.sqrt(sum/total)
end
function M.fitScale(measurements)
    local num,den=0,0
    for _,s in ipairs(measurements) do
        local w=s.weight or 1;assert(s.relative>0 and s.known>0 and w>0,"Invalid scale measurement")
        num=num+w*s.relative*s.known;den=den+w*s.relative*s.relative
    end
    assert(den>0,"Scale is not identifiable without known anchors")
    return num/den
end
function M.srgbToLinear(x)
    assert(x>=0 and x<=1,"sRGB normalized 0..1")
    if x<=.04045 then return x/12.92 end
    return ((x+.055)/1.055)^2.4
end
function M.linearToSrgb(x)
    if x<=.0031308 then return 12.92*x end
    return 1.055*x^(1/2.4)-.055
end
function M.tileSize(motifPitch,motifsPerImageTile)
    assert(motifPitch>0 and motifsPerImageTile>0,"Positive motif pitch and count required")
    return motifPitch*motifsPerImageTile
end
-- Closed, open-top hollow shell: outer/inner sides, end walls, gunwales and keel.
-- No Blender/mesh importer. This is numeric data; engine mesh creation is a separate gate.
function M.hullMesh(stations,keelY,topY,thickness)
    assert(#stations>=2 and topY>keelY and thickness>0,"Invalid hull parameters")
    local verts,faces={},{};local n=#stations
    assert(stations[2].x-stations[1].x>2*thickness and stations[n].x-stations[n-1].x>2*thickness,"End thickness exceeds station spacing")
    local function section(x,w,bottom)
        assert(w>1e-6,"Interior width collapsed")
        local h=topY-bottom;local hw=w/2
        return {{x,topY,-hw},{x,bottom+.4*h,-hw},{x,bottom,-.70*hw},{x,bottom,.70*hw},{x,bottom+.4*h,hw},{x,topY,hw}}
    end
    local outer,inner={},{}
    for j,s in ipairs(stations) do
        if j>1 then assert(s.x>stations[j-1].x,"Stations must increase along +X") end
        assert(s.width>2*thickness,"Thickness collapses interior")
        local ox=s.x;local ix=ox+(j==1 and thickness or (j==n and -thickness or 0))
        local oo=section(ox,s.width,keelY);local ii=section(ix,s.width-2*thickness,keelY+thickness)
        outer[j]={};inner[j]={}
        for k=1,6 do table.insert(verts,oo[k]);outer[j][k]=#verts end
        for k=1,6 do table.insert(verts,ii[k]);inner[j][k]=#verts end
    end
    local function tri(a,b,c) table.insert(faces,{a,b,c}) end
    local function quad(a,b,c,d) tri(a,b,c);tri(a,c,d) end
    for j=1,n-1 do
        for k=1,5 do
            quad(outer[j][k],outer[j+1][k],outer[j+1][k+1],outer[j][k+1])
            quad(inner[j][k+1],inner[j+1][k+1],inner[j+1][k],inner[j][k])
        end
        quad(outer[j][1],inner[j][1],inner[j+1][1],outer[j+1][1])
        quad(outer[j][6],outer[j+1][6],inner[j+1][6],inner[j][6])
    end
    for k=2,5 do tri(outer[1][1],outer[1][k],outer[1][k+1]);tri(outer[n][1],outer[n][k+1],outer[n][k]) end
    for k=2,5 do tri(inner[1][1],inner[1][k+1],inner[1][k]);tri(inner[n][1],inner[n][k],inner[n][k+1]) end
    quad(outer[1][1],outer[1][6],inner[1][6],inner[1][1])
    quad(outer[n][6],outer[n][1],inner[n][1],inner[n][6])
    -- Correct signed winding globally. Tests also check edge direction and self-consistency.
    local volume=0
    for _,f in ipairs(faces) do volume=volume+M.dot(verts[f[1]],M.cross(verts[f[2]],verts[f[3]]))/6 end
    if volume<0 then for _,f in ipairs(faces) do f[2],f[3]=f[3],f[2] end;volume=-volume end
    return {vertices=verts,triangles=faces,volume=volume,opening="INTENTIONAL_OPEN_TOP",stations=stations,thickness=thickness}
end
return M
