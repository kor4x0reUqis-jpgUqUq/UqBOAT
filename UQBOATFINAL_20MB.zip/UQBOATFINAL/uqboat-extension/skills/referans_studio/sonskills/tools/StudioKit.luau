--!nonstrict
-- Actual Studio EDIT adapter. Assembled installers inline this factory and its dependencies.
-- No foreign require/loadstring, HTTP script, filesystem or .rbx* file dependency.
return function(Math3,Acceptance,CameraGuard,Environment)
local env=Environment or {game=game,workspace=workspace,Instance=Instance,Enum=Enum,Content=Content,Vector3=Vector3,Color3=Color3,CFrame=CFrame,typeof=typeof,task=task,warn=warn,print=print}
local game,workspace,Instance,Enum,Content=env.game,env.workspace,env.Instance,env.Enum,env.Content
local Vector3,Color3,CFrame,typeof,task=env.Vector3,env.Color3,env.CFrame,env.typeof,env.task
local warn,print=env.warn,env.print
local K = {}
local RunService=game:GetService("RunService")
local ContentProvider=game:GetService("ContentProvider")
local Marketplace=game:GetService("MarketplaceService")
local ChangeHistory=game:GetService("ChangeHistoryService")
local HttpService=game:GetService("HttpService")
local FACES={
 {name="Right",bit=1,normal=Enum.NormalId.Right,axes={"Z","Y"}},
 {name="Top",bit=2,normal=Enum.NormalId.Top,axes={"X","Z"}},
 {name="Back",bit=4,normal=Enum.NormalId.Back,axes={"X","Y"}},
 {name="Left",bit=8,normal=Enum.NormalId.Left,axes={"Z","Y"}},
 {name="Bottom",bit=16,normal=Enum.NormalId.Bottom,axes={"X","Z"}},
 {name="Front",bit=32,normal=Enum.NormalId.Front,axes={"X","Y"}},
}
local PREFIX="MM4_Studs_"
local function editOnly()
 assert(RunService:IsStudio() and not RunService:IsRunning(),"Studio EDIT Command Bar required; stop Play/Run")
end
local function contentURI(value)
 if type(value)=="string" then return value end
 if typeof(value)=="Content" then
  local ok,u=pcall(function() return value.Uri end)
  if ok and type(u)=="string" then return u end
 end
 return nil
end
local function imageID(uri)
 if type(uri)~="string" then return nil end
 local s=string.match(uri,"^%s*(.-)%s*$")
 local id=string.match(s,"^rbxassetid://(%d+)$")
 if not id then
  local host,query=string.match(s,"^https?://([^/]+)/asset/?%?(.*)$")
  if host=="www.roblox.com" or host=="roblox.com" then
   id=string.match("&"..query,"[&]id=(%d+)[&]?")
  end
 end
 local n=tonumber(id);if n and n>0 and n%1==0 then return n end
 return nil
end
local function info(id) return Marketplace:GetProductInfoAsync(id,Enum.InfoType.Asset) end
local function safeImageStrings(id)
 local roots={};local output={}
 local ok,err=xpcall(function()
  roots=game:GetObjects("rbxassetid://"..tostring(id)) -- PluginSecurity: EDIT Command Bar
  for _,root in ipairs(roots) do
   assert(root.Parent==nil,"Foreign root unexpectedly parented")
   if root:IsA("LuaSourceContainer") then root:Destroy() else
    for _,x in ipairs(root:GetDescendants()) do if x:IsA("LuaSourceContainer") then x:Destroy() end end
    local list={root};for _,x in ipairs(root:GetDescendants()) do table.insert(list,x) end
    for _,x in ipairs(list) do
     local names={}
     if x:IsA("Decal") then names={"TextureContent","ColorMapContent","Texture","ColorMap"}
     elseif x:IsA("MeshPart") then names={"TextureContent","TextureID"}
     elseif x:IsA("SpecialMesh") then names={"TextureId"}
     elseif x:IsA("SurfaceAppearance") or x:IsA("MaterialVariant") then names={"ColorMapContent","ColorMap"}
     elseif x:IsA("ImageLabel") or x:IsA("ImageButton") then names={"ImageContent","Image"} end
     for _,property in ipairs(names) do
      local readable,value=pcall(function() return x[property] end)
      local uri=readable and contentURI(value) or nil
      if uri and uri~="" then table.insert(output,{uri=uri,path=x:GetFullName(),property=property}) end
     end
    end
   end
  end
 end,debug.traceback)
 -- The finally-equivalent cleanup also runs when property/metadata inspection fails.
 for _,root in ipairs(roots) do pcall(function() root:Destroy() end) end
 if not ok then error("BLOCKED_ASSET: "..tostring(err),0) end
 return output
end
local function resolveModel(sourceID)
 local source=info(sourceID);assert(source.AssetTypeId==10,"Configured source must still be Model(10)")
 local candidates,seen,visited={},{},{}
 local function resolve(items,chain)
  for _,item in ipairs(items) do
   local id=imageID(item.uri)
   if id and id~=sourceID then
    local ok,metadata=pcall(info,id)
    if not ok then warn("Image metadata denied",id,metadata)
    elseif metadata.AssetTypeId==1 and not seen[id] then
     seen[id]=true;table.insert(candidates,{id=id,uri="rbxassetid://"..id,assetTypeId=1,name=metadata.Name,sourcePath=chain.." / "..item.path,sourceProperty=item.property})
    elseif metadata.AssetTypeId==13 and not visited[id] then
     visited[id]=true;resolve(safeImageStrings(id),chain.." -> Decal#"..id)
    elseif metadata.AssetTypeId~=1 and metadata.AssetTypeId~=13 then warn("Rejected non-image content",id,metadata.AssetTypeId) end
   end
  end
 end
 resolve(safeImageStrings(sourceID),"Model#"..sourceID)
 table.sort(candidates,function(a,b) return a.id<b.id end)
 return candidates
end
local function fetch(uri)
 local success=false
 local events=0;local failed=false
 local ok,err=pcall(function()
  ContentProvider:PreloadAsync({uri},function(_,status)
   events=events+1;if status~=Enum.AssetFetchStatus.Success then failed=true end
  end)
 end)
 success=ok and events>0 and not failed
 assert(success,"BLOCKED_FETCH: "..tostring(err));return true
end
local function profileCopy(p)
 assert(type(p)=="table","Specify actual tile sizes, contrast and phase policy")
 assert(type(p.tileU)=="number" and type(p.tileV)=="number" and p.tileU>0 and p.tileV>0 and p.tileU<math.huge and p.tileV<math.huge,"Finite positive tileU/tileV in studs")
 assert(p.transparency and p.transparency>=0 and p.transparency<1,"Contrast must be explicit")
 for _,x in ipairs({p.woodMinTransparency or p.transparency,p.thinMinTransparency or p.transparency}) do assert(type(x)=="number" and x>=0 and x<1,"Role contrast must remain visible 0..1 exclusive") end
 assert(p.phaseMode=="LOCAL_ZERO","This adapter supports LOCAL_ZERO only; do not claim world UV continuity")
 return {tileU=p.tileU,tileV=p.tileV,transparency=p.transparency,phaseMode=p.phaseMode,
  woodMinTransparency=p.woodMinTransparency or p.transparency,thinMinTransparency=p.thinMinTransparency or p.transparency}
end
local function signature(uri,p)
 return string.format("%s|%.9g|%.9g|%.9g|%s|%.9g|%.9g",uri,p.tileU,p.tileV,p.transparency,p.phaseMode,p.woodMinTransparency,p.thinMinTransparency)
end
local function transparency(part,face,p)
 local a=p.transparency
 if part:GetAttribute("MM4Role")=="WOOD" then a=math.max(a,p.woodMinTransparency) end
 if math.min(part.Size[face.axes[1]]/p.tileU,part.Size[face.axes[2]]/p.tileV)<.35 then a=math.max(a,p.thinMinTransparency) end
 return a
end
local function putTexture(part,face,uri,p)
 local t=Instance.new("Texture");t.Name=PREFIX..face.name;t.Face=face.normal
 -- Current Content API; TextureContent is serializable. Same verified URI, no invented asset.
 t.TextureContent=Content.fromUri(uri);t.StudsPerTileU=p.tileU;t.StudsPerTileV=p.tileV
 t.OffsetStudsU=0;t.OffsetStudsV=0;t.Color3=Color3.new(1,1,1);t.Transparency=transparency(part,face,p);t.Parent=part
 return t
end
local function auditTextures(model,uri,p,requiresStuds)
 local actual,expected,instances=0,0,0;local errors={};local perFace={}
 for _,face in ipairs(FACES) do perFace[face.name]=0 end
 for _,part in ipairs(model:GetDescendants()) do
  if part:IsA("BasePart") then
   local mask=part:GetAttribute("MM4Mask")
   assert(type(mask)=="number","Every part needs an explicit surface policy: "..part.Name)
   local own=0;for _,t in ipairs(part:GetChildren()) do if t:IsA("Texture") and string.sub(t.Name,1,#PREFIX)==PREFIX then own=own+1 end end
   local wantCount=0
   for _,face in ipairs(FACES) do
    local want=requiresStuds and bit32.band(mask,face.bit)~=0
    local t=part:FindFirstChild(PREFIX..face.name)
    if want then
     expected=expected+1;wantCount=wantCount+1
     if not t or not t:IsA("Texture") or t.Face~=face.normal or contentURI(t.TextureContent)~=uri then
      table.insert(errors,part.Name.." / "..face.name.." missing/wrong image or direction")
     elseif math.abs(t.StudsPerTileU-p.tileU)>1e-5 or math.abs(t.StudsPerTileV-p.tileV)>1e-5 or math.abs(t.Transparency-transparency(part,face,p))>1e-4 or t.Color3~=Color3.new(1,1,1) or t.OffsetStudsU~=0 or t.OffsetStudsV~=0 then
      table.insert(errors,part.Name.." / "..face.name.." scale/contrast/tint/phase mismatch")
     else actual=actual+1;perFace[face.name]=perFace[face.name]+1 end
    elseif t then table.insert(errors,part.Name.." excluded face has a texture") end
   end
   instances=instances+own
   if own~=wantCount then table.insert(errors,part.Name.." duplicate/unexpected texture layer") end
  end
 end
 return {pass=#errors==0,actual=actual,expected=expected,instances=instances,perFace=perFace,errors=errors}
end
local function assertSurfaceManifest(model,manifest)
 local seen={}
 for _,part in ipairs(model:GetDescendants()) do if part:IsA("BasePart") then
  local rule=manifest[part.Name];assert(rule and not seen[part.Name],"New/duplicate part requires a new surface contract")
  assert(part:IsA("Part") and part.Shape==Enum.PartType.Block,"Block adapter cannot certify curved/mesh faces")
  assert(part:GetAttribute("MM4Mask")==rule.mask and part:GetAttribute("MM4Role")==rule.role and part:GetAttribute("MM4Exclusion")==rule.reason,"Surface contract modified since creation/visual acknowledgement")
  seen[part.Name]=true
 end end
 for name in pairs(manifest) do assert(seen[name],"Installed/staged part removed: "..name) end
end
local function obb(part)
 assert(part:IsA("Part") and part.Shape==Enum.PartType.Block,"OBB is not the exact surface of a mesh/wedge/cylinder")
 local x,y,z,a,b,c,d,e,f,g,h,i=part.CFrame:GetComponents()
 return {p={x,y,z},s={part.Size.X,part.Size.Y,part.Size.Z},r={a,b,c,d,e,f,g,h,i}}
end
function K.new(config)
 editOnly();assert(type(config.builder)=="function","Complete build function required")
 assert(config.name and config.ownerKey and type(config.requiresStuds)=="boolean","Explicit name/ownership/style required")
 local installedSurfaceManifest=nil
 local kit={Config=config,Policy=Acceptance.new(config),CouponModel=nil,Root=nil,Checks={},Session=HttpService:GenerateGUID(false)}
 function kit:Resolve()
  editOnly();self.Policy.approved=false;local candidates=resolveModel(self.Config.sourceModelId);self.Policy:Resolved(candidates)
  for i,c in ipairs(candidates) do print(i,c.uri,c.name,c.sourcePath,c.sourceProperty) end
  print("RESOLVED ONLY. No candidate selected, no approval, no final geometry installed.")
  return candidates
 end
 function kit:Coupon(index,profile,origin)
  editOnly();local candidate=self.Policy.candidates[index];assert(candidate,"Select an actual listed candidate")
  self.Policy.approved=false
  local p=profileCopy(profile);fetch(candidate.uri)
  if self.CouponModel then self.CouponModel:Destroy() end
  local model=Instance.new("Model");model.Name="MM4_Coupon_"..self.Session
  model:SetAttribute("MM4Owner",self.Config.ownerKey)
  local colors={Color3.fromRGB(218,80,53),Color3.fromRGB(226,235,235),Color3.fromRGB(169,117,69),Color3.fromRGB(224,207,39),Color3.fromRGB(52,139,189)}
  local center=origin or Vector3.new(0,12,0)
  for j,color in ipairs(colors) do
   local part=Instance.new("Part");part.Name=(j==5 and "Inclined30" or "Flat"..j);part.Anchored=true;part.CanCollide=false
   part.Size=Vector3.new(6,6,6);part.CFrame=CFrame.new(center+Vector3.new((j-3)*9,0,0))*(j==5 and CFrame.Angles(0,0,math.rad(30)) or CFrame.new())
   part.Color=color;part.Material=Enum.Material.Plastic;part.TopSurface=Enum.SurfaceType.Smooth;part.BottomSurface=Enum.SurfaceType.Smooth
   part:SetAttribute("MM4Mask",63);part:SetAttribute("MM4Role",j==3 and "WOOD" or "MAIN")
   for _,face in ipairs(FACES) do putTexture(part,face,candidate.uri,p) end
   part.Parent=model
  end
  model:SetAttribute("ImageURI",candidate.uri);model:SetAttribute("VisualAcknowledged",false);model.Parent=workspace
  self.CouponModel=model;self.Profile=p
  self.Policy:Coupon(index,p,signature(candidate.uri,p),true)
  print("COUPON READY: inspect all 30 faces, wood/red/white/yellow and slope; camera NOT moved. Select coupon and press F manually if desired.")
  return model
 end
 function kit:Approve(token)
  editOnly();assert(self.CouponModel and self.CouponModel.Parent,"Live coupon required")
  local p=self.Profile;local selected=self.Policy.selected
  local r=auditTextures(self.CouponModel,selected.uri,p,true)
  assert(r.pass and r.expected==30,"Coupon changed: regenerate it")
  local sig=signature(selected.uri,p);self.Policy:Approve(token,sig);self.CouponModel:SetAttribute("VisualAcknowledged",true)
  print("Human visual acknowledgement recorded. Model still not installed.")
 end
 function kit:ExplicitNoStuds(token,reason) editOnly();self.Policy:ExplicitNoStuds(token,reason) end
 function kit:Install(token,replaceOwned)
  editOnly();assert(token=="ONAYLI_KURULUMU_BASLAT","Explicit install command required")
  local before=CameraGuard.snapshot(workspace.CurrentCamera)
  local uri=self.Policy.selected and self.Policy.selected.uri or nil
  local sig=uri and signature(uri,self.Profile) or nil
  if self.Config.requiresStuds then
   assert(self.CouponModel and self.CouponModel.Parent,"Keep live coupon until install")
   local cr=auditTextures(self.CouponModel,uri,self.Profile,true);assert(cr.pass and cr.expected==30,"Coupon changed")
   fetch(uri)
  end
  local old=workspace:FindFirstChild(self.Config.name)
  local oldName=old and old.Name or nil;local oldParent=old and old.Parent or nil
  if old then
   assert(old:GetAttribute("MM4Owner")==self.Config.ownerKey,"Refuse to replace a user/unowned model")
   assert(replaceOwned==true,"Owned model exists; pass true explicitly to replace after staging audit")
  end
  self.Policy:BeginInstall(sig)
  local stage=Instance.new("Model");stage.Name=self.Config.name;stage:SetAttribute("MM4Owner",self.Config.ownerKey);stage:SetAttribute("MM4Version","4.1.0")
  local byName,checks,surfaceManifest={},{},{};local scale=self.Config.scale or 1;assert(scale>0,"Positive geometry scale")
  local worldCF=self.Config.worldCFrame or CFrame.new()
  local ctx={Model=stage,Parts=byName,Checks=checks,Scale=scale,WorldCFrame=worldCF,ImageURI=uri,Profile=self.Profile,Env=env}
  function ctx:Part(spec)
   assert(type(spec.name)=="string" and not byName[spec.name],"Unique semantic part name required")
   assert(spec.size and spec.cframe and spec.color and type(spec.mask)=="number" and spec.role,"Explicit geometry/material/surface contract required")
   assert(not spec.shape or spec.shape=="Block","This adapter only supports exact Block surfaces; use an explicit mesh/CSG adapter")
   assert(spec.size.X>0 and spec.size.Y>0 and spec.size.Z>0,"Positive dimensions")
   assert(spec.mask>=0 and spec.mask<=63 and spec.mask%1==0,"6-bit face mask required")
   if spec.mask==0 then assert(type(spec.exclusionReason)=="string" and #spec.exclusionReason>0,"Explain every surface exception") end
   local p=Instance.new("Part");p.Name=spec.name;p.Anchored=true;p.Size=spec.size*scale
   p.CFrame=worldCF*CFrame.new(spec.cframe.Position*scale)*spec.cframe.Rotation
   p.Color=spec.color;p.Material=spec.material or Enum.Material.Plastic;p.Transparency=spec.alpha or 0
   p.CanCollide=spec.collide~=false;p.CanTouch=false;p.CanQuery=spec.query~=false;p.CastShadow=p.Transparency==0
   for _,face in ipairs(FACES) do p[face.name.."Surface"]=Enum.SurfaceType.Smooth end
   p:SetAttribute("MM4Mask",spec.mask);p:SetAttribute("MM4Role",spec.role);p:SetAttribute("MM4Exclusion",spec.exclusionReason or "")
   p:SetAttribute("MM4ShapeState","CLOSED_NATIVE_PRIMITIVE")
   p.Parent=stage;byName[spec.name]=p;surfaceManifest[spec.name]={mask=spec.mask,role=spec.role,reason=spec.exclusionReason or ""};return p
  end
  function ctx:Contact(a,b,tolerance)
   table.insert(checks,{kind="CONTACT",a=a,b=b,tolerance=(tolerance or 1e-5)*scale})
  end
  function ctx:OpenRay(a,b,names)
   table.insert(checks,{kind="OPEN_RAY",a=(worldCF*CFrame.new(a*scale)).Position,b=(worldCF*CFrame.new(b*scale)).Position,names=names})
  end
  local ok,err=xpcall(function()
   self.Config.builder(ctx)
   assert(next(byName),"Empty builder")
   assertSurfaceManifest(stage,surfaceManifest)
   for _,c in ipairs(checks) do
    if c.kind=="CONTACT" then
     assert(byName[c.a] and byName[c.b],"Contact references must exist")
     assert(Math3.obbContact(obb(byName[c.a]),obb(byName[c.b]),c.tolerance),"Disconnected "..c.a.." -> "..c.b)
    elseif c.kind=="OPEN_RAY" then
     local a,b={c.a.X,c.a.Y,c.a.Z},{c.b.X,c.b.Y,c.b.Z}
     for _,name in ipairs(c.names) do assert(byName[name],"Aperture part missing");assert(not Math3.segmentOBB(a,b,obb(byName[name])),"Blocked opening: "..name) end
    end
   end
   local count=0
   for _,part in pairs(byName) do
    if self.Config.requiresStuds then for _,face in ipairs(FACES) do
     if bit32.band(part:GetAttribute("MM4Mask"),face.bit)~=0 then putTexture(part,face,uri,self.Profile);count=count+1;if count%1500==0 then task.wait() end end
    end end
   end
   local audit=auditTextures(stage,uri,self.Profile,self.Config.requiresStuds)
   assert(audit.pass,table.concat(audit.errors,"\n"));self.Policy:Applied(audit.actual,audit.expected)
   local unchanged,why=CameraGuard.unchanged(before,workspace.CurrentCamera)
   assert(unchanged,"Camera snapshot changed during staging; no commit. "..tostring(why))
   local commitReport={geometryPass=true,texturePass=true,cameraUntouched=true,foreignCode=false,primaryInstaller=true,surfaceAudit=audit,contactChecks=#checks}
   stage:SetAttribute("MM4TextureStatus",self.Config.requiresStuds and "ACTUALLY_APPLIED_REFERENCE_REVIEW_PENDING" or "NO_STUDS_EXPLICIT_USER_STYLE")
   if uri then stage:SetAttribute("MM4VerifiedImageURI",uri);stage:SetAttribute("MM4TileU",self.Profile.tileU);stage:SetAttribute("MM4TileV",self.Profile.tileV) end
   stage:SetAttribute("MM4ReferenceVisual","PENDING");stage:SetAttribute("MM4FPS","NOT_MEASURED")
   pcall(function() ChangeHistory:SetWaypoint("MM4 before commit") end)
   stage.Parent=workspace
   if old then
    local backups=game:GetService("ServerStorage"):FindFirstChild("MM4_Backups")
    if not backups then backups=Instance.new("Folder");backups.Name="MM4_Backups";backups.Parent=game:GetService("ServerStorage") end
    old.Name=old.Name.."_"..self.Session;old.Parent=backups -- retain editable prior result; no silent deletion
   end
   self.Policy:Commit(commitReport)
   self.Root=stage;self.LastAudit=audit;installedSurfaceManifest=surfaceManifest
   pcall(function() ChangeHistory:SetWaypoint("MM4 after commit") end)
   print("Installed via standalone code with actual surface audit. Reference/closeup/FPS review remains PENDING.",audit.actual,audit.expected)
  end,debug.traceback)
  if not ok then
   if old then pcall(function() old.Name=oldName;old.Parent=oldParent end) end
   stage:Destroy();self.Policy:AbortInstall(tostring(err))
   error("STAGING ABORTED; existing scene retained. "..tostring(err),0)
  end
  return stage,self.LastAudit
 end
 function kit:AuditInstalled()
  editOnly();assert(self.Root and self.Root.Parent and installedSurfaceManifest,"No installed owned scene")
  assertSurfaceManifest(self.Root,installedSurfaceManifest)
  local uri=self.Policy.selected and self.Policy.selected.uri or nil
  if uri then assert(signature(uri,self.Profile)==self.Policy.signature,"Profile changed since acknowledgement") end
  local result=auditTextures(self.Root,uri,self.Profile,self.Config.requiresStuds)
  if self.Config.requiresStuds then assert(result.expected>0,"Required texture disappeared") end
  self.LastAudit=result;return result
 end
 function kit:RemoveCoupon()
  editOnly();if self.CouponModel then self.CouponModel:Destroy();self.CouponModel=nil end
  -- No camera reset necessary: coupon creation never touched the camera.
 end
 function kit:WithView(pose,callback,token)
  editOnly();return CameraGuard.withPose(function() return workspace.CurrentCamera end,pose,callback,token)
 end
 function kit:Status() return {state=self.Policy.state,history=self.Policy.history,sourceModelId=self.Config.sourceModelId,selected=self.Policy.selected,actuallyApplied=self.LastAudit,referenceVisual="PENDING",fps="NOT_MEASURED"} end
 return kit
end
return K
end
