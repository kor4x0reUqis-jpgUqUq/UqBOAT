-- Exact delivered reconstruction subset, PARTIAL POSITIVE ONLY. Not source-game dimensions or full-model gold.
-- Native camera/doku/code defects are not inherited; new wrapper is texture-gated and default camera read-only.
return function(ctx)
 local E=ctx.Env or {Vector3=Vector3,CFrame=CFrame,Color3=Color3,Enum=Enum}
 local pivot=ctx:Part({name="PositivePairOrigin",cframe=E.CFrame.new(),size=E.Vector3.new(.1,.1,.1),color=E.Color3.new(0,0,0),role="PIVOT",mask=0,alpha=1,collide=false,query=false,exclusionReason="Invisible positive-pair origin"})
 ctx.Model.PrimaryPart=pivot
 local data={
  {name="Kabin_Doseme_03804",cf={0,0.3,0,1,0,0,0,1,0,0,0,1},size={15,0.6,15},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Alt_03805",cf={-7.2,2.64,0,1,0,0,0,1,0,0,0,1},size={0.6,5.28,15},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Ust_03806",cf={-7.2,11.35,0,1,0,0,0,1,0,0,0,1},size={0.6,1.3,15},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Dikme_03807",cf={-7.2,7.8,-7.2,1,0,0,0,1,0,0,0,1},size={0.6,8.4,0.65},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Dikme_03808",cf={-7.2,7.8,7.2,1,0,0,0,1,0,0,0,1},size={0.6,8.4,0.65},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Cam_03809",cf={-7.22,7.99,0,1,0,0,0,1,0,0,0,1},size={0.12,5.42,13.8},rgb={42,72,103},mask=0,role="MAIN",alpha=0.27,material="Glass",collide=true,reason="Delivered source explicit nonstuds surface policy: Glass"},
  {name="Kabin_Yan_Alt_03810",cf={7.2,2.64,0,1,0,0,0,1,0,0,0,1},size={0.6,5.28,15},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Ust_03811",cf={7.2,11.35,0,1,0,0,0,1,0,0,0,1},size={0.6,1.3,15},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Dikme_03812",cf={7.2,7.8,-7.2,1,0,0,0,1,0,0,0,1},size={0.6,8.4,0.65},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Dikme_03813",cf={7.2,7.8,7.2,1,0,0,0,1,0,0,0,1},size={0.6,8.4,0.65},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Cam_03814",cf={7.22,7.99,0,1,0,0,0,1,0,0,0,1},size={0.12,5.42,13.8},rgb={42,72,103},mask=0,role="MAIN",alpha=0.27,material="Glass",collide=true,reason="Delivered source explicit nonstuds surface policy: Glass"},
  {name="Kabin_Arka_Alt_03815",cf={0,2.76,-7.2,1,0,0,0,1,0,0,0,1},size={15,5.52,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Arka_Ust_03816",cf={0,11.4,-7.2,1,0,0,0,1,0,0,0,1},size={15,1.2,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Arka_Dikme_03817",cf={-7.05,7.92,-7.2,1,0,0,0,1,0,0,0,1},size={0.9,8.4,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Arka_Dikme_03818",cf={7.05,7.92,-7.2,1,0,0,0,1,0,0,0,1},size={0.9,8.4,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Arka_Cam_03819",cf={0,8.16,-7.23,1,0,0,0,1,0,0,0,1},size={13.2,5.28,0.12},rgb={37,71,104},mask=0,role="MAIN",alpha=0.3,material="Glass",collide=true,reason="Delivered source explicit nonstuds surface policy: Glass"},
  {name="Kabin_On_Sol_03820",cf={-2,2.4,7.2,1,0,0,0,1,0,0,0,1},size={11,4.8,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_On_Ust_03821",cf={0,11.4,7.2,1,0,0,0,1,0,0,0,1},size={15,1.2,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_On_Dikme_03822",cf={-7.2,7.92,7.2,1,0,0,0,1,0,0,0,1},size={0.6,8.4,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_On_Dikme_03823",cf={3.2,7.92,7.2,1,0,0,0,1,0,0,0,1},size={0.6,8.4,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_On_Dikme_03824",cf={7.2,7.92,7.2,1,0,0,0,1,0,0,0,1},size={0.6,8.4,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_On_Cam_03825",cf={-2,7.8,7.23,1,0,0,0,1,0,0,0,1},size={9.8,6,0.12},rgb={38,76,111},mask=0,role="MAIN",alpha=0.25,material="Glass",collide=true,reason="Delivered source explicit nonstuds surface policy: Glass"},
  {name="Kabin_Cati_03826",cf={0,12.25,0,1,0,0,0,1,0,0,0,1},size={16.4,0.65,16.4},rgb={56,115,180},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Ic_Kumanda_Masasi_03827",cf={0,1.5,-4.2,1,0,0,0,1,0,0,0,1},size={9,2.1,1.8},rgb={56,70,77},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Ic_Gosterge_03828",cf={-2.4,2.65,-3.75,1,0,0,0,1,0,0,0,1},size={1.1,0.28,0.7},rgb={27,37,42},mask=0,role="MAIN",alpha=0,material="Plastic",collide=true,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Ic_Gosterge_03829",cf={2.4,2.65,-3.75,1,0,0,0,1,0,0,0,1},size={1.1,0.28,0.7},rgb={27,37,42},mask=0,role="MAIN",alpha=0,material="Plastic",collide=true,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Ic_Koltuk_03830",cf={0,0.9,0,1,0,0,0,1,0,0,0,1},size={2.3,1.2,2.3},rgb={53,68,77},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Ic_Koltuk_Arka_03831",cf={0,2.1,0.9,1,0,0,0,1,0,0,0,1},size={2.3,2,0.4},rgb={53,68,77},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Egimli_Cati_03832",cf={-4.4,14.2,0,0.91354546,-0.40673664,0,0.40673664,0.91354546,0,0,0,1},size={10,0.8,17},rgb={48,104,171},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Egimli_Cati_03833",cf={4.4,14.2,0,0.91354546,0.40673664,0,-0.40673664,0.91354546,0,0,0,1},size={10,0.8,17},rgb={48,104,171},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03834",cf={0,12.705,-7.2,1,0,0,0,1,0,0,0,1},size={14.468969,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03835",cf={0,13.105,-7.2,1,0,0,0,1,0,0,0,1},size={12.672139,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03836",cf={0,13.505,-7.2,1,0,0,0,1,0,0,0,1},size={10.87531,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03837",cf={0,13.905,-7.2,1,0,0,0,1,0,0,0,1},size={9.078481,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03838",cf={0,14.305,-7.2,1,0,0,0,1,0,0,0,1},size={7.281651,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03839",cf={0,14.705,-7.2,1,0,0,0,1,0,0,0,1},size={5.484822,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03840",cf={0,15.105,-7.2,1,0,0,0,1,0,0,0,1},size={3.687992,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03841",cf={0,15.505,-7.2,1,0,0,0,1,0,0,0,1},size={1.891163,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03842",cf={0,12.705,7.2,1,0,0,0,1,0,0,0,1},size={14.468969,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03843",cf={0,13.105,7.2,1,0,0,0,1,0,0,0,1},size={12.672139,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03844",cf={0,13.505,7.2,1,0,0,0,1,0,0,0,1},size={10.87531,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03845",cf={0,13.905,7.2,1,0,0,0,1,0,0,0,1},size={9.078481,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03846",cf={0,14.305,7.2,1,0,0,0,1,0,0,0,1},size={7.281651,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03847",cf={0,14.705,7.2,1,0,0,0,1,0,0,0,1},size={5.484822,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03848",cf={0,15.105,7.2,1,0,0,0,1,0,0,0,1},size={3.687992,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03849",cf={0,15.505,7.2,1,0,0,0,1,0,0,0,1},size={1.891163,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Baca_03850",cf={5,16.8,-2,1,0,0,0,1,0,0,0,1},size={2.2,6.4,2.2},rgb={31,40,45},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
 }
 for _,p in ipairs(data) do
  ctx:Part({name=p.name,cframe=E.CFrame.new(table.unpack(p.cf)),size=E.Vector3.new(table.unpack(p.size)),color=E.Color3.fromRGB(table.unpack(p.rgb)),mask=p.mask,role=p.role,alpha=p.alpha,material=E.Enum.Material[p.material],collide=p.collide,exclusionReason=p.reason})
 end
 ctx:Contact("Kulube_Egimli_Cati_03832","Kulube_Egimli_Cati_03833",1e-05)
 ctx:Contact("Kulube_Baca_03850","Kulube_Egimli_Cati_03833",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03834","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03835","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03836","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03837","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03838","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03839","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03840","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03841","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03842","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03843","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03844","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03845","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03846","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03847","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03848","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03849","Kulube_Egimli_Cati_03832",1e-05)
 ctx.Model:SetAttribute("TrainingScope","PARTIAL_POSITIVE_COMPONENT_NOT_FULL_REFERENCE_GOLD")
 ctx.Model:SetAttribute("SourceOrigin","-86,5.6,74")
end
