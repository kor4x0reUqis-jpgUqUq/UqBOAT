-- SONSKILLS 4.1 standalone positive COMPONENT exercise, not a full map or fully accepted gold.
assert(_G.MM41PP03==nil,"Positive case already registered")

-- BEGIN INLINE tools/Math3.luau
local M=(function()
--!nonstrict
-- Portable numeric implementation; no Roblox globals, assets or runtime animation.
-- Units: stud; vectors {x,y,z}; row-major 3x3 right-handed rotation matrices.
local M = {}
function M.add(a,b) return {a[1]+b[1],a[2]+b[2],a[3]+b[3]} end
function M.sub(a,b) return {a[1]-b[1],a[2]-b[2],a[3]-b[3]} end
function M.mul(a,s) return {a[1]*s,a[2]*s,a[3]*s} end
function M.dot(a,b) return a[1]*b[1]+a[2]*b[2]+a[3]*b[3] end
function M.cross(a,b) return {a[2]*b[3]-a[3]*b[2],a[3]*b[1]-a[1]*b[3],a[1]*b[2]-a[2]*b[1]} end
function M.length(a) return math.sqrt(M.dot(a,a)) end
function M.unit(a)
    local n=M.length(a);assert(n>1e-12,"Zero-length direction");return M.mul(a,1/n)
end
function M.identity() return {1,0,0,0,1,0,0,0,1} end
function M.transpose(r) return {r[1],r[4],r[7],r[2],r[5],r[8],r[3],r[6],r[9]} end
function M.rotate(r,v)
    return {r[1]*v[1]+r[2]*v[2]+r[3]*v[3],r[4]*v[1]+r[5]*v[2]+r[6]*v[3],r[7]*v[1]+r[8]*v[2]+r[9]*v[3]}
end
function M.matmul(a,b)
    local r={}
    for i=0,2 do for j=0,2 do
        local v=0;for k=0,2 do v=v+a[i*3+k+1]*b[k*3+j+1] end
        r[i*3+j+1]=v
    end end
    return r
end
function M.ry(degrees)
    local a=math.rad(degrees);local c,s=math.cos(a),math.sin(a)
    return {c,0,s,0,1,0,-s,0,c}
end
function M.world(origin,r,localPoint,scale)
    assert(not scale or scale>0,"Positive uniform scale required")
    return M.add(origin,M.rotate(r,M.mul(localPoint,scale or 1)))
end
function M.localPoint(origin,r,worldPoint,scale)
    return M.mul(M.rotate(M.transpose(r),M.sub(worldPoint,origin)),1/(scale or 1))
end
function M.det(r)
    return r[1]*(r[5]*r[9]-r[6]*r[8])-r[2]*(r[4]*r[9]-r[6]*r[7])+r[3]*(r[4]*r[8]-r[5]*r[7])
end
function M.rotationValid(r,tol)
    tol=tol or 1e-6
    local rt=M.matmul(M.transpose(r),r);local id=M.identity()
    for i=1,9 do if math.abs(rt[i]-id[i])>tol then return false end end
    return math.abs(M.det(r)-1)<=tol -- reflections are NOT rotations
end
function M.axes(r) return {{r[1],r[4],r[7]},{r[2],r[5],r[8]},{r[3],r[6],r[9]}} end
function M.obbContact(a,b,tolerance)
    local eps=tolerance or 1e-5;assert(eps>=0,"Negative tolerance")
    local aa,bb=M.axes(a.r),M.axes(b.r);local axes={aa[1],aa[2],aa[3],bb[1],bb[2],bb[3]}
    for i=1,3 do for j=1,3 do table.insert(axes,M.cross(aa[i],bb[j])) end end
    local delta=M.sub(b.p,a.p);local greatestGap=-math.huge
    for _,raw in ipairs(axes) do
        local n=M.length(raw)
        if n>1e-10 then
            local axis=M.mul(raw,1/n);local ra,rb=0,0
            for j=1,3 do ra=ra+math.abs(M.dot(axis,aa[j]))*a.s[j]/2;rb=rb+math.abs(M.dot(axis,bb[j]))*b.s[j]/2 end
            local gap=math.abs(M.dot(delta,axis))-ra-rb;greatestGap=math.max(greatestGap,gap)
            if gap>eps then return false,gap end
        end
    end
    return true,greatestGap
end
function M.segmentOBB(a,b,box,tol)
    local e=tol or 1e-7;local inv=M.transpose(box.r)
    a=M.rotate(inv,M.sub(a,box.p));b=M.rotate(inv,M.sub(b,box.p))
    local d=M.sub(b,a);local lo,hi=0,1
    for j=1,3 do
        local h=box.s[j]/2
        if math.abs(d[j])<1e-12 then
            if math.abs(a[j])>h+e then return false end
        else
            local u,v=(-h-a[j])/d[j],(h-a[j])/d[j]
            lo=math.max(lo,math.min(u,v));hi=math.min(hi,math.max(u,v))
            if lo>hi+e then return false end
        end
    end
    return true,lo,hi
end
function M.segmentTriangle(a,b,v0,v1,v2,tolerance)
    local eps=tolerance or 1e-8;local d=M.sub(b,a);local e1=M.sub(v1,v0);local e2=M.sub(v2,v0)
    local h=M.cross(d,e2);local det=M.dot(e1,h)
    if math.abs(det)<eps then return false end
    local f=1/det;local s=M.sub(a,v0);local u=f*M.dot(s,h)
    if u< -eps or u>1+eps then return false end
    local q=M.cross(s,e1);local v=f*M.dot(d,q)
    if v< -eps or u+v>1+eps then return false end
    local t=f*M.dot(e2,q);return t>=-eps and t<=1+eps,t
end
function M.lookBasis(eye,target,up)
    local forward=M.unit(M.sub(target,eye));up=up or {0,1,0}
    if math.abs(M.dot(forward,M.unit(up)))>.999 then up={0,0,1} end
    if math.abs(M.dot(forward,M.unit(up)))>.999 then up={1,0,0} end
    local right=M.unit(M.cross(forward,up));local actualUp=M.cross(right,forward);local back=M.mul(forward,-1)
    return {right[1],actualUp[1],back[1],right[2],actualUp[2],back[2],right[3],actualUp[3],back[3]}
end
function M.project(point,camera)
    local r=M.lookBasis(camera.eye,camera.target,camera.up)
    local q=M.rotate(M.transpose(r),M.sub(point,camera.eye));local depth=-q[3]
    if depth<=0 then return nil,"BEHIND_CAMERA" end
    local t=math.tan(math.rad(camera.fovY)/2);local aspect=camera.width/camera.height
    return {.5+q[1]/(2*depth*t*aspect),.5-q[2]/(2*depth*t),depth}
end
function M.weightedScreenRMS(samples)
    assert(#samples>0,"No anchors");local total,sum=0,0
    for _,s in ipairs(samples) do
        local w=s.weight or 1;assert(w>0,"Positive weight required")
        local dx,dy=s.actual[1]-s.expected[1],s.actual[2]-s.expected[2]
        sum=sum+w*(dx*dx+dy*dy);total=total+w
    end
    return math.sqrt(sum/total)
end
function M.fitScale(measurements)
    local num,den=0,0
    for _,s in ipairs(measurements) do
        local w=s.weight or 1;assert(s.relative>0 and s.known>0 and w>0,"Invalid scale measurement")
        num=num+w*s.relative*s.known;den=den+w*s.relative*s.relative
    end
    assert(den>0,"Scale is not identifiable without known anchors")
    return num/den
end
function M.srgbToLinear(x)
    assert(x>=0 and x<=1,"sRGB normalized 0..1")
    if x<=.04045 then return x/12.92 end
    return ((x+.055)/1.055)^2.4
end
function M.linearToSrgb(x)
    if x<=.0031308 then return 12.92*x end
    return 1.055*x^(1/2.4)-.055
end
function M.tileSize(motifPitch,motifsPerImageTile)
    assert(motifPitch>0 and motifsPerImageTile>0,"Positive motif pitch and count required")
    return motifPitch*motifsPerImageTile
end
-- Closed, open-top hollow shell: outer/inner sides, end walls, gunwales and keel.
-- No Blender/mesh importer. This is numeric data; engine mesh creation is a separate gate.
function M.hullMesh(stations,keelY,topY,thickness)
    assert(#stations>=2 and topY>keelY and thickness>0,"Invalid hull parameters")
    local verts,faces={},{};local n=#stations
    assert(stations[2].x-stations[1].x>2*thickness and stations[n].x-stations[n-1].x>2*thickness,"End thickness exceeds station spacing")
    local function section(x,w,bottom)
        assert(w>1e-6,"Interior width collapsed")
        local h=topY-bottom;local hw=w/2
        return {{x,topY,-hw},{x,bottom+.4*h,-hw},{x,bottom,-.70*hw},{x,bottom,.70*hw},{x,bottom+.4*h,hw},{x,topY,hw}}
    end
    local outer,inner={},{}
    for j,s in ipairs(stations) do
        if j>1 then assert(s.x>stations[j-1].x,"Stations must increase along +X") end
        assert(s.width>2*thickness,"Thickness collapses interior")
        local ox=s.x;local ix=ox+(j==1 and thickness or (j==n and -thickness or 0))
        local oo=section(ox,s.width,keelY);local ii=section(ix,s.width-2*thickness,keelY+thickness)
        outer[j]={};inner[j]={}
        for k=1,6 do table.insert(verts,oo[k]);outer[j][k]=#verts end
        for k=1,6 do table.insert(verts,ii[k]);inner[j][k]=#verts end
    end
    local function tri(a,b,c) table.insert(faces,{a,b,c}) end
    local function quad(a,b,c,d) tri(a,b,c);tri(a,c,d) end
    for j=1,n-1 do
        for k=1,5 do
            quad(outer[j][k],outer[j+1][k],outer[j+1][k+1],outer[j][k+1])
            quad(inner[j][k+1],inner[j+1][k+1],inner[j+1][k],inner[j][k])
        end
        quad(outer[j][1],inner[j][1],inner[j+1][1],outer[j+1][1])
        quad(outer[j][6],outer[j+1][6],inner[j+1][6],inner[j][6])
    end
    for k=2,5 do tri(outer[1][1],outer[1][k],outer[1][k+1]);tri(outer[n][1],outer[n][k+1],outer[n][k]) end
    for k=2,5 do tri(inner[1][1],inner[1][k+1],inner[1][k]);tri(inner[n][1],inner[n][k],inner[n][k+1]) end
    quad(outer[1][1],outer[1][6],inner[1][6],inner[1][1])
    quad(outer[n][6],outer[n][1],inner[n][1],inner[n][6])
    -- Correct signed winding globally. Tests also check edge direction and self-consistency.
    local volume=0
    for _,f in ipairs(faces) do volume=volume+M.dot(verts[f[1]],M.cross(verts[f[2]],verts[f[3]]))/6 end
    if volume<0 then for _,f in ipairs(faces) do f[2],f[3]=f[3],f[2] end;volume=-volume end
    return {vertices=verts,triangles=faces,volume=volume,opening="INTENTIONAL_OPEN_TOP",stations=stations,thickness=thickness}
end
return M

end)()
-- END INLINE tools/Math3.luau

-- BEGIN INLINE tools/Acceptance.luau
local A=(function()
--!nonstrict
-- Pure, testable acceptance state machine. No Roblox calls. A PASS count is not a visual pass.
local A = {}
function A.new(config)
    assert(type(config)=="table" and type(config.requiresStuds)=="boolean","Explicit style contract required")
    local s={state="NEW",requiresStuds=config.requiresStuds,sourceModelId=config.sourceModelId,candidates={},history={"NEW"}}
    local function move(name) s.state=name;table.insert(s.history,name) end
    function s:Resolved(candidates)
        assert(self.requiresStuds,"Resolution not relevant to explicit no-studs mode")
        assert(#candidates>0,"BLOCKED_ASSET: no real images")
        for _,c in ipairs(candidates) do
            assert(c.assetTypeId==1 and c.id~=self.sourceModelId and type(c.uri)=="string","Model/Decal is not an image")
        end
        self.candidates=candidates;self.selected=nil;self.approved=false;move("SOURCE_RESOLVED")
    end
    function s:Coupon(index,profile,signature,fetched)
        assert(self.requiresStuds and self.candidates[index],"Select a listed image explicitly")
        assert(fetched==true,"BLOCKED_FETCH")
        assert(profile.tileU>0 and profile.tileV>0 and profile.transparency>=0 and profile.transparency<1,"Invalid physical tile/contrast")
        assert(type(signature)=="string" and #signature>0,"Coupon signature required")
        self.selected=self.candidates[index];self.profile=profile;self.signature=signature;self.fetched=true;self.approved=false
        move("COUPON_READY")
    end
    function s:Approve(token,liveSignature)
        assert(self.state=="COUPON_READY","Live coupon required; source resolution is not visual approval")
        assert(token=="KUPONU_GORSEL_OLARAK_ONAYLIYORUM","Human visual acknowledgement required")
        assert(liveSignature==self.signature,"Coupon/image/profile changed; build a new coupon")
        self.approved=true;move("VISUAL_ACKNOWLEDGED")
    end
    function s:ExplicitNoStuds(token,reason)
        assert(not self.requiresStuds,"No-studs cannot bypass a required studs contract")
        assert(token=="KULLANICI_ACIKCA_STUDS_ISTEMIYOR" and type(reason)=="string" and #reason>0,"Explicit user style exception required")
        self.noStudsReason=reason;move("EXPLICIT_NO_STUDS")
    end
    function s:BeginInstall(liveSignature)
        if self.requiresStuds then
            assert(self.approved and self.fetched and self.selected,"BLOCKED: do not install an untextured final model")
            assert(liveSignature==self.signature,"Live coupon became stale")
        else assert(self.noStudsReason,"No implicit texture fallback") end
        self.applied=nil;self.expected=nil
        move("STAGING")
    end
    function s:Applied(actual,expected)
        assert(self.state=="STAGING","Staging required")
        assert(actual==expected,"Texture face omissions/duplicates")
        if self.requiresStuds then assert(expected>0,"Required texture was not actually applied") end
        self.applied=actual;self.expected=expected
    end
    function s:Commit(report)
        assert(self.state=="STAGING" and self.applied~=nil,"Apply/audit actual staged output before commit")
        assert(report.geometryPass==true and report.texturePass==true,"Failed geometry/texture audit")
        assert(report.cameraUntouched==true,"Installer changed user camera")
        assert(report.foreignCode==false and report.primaryInstaller==true,"Unsafe source or wrong delivery")
        self.report=report;move("COMMITTED_REVIEW_PENDING")
    end
    function s:AbortInstall(reason)
        self.lastError=reason;self.applied=nil;self.expected=nil
        move(self.requiresStuds and (self.approved and "VISUAL_ACKNOWLEDGED" or "SOURCE_RESOLVED") or "EXPLICIT_NO_STUDS")
    end
    function s:FinalAcceptance(evidence)
        assert(self.state=="COMMITTED_REVIEW_PENDING","Commit first")
        for _,key in ipairs({"studioOpen","studioAPI","referenceVisual","criticalCloseups","cameraControl","assetAccess"}) do
            assert(evidence[key]=="PASS","Not accepted: "..key)
        end
        assert(evidence.fps=="PASS" or evidence.fps=="NOT_REQUESTED_WITH_DISCLOSURE","Do not invent FPS")
        move("USER_ACCEPTED_SCOPE")
    end
    return s
end
return A

end)()
-- END INLINE tools/Acceptance.luau

-- BEGIN INLINE tools/CameraGuard.luau
local C=(function()
--!nonstrict
-- Default: do not modify CurrentCamera, type, subject, CFrame, focus or FOV.
-- An explicit optional capture runs in a try/finally-like guard; no render-step binding.
local C = {}
local fields={"CameraType","CameraSubject","CFrame","Focus","FieldOfView"}
function C.snapshot(camera)
    if not camera then return {camera=nil} end
    local s={camera=camera}
    for _,k in ipairs(fields) do s[k]=camera[k] end
    return s
end
function C.unchanged(snapshot,camera)
    if snapshot.camera~=camera then return false,"CurrentCamera object changed" end
    if not camera then return true end
    for _,k in ipairs(fields) do if snapshot[k]~=camera[k] then return false,k.." changed" end end
    return true
end
function C.withPose(getCamera,pose,callback,acknowledgement)
    assert(acknowledgement=="KAMERA_POZUNU_GECICI_KULLAN","Camera changes are opt-in only")
    assert(type(callback)=="function","A bounded capture callback is required")
    local camera=getCamera();assert(camera,"No CurrentCamera")
    local before=C.snapshot(camera)
    local result=table.pack(xpcall(function()
        if pose.CameraType then camera.CameraType=pose.CameraType end
        if pose.CFrame then camera.CFrame=pose.CFrame end
        if pose.Focus then camera.Focus=pose.Focus end
        if pose.FieldOfView then camera.FieldOfView=pose.FieldOfView end
        return callback(camera)
    end,debug.traceback))
    local restoreErrors={}
    -- Never replace workspace.CurrentCamera or overwrite a newly selected camera.
    local stillCurrent=getCamera()==camera
    do
        for _,k in ipairs({"CFrame","Focus","FieldOfView","CameraSubject","CameraType"}) do
            -- CameraSubject cannot be set to nil. Nil is therefore never assigned.
            if before[k]~=nil then
                local ok,err=pcall(function() camera[k]=before[k] end)
                if not ok then table.insert(restoreErrors,k..": "..tostring(err)) end
            end
        end
    end
    if not stillCurrent then table.insert(restoreErrors,"CurrentCamera changed during capture; new camera was not touched") end
    local equal,changed=C.unchanged(before,camera)
    if not equal then table.insert(restoreErrors,"Snapshot not fully restored: "..tostring(changed)) end
    if #restoreErrors>0 then error("Camera restoration requires manual review: "..table.concat(restoreErrors," | ")) end
    if not result[1] then error(result[2],0) end
    return table.unpack(result,2,result.n)
end
return C

end)()
-- END INLINE tools/CameraGuard.luau

-- BEGIN INLINE tools/StudioKit.luau
local Factory=(function()
--!nonstrict
-- Actual Studio EDIT adapter. Assembled installers inline this factory and its dependencies.
-- No foreign require/loadstring, HTTP script, filesystem or .rbx* file dependency.
return function(Math3,Acceptance,CameraGuard,Environment)
local env=Environment or {game=game,workspace=workspace,Instance=Instance,Enum=Enum,Content=Content,Vector3=Vector3,Color3=Color3,CFrame=CFrame,typeof=typeof,task=task,warn=warn,print=print}
local game,workspace,Instance,Enum,Content=env.game,env.workspace,env.Instance,env.Enum,env.Content
local Vector3,Color3,CFrame,typeof,task=env.Vector3,env.Color3,env.CFrame,env.typeof,env.task
local warn,print=env.warn,env.print
local K = {}
local RunService=game:GetService("RunService")
local ContentProvider=game:GetService("ContentProvider")
local Marketplace=game:GetService("MarketplaceService")
local ChangeHistory=game:GetService("ChangeHistoryService")
local HttpService=game:GetService("HttpService")
local FACES={
 {name="Right",bit=1,normal=Enum.NormalId.Right,axes={"Z","Y"}},
 {name="Top",bit=2,normal=Enum.NormalId.Top,axes={"X","Z"}},
 {name="Back",bit=4,normal=Enum.NormalId.Back,axes={"X","Y"}},
 {name="Left",bit=8,normal=Enum.NormalId.Left,axes={"Z","Y"}},
 {name="Bottom",bit=16,normal=Enum.NormalId.Bottom,axes={"X","Z"}},
 {name="Front",bit=32,normal=Enum.NormalId.Front,axes={"X","Y"}},
}
local PREFIX="MM4_Studs_"
local function editOnly()
 assert(RunService:IsStudio() and not RunService:IsRunning(),"Studio EDIT Command Bar required; stop Play/Run")
end
local function contentURI(value)
 if type(value)=="string" then return value end
 if typeof(value)=="Content" then
  local ok,u=pcall(function() return value.Uri end)
  if ok and type(u)=="string" then return u end
 end
 return nil
end
local function imageID(uri)
 if type(uri)~="string" then return nil end
 local s=string.match(uri,"^%s*(.-)%s*$")
 local id=string.match(s,"^rbxassetid://(%d+)$")
 if not id then
  local host,query=string.match(s,"^https?://([^/]+)/asset/?%?(.*)$")
  if host=="www.roblox.com" or host=="roblox.com" then
   id=string.match("&"..query,"[&]id=(%d+)[&]?")
  end
 end
 local n=tonumber(id);if n and n>0 and n%1==0 then return n end
 return nil
end
local function info(id) return Marketplace:GetProductInfoAsync(id,Enum.InfoType.Asset) end
local function safeImageStrings(id)
 local roots={};local output={}
 local ok,err=xpcall(function()
  roots=game:GetObjects("rbxassetid://"..tostring(id)) -- PluginSecurity: EDIT Command Bar
  for _,root in ipairs(roots) do
   assert(root.Parent==nil,"Foreign root unexpectedly parented")
   if root:IsA("LuaSourceContainer") then root:Destroy() else
    for _,x in ipairs(root:GetDescendants()) do if x:IsA("LuaSourceContainer") then x:Destroy() end end
    local list={root};for _,x in ipairs(root:GetDescendants()) do table.insert(list,x) end
    for _,x in ipairs(list) do
     local names={}
     if x:IsA("Decal") then names={"TextureContent","ColorMapContent","Texture","ColorMap"}
     elseif x:IsA("MeshPart") then names={"TextureContent","TextureID"}
     elseif x:IsA("SpecialMesh") then names={"TextureId"}
     elseif x:IsA("SurfaceAppearance") or x:IsA("MaterialVariant") then names={"ColorMapContent","ColorMap"}
     elseif x:IsA("ImageLabel") or x:IsA("ImageButton") then names={"ImageContent","Image"} end
     for _,property in ipairs(names) do
      local readable,value=pcall(function() return x[property] end)
      local uri=readable and contentURI(value) or nil
      if uri and uri~="" then table.insert(output,{uri=uri,path=x:GetFullName(),property=property}) end
     end
    end
   end
  end
 end,debug.traceback)
 -- The finally-equivalent cleanup also runs when property/metadata inspection fails.
 for _,root in ipairs(roots) do pcall(function() root:Destroy() end) end
 if not ok then error("BLOCKED_ASSET: "..tostring(err),0) end
 return output
end
local function resolveModel(sourceID)
 local source=info(sourceID);assert(source.AssetTypeId==10,"Configured source must still be Model(10)")
 local candidates,seen,visited={},{},{}
 local function resolve(items,chain)
  for _,item in ipairs(items) do
   local id=imageID(item.uri)
   if id and id~=sourceID then
    local ok,metadata=pcall(info,id)
    if not ok then warn("Image metadata denied",id,metadata)
    elseif metadata.AssetTypeId==1 and not seen[id] then
     seen[id]=true;table.insert(candidates,{id=id,uri="rbxassetid://"..id,assetTypeId=1,name=metadata.Name,sourcePath=chain.." / "..item.path,sourceProperty=item.property})
    elseif metadata.AssetTypeId==13 and not visited[id] then
     visited[id]=true;resolve(safeImageStrings(id),chain.." -> Decal#"..id)
    elseif metadata.AssetTypeId~=1 and metadata.AssetTypeId~=13 then warn("Rejected non-image content",id,metadata.AssetTypeId) end
   end
  end
 end
 resolve(safeImageStrings(sourceID),"Model#"..sourceID)
 table.sort(candidates,function(a,b) return a.id<b.id end)
 return candidates
end
local function fetch(uri)
 local success=false
 local events=0;local failed=false
 local ok,err=pcall(function()
  ContentProvider:PreloadAsync({uri},function(_,status)
   events=events+1;if status~=Enum.AssetFetchStatus.Success then failed=true end
  end)
 end)
 success=ok and events>0 and not failed
 assert(success,"BLOCKED_FETCH: "..tostring(err));return true
end
local function profileCopy(p)
 assert(type(p)=="table","Specify actual tile sizes, contrast and phase policy")
 assert(type(p.tileU)=="number" and type(p.tileV)=="number" and p.tileU>0 and p.tileV>0 and p.tileU<math.huge and p.tileV<math.huge,"Finite positive tileU/tileV in studs")
 assert(p.transparency and p.transparency>=0 and p.transparency<1,"Contrast must be explicit")
 for _,x in ipairs({p.woodMinTransparency or p.transparency,p.thinMinTransparency or p.transparency}) do assert(type(x)=="number" and x>=0 and x<1,"Role contrast must remain visible 0..1 exclusive") end
 assert(p.phaseMode=="LOCAL_ZERO","This adapter supports LOCAL_ZERO only; do not claim world UV continuity")
 return {tileU=p.tileU,tileV=p.tileV,transparency=p.transparency,phaseMode=p.phaseMode,
  woodMinTransparency=p.woodMinTransparency or p.transparency,thinMinTransparency=p.thinMinTransparency or p.transparency}
end
local function signature(uri,p)
 return string.format("%s|%.9g|%.9g|%.9g|%s|%.9g|%.9g",uri,p.tileU,p.tileV,p.transparency,p.phaseMode,p.woodMinTransparency,p.thinMinTransparency)
end
local function transparency(part,face,p)
 local a=p.transparency
 if part:GetAttribute("MM4Role")=="WOOD" then a=math.max(a,p.woodMinTransparency) end
 if math.min(part.Size[face.axes[1]]/p.tileU,part.Size[face.axes[2]]/p.tileV)<.35 then a=math.max(a,p.thinMinTransparency) end
 return a
end
local function putTexture(part,face,uri,p)
 local t=Instance.new("Texture");t.Name=PREFIX..face.name;t.Face=face.normal
 -- Current Content API; TextureContent is serializable. Same verified URI, no invented asset.
 t.TextureContent=Content.fromUri(uri);t.StudsPerTileU=p.tileU;t.StudsPerTileV=p.tileV
 t.OffsetStudsU=0;t.OffsetStudsV=0;t.Color3=Color3.new(1,1,1);t.Transparency=transparency(part,face,p);t.Parent=part
 return t
end
local function auditTextures(model,uri,p,requiresStuds)
 local actual,expected,instances=0,0,0;local errors={};local perFace={}
 for _,face in ipairs(FACES) do perFace[face.name]=0 end
 for _,part in ipairs(model:GetDescendants()) do
  if part:IsA("BasePart") then
   local mask=part:GetAttribute("MM4Mask")
   assert(type(mask)=="number","Every part needs an explicit surface policy: "..part.Name)
   local own=0;for _,t in ipairs(part:GetChildren()) do if t:IsA("Texture") and string.sub(t.Name,1,#PREFIX)==PREFIX then own=own+1 end end
   local wantCount=0
   for _,face in ipairs(FACES) do
    local want=requiresStuds and bit32.band(mask,face.bit)~=0
    local t=part:FindFirstChild(PREFIX..face.name)
    if want then
     expected=expected+1;wantCount=wantCount+1
     if not t or not t:IsA("Texture") or t.Face~=face.normal or contentURI(t.TextureContent)~=uri then
      table.insert(errors,part.Name.." / "..face.name.." missing/wrong image or direction")
     elseif math.abs(t.StudsPerTileU-p.tileU)>1e-5 or math.abs(t.StudsPerTileV-p.tileV)>1e-5 or math.abs(t.Transparency-transparency(part,face,p))>1e-4 or t.Color3~=Color3.new(1,1,1) or t.OffsetStudsU~=0 or t.OffsetStudsV~=0 then
      table.insert(errors,part.Name.." / "..face.name.." scale/contrast/tint/phase mismatch")
     else actual=actual+1;perFace[face.name]=perFace[face.name]+1 end
    elseif t then table.insert(errors,part.Name.." excluded face has a texture") end
   end
   instances=instances+own
   if own~=wantCount then table.insert(errors,part.Name.." duplicate/unexpected texture layer") end
  end
 end
 return {pass=#errors==0,actual=actual,expected=expected,instances=instances,perFace=perFace,errors=errors}
end
local function assertSurfaceManifest(model,manifest)
 local seen={}
 for _,part in ipairs(model:GetDescendants()) do if part:IsA("BasePart") then
  local rule=manifest[part.Name];assert(rule and not seen[part.Name],"New/duplicate part requires a new surface contract")
  assert(part:IsA("Part") and part.Shape==Enum.PartType.Block,"Block adapter cannot certify curved/mesh faces")
  assert(part:GetAttribute("MM4Mask")==rule.mask and part:GetAttribute("MM4Role")==rule.role and part:GetAttribute("MM4Exclusion")==rule.reason,"Surface contract modified since creation/visual acknowledgement")
  seen[part.Name]=true
 end end
 for name in pairs(manifest) do assert(seen[name],"Installed/staged part removed: "..name) end
end
local function obb(part)
 assert(part:IsA("Part") and part.Shape==Enum.PartType.Block,"OBB is not the exact surface of a mesh/wedge/cylinder")
 local x,y,z,a,b,c,d,e,f,g,h,i=part.CFrame:GetComponents()
 return {p={x,y,z},s={part.Size.X,part.Size.Y,part.Size.Z},r={a,b,c,d,e,f,g,h,i}}
end
function K.new(config)
 editOnly();assert(type(config.builder)=="function","Complete build function required")
 assert(config.name and config.ownerKey and type(config.requiresStuds)=="boolean","Explicit name/ownership/style required")
 local installedSurfaceManifest=nil
 local kit={Config=config,Policy=Acceptance.new(config),CouponModel=nil,Root=nil,Checks={},Session=HttpService:GenerateGUID(false)}
 function kit:Resolve()
  editOnly();self.Policy.approved=false;local candidates=resolveModel(self.Config.sourceModelId);self.Policy:Resolved(candidates)
  for i,c in ipairs(candidates) do print(i,c.uri,c.name,c.sourcePath,c.sourceProperty) end
  print("RESOLVED ONLY. No candidate selected, no approval, no final geometry installed.")
  return candidates
 end
 function kit:Coupon(index,profile,origin)
  editOnly();local candidate=self.Policy.candidates[index];assert(candidate,"Select an actual listed candidate")
  self.Policy.approved=false
  local p=profileCopy(profile);fetch(candidate.uri)
  if self.CouponModel then self.CouponModel:Destroy() end
  local model=Instance.new("Model");model.Name="MM4_Coupon_"..self.Session
  model:SetAttribute("MM4Owner",self.Config.ownerKey)
  local colors={Color3.fromRGB(218,80,53),Color3.fromRGB(226,235,235),Color3.fromRGB(169,117,69),Color3.fromRGB(224,207,39),Color3.fromRGB(52,139,189)}
  local center=origin or Vector3.new(0,12,0)
  for j,color in ipairs(colors) do
   local part=Instance.new("Part");part.Name=(j==5 and "Inclined30" or "Flat"..j);part.Anchored=true;part.CanCollide=false
   part.Size=Vector3.new(6,6,6);part.CFrame=CFrame.new(center+Vector3.new((j-3)*9,0,0))*(j==5 and CFrame.Angles(0,0,math.rad(30)) or CFrame.new())
   part.Color=color;part.Material=Enum.Material.Plastic;part.TopSurface=Enum.SurfaceType.Smooth;part.BottomSurface=Enum.SurfaceType.Smooth
   part:SetAttribute("MM4Mask",63);part:SetAttribute("MM4Role",j==3 and "WOOD" or "MAIN")
   for _,face in ipairs(FACES) do putTexture(part,face,candidate.uri,p) end
   part.Parent=model
  end
  model:SetAttribute("ImageURI",candidate.uri);model:SetAttribute("VisualAcknowledged",false);model.Parent=workspace
  self.CouponModel=model;self.Profile=p
  self.Policy:Coupon(index,p,signature(candidate.uri,p),true)
  print("COUPON READY: inspect all 30 faces, wood/red/white/yellow and slope; camera NOT moved. Select coupon and press F manually if desired.")
  return model
 end
 function kit:Approve(token)
  editOnly();assert(self.CouponModel and self.CouponModel.Parent,"Live coupon required")
  local p=self.Profile;local selected=self.Policy.selected
  local r=auditTextures(self.CouponModel,selected.uri,p,true)
  assert(r.pass and r.expected==30,"Coupon changed: regenerate it")
  local sig=signature(selected.uri,p);self.Policy:Approve(token,sig);self.CouponModel:SetAttribute("VisualAcknowledged",true)
  print("Human visual acknowledgement recorded. Model still not installed.")
 end
 function kit:ExplicitNoStuds(token,reason) editOnly();self.Policy:ExplicitNoStuds(token,reason) end
 function kit:Install(token,replaceOwned)
  editOnly();assert(token=="ONAYLI_KURULUMU_BASLAT","Explicit install command required")
  local before=CameraGuard.snapshot(workspace.CurrentCamera)
  local uri=self.Policy.selected and self.Policy.selected.uri or nil
  local sig=uri and signature(uri,self.Profile) or nil
  if self.Config.requiresStuds then
   assert(self.CouponModel and self.CouponModel.Parent,"Keep live coupon until install")
   local cr=auditTextures(self.CouponModel,uri,self.Profile,true);assert(cr.pass and cr.expected==30,"Coupon changed")
   fetch(uri)
  end
  local old=workspace:FindFirstChild(self.Config.name)
  local oldName=old and old.Name or nil;local oldParent=old and old.Parent or nil
  if old then
   assert(old:GetAttribute("MM4Owner")==self.Config.ownerKey,"Refuse to replace a user/unowned model")
   assert(replaceOwned==true,"Owned model exists; pass true explicitly to replace after staging audit")
  end
  self.Policy:BeginInstall(sig)
  local stage=Instance.new("Model");stage.Name=self.Config.name;stage:SetAttribute("MM4Owner",self.Config.ownerKey);stage:SetAttribute("MM4Version","4.1.0")
  local byName,checks,surfaceManifest={},{},{};local scale=self.Config.scale or 1;assert(scale>0,"Positive geometry scale")
  local worldCF=self.Config.worldCFrame or CFrame.new()
  local ctx={Model=stage,Parts=byName,Checks=checks,Scale=scale,WorldCFrame=worldCF,ImageURI=uri,Profile=self.Profile,Env=env}
  function ctx:Part(spec)
   assert(type(spec.name)=="string" and not byName[spec.name],"Unique semantic part name required")
   assert(spec.size and spec.cframe and spec.color and type(spec.mask)=="number" and spec.role,"Explicit geometry/material/surface contract required")
   assert(not spec.shape or spec.shape=="Block","This adapter only supports exact Block surfaces; use an explicit mesh/CSG adapter")
   assert(spec.size.X>0 and spec.size.Y>0 and spec.size.Z>0,"Positive dimensions")
   assert(spec.mask>=0 and spec.mask<=63 and spec.mask%1==0,"6-bit face mask required")
   if spec.mask==0 then assert(type(spec.exclusionReason)=="string" and #spec.exclusionReason>0,"Explain every surface exception") end
   local p=Instance.new("Part");p.Name=spec.name;p.Anchored=true;p.Size=spec.size*scale
   p.CFrame=worldCF*CFrame.new(spec.cframe.Position*scale)*spec.cframe.Rotation
   p.Color=spec.color;p.Material=spec.material or Enum.Material.Plastic;p.Transparency=spec.alpha or 0
   p.CanCollide=spec.collide~=false;p.CanTouch=false;p.CanQuery=spec.query~=false;p.CastShadow=p.Transparency==0
   for _,face in ipairs(FACES) do p[face.name.."Surface"]=Enum.SurfaceType.Smooth end
   p:SetAttribute("MM4Mask",spec.mask);p:SetAttribute("MM4Role",spec.role);p:SetAttribute("MM4Exclusion",spec.exclusionReason or "")
   p:SetAttribute("MM4ShapeState","CLOSED_NATIVE_PRIMITIVE")
   p.Parent=stage;byName[spec.name]=p;surfaceManifest[spec.name]={mask=spec.mask,role=spec.role,reason=spec.exclusionReason or ""};return p
  end
  function ctx:Contact(a,b,tolerance)
   table.insert(checks,{kind="CONTACT",a=a,b=b,tolerance=(tolerance or 1e-5)*scale})
  end
  function ctx:OpenRay(a,b,names)
   table.insert(checks,{kind="OPEN_RAY",a=(worldCF*CFrame.new(a*scale)).Position,b=(worldCF*CFrame.new(b*scale)).Position,names=names})
  end
  local ok,err=xpcall(function()
   self.Config.builder(ctx)
   assert(next(byName),"Empty builder")
   assertSurfaceManifest(stage,surfaceManifest)
   for _,c in ipairs(checks) do
    if c.kind=="CONTACT" then
     assert(byName[c.a] and byName[c.b],"Contact references must exist")
     assert(Math3.obbContact(obb(byName[c.a]),obb(byName[c.b]),c.tolerance),"Disconnected "..c.a.." -> "..c.b)
    elseif c.kind=="OPEN_RAY" then
     local a,b={c.a.X,c.a.Y,c.a.Z},{c.b.X,c.b.Y,c.b.Z}
     for _,name in ipairs(c.names) do assert(byName[name],"Aperture part missing");assert(not Math3.segmentOBB(a,b,obb(byName[name])),"Blocked opening: "..name) end
    end
   end
   local count=0
   for _,part in pairs(byName) do
    if self.Config.requiresStuds then for _,face in ipairs(FACES) do
     if bit32.band(part:GetAttribute("MM4Mask"),face.bit)~=0 then putTexture(part,face,uri,self.Profile);count=count+1;if count%1500==0 then task.wait() end end
    end end
   end
   local audit=auditTextures(stage,uri,self.Profile,self.Config.requiresStuds)
   assert(audit.pass,table.concat(audit.errors,"\n"));self.Policy:Applied(audit.actual,audit.expected)
   local unchanged,why=CameraGuard.unchanged(before,workspace.CurrentCamera)
   assert(unchanged,"Camera snapshot changed during staging; no commit. "..tostring(why))
   local commitReport={geometryPass=true,texturePass=true,cameraUntouched=true,foreignCode=false,primaryInstaller=true,surfaceAudit=audit,contactChecks=#checks}
   stage:SetAttribute("MM4TextureStatus",self.Config.requiresStuds and "ACTUALLY_APPLIED_REFERENCE_REVIEW_PENDING" or "NO_STUDS_EXPLICIT_USER_STYLE")
   if uri then stage:SetAttribute("MM4VerifiedImageURI",uri);stage:SetAttribute("MM4TileU",self.Profile.tileU);stage:SetAttribute("MM4TileV",self.Profile.tileV) end
   stage:SetAttribute("MM4ReferenceVisual","PENDING");stage:SetAttribute("MM4FPS","NOT_MEASURED")
   pcall(function() ChangeHistory:SetWaypoint("MM4 before commit") end)
   stage.Parent=workspace
   if old then
    local backups=game:GetService("ServerStorage"):FindFirstChild("MM4_Backups")
    if not backups then backups=Instance.new("Folder");backups.Name="MM4_Backups";backups.Parent=game:GetService("ServerStorage") end
    old.Name=old.Name.."_"..self.Session;old.Parent=backups -- retain editable prior result; no silent deletion
   end
   self.Policy:Commit(commitReport)
   self.Root=stage;self.LastAudit=audit;installedSurfaceManifest=surfaceManifest
   pcall(function() ChangeHistory:SetWaypoint("MM4 after commit") end)
   print("Installed via standalone code with actual surface audit. Reference/closeup/FPS review remains PENDING.",audit.actual,audit.expected)
  end,debug.traceback)
  if not ok then
   if old then pcall(function() old.Name=oldName;old.Parent=oldParent end) end
   stage:Destroy();self.Policy:AbortInstall(tostring(err))
   error("STAGING ABORTED; existing scene retained. "..tostring(err),0)
  end
  return stage,self.LastAudit
 end
 function kit:AuditInstalled()
  editOnly();assert(self.Root and self.Root.Parent and installedSurfaceManifest,"No installed owned scene")
  assertSurfaceManifest(self.Root,installedSurfaceManifest)
  local uri=self.Policy.selected and self.Policy.selected.uri or nil
  if uri then assert(signature(uri,self.Profile)==self.Policy.signature,"Profile changed since acknowledgement") end
  local result=auditTextures(self.Root,uri,self.Profile,self.Config.requiresStuds)
  if self.Config.requiresStuds then assert(result.expected>0,"Required texture disappeared") end
  self.LastAudit=result;return result
 end
 function kit:RemoveCoupon()
  editOnly();if self.CouponModel then self.CouponModel:Destroy();self.CouponModel=nil end
  -- No camera reset necessary: coupon creation never touched the camera.
 end
 function kit:WithView(pose,callback,token)
  editOnly();return CameraGuard.withPose(function() return workspace.CurrentCamera end,pose,callback,token)
 end
 function kit:Status() return {state=self.Policy.state,history=self.Policy.history,sourceModelId=self.Config.sourceModelId,selected=self.Policy.selected,actuallyApplied=self.LastAudit,referenceVisual="PENDING",fps="NOT_MEASURED"} end
 return kit
end
return K
end

end)()
-- END INLINE tools/StudioKit.luau

-- BEGIN INLINE training/positive_pairs/warehouse_interior/Builder.luau
local Builder=(function()
-- Exact delivered reconstruction subset, PARTIAL POSITIVE ONLY. Not source-game dimensions or full-model gold.
-- Native camera/doku/code defects are not inherited; new wrapper is texture-gated and default camera read-only.
return function(ctx)
 local E=ctx.Env or {Vector3=Vector3,CFrame=CFrame,Color3=Color3,Enum=Enum}
 local pivot=ctx:Part({name="PositivePairOrigin",cframe=E.CFrame.new(),size=E.Vector3.new(.1,.1,.1),color=E.Color3.new(0,0,0),role="PIVOT",mask=0,alpha=1,collide=false,query=false,exclusionReason="Invisible positive-pair origin"})
 ctx.Model.PrimaryPart=pivot
 local data={
  {name="Depo_Doseme_02522",cf={0,0.4,0,1,0,0,0,1,0,0,0,1},size={32,0.8,29},rgb={113,120,114},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Duvar_02523",cf={-15.65,11,0,1,0,0,0,1,0,0,0,1},size={0.7,22,29},rgb={55,137,183},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Yan_02524",cf={-11.8,11,14.15,1,0,0,0,1,0,0,0,1},size={8.4,22,0.7},rgb={55,137,183},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02525",cf={-16.12,11,-14.1,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02526",cf={-16.12,11,-13.15,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02527",cf={-16.12,11,-12.2,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02528",cf={-16.12,11,-11.25,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02529",cf={-16.12,11,-10.3,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02530",cf={-16.12,11,-9.35,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02531",cf={-16.12,11,-8.4,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02532",cf={-16.12,11,-7.45,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02533",cf={-16.12,11,-6.5,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02534",cf={-16.12,11,-5.55,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02535",cf={-16.12,11,-4.6,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02536",cf={-16.12,11,-3.65,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02537",cf={-16.12,11,-2.7,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02538",cf={-16.12,11,-1.75,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02539",cf={-16.12,11,-0.8,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02540",cf={-16.12,11,0.15,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02541",cf={-16.12,11,1.1,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02542",cf={-16.12,11,2.05,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02543",cf={-16.12,11,3,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02544",cf={-16.12,11,3.95,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02545",cf={-16.12,11,4.9,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02546",cf={-16.12,11,5.85,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02547",cf={-16.12,11,6.8,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02548",cf={-16.12,11,7.75,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02549",cf={-16.12,11,8.7,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02550",cf={-16.12,11,9.65,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02551",cf={-16.12,11,10.6,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02552",cf={-16.12,11,11.55,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02553",cf={-16.12,11,12.5,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02554",cf={-16.12,11,13.45,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02555",cf={-16.12,11,14.4,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Duvar_02556",cf={15.65,11,0,1,0,0,0,1,0,0,0,1},size={0.7,22,29},rgb={55,137,183},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Yan_02557",cf={11.8,11,14.15,1,0,0,0,1,0,0,0,1},size={8.4,22,0.7},rgb={55,137,183},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02558",cf={16.12,11,-14.1,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02559",cf={16.12,11,-13.15,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02560",cf={16.12,11,-12.2,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02561",cf={16.12,11,-11.25,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02562",cf={16.12,11,-10.3,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02563",cf={16.12,11,-9.35,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02564",cf={16.12,11,-8.4,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02565",cf={16.12,11,-7.45,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02566",cf={16.12,11,-6.5,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02567",cf={16.12,11,-5.55,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02568",cf={16.12,11,-4.6,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02569",cf={16.12,11,-3.65,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02570",cf={16.12,11,-2.7,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02571",cf={16.12,11,-1.75,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02572",cf={16.12,11,-0.8,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02573",cf={16.12,11,0.15,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02574",cf={16.12,11,1.1,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02575",cf={16.12,11,2.05,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02576",cf={16.12,11,3,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02577",cf={16.12,11,3.95,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02578",cf={16.12,11,4.9,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02579",cf={16.12,11,5.85,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02580",cf={16.12,11,6.8,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02581",cf={16.12,11,7.75,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02582",cf={16.12,11,8.7,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02583",cf={16.12,11,9.65,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02584",cf={16.12,11,10.6,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02585",cf={16.12,11,11.55,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02586",cf={16.12,11,12.5,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02587",cf={16.12,11,13.45,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Yan_Sac_Olugu_02588",cf={16.12,11,14.4,1,0,0,0,1,0,0,0,1},size={0.25,22,0.3},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Duvar_02589",cf={0,11,-14.15,1,0,0,0,1,0,0,0,1},size={32,22,0.7},rgb={55,137,183},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02590",cf={-15.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02591",cf={-15.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02592",cf={-14.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02593",cf={-14.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02594",cf={-13.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02595",cf={-13.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02596",cf={-12.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02597",cf={-12.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02598",cf={-11.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02599",cf={-11.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02600",cf={-10.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02601",cf={-10.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02602",cf={-9.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02603",cf={-9.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02604",cf={-8.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02605",cf={-8.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02606",cf={-7.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02607",cf={-7.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02608",cf={-6.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02609",cf={-5.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02610",cf={-4.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02611",cf={-3.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02612",cf={-2.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02613",cf={-1.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02614",cf={-0.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02615",cf={0.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02616",cf={1.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02617",cf={2.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02618",cf={3.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02619",cf={4.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02620",cf={5.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02621",cf={6.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02622",cf={7.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02623",cf={7.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02624",cf={8.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02625",cf={8.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02626",cf={9.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02627",cf={9.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02628",cf={10.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02629",cf={10.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02630",cf={11.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02631",cf={11.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02632",cf={12.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02633",cf={12.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02634",cf={13.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02635",cf={13.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02636",cf={14.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02637",cf={14.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Arka_Sac_Olugu_02638",cf={15.5,11,-14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_On_Sac_Olugu_02639",cf={15.5,11,14.62,1,0,0,0,1,0,0,0,1},size={0.3,22,0.24},rgb={41,117,166},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Kapi_Ust_Atki_02640",cf={0,19,14.15,1,0,0,0,1,0,0,0,1},size={15.4,6,0.7},rgb={55,137,183},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Beyaz_Duz_Cati_02641",cf={0,22.45,0,1,0,0,0,1,0,0,0,1},size={34,0.9,31},rgb={223,233,233},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Ic_Tasiyici_02642",cf={-14,10,0,1,0,0,0,1,0,0,0,1},size={0.7,20,0.7},rgb={106,125,137},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Ic_Tasiyici_02643",cf={14,10,0,1,0,0,0,1,0,0,0,1},size={0.7,20,0.7},rgb={106,125,137},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Ic_Cati_Kirisi_02644",cf={0,21,-10,1,0,0,0,1,0,0,0,1},size={30,0.7,0.8},rgb={106,125,137},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Ic_Cati_Kirisi_02645",cf={0,21,0,1,0,0,0,1,0,0,0,1},size={30,0.7,0.8},rgb={106,125,137},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Ic_Cati_Kirisi_02646",cf={0,21,10,1,0,0,0,1,0,0,0,1},size={30,0.7,0.8},rgb={106,125,137},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Depo_Muz_Tabela_02647",cf={0,18.3,15.05,1,0,0,0,1,0,0,0,1},size={18,3.4,0.45},rgb={223,233,233},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Muz_Dilim_02648",cf={-3.583333,18.9,15.34,-0.5721816,0.82012695,0,-0.82012695,-0.5721816,0,0,0,1},size={1.08,1.792697,1.28},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02649",cf={-2.15,18.1,15.34,-0.38613809,0.92244099,0,-0.92244099,-0.38613809,0,0,0,1},size={1.08,1.598848,1.28},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02650",cf={-0.716667,17.7,15.34,-0.13819603,0.9904049,0,-0.9904049,-0.13819603,0,0,0,1},size={1.08,1.49222,1.28},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02651",cf={0.716667,17.7,15.34,0.13819603,0.9904049,-0,-0.9904049,0.13819603,0,0,0,1},size={1.08,1.49222,1.28},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02652",cf={2.15,18.1,15.34,0.38613809,0.92244099,-0,-0.92244099,0.38613809,0,0,0,1},size={1.08,1.598848,1.28},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02653",cf={3.583333,18.9,15.34,0.5721816,0.82012695,-0,-0.82012695,0.5721816,0,0,0,1},size={1.08,1.792697,1.28},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Sap_02654",cf={4.3,19.88,15.34,1,0,0,0,1,0,0,0,1},size={0.48,0.96,0.48},rgb={99,117,47},mask=0,role="MAIN",alpha=0,material="Plastic",collide=false,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Sandik_Taban_02655",cf={-6,1.02,-5,1,0,0,0,1,0,0,0,1},size={5.5,0.44,5.5},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kapak_02656",cf={-6,6.58,-5,1,0,0,0,1,0,0,0,1},size={5.5,0.44,5.5},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_OnArka_Panel_02657",cf={-6,3.8,-7.57,1,0,0,0,1,0,0,0,1},size={5.3,5.4,0.36},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Yan_Panel_02658",cf={-8.57,3.8,-5,1,0,0,0,1,0,0,0,1},size={0.36,5.4,5.3},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02659",cf={-8.5,3.8,-7.75,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02660",cf={-8.5,3.8,-2.25,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_OnArka_Panel_02661",cf={-6,3.8,-2.43,1,0,0,0,1,0,0,0,1},size={5.3,5.4,0.36},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Yan_Panel_02662",cf={-3.43,3.8,-5,1,0,0,0,1,0,0,0,1},size={0.36,5.4,5.3},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02663",cf={-3.5,3.8,-7.75,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02664",cf={-3.5,3.8,-2.25,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02665",cf={-6,1.46,-7.77,1,0,0,0,1,0,0,0,1},size={5.5,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02666",cf={-6,1.46,-2.23,1,0,0,0,1,0,0,0,1},size={5.5,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02667",cf={-8.77,1.46,-5,1,0,0,0,1,0,0,0,1},size={0.14,0.28,5.5},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02668",cf={-3.23,1.46,-5,1,0,0,0,1,0,0,0,1},size={0.14,0.28,5.5},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02669",cf={-6,6.14,-7.77,1,0,0,0,1,0,0,0,1},size={5.5,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02670",cf={-6,6.14,-2.23,1,0,0,0,1,0,0,0,1},size={5.5,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02671",cf={-8.77,6.14,-5,1,0,0,0,1,0,0,0,1},size={0.14,0.28,5.5},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02672",cf={-3.23,6.14,-5,1,0,0,0,1,0,0,0,1},size={0.14,0.28,5.5},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Taban_02673",cf={5,1.02,-8,1,0,0,0,1,0,0,0,1},size={5.5,0.44,5.5},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kapak_02674",cf={5,6.58,-8,1,0,0,0,1,0,0,0,1},size={5.5,0.44,5.5},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_OnArka_Panel_02675",cf={5,3.8,-10.57,1,0,0,0,1,0,0,0,1},size={5.3,5.4,0.36},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Yan_Panel_02676",cf={2.43,3.8,-8,1,0,0,0,1,0,0,0,1},size={0.36,5.4,5.3},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02677",cf={2.5,3.8,-10.75,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02678",cf={2.5,3.8,-5.25,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_OnArka_Panel_02679",cf={5,3.8,-5.43,1,0,0,0,1,0,0,0,1},size={5.3,5.4,0.36},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Yan_Panel_02680",cf={7.57,3.8,-8,1,0,0,0,1,0,0,0,1},size={0.36,5.4,5.3},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02681",cf={7.5,3.8,-10.75,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02682",cf={7.5,3.8,-5.25,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02683",cf={5,1.46,-10.77,1,0,0,0,1,0,0,0,1},size={5.5,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02684",cf={5,1.46,-5.23,1,0,0,0,1,0,0,0,1},size={5.5,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02685",cf={2.23,1.46,-8,1,0,0,0,1,0,0,0,1},size={0.14,0.28,5.5},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02686",cf={7.77,1.46,-8,1,0,0,0,1,0,0,0,1},size={0.14,0.28,5.5},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02687",cf={5,6.14,-10.77,1,0,0,0,1,0,0,0,1},size={5.5,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02688",cf={5,6.14,-5.23,1,0,0,0,1,0,0,0,1},size={5.5,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02689",cf={2.23,6.14,-8,1,0,0,0,1,0,0,0,1},size={0.14,0.28,5.5},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02690",cf={7.77,6.14,-8,1,0,0,0,1,0,0,0,1},size={0.14,0.28,5.5},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Taban_02691",cf={7,1.02,2,1,0,0,0,1,0,0,0,1},size={5.5,0.44,5.5},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kapak_02692",cf={7,6.58,2,1,0,0,0,1,0,0,0,1},size={5.5,0.44,5.5},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_OnArka_Panel_02693",cf={7,3.8,-0.57,1,0,0,0,1,0,0,0,1},size={5.3,5.4,0.36},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Yan_Panel_02694",cf={4.43,3.8,2,1,0,0,0,1,0,0,0,1},size={0.36,5.4,5.3},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02695",cf={4.5,3.8,-0.75,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02696",cf={4.5,3.8,4.75,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_OnArka_Panel_02697",cf={7,3.8,4.57,1,0,0,0,1,0,0,0,1},size={5.3,5.4,0.36},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Yan_Panel_02698",cf={9.57,3.8,2,1,0,0,0,1,0,0,0,1},size={0.36,5.4,5.3},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02699",cf={9.5,3.8,-0.75,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02700",cf={9.5,3.8,4.75,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02701",cf={7,1.46,-0.77,1,0,0,0,1,0,0,0,1},size={5.5,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02702",cf={7,1.46,4.77,1,0,0,0,1,0,0,0,1},size={5.5,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02703",cf={4.23,1.46,2,1,0,0,0,1,0,0,0,1},size={0.14,0.28,5.5},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02704",cf={9.77,1.46,2,1,0,0,0,1,0,0,0,1},size={0.14,0.28,5.5},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02705",cf={7,6.14,-0.77,1,0,0,0,1,0,0,0,1},size={5.5,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02706",cf={7,6.14,4.77,1,0,0,0,1,0,0,0,1},size={5.5,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02707",cf={4.23,6.14,2,1,0,0,0,1,0,0,0,1},size={0.14,0.28,5.5},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02708",cf={9.77,6.14,2,1,0,0,0,1,0,0,0,1},size={0.14,0.28,5.5},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Taban_02709",cf={-9,23.12,1,1,0,0,0,1,0,0,0,1},size={6,0.44,6},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kapak_02710",cf={-9,27.68,1,1,0,0,0,1,0,0,0,1},size={6,0.44,6},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_OnArka_Panel_02711",cf={-9,25.4,-1.82,1,0,0,0,1,0,0,0,1},size={5.8,4.4,0.36},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Yan_Panel_02712",cf={-11.82,25.4,1,1,0,0,0,1,0,0,0,1},size={0.36,4.4,5.8},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02713",cf={-11.75,25.4,-2,1,0,0,0,1,0,0,0,1},size={0.6,4.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02714",cf={-11.75,25.4,4,1,0,0,0,1,0,0,0,1},size={0.6,4.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_OnArka_Panel_02715",cf={-9,25.4,3.82,1,0,0,0,1,0,0,0,1},size={5.8,4.4,0.36},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Yan_Panel_02716",cf={-6.18,25.4,1,1,0,0,0,1,0,0,0,1},size={0.36,4.4,5.8},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02717",cf={-6.25,25.4,-2,1,0,0,0,1,0,0,0,1},size={0.6,4.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02718",cf={-6.25,25.4,4,1,0,0,0,1,0,0,0,1},size={0.6,4.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02719",cf={-9,23.56,-2.02,1,0,0,0,1,0,0,0,1},size={6,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02720",cf={-9,23.56,4.02,1,0,0,0,1,0,0,0,1},size={6,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02721",cf={-12.02,23.56,1,1,0,0,0,1,0,0,0,1},size={0.14,0.28,6},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02722",cf={-5.98,23.56,1,1,0,0,0,1,0,0,0,1},size={0.14,0.28,6},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02723",cf={-9,27.24,-2.02,1,0,0,0,1,0,0,0,1},size={6,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02724",cf={-9,27.24,4.02,1,0,0,0,1,0,0,0,1},size={6,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02725",cf={-12.02,27.24,1,1,0,0,0,1,0,0,0,1},size={0.14,0.28,6},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02726",cf={-5.98,27.24,1,1,0,0,0,1,0,0,0,1},size={0.14,0.28,6},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Muz_Dilim_02727",cf={-11.379167,28.355,1.035,-0.5721816,0.81480907,-0.09324375,-0.82012695,-0.56847145,0.06505378,0,0.11369429,0.99351578},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02728",cf={-10.8775,28.075,1.105,-0.38613809,0.91489362,-0.11775842,-0.92244099,-0.38297872,0.04929422,0,0.12765957,0.99181804},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02729",cf={-10.375833,27.935,1.175,-0.13819603,0.98108079,-0.13558147,-0.9904049,-0.13689499,0.01891834,0,0.13689499,0.99058556},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02730",cf={-9.874167,27.935,1.245,0.13819603,0.98108079,-0.13558147,-0.9904049,0.13689499,-0.01891834,0,0.13689499,0.99058556},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02731",cf={-9.3725,28.075,1.315,0.38613809,0.91489362,-0.11775842,-0.92244099,0.38297872,-0.04929422,0,0.12765957,0.99181804},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02732",cf={-8.870833,28.355,1.385,0.5721816,0.81480907,-0.09324375,-0.82012695,0.56847145,-0.06505378,0,0.11369429,0.99351578},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Sap_02733",cf={-8.62,28.698,1.42,1,0,0,0,1,0,0,0,1},size={0.168,0.336,0.168},rgb={99,117,47},mask=0,role="MAIN",alpha=0,material="Plastic",collide=false,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Muz_Dilim_02734",cf={-10.61209,28.355,1.209206,-0.56847163,0.82270259,0.00066777,-0.82270286,-0.56847145,-0.00046142,0,-0.00081168,0.99999967},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02735",cf={-10.105564,28.075,1.208706,-0.38297888,0.92375671,0.0008419,-0.9237571,-0.38297872,-0.00034904,0,-0.00091138,0.99999958},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02736",cf={-9.599037,27.935,1.208206,-0.13689506,0.99058508,0.00096811,-0.99058556,-0.13689499,-0.00013379,0,-0.00097731,0.99999952},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02737",cf={-9.09251,27.935,1.207706,0.13689506,0.99058508,0.00096811,-0.99058556,0.13689499,0.00013379,0,-0.00097731,0.99999952},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02738",cf={-8.585984,28.075,1.207207,0.38297888,0.92375671,0.0008419,-0.9237571,0.38297872,0.00034904,0,-0.00091138,0.99999958},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02739",cf={-8.079457,28.355,1.206707,0.56847163,0.82270259,0.00066777,-0.82270286,0.56847145,0.00046142,0,-0.00081168,0.99999967},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Sap_02740",cf={-7.826194,28.698,1.206457,1,0,0,0,1,0,0,0,1},size={0.168,0.336,0.168},rgb={99,117,47},mask=0,role="MAIN",alpha=0,material="Plastic",collide=false,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Muz_Dilim_02741",cf={-9.820935,28.355,1.379339,-0.57228832,0.81458314,0.09455357,-0.82005248,-0.56847145,-0.0659859,0,-0.11530185,0.9933305},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02742",cf={-9.319408,28.075,1.30835,-0.38622921,0.91463994,0.11941851,-0.92240284,-0.38297872,-0.05000301,0,-0.1294646,0.99158404},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02743",cf={-8.81788,27.935,1.23736,-0.13823363,0.98080876,0.13749778,-0.99039965,-0.13689499,-0.01919106,0,-0.1388306,0.99031614},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02744",cf={-8.316352,27.935,1.16637,0.13823363,0.98080876,0.13749778,-0.99039965,0.13689499,0.01919106,0,-0.1388306,0.99031614},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02745",cf={-7.814825,28.075,1.09538,0.38622921,0.91463994,0.11941851,-0.92240284,0.38297872,0.05000301,0,-0.1294646,0.99158404},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02746",cf={-7.313297,28.355,1.024391,0.57228832,0.81458314,0.09455357,-0.82005248,0.56847145,0.0659859,0,-0.11530185,0.9933305},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Sap_02747",cf={-7.062533,28.698,0.988896,1,0,0,0,1,0,0,0,1},size={0.168,0.336,0.168},rgb={99,117,47},mask=0,role="MAIN",alpha=0,material="Plastic",collide=false,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Muz_Dilim_02748",cf={-9.006502,28.355,1.54209,-0.58378595,0.79060876,0.18474779,-0.8119076,-0.56847145,-0.13283921,0,-0.22754781,0.97376691},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02749",cf={-8.519736,28.075,1.401992,-0.39612631,0.88772073,0.23459719,-0.91819603,-0.38297872,-0.10120945,0,-0.25549793,0.9668096},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02750",cf={-8.032969,27.935,1.261894,-0.14234171,0.95194211,0.27119191,-0.98981758,-0.13689499,-0.03899903,0,-0.27398171,0.9617349},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02751",cf={-7.546202,27.935,1.121796,0.14234171,0.95194211,0.27119191,-0.98981758,0.13689499,0.03899903,0,-0.27398171,0.9617349},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02752",cf={-7.059435,28.075,0.981697,0.39612631,0.88772073,0.23459719,-0.91819603,0.38297872,0.10120945,0,-0.25549793,0.9668096},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02753",cf={-6.572668,28.355,0.841599,0.58378595,0.79060876,0.18474779,-0.8119076,0.56847145,0.13283921,0,-0.22754781,0.97376691},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Sap_02754",cf={-6.329285,28.698,0.77155,1,0,0,0,1,0,0,0,1},size={0.168,0.336,0.168},rgb={99,117,47},mask=0,role="MAIN",alpha=0,material="Plastic",collide=false,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Sandik_Taban_02755",cf={0,23.12,-5,1,0,0,0,1,0,0,0,1},size={6,0.44,6},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kapak_02756",cf={0,28.68,-5,1,0,0,0,1,0,0,0,1},size={6,0.44,6},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_OnArka_Panel_02757",cf={0,25.9,-7.82,1,0,0,0,1,0,0,0,1},size={5.8,5.4,0.36},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Yan_Panel_02758",cf={-2.82,25.9,-5,1,0,0,0,1,0,0,0,1},size={0.36,5.4,5.8},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02759",cf={-2.75,25.9,-8,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02760",cf={-2.75,25.9,-2,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_OnArka_Panel_02761",cf={0,25.9,-2.18,1,0,0,0,1,0,0,0,1},size={5.8,5.4,0.36},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Yan_Panel_02762",cf={2.82,25.9,-5,1,0,0,0,1,0,0,0,1},size={0.36,5.4,5.8},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02763",cf={2.75,25.9,-8,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02764",cf={2.75,25.9,-2,1,0,0,0,1,0,0,0,1},size={0.6,5.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02765",cf={0,23.56,-8.02,1,0,0,0,1,0,0,0,1},size={6,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02766",cf={0,23.56,-1.98,1,0,0,0,1,0,0,0,1},size={6,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02767",cf={-3.02,23.56,-5,1,0,0,0,1,0,0,0,1},size={0.14,0.28,6},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02768",cf={3.02,23.56,-5,1,0,0,0,1,0,0,0,1},size={0.14,0.28,6},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02769",cf={0,28.24,-8.02,1,0,0,0,1,0,0,0,1},size={6,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02770",cf={0,28.24,-1.98,1,0,0,0,1,0,0,0,1},size={6,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02771",cf={-3.02,28.24,-5,1,0,0,0,1,0,0,0,1},size={0.14,0.28,6},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02772",cf={3.02,28.24,-5,1,0,0,0,1,0,0,0,1},size={0.14,0.28,6},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Muz_Dilim_02773",cf={-2.379167,29.355,-4.965,-0.5721816,0.81480907,-0.09324375,-0.82012695,-0.56847145,0.06505378,0,0.11369429,0.99351578},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02774",cf={-1.8775,29.075,-4.895,-0.38613809,0.91489362,-0.11775842,-0.92244099,-0.38297872,0.04929422,0,0.12765957,0.99181804},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02775",cf={-1.375833,28.935,-4.825,-0.13819603,0.98108079,-0.13558147,-0.9904049,-0.13689499,0.01891834,0,0.13689499,0.99058556},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02776",cf={-0.874167,28.935,-4.755,0.13819603,0.98108079,-0.13558147,-0.9904049,0.13689499,-0.01891834,0,0.13689499,0.99058556},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02777",cf={-0.3725,29.075,-4.685,0.38613809,0.91489362,-0.11775842,-0.92244099,0.38297872,-0.04929422,0,0.12765957,0.99181804},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02778",cf={0.129167,29.355,-4.615,0.5721816,0.81480907,-0.09324375,-0.82012695,0.56847145,-0.06505378,0,0.11369429,0.99351578},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Sap_02779",cf={0.38,29.698,-4.58,1,0,0,0,1,0,0,0,1},size={0.168,0.336,0.168},rgb={99,117,47},mask=0,role="MAIN",alpha=0,material="Plastic",collide=false,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Muz_Dilim_02780",cf={-1.61209,29.355,-4.790794,-0.56847163,0.82270259,0.00066777,-0.82270286,-0.56847145,-0.00046142,0,-0.00081168,0.99999967},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02781",cf={-1.105564,29.075,-4.791294,-0.38297888,0.92375671,0.0008419,-0.9237571,-0.38297872,-0.00034904,0,-0.00091138,0.99999958},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02782",cf={-0.599037,28.935,-4.791794,-0.13689506,0.99058508,0.00096811,-0.99058556,-0.13689499,-0.00013379,0,-0.00097731,0.99999952},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02783",cf={-0.09251,28.935,-4.792294,0.13689506,0.99058508,0.00096811,-0.99058556,0.13689499,0.00013379,0,-0.00097731,0.99999952},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02784",cf={0.414016,29.075,-4.792793,0.38297888,0.92375671,0.0008419,-0.9237571,0.38297872,0.00034904,0,-0.00091138,0.99999958},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02785",cf={0.920543,29.355,-4.793293,0.56847163,0.82270259,0.00066777,-0.82270286,0.56847145,0.00046142,0,-0.00081168,0.99999967},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Sap_02786",cf={1.173806,29.698,-4.793543,1,0,0,0,1,0,0,0,1},size={0.168,0.336,0.168},rgb={99,117,47},mask=0,role="MAIN",alpha=0,material="Plastic",collide=false,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Muz_Dilim_02787",cf={-0.820935,29.355,-4.620661,-0.57228832,0.81458314,0.09455357,-0.82005248,-0.56847145,-0.0659859,0,-0.11530185,0.9933305},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02788",cf={-0.319408,29.075,-4.69165,-0.38622921,0.91463994,0.11941851,-0.92240284,-0.38297872,-0.05000301,0,-0.1294646,0.99158404},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02789",cf={0.18212,28.935,-4.76264,-0.13823363,0.98080876,0.13749778,-0.99039965,-0.13689499,-0.01919106,0,-0.1388306,0.99031614},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02790",cf={0.683648,28.935,-4.83363,0.13823363,0.98080876,0.13749778,-0.99039965,0.13689499,0.01919106,0,-0.1388306,0.99031614},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02791",cf={1.185175,29.075,-4.90462,0.38622921,0.91463994,0.11941851,-0.92240284,0.38297872,0.05000301,0,-0.1294646,0.99158404},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02792",cf={1.686703,29.355,-4.975609,0.57228832,0.81458314,0.09455357,-0.82005248,0.56847145,0.0659859,0,-0.11530185,0.9933305},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Sap_02793",cf={1.937467,29.698,-5.011104,1,0,0,0,1,0,0,0,1},size={0.168,0.336,0.168},rgb={99,117,47},mask=0,role="MAIN",alpha=0,material="Plastic",collide=false,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Muz_Dilim_02794",cf={-0.006502,29.355,-4.45791,-0.58378595,0.79060876,0.18474779,-0.8119076,-0.56847145,-0.13283921,0,-0.22754781,0.97376691},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02795",cf={0.480264,29.075,-4.598008,-0.39612631,0.88772073,0.23459719,-0.91819603,-0.38297872,-0.10120945,0,-0.25549793,0.9668096},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02796",cf={0.967031,28.935,-4.738106,-0.14234171,0.95194211,0.27119191,-0.98981758,-0.13689499,-0.03899903,0,-0.27398171,0.9617349},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02797",cf={1.453798,28.935,-4.878204,0.14234171,0.95194211,0.27119191,-0.98981758,0.13689499,0.03899903,0,-0.27398171,0.9617349},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02798",cf={1.940565,29.075,-5.018303,0.39612631,0.88772073,0.23459719,-0.91819603,0.38297872,0.10120945,0,-0.25549793,0.9668096},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02799",cf={2.427332,29.355,-5.158401,0.58378595,0.79060876,0.18474779,-0.8119076,0.56847145,0.13283921,0,-0.22754781,0.97376691},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Sap_02800",cf={2.670715,29.698,-5.22845,1,0,0,0,1,0,0,0,1},size={0.168,0.336,0.168},rgb={99,117,47},mask=0,role="MAIN",alpha=0,material="Plastic",collide=false,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Sandik_Taban_02801",cf={8,23.12,4,1,0,0,0,1,0,0,0,1},size={6,0.44,6},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kapak_02802",cf={8,26.68,4,1,0,0,0,1,0,0,0,1},size={6,0.44,6},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_OnArka_Panel_02803",cf={8,24.9,1.18,1,0,0,0,1,0,0,0,1},size={5.8,3.4,0.36},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Yan_Panel_02804",cf={5.18,24.9,4,1,0,0,0,1,0,0,0,1},size={0.36,3.4,5.8},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02805",cf={5.25,24.9,1,1,0,0,0,1,0,0,0,1},size={0.6,3.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02806",cf={5.25,24.9,7,1,0,0,0,1,0,0,0,1},size={0.6,3.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_OnArka_Panel_02807",cf={8,24.9,6.82,1,0,0,0,1,0,0,0,1},size={5.8,3.4,0.36},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Yan_Panel_02808",cf={10.82,24.9,4,1,0,0,0,1,0,0,0,1},size={0.36,3.4,5.8},rgb={201,176,124},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02809",cf={10.75,24.9,1,1,0,0,0,1,0,0,0,1},size={0.6,3.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Kose_02810",cf={10.75,24.9,7,1,0,0,0,1,0,0,0,1},size={0.6,3.8,0.32},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02811",cf={8,23.56,0.98,1,0,0,0,1,0,0,0,1},size={6,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02812",cf={8,23.56,7.02,1,0,0,0,1,0,0,0,1},size={6,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02813",cf={4.98,23.56,4,1,0,0,0,1,0,0,0,1},size={0.14,0.28,6},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02814",cf={11.02,23.56,4,1,0,0,0,1,0,0,0,1},size={0.14,0.28,6},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02815",cf={8,26.24,0.98,1,0,0,0,1,0,0,0,1},size={6,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02816",cf={8,26.24,7.02,1,0,0,0,1,0,0,0,1},size={6,0.28,0.14},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02817",cf={4.98,26.24,4,1,0,0,0,1,0,0,0,1},size={0.14,0.28,6},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Sandik_Cerceve_02818",cf={11.02,26.24,4,1,0,0,0,1,0,0,0,1},size={0.14,0.28,6},rgb={132,111,72},mask=63,role="WOOD",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Muz_Dilim_02819",cf={5.620833,27.355,4.035,-0.5721816,0.81480907,-0.09324375,-0.82012695,-0.56847145,0.06505378,0,0.11369429,0.99351578},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02820",cf={6.1225,27.075,4.105,-0.38613809,0.91489362,-0.11775842,-0.92244099,-0.38297872,0.04929422,0,0.12765957,0.99181804},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02821",cf={6.624167,26.935,4.175,-0.13819603,0.98108079,-0.13558147,-0.9904049,-0.13689499,0.01891834,0,0.13689499,0.99058556},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02822",cf={7.125833,26.935,4.245,0.13819603,0.98108079,-0.13558147,-0.9904049,0.13689499,-0.01891834,0,0.13689499,0.99058556},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02823",cf={7.6275,27.075,4.315,0.38613809,0.91489362,-0.11775842,-0.92244099,0.38297872,-0.04929422,0,0.12765957,0.99181804},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02824",cf={8.129167,27.355,4.385,0.5721816,0.81480907,-0.09324375,-0.82012695,0.56847145,-0.06505378,0,0.11369429,0.99351578},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Sap_02825",cf={8.38,27.698,4.42,1,0,0,0,1,0,0,0,1},size={0.168,0.336,0.168},rgb={99,117,47},mask=0,role="MAIN",alpha=0,material="Plastic",collide=false,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Muz_Dilim_02826",cf={6.38791,27.355,4.209206,-0.56847163,0.82270259,0.00066777,-0.82270286,-0.56847145,-0.00046142,0,-0.00081168,0.99999967},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02827",cf={6.894436,27.075,4.208706,-0.38297888,0.92375671,0.0008419,-0.9237571,-0.38297872,-0.00034904,0,-0.00091138,0.99999958},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02828",cf={7.400963,26.935,4.208206,-0.13689506,0.99058508,0.00096811,-0.99058556,-0.13689499,-0.00013379,0,-0.00097731,0.99999952},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02829",cf={7.90749,26.935,4.207706,0.13689506,0.99058508,0.00096811,-0.99058556,0.13689499,0.00013379,0,-0.00097731,0.99999952},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02830",cf={8.414016,27.075,4.207207,0.38297888,0.92375671,0.0008419,-0.9237571,0.38297872,0.00034904,0,-0.00091138,0.99999958},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02831",cf={8.920543,27.355,4.206707,0.56847163,0.82270259,0.00066777,-0.82270286,0.56847145,0.00046142,0,-0.00081168,0.99999967},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Sap_02832",cf={9.173806,27.698,4.206457,1,0,0,0,1,0,0,0,1},size={0.168,0.336,0.168},rgb={99,117,47},mask=0,role="MAIN",alpha=0,material="Plastic",collide=false,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Muz_Dilim_02833",cf={7.179065,27.355,4.379339,-0.57228832,0.81458314,0.09455357,-0.82005248,-0.56847145,-0.0659859,0,-0.11530185,0.9933305},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02834",cf={7.680592,27.075,4.30835,-0.38622921,0.91463994,0.11941851,-0.92240284,-0.38297872,-0.05000301,0,-0.1294646,0.99158404},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02835",cf={8.18212,26.935,4.23736,-0.13823363,0.98080876,0.13749778,-0.99039965,-0.13689499,-0.01919106,0,-0.1388306,0.99031614},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02836",cf={8.683648,26.935,4.16637,0.13823363,0.98080876,0.13749778,-0.99039965,0.13689499,0.01919106,0,-0.1388306,0.99031614},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02837",cf={9.185175,27.075,4.09538,0.38622921,0.91463994,0.11941851,-0.92240284,0.38297872,0.05000301,0,-0.1294646,0.99158404},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02838",cf={9.686703,27.355,4.024391,0.57228832,0.81458314,0.09455357,-0.82005248,0.56847145,0.0659859,0,-0.11530185,0.9933305},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Sap_02839",cf={9.937467,27.698,3.988896,1,0,0,0,1,0,0,0,1},size={0.168,0.336,0.168},rgb={99,117,47},mask=0,role="MAIN",alpha=0,material="Plastic",collide=false,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Muz_Dilim_02840",cf={7.993498,27.355,4.54209,-0.58378595,0.79060876,0.18474779,-0.8119076,-0.56847145,-0.13283921,0,-0.22754781,0.97376691},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02841",cf={8.480264,27.075,4.401992,-0.39612631,0.88772073,0.23459719,-0.91819603,-0.38297872,-0.10120945,0,-0.25549793,0.9668096},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02842",cf={8.967031,26.935,4.261894,-0.14234171,0.95194211,0.27119191,-0.98981758,-0.13689499,-0.03899903,0,-0.27398171,0.9617349},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02843",cf={9.453798,26.935,4.121796,0.14234171,0.95194211,0.27119191,-0.98981758,0.13689499,0.03899903,0,-0.27398171,0.9617349},size={0.378,0.556341,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02844",cf={9.940565,27.075,3.981697,0.39612631,0.88772073,0.23459719,-0.91819603,0.38297872,0.10120945,0,-0.25549793,0.9668096},size={0.378,0.593333,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Dilim_02845",cf={10.427332,27.355,3.841599,0.58378595,0.79060876,0.18474779,-0.8119076,0.56847145,0.13283921,0,-0.22754781,0.97376691},size={0.378,0.660686,0.448},rgb={224,207,39},mask=63,role="MAIN",alpha=0,material="Plastic",collide=false,reason=""},
  {name="Muz_Sap_02846",cf={10.670715,27.698,3.77155,1,0,0,0,1,0,0,0,1},size={0.168,0.336,0.168},rgb={99,117,47},mask=0,role="MAIN",alpha=0,material="Plastic",collide=false,reason="Delivered source explicit nonstuds surface policy: Plastic"},
 }
 for _,p in ipairs(data) do
  ctx:Part({name=p.name,cframe=E.CFrame.new(table.unpack(p.cf)),size=E.Vector3.new(table.unpack(p.size)),color=E.Color3.fromRGB(table.unpack(p.rgb)),mask=p.mask,role=p.role,alpha=p.alpha,material=E.Enum.Material[p.material],collide=p.collide,exclusionReason=p.reason})
 end
 ctx:Contact("Depo_Doseme_02522","Depo_Yan_Duvar_02523",1e-05)
 ctx:Contact("Depo_Arka_Duvar_02589","Depo_Yan_Duvar_02523",1e-05)
 ctx:Contact("Depo_Doseme_02522","Depo_Yan_Duvar_02556",1e-05)
 ctx:Contact("Depo_Arka_Duvar_02589","Depo_Yan_Duvar_02556",1e-05)
 ctx:Contact("Depo_Doseme_02522","Depo_Arka_Duvar_02589",1e-05)
 ctx.Model:SetAttribute("TrainingScope","PARTIAL_POSITIVE_COMPONENT_NOT_FULL_REFERENCE_GOLD")
 ctx.Model:SetAttribute("SourceOrigin","78,5.6,-53")
end

end)()
-- END INLINE training/positive_pairs/warehouse_interior/Builder.luau

_G.MM41PP03=Factory(M,A,C).new({name="MM41_PP03",ownerKey="MM41_POSITIVE_PP03",requiresStuds=true,sourceModelId=9454666962,scale=1,worldCFrame=CFrame.new(0,8,0),builder=Builder})
print("PP03 ready; Resolve -> real candidate Coupon -> explicit Approve -> Install -> AuditInstalled. No active camera changes; no untextured final main build.")
