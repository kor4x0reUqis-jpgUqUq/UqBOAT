-- SONSKILLS 4.1 standalone positive COMPONENT exercise, not a full map or fully accepted gold.
assert(_G.MM41PP04==nil,"Positive case already registered")

-- BEGIN INLINE tools/Math3.luau
local M=(function()
--!nonstrict
-- Portable numeric implementation; no Roblox globals, assets or runtime animation.
-- Units: stud; vectors {x,y,z}; row-major 3x3 right-handed rotation matrices.
local M = {}
function M.add(a,b) return {a[1]+b[1],a[2]+b[2],a[3]+b[3]} end
function M.sub(a,b) return {a[1]-b[1],a[2]-b[2],a[3]-b[3]} end
function M.mul(a,s) return {a[1]*s,a[2]*s,a[3]*s} end
function M.dot(a,b) return a[1]*b[1]+a[2]*b[2]+a[3]*b[3] end
function M.cross(a,b) return {a[2]*b[3]-a[3]*b[2],a[3]*b[1]-a[1]*b[3],a[1]*b[2]-a[2]*b[1]} end
function M.length(a) return math.sqrt(M.dot(a,a)) end
function M.unit(a)
    local n=M.length(a);assert(n>1e-12,"Zero-length direction");return M.mul(a,1/n)
end
function M.identity() return {1,0,0,0,1,0,0,0,1} end
function M.transpose(r) return {r[1],r[4],r[7],r[2],r[5],r[8],r[3],r[6],r[9]} end
function M.rotate(r,v)
    return {r[1]*v[1]+r[2]*v[2]+r[3]*v[3],r[4]*v[1]+r[5]*v[2]+r[6]*v[3],r[7]*v[1]+r[8]*v[2]+r[9]*v[3]}
end
function M.matmul(a,b)
    local r={}
    for i=0,2 do for j=0,2 do
        local v=0;for k=0,2 do v=v+a[i*3+k+1]*b[k*3+j+1] end
        r[i*3+j+1]=v
    end end
    return r
end
function M.ry(degrees)
    local a=math.rad(degrees);local c,s=math.cos(a),math.sin(a)
    return {c,0,s,0,1,0,-s,0,c}
end
function M.world(origin,r,localPoint,scale)
    assert(not scale or scale>0,"Positive uniform scale required")
    return M.add(origin,M.rotate(r,M.mul(localPoint,scale or 1)))
end
function M.localPoint(origin,r,worldPoint,scale)
    return M.mul(M.rotate(M.transpose(r),M.sub(worldPoint,origin)),1/(scale or 1))
end
function M.det(r)
    return r[1]*(r[5]*r[9]-r[6]*r[8])-r[2]*(r[4]*r[9]-r[6]*r[7])+r[3]*(r[4]*r[8]-r[5]*r[7])
end
function M.rotationValid(r,tol)
    tol=tol or 1e-6
    local rt=M.matmul(M.transpose(r),r);local id=M.identity()
    for i=1,9 do if math.abs(rt[i]-id[i])>tol then return false end end
    return math.abs(M.det(r)-1)<=tol -- reflections are NOT rotations
end
function M.axes(r) return {{r[1],r[4],r[7]},{r[2],r[5],r[8]},{r[3],r[6],r[9]}} end
function M.obbContact(a,b,tolerance)
    local eps=tolerance or 1e-5;assert(eps>=0,"Negative tolerance")
    local aa,bb=M.axes(a.r),M.axes(b.r);local axes={aa[1],aa[2],aa[3],bb[1],bb[2],bb[3]}
    for i=1,3 do for j=1,3 do table.insert(axes,M.cross(aa[i],bb[j])) end end
    local delta=M.sub(b.p,a.p);local greatestGap=-math.huge
    for _,raw in ipairs(axes) do
        local n=M.length(raw)
        if n>1e-10 then
            local axis=M.mul(raw,1/n);local ra,rb=0,0
            for j=1,3 do ra=ra+math.abs(M.dot(axis,aa[j]))*a.s[j]/2;rb=rb+math.abs(M.dot(axis,bb[j]))*b.s[j]/2 end
            local gap=math.abs(M.dot(delta,axis))-ra-rb;greatestGap=math.max(greatestGap,gap)
            if gap>eps then return false,gap end
        end
    end
    return true,greatestGap
end
function M.segmentOBB(a,b,box,tol)
    local e=tol or 1e-7;local inv=M.transpose(box.r)
    a=M.rotate(inv,M.sub(a,box.p));b=M.rotate(inv,M.sub(b,box.p))
    local d=M.sub(b,a);local lo,hi=0,1
    for j=1,3 do
        local h=box.s[j]/2
        if math.abs(d[j])<1e-12 then
            if math.abs(a[j])>h+e then return false end
        else
            local u,v=(-h-a[j])/d[j],(h-a[j])/d[j]
            lo=math.max(lo,math.min(u,v));hi=math.min(hi,math.max(u,v))
            if lo>hi+e then return false end
        end
    end
    return true,lo,hi
end
function M.segmentTriangle(a,b,v0,v1,v2,tolerance)
    local eps=tolerance or 1e-8;local d=M.sub(b,a);local e1=M.sub(v1,v0);local e2=M.sub(v2,v0)
    local h=M.cross(d,e2);local det=M.dot(e1,h)
    if math.abs(det)<eps then return false end
    local f=1/det;local s=M.sub(a,v0);local u=f*M.dot(s,h)
    if u< -eps or u>1+eps then return false end
    local q=M.cross(s,e1);local v=f*M.dot(d,q)
    if v< -eps or u+v>1+eps then return false end
    local t=f*M.dot(e2,q);return t>=-eps and t<=1+eps,t
end
function M.lookBasis(eye,target,up)
    local forward=M.unit(M.sub(target,eye));up=up or {0,1,0}
    if math.abs(M.dot(forward,M.unit(up)))>.999 then up={0,0,1} end
    if math.abs(M.dot(forward,M.unit(up)))>.999 then up={1,0,0} end
    local right=M.unit(M.cross(forward,up));local actualUp=M.cross(right,forward);local back=M.mul(forward,-1)
    return {right[1],actualUp[1],back[1],right[2],actualUp[2],back[2],right[3],actualUp[3],back[3]}
end
function M.project(point,camera)
    local r=M.lookBasis(camera.eye,camera.target,camera.up)
    local q=M.rotate(M.transpose(r),M.sub(point,camera.eye));local depth=-q[3]
    if depth<=0 then return nil,"BEHIND_CAMERA" end
    local t=math.tan(math.rad(camera.fovY)/2);local aspect=camera.width/camera.height
    return {.5+q[1]/(2*depth*t*aspect),.5-q[2]/(2*depth*t),depth}
end
function M.weightedScreenRMS(samples)
    assert(#samples>0,"No anchors");local total,sum=0,0
    for _,s in ipairs(samples) do
        local w=s.weight or 1;assert(w>0,"Positive weight required")
        local dx,dy=s.actual[1]-s.expected[1],s.actual[2]-s.expected[2]
        sum=sum+w*(dx*dx+dy*dy);total=total+w
    end
    return math.sqrt(sum/total)
end
function M.fitScale(measurements)
    local num,den=0,0
    for _,s in ipairs(measurements) do
        local w=s.weight or 1;assert(s.relative>0 and s.known>0 and w>0,"Invalid scale measurement")
        num=num+w*s.relative*s.known;den=den+w*s.relative*s.relative
    end
    assert(den>0,"Scale is not identifiable without known anchors")
    return num/den
end
function M.srgbToLinear(x)
    assert(x>=0 and x<=1,"sRGB normalized 0..1")
    if x<=.04045 then return x/12.92 end
    return ((x+.055)/1.055)^2.4
end
function M.linearToSrgb(x)
    if x<=.0031308 then return 12.92*x end
    return 1.055*x^(1/2.4)-.055
end
function M.tileSize(motifPitch,motifsPerImageTile)
    assert(motifPitch>0 and motifsPerImageTile>0,"Positive motif pitch and count required")
    return motifPitch*motifsPerImageTile
end
-- Closed, open-top hollow shell: outer/inner sides, end walls, gunwales and keel.
-- No Blender/mesh importer. This is numeric data; engine mesh creation is a separate gate.
function M.hullMesh(stations,keelY,topY,thickness)
    assert(#stations>=2 and topY>keelY and thickness>0,"Invalid hull parameters")
    local verts,faces={},{};local n=#stations
    assert(stations[2].x-stations[1].x>2*thickness and stations[n].x-stations[n-1].x>2*thickness,"End thickness exceeds station spacing")
    local function section(x,w,bottom)
        assert(w>1e-6,"Interior width collapsed")
        local h=topY-bottom;local hw=w/2
        return {{x,topY,-hw},{x,bottom+.4*h,-hw},{x,bottom,-.70*hw},{x,bottom,.70*hw},{x,bottom+.4*h,hw},{x,topY,hw}}
    end
    local outer,inner={},{}
    for j,s in ipairs(stations) do
        if j>1 then assert(s.x>stations[j-1].x,"Stations must increase along +X") end
        assert(s.width>2*thickness,"Thickness collapses interior")
        local ox=s.x;local ix=ox+(j==1 and thickness or (j==n and -thickness or 0))
        local oo=section(ox,s.width,keelY);local ii=section(ix,s.width-2*thickness,keelY+thickness)
        outer[j]={};inner[j]={}
        for k=1,6 do table.insert(verts,oo[k]);outer[j][k]=#verts end
        for k=1,6 do table.insert(verts,ii[k]);inner[j][k]=#verts end
    end
    local function tri(a,b,c) table.insert(faces,{a,b,c}) end
    local function quad(a,b,c,d) tri(a,b,c);tri(a,c,d) end
    for j=1,n-1 do
        for k=1,5 do
            quad(outer[j][k],outer[j+1][k],outer[j+1][k+1],outer[j][k+1])
            quad(inner[j][k+1],inner[j+1][k+1],inner[j+1][k],inner[j][k])
        end
        quad(outer[j][1],inner[j][1],inner[j+1][1],outer[j+1][1])
        quad(outer[j][6],outer[j+1][6],inner[j+1][6],inner[j][6])
    end
    for k=2,5 do tri(outer[1][1],outer[1][k],outer[1][k+1]);tri(outer[n][1],outer[n][k+1],outer[n][k]) end
    for k=2,5 do tri(inner[1][1],inner[1][k+1],inner[1][k]);tri(inner[n][1],inner[n][k],inner[n][k+1]) end
    quad(outer[1][1],outer[1][6],inner[1][6],inner[1][1])
    quad(outer[n][6],outer[n][1],inner[n][1],inner[n][6])
    -- Correct signed winding globally. Tests also check edge direction and self-consistency.
    local volume=0
    for _,f in ipairs(faces) do volume=volume+M.dot(verts[f[1]],M.cross(verts[f[2]],verts[f[3]]))/6 end
    if volume<0 then for _,f in ipairs(faces) do f[2],f[3]=f[3],f[2] end;volume=-volume end
    return {vertices=verts,triangles=faces,volume=volume,opening="INTENTIONAL_OPEN_TOP",stations=stations,thickness=thickness}
end
return M

end)()
-- END INLINE tools/Math3.luau

-- BEGIN INLINE tools/Acceptance.luau
local A=(function()
--!nonstrict
-- Pure, testable acceptance state machine. No Roblox calls. A PASS count is not a visual pass.
local A = {}
function A.new(config)
    assert(type(config)=="table" and type(config.requiresStuds)=="boolean","Explicit style contract required")
    local s={state="NEW",requiresStuds=config.requiresStuds,sourceModelId=config.sourceModelId,candidates={},history={"NEW"}}
    local function move(name) s.state=name;table.insert(s.history,name) end
    function s:Resolved(candidates)
        assert(self.requiresStuds,"Resolution not relevant to explicit no-studs mode")
        assert(#candidates>0,"BLOCKED_ASSET: no real images")
        for _,c in ipairs(candidates) do
            assert(c.assetTypeId==1 and c.id~=self.sourceModelId and type(c.uri)=="string","Model/Decal is not an image")
        end
        self.candidates=candidates;self.selected=nil;self.approved=false;move("SOURCE_RESOLVED")
    end
    function s:Coupon(index,profile,signature,fetched)
        assert(self.requiresStuds and self.candidates[index],"Select a listed image explicitly")
        assert(fetched==true,"BLOCKED_FETCH")
        assert(profile.tileU>0 and profile.tileV>0 and profile.transparency>=0 and profile.transparency<1,"Invalid physical tile/contrast")
        assert(type(signature)=="string" and #signature>0,"Coupon signature required")
        self.selected=self.candidates[index];self.profile=profile;self.signature=signature;self.fetched=true;self.approved=false
        move("COUPON_READY")
    end
    function s:Approve(token,liveSignature)
        assert(self.state=="COUPON_READY","Live coupon required; source resolution is not visual approval")
        assert(token=="KUPONU_GORSEL_OLARAK_ONAYLIYORUM","Human visual acknowledgement required")
        assert(liveSignature==self.signature,"Coupon/image/profile changed; build a new coupon")
        self.approved=true;move("VISUAL_ACKNOWLEDGED")
    end
    function s:ExplicitNoStuds(token,reason)
        assert(not self.requiresStuds,"No-studs cannot bypass a required studs contract")
        assert(token=="KULLANICI_ACIKCA_STUDS_ISTEMIYOR" and type(reason)=="string" and #reason>0,"Explicit user style exception required")
        self.noStudsReason=reason;move("EXPLICIT_NO_STUDS")
    end
    function s:BeginInstall(liveSignature)
        if self.requiresStuds then
            assert(self.approved and self.fetched and self.selected,"BLOCKED: do not install an untextured final model")
            assert(liveSignature==self.signature,"Live coupon became stale")
        else assert(self.noStudsReason,"No implicit texture fallback") end
        self.applied=nil;self.expected=nil
        move("STAGING")
    end
    function s:Applied(actual,expected)
        assert(self.state=="STAGING","Staging required")
        assert(actual==expected,"Texture face omissions/duplicates")
        if self.requiresStuds then assert(expected>0,"Required texture was not actually applied") end
        self.applied=actual;self.expected=expected
    end
    function s:Commit(report)
        assert(self.state=="STAGING" and self.applied~=nil,"Apply/audit actual staged output before commit")
        assert(report.geometryPass==true and report.texturePass==true,"Failed geometry/texture audit")
        assert(report.cameraUntouched==true,"Installer changed user camera")
        assert(report.foreignCode==false and report.primaryInstaller==true,"Unsafe source or wrong delivery")
        self.report=report;move("COMMITTED_REVIEW_PENDING")
    end
    function s:AbortInstall(reason)
        self.lastError=reason;self.applied=nil;self.expected=nil
        move(self.requiresStuds and (self.approved and "VISUAL_ACKNOWLEDGED" or "SOURCE_RESOLVED") or "EXPLICIT_NO_STUDS")
    end
    function s:FinalAcceptance(evidence)
        assert(self.state=="COMMITTED_REVIEW_PENDING","Commit first")
        for _,key in ipairs({"studioOpen","studioAPI","referenceVisual","criticalCloseups","cameraControl","assetAccess"}) do
            assert(evidence[key]=="PASS","Not accepted: "..key)
        end
        assert(evidence.fps=="PASS" or evidence.fps=="NOT_REQUESTED_WITH_DISCLOSURE","Do not invent FPS")
        move("USER_ACCEPTED_SCOPE")
    end
    return s
end
return A

end)()
-- END INLINE tools/Acceptance.luau

-- BEGIN INLINE tools/CameraGuard.luau
local C=(function()
--!nonstrict
-- Default: do not modify CurrentCamera, type, subject, CFrame, focus or FOV.
-- An explicit optional capture runs in a try/finally-like guard; no render-step binding.
local C = {}
local fields={"CameraType","CameraSubject","CFrame","Focus","FieldOfView"}
function C.snapshot(camera)
    if not camera then return {camera=nil} end
    local s={camera=camera}
    for _,k in ipairs(fields) do s[k]=camera[k] end
    return s
end
function C.unchanged(snapshot,camera)
    if snapshot.camera~=camera then return false,"CurrentCamera object changed" end
    if not camera then return true end
    for _,k in ipairs(fields) do if snapshot[k]~=camera[k] then return false,k.." changed" end end
    return true
end
function C.withPose(getCamera,pose,callback,acknowledgement)
    assert(acknowledgement=="KAMERA_POZUNU_GECICI_KULLAN","Camera changes are opt-in only")
    assert(type(callback)=="function","A bounded capture callback is required")
    local camera=getCamera();assert(camera,"No CurrentCamera")
    local before=C.snapshot(camera)
    local result=table.pack(xpcall(function()
        if pose.CameraType then camera.CameraType=pose.CameraType end
        if pose.CFrame then camera.CFrame=pose.CFrame end
        if pose.Focus then camera.Focus=pose.Focus end
        if pose.FieldOfView then camera.FieldOfView=pose.FieldOfView end
        return callback(camera)
    end,debug.traceback))
    local restoreErrors={}
    -- Never replace workspace.CurrentCamera or overwrite a newly selected camera.
    local stillCurrent=getCamera()==camera
    do
        for _,k in ipairs({"CFrame","Focus","FieldOfView","CameraSubject","CameraType"}) do
            -- CameraSubject cannot be set to nil. Nil is therefore never assigned.
            if before[k]~=nil then
                local ok,err=pcall(function() camera[k]=before[k] end)
                if not ok then table.insert(restoreErrors,k..": "..tostring(err)) end
            end
        end
    end
    if not stillCurrent then table.insert(restoreErrors,"CurrentCamera changed during capture; new camera was not touched") end
    local equal,changed=C.unchanged(before,camera)
    if not equal then table.insert(restoreErrors,"Snapshot not fully restored: "..tostring(changed)) end
    if #restoreErrors>0 then error("Camera restoration requires manual review: "..table.concat(restoreErrors," | ")) end
    if not result[1] then error(result[2],0) end
    return table.unpack(result,2,result.n)
end
return C

end)()
-- END INLINE tools/CameraGuard.luau

-- BEGIN INLINE tools/StudioKit.luau
local Factory=(function()
--!nonstrict
-- Actual Studio EDIT adapter. Assembled installers inline this factory and its dependencies.
-- No foreign require/loadstring, HTTP script, filesystem or .rbx* file dependency.
return function(Math3,Acceptance,CameraGuard,Environment)
local env=Environment or {game=game,workspace=workspace,Instance=Instance,Enum=Enum,Content=Content,Vector3=Vector3,Color3=Color3,CFrame=CFrame,typeof=typeof,task=task,warn=warn,print=print}
local game,workspace,Instance,Enum,Content=env.game,env.workspace,env.Instance,env.Enum,env.Content
local Vector3,Color3,CFrame,typeof,task=env.Vector3,env.Color3,env.CFrame,env.typeof,env.task
local warn,print=env.warn,env.print
local K = {}
local RunService=game:GetService("RunService")
local ContentProvider=game:GetService("ContentProvider")
local Marketplace=game:GetService("MarketplaceService")
local ChangeHistory=game:GetService("ChangeHistoryService")
local HttpService=game:GetService("HttpService")
local FACES={
 {name="Right",bit=1,normal=Enum.NormalId.Right,axes={"Z","Y"}},
 {name="Top",bit=2,normal=Enum.NormalId.Top,axes={"X","Z"}},
 {name="Back",bit=4,normal=Enum.NormalId.Back,axes={"X","Y"}},
 {name="Left",bit=8,normal=Enum.NormalId.Left,axes={"Z","Y"}},
 {name="Bottom",bit=16,normal=Enum.NormalId.Bottom,axes={"X","Z"}},
 {name="Front",bit=32,normal=Enum.NormalId.Front,axes={"X","Y"}},
}
local PREFIX="MM4_Studs_"
local function editOnly()
 assert(RunService:IsStudio() and not RunService:IsRunning(),"Studio EDIT Command Bar required; stop Play/Run")
end
local function contentURI(value)
 if type(value)=="string" then return value end
 if typeof(value)=="Content" then
  local ok,u=pcall(function() return value.Uri end)
  if ok and type(u)=="string" then return u end
 end
 return nil
end
local function imageID(uri)
 if type(uri)~="string" then return nil end
 local s=string.match(uri,"^%s*(.-)%s*$")
 local id=string.match(s,"^rbxassetid://(%d+)$")
 if not id then
  local host,query=string.match(s,"^https?://([^/]+)/asset/?%?(.*)$")
  if host=="www.roblox.com" or host=="roblox.com" then
   id=string.match("&"..query,"[&]id=(%d+)[&]?")
  end
 end
 local n=tonumber(id);if n and n>0 and n%1==0 then return n end
 return nil
end
local function info(id) return Marketplace:GetProductInfoAsync(id,Enum.InfoType.Asset) end
local function safeImageStrings(id)
 local roots={};local output={}
 local ok,err=xpcall(function()
  roots=game:GetObjects("rbxassetid://"..tostring(id)) -- PluginSecurity: EDIT Command Bar
  for _,root in ipairs(roots) do
   assert(root.Parent==nil,"Foreign root unexpectedly parented")
   if root:IsA("LuaSourceContainer") then root:Destroy() else
    for _,x in ipairs(root:GetDescendants()) do if x:IsA("LuaSourceContainer") then x:Destroy() end end
    local list={root};for _,x in ipairs(root:GetDescendants()) do table.insert(list,x) end
    for _,x in ipairs(list) do
     local names={}
     if x:IsA("Decal") then names={"TextureContent","ColorMapContent","Texture","ColorMap"}
     elseif x:IsA("MeshPart") then names={"TextureContent","TextureID"}
     elseif x:IsA("SpecialMesh") then names={"TextureId"}
     elseif x:IsA("SurfaceAppearance") or x:IsA("MaterialVariant") then names={"ColorMapContent","ColorMap"}
     elseif x:IsA("ImageLabel") or x:IsA("ImageButton") then names={"ImageContent","Image"} end
     for _,property in ipairs(names) do
      local readable,value=pcall(function() return x[property] end)
      local uri=readable and contentURI(value) or nil
      if uri and uri~="" then table.insert(output,{uri=uri,path=x:GetFullName(),property=property}) end
     end
    end
   end
  end
 end,debug.traceback)
 -- The finally-equivalent cleanup also runs when property/metadata inspection fails.
 for _,root in ipairs(roots) do pcall(function() root:Destroy() end) end
 if not ok then error("BLOCKED_ASSET: "..tostring(err),0) end
 return output
end
local function resolveModel(sourceID)
 local source=info(sourceID);assert(source.AssetTypeId==10,"Configured source must still be Model(10)")
 local candidates,seen,visited={},{},{}
 local function resolve(items,chain)
  for _,item in ipairs(items) do
   local id=imageID(item.uri)
   if id and id~=sourceID then
    local ok,metadata=pcall(info,id)
    if not ok then warn("Image metadata denied",id,metadata)
    elseif metadata.AssetTypeId==1 and not seen[id] then
     seen[id]=true;table.insert(candidates,{id=id,uri="rbxassetid://"..id,assetTypeId=1,name=metadata.Name,sourcePath=chain.." / "..item.path,sourceProperty=item.property})
    elseif metadata.AssetTypeId==13 and not visited[id] then
     visited[id]=true;resolve(safeImageStrings(id),chain.." -> Decal#"..id)
    elseif metadata.AssetTypeId~=1 and metadata.AssetTypeId~=13 then warn("Rejected non-image content",id,metadata.AssetTypeId) end
   end
  end
 end
 resolve(safeImageStrings(sourceID),"Model#"..sourceID)
 table.sort(candidates,function(a,b) return a.id<b.id end)
 return candidates
end
local function fetch(uri)
 local success=false
 local events=0;local failed=false
 local ok,err=pcall(function()
  ContentProvider:PreloadAsync({uri},function(_,status)
   events=events+1;if status~=Enum.AssetFetchStatus.Success then failed=true end
  end)
 end)
 success=ok and events>0 and not failed
 assert(success,"BLOCKED_FETCH: "..tostring(err));return true
end
local function profileCopy(p)
 assert(type(p)=="table","Specify actual tile sizes, contrast and phase policy")
 assert(type(p.tileU)=="number" and type(p.tileV)=="number" and p.tileU>0 and p.tileV>0 and p.tileU<math.huge and p.tileV<math.huge,"Finite positive tileU/tileV in studs")
 assert(p.transparency and p.transparency>=0 and p.transparency<1,"Contrast must be explicit")
 for _,x in ipairs({p.woodMinTransparency or p.transparency,p.thinMinTransparency or p.transparency}) do assert(type(x)=="number" and x>=0 and x<1,"Role contrast must remain visible 0..1 exclusive") end
 assert(p.phaseMode=="LOCAL_ZERO","This adapter supports LOCAL_ZERO only; do not claim world UV continuity")
 return {tileU=p.tileU,tileV=p.tileV,transparency=p.transparency,phaseMode=p.phaseMode,
  woodMinTransparency=p.woodMinTransparency or p.transparency,thinMinTransparency=p.thinMinTransparency or p.transparency}
end
local function signature(uri,p)
 return string.format("%s|%.9g|%.9g|%.9g|%s|%.9g|%.9g",uri,p.tileU,p.tileV,p.transparency,p.phaseMode,p.woodMinTransparency,p.thinMinTransparency)
end
local function transparency(part,face,p)
 local a=p.transparency
 if part:GetAttribute("MM4Role")=="WOOD" then a=math.max(a,p.woodMinTransparency) end
 if math.min(part.Size[face.axes[1]]/p.tileU,part.Size[face.axes[2]]/p.tileV)<.35 then a=math.max(a,p.thinMinTransparency) end
 return a
end
local function putTexture(part,face,uri,p)
 local t=Instance.new("Texture");t.Name=PREFIX..face.name;t.Face=face.normal
 -- Current Content API; TextureContent is serializable. Same verified URI, no invented asset.
 t.TextureContent=Content.fromUri(uri);t.StudsPerTileU=p.tileU;t.StudsPerTileV=p.tileV
 t.OffsetStudsU=0;t.OffsetStudsV=0;t.Color3=Color3.new(1,1,1);t.Transparency=transparency(part,face,p);t.Parent=part
 return t
end
local function auditTextures(model,uri,p,requiresStuds)
 local actual,expected,instances=0,0,0;local errors={};local perFace={}
 for _,face in ipairs(FACES) do perFace[face.name]=0 end
 for _,part in ipairs(model:GetDescendants()) do
  if part:IsA("BasePart") then
   local mask=part:GetAttribute("MM4Mask")
   assert(type(mask)=="number","Every part needs an explicit surface policy: "..part.Name)
   local own=0;for _,t in ipairs(part:GetChildren()) do if t:IsA("Texture") and string.sub(t.Name,1,#PREFIX)==PREFIX then own=own+1 end end
   local wantCount=0
   for _,face in ipairs(FACES) do
    local want=requiresStuds and bit32.band(mask,face.bit)~=0
    local t=part:FindFirstChild(PREFIX..face.name)
    if want then
     expected=expected+1;wantCount=wantCount+1
     if not t or not t:IsA("Texture") or t.Face~=face.normal or contentURI(t.TextureContent)~=uri then
      table.insert(errors,part.Name.." / "..face.name.." missing/wrong image or direction")
     elseif math.abs(t.StudsPerTileU-p.tileU)>1e-5 or math.abs(t.StudsPerTileV-p.tileV)>1e-5 or math.abs(t.Transparency-transparency(part,face,p))>1e-4 or t.Color3~=Color3.new(1,1,1) or t.OffsetStudsU~=0 or t.OffsetStudsV~=0 then
      table.insert(errors,part.Name.." / "..face.name.." scale/contrast/tint/phase mismatch")
     else actual=actual+1;perFace[face.name]=perFace[face.name]+1 end
    elseif t then table.insert(errors,part.Name.." excluded face has a texture") end
   end
   instances=instances+own
   if own~=wantCount then table.insert(errors,part.Name.." duplicate/unexpected texture layer") end
  end
 end
 return {pass=#errors==0,actual=actual,expected=expected,instances=instances,perFace=perFace,errors=errors}
end
local function assertSurfaceManifest(model,manifest)
 local seen={}
 for _,part in ipairs(model:GetDescendants()) do if part:IsA("BasePart") then
  local rule=manifest[part.Name];assert(rule and not seen[part.Name],"New/duplicate part requires a new surface contract")
  assert(part:IsA("Part") and part.Shape==Enum.PartType.Block,"Block adapter cannot certify curved/mesh faces")
  assert(part:GetAttribute("MM4Mask")==rule.mask and part:GetAttribute("MM4Role")==rule.role and part:GetAttribute("MM4Exclusion")==rule.reason,"Surface contract modified since creation/visual acknowledgement")
  seen[part.Name]=true
 end end
 for name in pairs(manifest) do assert(seen[name],"Installed/staged part removed: "..name) end
end
local function obb(part)
 assert(part:IsA("Part") and part.Shape==Enum.PartType.Block,"OBB is not the exact surface of a mesh/wedge/cylinder")
 local x,y,z,a,b,c,d,e,f,g,h,i=part.CFrame:GetComponents()
 return {p={x,y,z},s={part.Size.X,part.Size.Y,part.Size.Z},r={a,b,c,d,e,f,g,h,i}}
end
function K.new(config)
 editOnly();assert(type(config.builder)=="function","Complete build function required")
 assert(config.name and config.ownerKey and type(config.requiresStuds)=="boolean","Explicit name/ownership/style required")
 local installedSurfaceManifest=nil
 local kit={Config=config,Policy=Acceptance.new(config),CouponModel=nil,Root=nil,Checks={},Session=HttpService:GenerateGUID(false)}
 function kit:Resolve()
  editOnly();self.Policy.approved=false;local candidates=resolveModel(self.Config.sourceModelId);self.Policy:Resolved(candidates)
  for i,c in ipairs(candidates) do print(i,c.uri,c.name,c.sourcePath,c.sourceProperty) end
  print("RESOLVED ONLY. No candidate selected, no approval, no final geometry installed.")
  return candidates
 end
 function kit:Coupon(index,profile,origin)
  editOnly();local candidate=self.Policy.candidates[index];assert(candidate,"Select an actual listed candidate")
  self.Policy.approved=false
  local p=profileCopy(profile);fetch(candidate.uri)
  if self.CouponModel then self.CouponModel:Destroy() end
  local model=Instance.new("Model");model.Name="MM4_Coupon_"..self.Session
  model:SetAttribute("MM4Owner",self.Config.ownerKey)
  local colors={Color3.fromRGB(218,80,53),Color3.fromRGB(226,235,235),Color3.fromRGB(169,117,69),Color3.fromRGB(224,207,39),Color3.fromRGB(52,139,189)}
  local center=origin or Vector3.new(0,12,0)
  for j,color in ipairs(colors) do
   local part=Instance.new("Part");part.Name=(j==5 and "Inclined30" or "Flat"..j);part.Anchored=true;part.CanCollide=false
   part.Size=Vector3.new(6,6,6);part.CFrame=CFrame.new(center+Vector3.new((j-3)*9,0,0))*(j==5 and CFrame.Angles(0,0,math.rad(30)) or CFrame.new())
   part.Color=color;part.Material=Enum.Material.Plastic;part.TopSurface=Enum.SurfaceType.Smooth;part.BottomSurface=Enum.SurfaceType.Smooth
   part:SetAttribute("MM4Mask",63);part:SetAttribute("MM4Role",j==3 and "WOOD" or "MAIN")
   for _,face in ipairs(FACES) do putTexture(part,face,candidate.uri,p) end
   part.Parent=model
  end
  model:SetAttribute("ImageURI",candidate.uri);model:SetAttribute("VisualAcknowledged",false);model.Parent=workspace
  self.CouponModel=model;self.Profile=p
  self.Policy:Coupon(index,p,signature(candidate.uri,p),true)
  print("COUPON READY: inspect all 30 faces, wood/red/white/yellow and slope; camera NOT moved. Select coupon and press F manually if desired.")
  return model
 end
 function kit:Approve(token)
  editOnly();assert(self.CouponModel and self.CouponModel.Parent,"Live coupon required")
  local p=self.Profile;local selected=self.Policy.selected
  local r=auditTextures(self.CouponModel,selected.uri,p,true)
  assert(r.pass and r.expected==30,"Coupon changed: regenerate it")
  local sig=signature(selected.uri,p);self.Policy:Approve(token,sig);self.CouponModel:SetAttribute("VisualAcknowledged",true)
  print("Human visual acknowledgement recorded. Model still not installed.")
 end
 function kit:ExplicitNoStuds(token,reason) editOnly();self.Policy:ExplicitNoStuds(token,reason) end
 function kit:Install(token,replaceOwned)
  editOnly();assert(token=="ONAYLI_KURULUMU_BASLAT","Explicit install command required")
  local before=CameraGuard.snapshot(workspace.CurrentCamera)
  local uri=self.Policy.selected and self.Policy.selected.uri or nil
  local sig=uri and signature(uri,self.Profile) or nil
  if self.Config.requiresStuds then
   assert(self.CouponModel and self.CouponModel.Parent,"Keep live coupon until install")
   local cr=auditTextures(self.CouponModel,uri,self.Profile,true);assert(cr.pass and cr.expected==30,"Coupon changed")
   fetch(uri)
  end
  local old=workspace:FindFirstChild(self.Config.name)
  local oldName=old and old.Name or nil;local oldParent=old and old.Parent or nil
  if old then
   assert(old:GetAttribute("MM4Owner")==self.Config.ownerKey,"Refuse to replace a user/unowned model")
   assert(replaceOwned==true,"Owned model exists; pass true explicitly to replace after staging audit")
  end
  self.Policy:BeginInstall(sig)
  local stage=Instance.new("Model");stage.Name=self.Config.name;stage:SetAttribute("MM4Owner",self.Config.ownerKey);stage:SetAttribute("MM4Version","4.1.0")
  local byName,checks,surfaceManifest={},{},{};local scale=self.Config.scale or 1;assert(scale>0,"Positive geometry scale")
  local worldCF=self.Config.worldCFrame or CFrame.new()
  local ctx={Model=stage,Parts=byName,Checks=checks,Scale=scale,WorldCFrame=worldCF,ImageURI=uri,Profile=self.Profile,Env=env}
  function ctx:Part(spec)
   assert(type(spec.name)=="string" and not byName[spec.name],"Unique semantic part name required")
   assert(spec.size and spec.cframe and spec.color and type(spec.mask)=="number" and spec.role,"Explicit geometry/material/surface contract required")
   assert(not spec.shape or spec.shape=="Block","This adapter only supports exact Block surfaces; use an explicit mesh/CSG adapter")
   assert(spec.size.X>0 and spec.size.Y>0 and spec.size.Z>0,"Positive dimensions")
   assert(spec.mask>=0 and spec.mask<=63 and spec.mask%1==0,"6-bit face mask required")
   if spec.mask==0 then assert(type(spec.exclusionReason)=="string" and #spec.exclusionReason>0,"Explain every surface exception") end
   local p=Instance.new("Part");p.Name=spec.name;p.Anchored=true;p.Size=spec.size*scale
   p.CFrame=worldCF*CFrame.new(spec.cframe.Position*scale)*spec.cframe.Rotation
   p.Color=spec.color;p.Material=spec.material or Enum.Material.Plastic;p.Transparency=spec.alpha or 0
   p.CanCollide=spec.collide~=false;p.CanTouch=false;p.CanQuery=spec.query~=false;p.CastShadow=p.Transparency==0
   for _,face in ipairs(FACES) do p[face.name.."Surface"]=Enum.SurfaceType.Smooth end
   p:SetAttribute("MM4Mask",spec.mask);p:SetAttribute("MM4Role",spec.role);p:SetAttribute("MM4Exclusion",spec.exclusionReason or "")
   p:SetAttribute("MM4ShapeState","CLOSED_NATIVE_PRIMITIVE")
   p.Parent=stage;byName[spec.name]=p;surfaceManifest[spec.name]={mask=spec.mask,role=spec.role,reason=spec.exclusionReason or ""};return p
  end
  function ctx:Contact(a,b,tolerance)
   table.insert(checks,{kind="CONTACT",a=a,b=b,tolerance=(tolerance or 1e-5)*scale})
  end
  function ctx:OpenRay(a,b,names)
   table.insert(checks,{kind="OPEN_RAY",a=(worldCF*CFrame.new(a*scale)).Position,b=(worldCF*CFrame.new(b*scale)).Position,names=names})
  end
  local ok,err=xpcall(function()
   self.Config.builder(ctx)
   assert(next(byName),"Empty builder")
   assertSurfaceManifest(stage,surfaceManifest)
   for _,c in ipairs(checks) do
    if c.kind=="CONTACT" then
     assert(byName[c.a] and byName[c.b],"Contact references must exist")
     assert(Math3.obbContact(obb(byName[c.a]),obb(byName[c.b]),c.tolerance),"Disconnected "..c.a.." -> "..c.b)
    elseif c.kind=="OPEN_RAY" then
     local a,b={c.a.X,c.a.Y,c.a.Z},{c.b.X,c.b.Y,c.b.Z}
     for _,name in ipairs(c.names) do assert(byName[name],"Aperture part missing");assert(not Math3.segmentOBB(a,b,obb(byName[name])),"Blocked opening: "..name) end
    end
   end
   local count=0
   for _,part in pairs(byName) do
    if self.Config.requiresStuds then for _,face in ipairs(FACES) do
     if bit32.band(part:GetAttribute("MM4Mask"),face.bit)~=0 then putTexture(part,face,uri,self.Profile);count=count+1;if count%1500==0 then task.wait() end end
    end end
   end
   local audit=auditTextures(stage,uri,self.Profile,self.Config.requiresStuds)
   assert(audit.pass,table.concat(audit.errors,"\n"));self.Policy:Applied(audit.actual,audit.expected)
   local unchanged,why=CameraGuard.unchanged(before,workspace.CurrentCamera)
   assert(unchanged,"Camera snapshot changed during staging; no commit. "..tostring(why))
   local commitReport={geometryPass=true,texturePass=true,cameraUntouched=true,foreignCode=false,primaryInstaller=true,surfaceAudit=audit,contactChecks=#checks}
   stage:SetAttribute("MM4TextureStatus",self.Config.requiresStuds and "ACTUALLY_APPLIED_REFERENCE_REVIEW_PENDING" or "NO_STUDS_EXPLICIT_USER_STYLE")
   if uri then stage:SetAttribute("MM4VerifiedImageURI",uri);stage:SetAttribute("MM4TileU",self.Profile.tileU);stage:SetAttribute("MM4TileV",self.Profile.tileV) end
   stage:SetAttribute("MM4ReferenceVisual","PENDING");stage:SetAttribute("MM4FPS","NOT_MEASURED")
   pcall(function() ChangeHistory:SetWaypoint("MM4 before commit") end)
   stage.Parent=workspace
   if old then
    local backups=game:GetService("ServerStorage"):FindFirstChild("MM4_Backups")
    if not backups then backups=Instance.new("Folder");backups.Name="MM4_Backups";backups.Parent=game:GetService("ServerStorage") end
    old.Name=old.Name.."_"..self.Session;old.Parent=backups -- retain editable prior result; no silent deletion
   end
   self.Policy:Commit(commitReport)
   self.Root=stage;self.LastAudit=audit;installedSurfaceManifest=surfaceManifest
   pcall(function() ChangeHistory:SetWaypoint("MM4 after commit") end)
   print("Installed via standalone code with actual surface audit. Reference/closeup/FPS review remains PENDING.",audit.actual,audit.expected)
  end,debug.traceback)
  if not ok then
   if old then pcall(function() old.Name=oldName;old.Parent=oldParent end) end
   stage:Destroy();self.Policy:AbortInstall(tostring(err))
   error("STAGING ABORTED; existing scene retained. "..tostring(err),0)
  end
  return stage,self.LastAudit
 end
 function kit:AuditInstalled()
  editOnly();assert(self.Root and self.Root.Parent and installedSurfaceManifest,"No installed owned scene")
  assertSurfaceManifest(self.Root,installedSurfaceManifest)
  local uri=self.Policy.selected and self.Policy.selected.uri or nil
  if uri then assert(signature(uri,self.Profile)==self.Policy.signature,"Profile changed since acknowledgement") end
  local result=auditTextures(self.Root,uri,self.Profile,self.Config.requiresStuds)
  if self.Config.requiresStuds then assert(result.expected>0,"Required texture disappeared") end
  self.LastAudit=result;return result
 end
 function kit:RemoveCoupon()
  editOnly();if self.CouponModel then self.CouponModel:Destroy();self.CouponModel=nil end
  -- No camera reset necessary: coupon creation never touched the camera.
 end
 function kit:WithView(pose,callback,token)
  editOnly();return CameraGuard.withPose(function() return workspace.CurrentCamera end,pose,callback,token)
 end
 function kit:Status() return {state=self.Policy.state,history=self.Policy.history,sourceModelId=self.Config.sourceModelId,selected=self.Policy.selected,actuallyApplied=self.LastAudit,referenceVisual="PENDING",fps="NOT_MEASURED"} end
 return kit
end
return K
end

end)()
-- END INLINE tools/StudioKit.luau

-- BEGIN INLINE training/positive_pairs/blue_roof_hut/Builder.luau
local Builder=(function()
-- Exact delivered reconstruction subset, PARTIAL POSITIVE ONLY. Not source-game dimensions or full-model gold.
-- Native camera/doku/code defects are not inherited; new wrapper is texture-gated and default camera read-only.
return function(ctx)
 local E=ctx.Env or {Vector3=Vector3,CFrame=CFrame,Color3=Color3,Enum=Enum}
 local pivot=ctx:Part({name="PositivePairOrigin",cframe=E.CFrame.new(),size=E.Vector3.new(.1,.1,.1),color=E.Color3.new(0,0,0),role="PIVOT",mask=0,alpha=1,collide=false,query=false,exclusionReason="Invisible positive-pair origin"})
 ctx.Model.PrimaryPart=pivot
 local data={
  {name="Kabin_Doseme_03804",cf={0,0.3,0,1,0,0,0,1,0,0,0,1},size={15,0.6,15},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Alt_03805",cf={-7.2,2.64,0,1,0,0,0,1,0,0,0,1},size={0.6,5.28,15},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Ust_03806",cf={-7.2,11.35,0,1,0,0,0,1,0,0,0,1},size={0.6,1.3,15},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Dikme_03807",cf={-7.2,7.8,-7.2,1,0,0,0,1,0,0,0,1},size={0.6,8.4,0.65},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Dikme_03808",cf={-7.2,7.8,7.2,1,0,0,0,1,0,0,0,1},size={0.6,8.4,0.65},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Cam_03809",cf={-7.22,7.99,0,1,0,0,0,1,0,0,0,1},size={0.12,5.42,13.8},rgb={42,72,103},mask=0,role="MAIN",alpha=0.27,material="Glass",collide=true,reason="Delivered source explicit nonstuds surface policy: Glass"},
  {name="Kabin_Yan_Alt_03810",cf={7.2,2.64,0,1,0,0,0,1,0,0,0,1},size={0.6,5.28,15},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Ust_03811",cf={7.2,11.35,0,1,0,0,0,1,0,0,0,1},size={0.6,1.3,15},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Dikme_03812",cf={7.2,7.8,-7.2,1,0,0,0,1,0,0,0,1},size={0.6,8.4,0.65},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Dikme_03813",cf={7.2,7.8,7.2,1,0,0,0,1,0,0,0,1},size={0.6,8.4,0.65},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Yan_Cam_03814",cf={7.22,7.99,0,1,0,0,0,1,0,0,0,1},size={0.12,5.42,13.8},rgb={42,72,103},mask=0,role="MAIN",alpha=0.27,material="Glass",collide=true,reason="Delivered source explicit nonstuds surface policy: Glass"},
  {name="Kabin_Arka_Alt_03815",cf={0,2.76,-7.2,1,0,0,0,1,0,0,0,1},size={15,5.52,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Arka_Ust_03816",cf={0,11.4,-7.2,1,0,0,0,1,0,0,0,1},size={15,1.2,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Arka_Dikme_03817",cf={-7.05,7.92,-7.2,1,0,0,0,1,0,0,0,1},size={0.9,8.4,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Arka_Dikme_03818",cf={7.05,7.92,-7.2,1,0,0,0,1,0,0,0,1},size={0.9,8.4,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_Arka_Cam_03819",cf={0,8.16,-7.23,1,0,0,0,1,0,0,0,1},size={13.2,5.28,0.12},rgb={37,71,104},mask=0,role="MAIN",alpha=0.3,material="Glass",collide=true,reason="Delivered source explicit nonstuds surface policy: Glass"},
  {name="Kabin_On_Sol_03820",cf={-2,2.4,7.2,1,0,0,0,1,0,0,0,1},size={11,4.8,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_On_Ust_03821",cf={0,11.4,7.2,1,0,0,0,1,0,0,0,1},size={15,1.2,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_On_Dikme_03822",cf={-7.2,7.92,7.2,1,0,0,0,1,0,0,0,1},size={0.6,8.4,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_On_Dikme_03823",cf={3.2,7.92,7.2,1,0,0,0,1,0,0,0,1},size={0.6,8.4,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_On_Dikme_03824",cf={7.2,7.92,7.2,1,0,0,0,1,0,0,0,1},size={0.6,8.4,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kabin_On_Cam_03825",cf={-2,7.8,7.23,1,0,0,0,1,0,0,0,1},size={9.8,6,0.12},rgb={38,76,111},mask=0,role="MAIN",alpha=0.25,material="Glass",collide=true,reason="Delivered source explicit nonstuds surface policy: Glass"},
  {name="Kabin_Cati_03826",cf={0,12.25,0,1,0,0,0,1,0,0,0,1},size={16.4,0.65,16.4},rgb={56,115,180},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Ic_Kumanda_Masasi_03827",cf={0,1.5,-4.2,1,0,0,0,1,0,0,0,1},size={9,2.1,1.8},rgb={56,70,77},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Ic_Gosterge_03828",cf={-2.4,2.65,-3.75,1,0,0,0,1,0,0,0,1},size={1.1,0.28,0.7},rgb={27,37,42},mask=0,role="MAIN",alpha=0,material="Plastic",collide=true,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Ic_Gosterge_03829",cf={2.4,2.65,-3.75,1,0,0,0,1,0,0,0,1},size={1.1,0.28,0.7},rgb={27,37,42},mask=0,role="MAIN",alpha=0,material="Plastic",collide=true,reason="Delivered source explicit nonstuds surface policy: Plastic"},
  {name="Ic_Koltuk_03830",cf={0,0.9,0,1,0,0,0,1,0,0,0,1},size={2.3,1.2,2.3},rgb={53,68,77},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Ic_Koltuk_Arka_03831",cf={0,2.1,0.9,1,0,0,0,1,0,0,0,1},size={2.3,2,0.4},rgb={53,68,77},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Egimli_Cati_03832",cf={-4.4,14.2,0,0.91354546,-0.40673664,0,0.40673664,0.91354546,0,0,0,1},size={10,0.8,17},rgb={48,104,171},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Egimli_Cati_03833",cf={4.4,14.2,0,0.91354546,0.40673664,0,-0.40673664,0.91354546,0,0,0,1},size={10,0.8,17},rgb={48,104,171},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03834",cf={0,12.705,-7.2,1,0,0,0,1,0,0,0,1},size={14.468969,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03835",cf={0,13.105,-7.2,1,0,0,0,1,0,0,0,1},size={12.672139,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03836",cf={0,13.505,-7.2,1,0,0,0,1,0,0,0,1},size={10.87531,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03837",cf={0,13.905,-7.2,1,0,0,0,1,0,0,0,1},size={9.078481,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03838",cf={0,14.305,-7.2,1,0,0,0,1,0,0,0,1},size={7.281651,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03839",cf={0,14.705,-7.2,1,0,0,0,1,0,0,0,1},size={5.484822,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03840",cf={0,15.105,-7.2,1,0,0,0,1,0,0,0,1},size={3.687992,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03841",cf={0,15.505,-7.2,1,0,0,0,1,0,0,0,1},size={1.891163,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03842",cf={0,12.705,7.2,1,0,0,0,1,0,0,0,1},size={14.468969,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03843",cf={0,13.105,7.2,1,0,0,0,1,0,0,0,1},size={12.672139,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03844",cf={0,13.505,7.2,1,0,0,0,1,0,0,0,1},size={10.87531,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03845",cf={0,13.905,7.2,1,0,0,0,1,0,0,0,1},size={9.078481,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03846",cf={0,14.305,7.2,1,0,0,0,1,0,0,0,1},size={7.281651,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03847",cf={0,14.705,7.2,1,0,0,0,1,0,0,0,1},size={5.484822,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03848",cf={0,15.105,7.2,1,0,0,0,1,0,0,0,1},size={3.687992,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Kapali_Kalkan_Duvari_03849",cf={0,15.505,7.2,1,0,0,0,1,0,0,0,1},size={1.891163,0.41,0.6},rgb={155,108,57},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
  {name="Kulube_Baca_03850",cf={5,16.8,-2,1,0,0,0,1,0,0,0,1},size={2.2,6.4,2.2},rgb={31,40,45},mask=63,role="MAIN",alpha=0,material="Plastic",collide=true,reason=""},
 }
 for _,p in ipairs(data) do
  ctx:Part({name=p.name,cframe=E.CFrame.new(table.unpack(p.cf)),size=E.Vector3.new(table.unpack(p.size)),color=E.Color3.fromRGB(table.unpack(p.rgb)),mask=p.mask,role=p.role,alpha=p.alpha,material=E.Enum.Material[p.material],collide=p.collide,exclusionReason=p.reason})
 end
 ctx:Contact("Kulube_Egimli_Cati_03832","Kulube_Egimli_Cati_03833",1e-05)
 ctx:Contact("Kulube_Baca_03850","Kulube_Egimli_Cati_03833",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03834","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03835","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03836","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03837","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03838","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03839","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03840","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03841","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03842","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03843","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03844","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03845","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03846","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03847","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03848","Kulube_Egimli_Cati_03832",1e-05)
 ctx:Contact("Kulube_Kapali_Kalkan_Duvari_03849","Kulube_Egimli_Cati_03832",1e-05)
 ctx.Model:SetAttribute("TrainingScope","PARTIAL_POSITIVE_COMPONENT_NOT_FULL_REFERENCE_GOLD")
 ctx.Model:SetAttribute("SourceOrigin","-86,5.6,74")
end

end)()
-- END INLINE training/positive_pairs/blue_roof_hut/Builder.luau

_G.MM41PP04=Factory(M,A,C).new({name="MM41_PP04",ownerKey="MM41_POSITIVE_PP04",requiresStuds=true,sourceModelId=9454666962,scale=1,worldCFrame=CFrame.new(0,8,0),builder=Builder})
print("PP04 ready; Resolve -> real candidate Coupon -> explicit Approve -> Install -> AuditInstalled. No active camera changes; no untextured final main build.")
