-- Training sub-scene, NOT a new/full harbor delivery and NOT a Studio-tested gold model.
-- Relative dimensions taken from the scoped, user-approved warehouse/dock approach.
-- Every generated element has a geometric/structural role. No arbitrary Part quota.
return function(ctx)
 local E=ctx.Env or {Vector3=Vector3,CFrame=CFrame,Color3=Color3}
 local CFrame=E.CFrame
 local V,CF,RGB=E.Vector3.new,CFrame.new,E.Color3.fromRGB
 local wood=RGB(167,113,65);local dark=RGB(106,70,43);local blue=RGB(55,137,183);local white=RGB(223,233,233)
 local wallNames={}
 local function part(name,pos,size,color,role,mask,alpha)
  return ctx:Part({name=name,cframe=CF(pos),size=size,color=color,role=role or "MAIN",mask=mask or 63,alpha=alpha or 0})
 end
 local pivot=ctx:Part({name="Origin",cframe=CF(),size=V(.1,.1,.1),color=RGB(0,0,0),mask=0,role="PIVOT",alpha=1,collide=false,query=false,exclusionReason="Invisible origin marker; not a visible surface"})
 ctx.Model.PrimaryPart=pivot
 part("Bed",V(0,-9,0),V(44,2,40),RGB(198,184,139),"MAIN")
 for _,x in ipairs({-14,14}) do
  local beam="Bearing"..x;part(beam,V(x,-1.35,0),V(1.4,1.4,38),dark,"WOOD")
  for _,z in ipairs({-13,13}) do
   local pile="Pile"..x.."_"..z;part(pile,V(x,-4.4,z),V(1.6,7.2,1.6),dark,"WOOD")
   ctx:Contact(pile,"Bed");ctx:Contact(pile,beam)
  end
 end
 local n=27;local pitch=38/n
 for j=1,n do
  local name="DeckBoard"..j
  part(name,V(0,-.35,-19+(j-.5)*pitch),V(40,.7,pitch-.025),wood,"WOOD")
  ctx:Contact(name,"Bearing-14");ctx:Contact(name,"Bearing14")
 end
 part("WarehouseFloor",V(0,.4,0),V(32,.8,29),RGB(113,120,114))
 ctx:Contact("WarehouseFloor","DeckBoard14")
 local function wall(name,pos,size)
  part(name,pos,size,blue);table.insert(wallNames,name)
 end
 for _,side in ipairs({-1,1}) do
  wall("Side"..side,V(side*15.65,11,0),V(.7,22,29))
  wall("FrontPier"..side,V(side*11.8,11,14.15),V(8.4,22,.7))
  for j=0,29 do wall("SideRib"..side.."_"..j,V(side*16.12,11,-14+.95*j),V(.25,22,.3)) end
 end
 wall("BackWall",V(0,11,-14.15),V(32,22,.7))
 wall("DoorHeader",V(0,19,14.15),V(15.4,6,.7))
 for j=0,31 do
  local x=-15.5+j
  wall("BackRib"..j,V(x,11,-14.62),V(.3,22,.24))
  if math.abs(x)>7.4 then wall("FrontRib"..j,V(x,11,14.62),V(.3,22,.24)) end
 end
 part("Roof",V(0,22.45,0),V(34,.9,31),white)
 for j,z in ipairs({-10,0,10}) do
  local name="RoofBearing"..j;part(name,V(0,21.55,z),V(31,1,.8),RGB(106,125,137))
  ctx:Contact(name,"Roof");ctx:Contact(name,"Side-1");ctx:Contact(name,"Side1")
 end
 ctx:Contact("BackWall","Side-1");ctx:Contact("BackWall","Side1");ctx:Contact("DoorHeader","FrontPier-1");ctx:Contact("DoorHeader","FrontPier1")
 ctx:Contact("Roof","Side-1");ctx:Contact("Roof","Side1");ctx:Contact("WarehouseFloor","BackWall")
 part("BananaSign",V(0,18.3,15.05),V(18,3.4,.45),white)
 -- Embossed banana profile, not a painted fake opening or substitute studs.
 local prior=nil
 for j=0,8 do
  local t=j/8;local p=V((t-.5)*8,18.5+(2*t-1)^2*1.2-.6,15.34)
  if prior then
   local delta=p-prior;local cf=CFrame.lookAt((p+prior)/2,p,V(0,0,1))
   ctx:Part({name="BananaEmboss"..j,cframe=cf,size=V(.5,.5,delta.Magnitude+.02),color=RGB(224,207,39),mask=63,role="MAIN"})
  end
  prior=p
 end
 local function crate(name,x,y,z,w,h,d)
  part(name.."Bottom",V(x,y+.22,z),V(w,.44,d),dark,"WOOD")
  part(name.."Lid",V(x,y+h-.22,z),V(w,.44,d),RGB(201,176,124),"WOOD")
  for _,side in ipairs({-1,1}) do
   part(name.."X"..side,V(x+side*(w/2-.18),y+h/2,z),V(.36,h-.6,d),RGB(201,176,124),"WOOD")
   part(name.."Z"..side,V(x,y+h/2,z+side*(d/2-.18)),V(w,h-.6,.36),RGB(201,176,124),"WOOD")
   for _,zz in ipairs({-d/2,d/2}) do part(name.."Corner"..side.."_"..zz,V(x+side*(w/2-.25),y+h/2,z+zz),V(.6,h-.2,.32),dark,"WOOD") end
  end
 end
 crate("InsideCrate",-7,.8,-7,6,6,6);ctx:Contact("InsideCrateBottom","WarehouseFloor")
 crate("RoofCrate",4,22.9,-3,6,5,6);ctx:Contact("RoofCrateBottom","Roof")
 ctx:OpenRay(V(0,8,16),V(0,8,12),wallNames)
 -- Model space clear aperture after ribs: width 14.7, floor 0.8 to header 16.0.
 ctx.Model:SetAttribute("DoorClearWidth",14.7*ctx.Scale)
 ctx.Model:SetAttribute("DoorClearHeight",15.2*ctx.Scale)
 ctx.Model:SetAttribute("TrainingScope","Warehouse+dock sub-scene only; not the complete reference map")
end
