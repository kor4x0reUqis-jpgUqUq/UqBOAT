-- Synthetic hinge/clip structure lab, NOT a finished creature or published animation.
-- Actual editable Motor6D + KeyframeSequence/Keyframe/Pose. No runtime sine substitute.
return function()
 local Lab={Root=nil}
 function Lab:Build(token)
  assert(token=="YALNIZ_DUZENLENEBILIR_KLIP_LABORATUVARI","Explicit synthetic animation lab request required")
  local run=game:GetService("RunService");assert(run:IsStudio() and not run:IsRunning(),"EDIT only")
  assert(not self.Root,"Remove this lab before rebuilding")
  local model=Instance.new("Model");model.Name="MM4_Synthetic_Editable_Hinge_Lab"
  local root=Instance.new("Part");root.Name="Root";root.Size=Vector3.new(4,3,4);root.CFrame=CFrame.new(0,8,0);root.Anchored=true;root.Color=Color3.fromRGB(95,121,151);root.Parent=model
  local wing=Instance.new("Part");wing.Name="Wing";wing.Size=Vector3.new(8,.6,3);wing.Anchored=false;wing.Massless=true;wing.CanCollide=false;wing.Color=Color3.fromRGB(196,169,85);wing.Parent=model
  local motor=Instance.new("Motor6D");motor.Name="RightHinge";motor.Part0=root;motor.Part1=wing
  motor.C0=CFrame.new(2,0,0);motor.C1=CFrame.new(-4,0,0);motor.Parent=root
  local importPose=CFrame.Angles(0,0,math.rad(18))
  motor.Transform=importPose;wing.CFrame=root.CFrame*motor.C0*importPose*motor.C1:Inverse()
  local controller=Instance.new("AnimationController");controller.Name="AnimationController";controller.Parent=model
  local animator=Instance.new("Animator");animator.Parent=controller
  local clips=Instance.new("Folder");clips.Name="EditableClips";clips.Parent=model
  local function clip(name,loop,frames)
   local seq=Instance.new("KeyframeSequence");seq.Name=name;seq.Loop=loop
   for _,record in ipairs(frames) do
    local k=Instance.new("Keyframe");k.Time=record.time;k.Parent=seq
    local rp=Instance.new("Pose");rp.Name="Root";rp.CFrame=CFrame.new();rp.Weight=1;rp.Parent=k
    local wp=Instance.new("Pose");wp.Name="Wing";wp.CFrame=CFrame.Angles(0,0,math.rad(record.degrees));wp.Weight=1;wp.Parent=rp
    if record.marker then local m=Instance.new("KeyframeMarker");m.Name=record.marker;m.Value="";m.Parent=k end
   end
   seq.Parent=clips;return seq
  end
  clip("WingFold",false,{{time=0,degrees=18},{time=.25,degrees=40},{time=.65,degrees=78,marker="FoldComplete"}})
  clip("WingDownstroke",false,{{time=0,degrees=18},{time=.16,degrees=38,marker="Windup"},{time=.43,degrees=-38,marker="WingForce"},{time=.75,degrees=18,marker="Recover"}})
  clip("WingHold",true,{{time=0,degrees=18},{time=.4,degrees=18},{time=.8,degrees=18}})
  model.PrimaryPart=root;model:SetAttribute("TrainingOnly",true)
  model:SetAttribute("SourceState","EDITABLE_LOCAL_CLIPS_CREATED_NOT_EDITOR_OR_PUBLISHED_TESTED")
  model:SetAttribute("TextureState","EXPLICIT_UNTEXTURED_SYNTHETIC_RIG_LAB")
  model:SetAttribute("NotGameplay",true);model.Parent=workspace;self.Root=model
  print("Editable local rig/clips created; open them in Animation Editor to validate hierarchy. No animation asset ID was invented. No active camera was modified.")
  return model
 end
 function Lab:Remove() if self.Root then self.Root:Destroy();self.Root=nil end end
 return Lab
end
