-- Synthetic geometry laboratory ONLY, not a source-faithful corrected harbor boat.
-- Inlined Math3 dependency; no Blender, mesh ID, remote script or active-camera changes.
-- Explicit untextured lab acknowledgement is mandatory; NEVER use as a studs-task fallback.
return function(Math3)
 local Lab={Part=nil,Editable=nil,Data=nil}
 local stations={{x=-24,width=4.5},{x=-18,width=11},{x=-8,width=14},{x=6,width=14},{x=17,width=10},{x=24,width=2.5}}
 function Lab:Build(token)
  assert(token=="YALNIZ_SENTETIK_GEOMETRI_LABORATUVARI","This is an untextured math lab, not the required studs delivery")
  local run=game:GetService("RunService");assert(run:IsStudio() and not run:IsRunning(),"Studio EDIT only")
  assert(not self.Part,"Remove only this lab's existing result with :Remove() before rebuilding")
  local AssetService=game:GetService("AssetService");local editable=nil;local output=nil
  local ok,err=xpcall(function()
   local data=Math3.hullMesh(stations,-1.2,5.8,.45)
   local lo={math.huge,math.huge,math.huge};local hi={-math.huge,-math.huge,-math.huge}
   for _,v in ipairs(data.vertices) do for j=1,3 do lo[j]=math.min(lo[j],v[j]);hi[j]=math.max(hi[j],v[j]) end end
   local center={(lo[1]+hi[1])/2,(lo[2]+hi[2])/2,(lo[3]+hi[3])/2}
   editable=AssetService:CreateEditableMesh()
   assert(editable,"EditableMesh budget/capability denied; do not substitute a filled box")
   local ids={}
   for i,v in ipairs(data.vertices) do ids[i]=editable:AddVertex(Vector3.new(v[1]-center[1],v[2]-center[2],v[3]-center[3])) end
   for _,f in ipairs(data.triangles) do
    local id=editable:AddTriangle(ids[f[1]],ids[f[2]],ids[f[3]])
    local a,b,c=data.vertices[f[1]],data.vertices[f[2]],data.vertices[f[3]]
    local n=Math3.unit(Math3.cross(Math3.sub(b,a),Math3.sub(c,a)))
    local normal=editable:AddNormal(Vector3.new(n[1],n[2],n[3]));editable:SetFaceNormals(id,{normal,normal,normal})
   end
   output=AssetService:CreateMeshPartAsync(Content.fromObject(editable),{CollisionFidelity=Enum.CollisionFidelity.Default,RenderFidelity=Enum.RenderFidelity.Precise})
   assert(output and output:IsA("MeshPart"),"MeshPart generation failed")
   output.Name="MM4_Synthetic_OpenTop_Hull_Lab";output.Anchored=true
   output.Size=Vector3.new(hi[1]-lo[1],hi[2]-lo[2],hi[3]-lo[3])
   output.CFrame=CFrame.new(center[1],center[2]+8,center[3]);output.Color=Color3.fromRGB(46,113,176)
   output.Material=Enum.Material.Plastic;output.CanTouch=false
   output:SetAttribute("TrainingOnly",true);output:SetAttribute("StudsStatus","EXPLICIT_UNTEXTURED_SYNTHETIC_MATH_LAB")
   output:SetAttribute("ReferenceVisualAcceptance","NOT_A_REFERENCE_RECONSTRUCTION")
   output:SetAttribute("CollisionAcceptance","PENDING_STUDIO_PLAYER_AND_HULL_TESTS")
   output.Parent=workspace
   self.Part=output;self.Editable=editable;self.Data=data
   print("Synthetic hull created: numerical manifold != source boat visual acceptance. No camera properties changed. No image/asset ID invented.")
  end,debug.traceback)
  if not ok then
   if output then output:Destroy() end;if editable then editable:Destroy() end
   error("Mesh lab blocked; no proxy substituted: "..tostring(err),0)
  end
  return self.Part
 end
 function Lab:Remove()
  if self.Part then self.Part:Destroy();self.Part=nil end
  if self.Editable then self.Editable:Destroy();self.Editable=nil end
 end
 return Lab
end
