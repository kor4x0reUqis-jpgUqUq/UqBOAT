--!nonstrict
-- Offline pure-math + mock-adapter regression tests. NOT Roblox Studio/asset/visual proof.
local M=require("../tools/Math3")
local Acceptance=require("../tools/Acceptance")
local CG=require("../tools/CameraGuard")
local Factory=require("../tools/StudioKit")
local Mock=require("./MockStudio")
local Warehouse=require("../examples/Depo_Iskele_Builder")
local passed,failed=0,0
local function near(a,b,e) assert(math.abs(a-b)<(e or 1e-7),tostring(a).." != "..tostring(b)) end
local function fails(fn) local ok=pcall(fn);assert(not ok,"Expected a blocking failure") end
local function test(name,fn)
 local ok,err=xpcall(fn,debug.traceback)
 if ok then passed=passed+1;print("PASS "..name) else failed=failed+1;print("FAIL "..name.." | "..tostring(err)) end
end
local function fixture(builder,requires)
 local mock=Mock.new();local kitlib=Factory(M,Acceptance,CG,mock.env)
 local kit=kitlib.new({name="TEST_OWNED_SCENE",ownerKey="MM4_TEST_ONLY",requiresStuds=requires~=false,sourceModelId=9454666962,builder=builder or Warehouse})
 return kit,mock
end
local function coupon(kit)
 kit:Resolve();kit:Coupon(1,{tileU=2,tileV=2,transparency=.35,woodMinTransparency=.48,thinMinTransparency=.78,phaseMode="LOCAL_ZERO"})
end
local function approved(kit) coupon(kit);kit:Approve("KUPONU_GORSEL_OLARAK_ONAYLIYORUM") end
local function install(kit,replace) return kit:Install("ONAYLI_KURULUMU_BASLAT",replace) end

test("M01_LOCAL_WORLD_BLUE_BOARDING",function()
 local p=M.world({-39,0,19},M.ry(-5),{-12,6.65,7.36})
 near(p[1],-51.59580264372371,1e-5);near(p[2],6.65);near(p[3],25.28612406498335,1e-5)
 local q=M.localPoint({-39,0,19},M.ry(-5),p);near(q[1],-12);near(q[3],7.36)
end)
test("M02_SCALE_TRANSLATION_NOT_ROTATION",function()
 local p=M.world({10,3,-5},M.ry(90),{2,4,6},2);near(p[1],22);near(p[2],11);near(p[3],-9)
 assert(M.rotationValid(M.ry(90)))
end)
test("M03_REFLECTION_IS_NOT_ROTATION",function() assert(not M.rotationValid({-1,0,0,0,1,0,0,0,1})) end)
test("M04_ORTHONORMAL_DOES_NOT_MEAN_CONTACT",function()
 local a={p={0,0,0},s={2,2,2},r=M.identity()};local b={p={5,0,0},s={2,2,2},r=M.identity()}
 assert(M.rotationValid(a.r) and M.rotationValid(b.r));assert(not M.obbContact(a,b))
 b.p={2,0,0};assert(M.obbContact(a,b));b.p={2.01,0,0};assert(not M.obbContact(a,b,1e-5))
end)
test("M05_RAY_OPENING_VS_PAINTED_HOLE",function()
 local wall={p={0,2,0},s={10,4,.5},r=M.identity()};assert(M.segmentOBB({0,2,2},{0,2,-2},wall))
 wall.p={5,2,0};wall.s={2,4,.5};assert(not M.segmentOBB({0,2,2},{0,2,-2},wall))
end)
test("M06_CAMERA_PROJECT_AND_BEHIND",function()
 local camera={eye={0,0,10},target={0,0,0},fovY=60,width=1600,height=900}
 local p=M.project({0,0,0},camera);near(p[1],.5);near(p[2],.5)
 assert(M.project({0,0,11},camera)==nil)
 assert(M.rotationValid(M.lookBasis({0,10,0},{0,0,0})))
end)
test("M07_NORMALIZED_SCREEN_RMS",function()
 near(M.weightedScreenRMS({{actual={.52,.5},expected={.5,.5},weight=1},{actual={.5,.51},expected={.5,.5},weight=3}}),math.sqrt(.0007/4))
end)
test("M08_WEIGHTED_SCALE_IDENTIFIABILITY",function()
 near(M.fitScale({{relative=3,known=6},{relative=5,known=10,weight=2}}),2);fails(function() M.fitScale({}) end)
end)
test("M09_SRGB_NOT_LINEAR_RGB",function() near(M.srgbToLinear(.5),.21404114048223255);near(M.linearToSrgb(M.srgbToLinear(.5)),.5) end)
test("M10_TILE_IMAGE_COUNT_NOT_ONE_STUD",function() near(M.tileSize(1.25,4),5);fails(function() M.tileSize(0,4) end) end)
local stations={{x=-24,width=4.5},{x=-18,width=11},{x=-8,width=14},{x=6,width=14},{x=17,width=10},{x=24,width=2.5}}
test("M11_HULL_MANIFOLD_AND_DIRECTED_EDGES",function()
 local h=M.hullMesh(stations,-1.2,5.8,.45);assert(h.volume>0)
 local edges={}
 for _,f in ipairs(h.triangles) do
  local a,b,c=h.vertices[f[1]],h.vertices[f[2]],h.vertices[f[3]]
  assert(M.length(M.cross(M.sub(b,a),M.sub(c,a)))>1e-8,"Degenerate face")
  for j=1,3 do
   local u,v=f[j],f[j%3+1];local key=math.min(u,v)..":"..math.max(u,v)
   local e=edges[key] or {count=0,direction=0};e.count=e.count+1;e.direction=e.direction+(u<v and 1 or -1);edges[key]=e
  end
 end
 local E=0;for key,e in pairs(edges) do E=E+1;assert(e.count==2 and e.direction==0,"Bad cap/winding edge "..key.." "..e.count.." "..e.direction) end
 assert(#h.vertices-E+#h.triangles==2,"Closed cup boundary Euler characteristic")
end)
test("M13_HULL_OPEN_TOP_IS_REAL_NOT_PAINT",function()
 local h=M.hullMesh(stations,-1.2,5.8,.45)
 for _,f in ipairs(h.triangles) do assert(not M.segmentTriangle({0,7,0},{0,0,0},h.vertices[f[1]],h.vertices[f[2]],h.vertices[f[3]]),"A fake lid covers the interior") end
 local hit=false
 for _,f in ipairs(h.triangles) do if M.segmentTriangle({0,0,0},{0,-2,0},h.vertices[f[1]],h.vertices[f[2]],h.vertices[f[3]]) then hit=true end end
 assert(hit,"No real interior floor")
end)
test("M12_HULL_STATIONS_COLLAPSE_REJECTED",function() fails(function() M.hullMesh({{x=0,width=1},{x=1,width=1}},0,2,.8) end) end)

test("S01_SOURCE_NOT_AUTO_SELECTED_OR_APPROVED",function()
 local k,m=fixture();k:Resolve();assert(k.Policy.selected==nil and not k.Policy.approved);assert(not m.workspace:FindFirstChild("TEST_OWNED_SCENE"));fails(function() install(k) end)
end)
test("S02_FOREIGN_SCRIPTS_STRIPPED_UNPARENTED",function() local k,m=fixture();k:Resolve();assert(m.calls.destroyedScripts==2);for _,p in ipairs(m.all) do if p.Name=="FAKE_DOWNLOADED_UNPARENTED_MODEL" then assert(p._destroyed and p.Parent==nil) end end end)
test("S03_PERMISSION_FAILURE_BLOCKS_MODEL",function() local k,m=fixture();m.options.denyAsset=true;fails(function() k:Resolve() end);fails(function() install(k) end);assert(not m.workspace:FindFirstChild("TEST_OWNED_SCENE")) end)
test("S04_MODEL_ID_REJECTED_AS_IMAGE",function() local k,m=fixture();m.options.invalidType=true;fails(function() k:Resolve() end);assert(not k.Policy.approved) end)
test("S05_FETCH_FAILURE_NOT_VISUAL_SUCCESS",function() local k,m=fixture();k:Resolve();m.options.failFetch=true;fails(function() k:Coupon(1,{tileU=1,tileV=1,transparency=.35,phaseMode="LOCAL_ZERO"}) end);assert(not k.Policy.approved);fails(function() install(k) end) end)
test("S06_COUPON_NEVER_MOVES_CAMERA",function() local k,m=fixture();coupon(k);assert(m.calls.cameraWrites==0);assert(k.Policy.state=="COUPON_READY") end)
test("S07_EXPLICIT_VISUAL_ACK_REQUIRED",function() local k=fixture();coupon(k);fails(function() k:Approve("YES_AUTOMATIC") end);fails(function() install(k) end) end)
test("S08_CHANGED_COUPON_BLOCKS_APPROVAL",function()
 local k,m=fixture();coupon(k);local part=k.CouponModel:GetChildren()[1];local t=part:GetChildren()[1];t.StudsPerTileU=7
 fails(function() k:Approve("KUPONU_GORSEL_OLARAK_ONAYLIYORUM") end);assert(not k.Policy.approved)
end)
test("S09_PROFILE_CHANGE_REVOKES_INSTALL",function() local k=fixture();approved(k);k.Profile.tileU=7;fails(function() install(k) end) end)
test("S10_FULL_WAREHOUSE_CONTACTS_TEXTURE_INSTALL",function()
 local k,m=fixture();approved(k);local root,audit=install(k)
 assert(root.Parent==m.workspace and audit.pass and audit.actual==audit.expected and audit.actual>0)
 for _,n in pairs(audit.perFace) do assert(n==audit.perFace.Top) end
 assert(m.calls.cameraWrites==0 and k.Policy.state=="COMMITTED_REVIEW_PENDING")
 assert(root:GetAttribute("DoorClearWidth")==14.7);assert(root:GetAttribute("DoorClearHeight")==15.2)
end)
test("S11_OWNED_REPLACEMENT_EXPLICIT_AND_BACKED_UP",function()
 local k,m=fixture();approved(k);local old=install(k);fails(function() install(k) end);assert(old.Parent==m.workspace)
 local new=install(k,true);assert(new~=old and old.Parent.Name=="MM4_Backups")
end)
test("S12_UNOWNED_SCENE_NOT_DELETED",function()
 local k,m=fixture();local old=m.env.Instance.new("Model");old.Name="TEST_OWNED_SCENE";old.Parent=m.workspace
 approved(k);fails(function() install(k,true) end);assert(old.Parent==m.workspace and not old._destroyed)
end)
test("S13_BUILDER_FAILURE_NO_PARTIAL_MODEL",function() local k,m=fixture(function() error("FAKE_BUILD_FAILURE") end);approved(k);fails(function() install(k) end);assert(not m.workspace:FindFirstChild("TEST_OWNED_SCENE")) end)
test("S14_REQUIRED_STUDS_CANNOT_SILENTLY_SKIP",function() local k=fixture();fails(function() k:ExplicitNoStuds("KULLANICI_ACIKCA_STUDS_ISTEMIYOR","fake bypass") end) end)
test("S15_EXPLICIT_NO_STUDS_CONTRACT",function()
 local k,m=fixture(nil,false);fails(function() install(k) end)
 k:ExplicitNoStuds("KULLANICI_ACIKCA_STUDS_ISTEMIYOR","Synthetic test case: user explicitly requested untextured geometry")
 local _,audit=install(k);assert(audit.actual==0 and audit.expected==0 and m.calls.downloads==0)
end)
test("S16_BLOCKED_CONTACT_ABORTS",function()
 local function bad(ctx)
  local E=ctx.Env
  ctx:Part({name="A",cframe=E.CFrame.new(),size=E.Vector3.new(2,2,2),color=E.Color3.new(1,1,1),role="MAIN",mask=63})
  ctx:Part({name="B",cframe=E.CFrame.new(10,0,0),size=E.Vector3.new(2,2,2),color=E.Color3.new(1,1,1),role="MAIN",mask=63})
  ctx:Contact("A","B")
 end
 local k,m=fixture(bad);approved(k);fails(function() install(k) end);assert(not m.workspace:FindFirstChild("TEST_OWNED_SCENE"))
end)
test("S17_OFFLINE_PASS_IS_NOT_FINAL_VISUAL_PASS",function()
 local k=fixture();approved(k);install(k)
 fails(function() k.Policy:FinalAcceptance({studioOpen="PASS",studioAPI="PASS",referenceVisual="NOT_RUN"}) end)
 assert(k.Policy.state=="COMMITTED_REVIEW_PENDING")
end)
test("S18_POST_INSTALL_OMISSION_IS_DETECTED",function()
 local k=fixture();approved(k);local root=install(k)
 assert(k:AuditInstalled().pass)
 for _,p in ipairs(root:GetDescendants()) do if p:IsA("Texture") then p:Destroy();break end end
 assert(not k:AuditInstalled().pass)
end)
test("S19_MASK_DROP_CANNOT_FAKE_POST_AUDIT",function()
 local k=fixture();approved(k);local root=install(k)
 for _,p in ipairs(root:GetDescendants()) do if p:IsA("BasePart") and p:GetAttribute("MM4Mask")==63 then p:SetAttribute("MM4Mask",0);break end end
 fails(function() k:AuditInstalled() end)
end)
test("S20_REPLACEMENT_FAILURE_RESTORES_PREVIOUS_SCENE",function()
 local k,m=fixture();approved(k);local old=install(k)
 k.Policy.Commit=function() error("FAKE_COMMIT_FAILURE") end
 fails(function() install(k,true) end)
 assert(old.Parent==m.workspace and old.Name=="TEST_OWNED_SCENE" and not old._destroyed)
end)
test("S21_NEW_FETCH_FAILURE_REVOKES_OLD_APPROVAL",function()
 local k,m=fixture();approved(k);m.options.failFetch=true
 fails(function() k:Coupon(1,{tileU=2,tileV=2,transparency=.35,phaseMode="LOCAL_ZERO"}) end)
 assert(not k.Policy.approved);fails(function() install(k) end)
end)
test("S22_BUILDER_MASK_DROP_BEFORE_COMMIT_BLOCKED",function()
 local function altered(ctx)
  Warehouse(ctx)
  ctx.Parts.Side1:SetAttribute("MM4Mask",0)
 end
 local k,m=fixture(altered);approved(k);fails(function() install(k) end);assert(not m.workspace:FindFirstChild("TEST_OWNED_SCENE"))
end)
test("S23_HALF_SCALE_SAME_WORLD_TILE_POLICY",function()
 local k,m=fixture();k.Config.scale=.5;approved(k);local root,audit=install(k)
 assert(audit.pass);near(root:GetAttribute("DoorClearWidth"),7.35);near(root:GetAttribute("DoorClearHeight"),7.6)
 assert(k.Profile.tileU==2 and m.calls.cameraWrites==0)
end)
test("C01_NO_OPTIN_NO_CAMERA_WRITE",function()
 local _,m=fixture();fails(function() CG.withPose(function() return m.workspace.CurrentCamera end,{CameraType="Scriptable"},function() end,"NO") end)
 assert(m.calls.cameraWrites==0)
end)
test("C02_OPTIONAL_VIEW_RESTORES_ON_SUCCESS",function()
 local _,m=fixture();local cam=m.workspace.CurrentCamera;local before=CG.snapshot(cam)
 CG.withPose(function() return cam end,{CameraType="Scriptable",CFrame=m.env.CFrame.new(1,2,3),FieldOfView=30},function() assert(cam.CameraType=="Scriptable") end,"KAMERA_POZUNU_GECICI_KULLAN")
 assert(CG.unchanged(before,cam))
end)
test("C03_OPTIONAL_VIEW_RESTORES_ON_EXCEPTION",function()
 local _,m=fixture();local cam=m.workspace.CurrentCamera;local before=CG.snapshot(cam)
 fails(function() CG.withPose(function() return cam end,{CameraType="Scriptable",FieldOfView=10},function() error("FAKE_CAPTURE_FAILURE") end,"KAMERA_POZUNU_GECICI_KULLAN") end)
 assert(CG.unchanged(before,cam))
end)
test("C04_NIL_SUBJECT_NEVER_ASSIGNED",function()
 local raw={CameraType="Custom",CFrame=1,Focus=2,FieldOfView=70};local invalid=0
 local cam=setmetatable({}, {__index=raw,__newindex=function(_,k,v) if k=="CameraSubject" and v==nil then invalid=invalid+1 end;raw[k]=v end})
 CG.withPose(function() return cam end,{FieldOfView=30},function() end,"KAMERA_POZUNU_GECICI_KULLAN")
 assert(invalid==0 and cam.FieldOfView==70)
end)
test("C05_CAMERA_SWAP_NEW_CAMERA_UNTOUCHED",function()
 local _,m=fixture();local old=m.workspace.CurrentCamera;local snap=CG.snapshot(old)
 local newCamera={CameraType="USER_SELECTED",FieldOfView=83};local active=old
 fails(function() CG.withPose(function() return active end,{CameraType="Scriptable"},function() active=newCamera end,"KAMERA_POZUNU_GECICI_KULLAN") end)
 assert(active==newCamera and newCamera.CameraType=="USER_SELECTED" and newCamera.FieldOfView==83)
 assert(CG.unchanged(snap,old))
end)
local PositiveExpected=require("./positive_expected")
local PositiveBuilders={
 require("../training/positive_pairs/red_gantry_container/Builder"),
 require("../training/positive_pairs/yellow_crane_payload/Builder"),
 require("../training/positive_pairs/warehouse_interior/Builder"),
 require("../training/positive_pairs/blue_roof_hut/Builder"),
}
for i,builder in ipairs(PositiveBuilders) do
 local expected=PositiveExpected[i]
 test("PP_SOURCE_PARITY_TEXTURE_CAMERA_"..expected.id,function()
  local k,m=fixture(builder);approved(k);local root,audit=install(k);assert(audit.pass and k:AuditInstalled().pass)
  assert(#root:GetChildren()==#expected.parts+1,"Source subset part count changed")
  for _,p in ipairs(expected.parts) do
   local actual=root:FindFirstChild(p.n);assert(actual,"Missing source part "..p.n)
   local x,y,z,aa,bb,cc,dd,ee,ff,gg,hh,ii=actual.CFrame:GetComponents()
   near(x+expected.origin[1],p.p[1],2e-6);near(y+expected.origin[2],p.p[2],2e-6);near(z+expected.origin[3],p.p[3],2e-6)
   for j,v in ipairs({aa,bb,cc,dd,ee,ff,gg,hh,ii}) do near(v,p.r[j],1e-7) end
   near(actual.Size.X,p.s[1]);near(actual.Size.Y,p.s[2]);near(actual.Size.Z,p.s[3])
   near(actual.Color.R,p.c[1]/255);near(actual.Color.G,p.c[2]/255);near(actual.Color.B,p.c[3]/255)
   assert(actual.Material==m.env.Enum.Material[p.m] and actual.CanCollide==p.k and actual:GetAttribute("MM4Mask")==p.f)
   near(actual.Transparency,p.a)
  end
  assert(m.calls.cameraWrites==0,"Positive example must not lock/move user camera")
 end)
end
print("OFFLINE_TEST_SUMMARY "..passed.." PASS "..failed.." FAIL")
assert(failed==0,"Offline regression failures")
