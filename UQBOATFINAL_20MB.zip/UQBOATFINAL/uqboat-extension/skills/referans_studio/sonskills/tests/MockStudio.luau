--!nonstrict
-- TEST DOUBLE ONLY. No Roblox engine, network, real asset, permissions or image rendering.
-- Numeric IDs below are FICTIONAL FIXTURES, never asserted as usable assets.
local M=require("../tools/Math3")
local R={}
function R.new()
 local calls={created=0,destroyedScripts=0,downloads=0,metadata=0,fetch=0,waypoints=0,cameraWrites=0}
 local V={};local vm={}
 function V.new(x,y,z) return setmetatable({X=x or 0,Y=y or 0,Z=z or 0,_type="Vector3"},vm) end
 vm.__add=function(a,b) return V.new(a.X+b.X,a.Y+b.Y,a.Z+b.Z) end
 vm.__sub=function(a,b) return V.new(a.X-b.X,a.Y-b.Y,a.Z-b.Z) end
 vm.__mul=function(a,b) if type(a)=="number" then a,b=b,a end;return V.new(a.X*b,a.Y*b,a.Z*b) end
 vm.__div=function(a,b) return a*(1/b) end
 vm.__unm=function(a) return a*(-1) end
 vm.__eq=function(a,b) return a.X==b.X and a.Y==b.Y and a.Z==b.Z end
 vm.__index=function(a,k)
  if k=="Magnitude" then return math.sqrt(a.X*a.X+a.Y*a.Y+a.Z*a.Z) end
  if k=="Unit" then return a/a.Magnitude end
  if k=="Dot" then return function(x,y) return x.X*y.X+x.Y*y.Y+x.Z*y.Z end end
 end
 local CF={};local cm={};local function ar(v) return {v.X,v.Y,v.Z} end
 local function cf(p,r) return setmetatable({_p=p,_r=r,_type="CFrame"},cm) end
 function CF.new(a,b,c,...)
  if type(a)=="table" then return cf(a,M.identity()) end
  local matrix={...}
  return cf(V.new(a or 0,b or 0,c or 0),#matrix==9 and matrix or M.identity())
 end
 function CF.Angles(x,y,z)
  local cx,sx,cy,sy,cz,sz=math.cos(x),math.sin(x),math.cos(y),math.sin(y),math.cos(z),math.sin(z)
  return cf(V.new(),M.matmul(M.matmul({1,0,0,0,cx,-sx,0,sx,cx},{cy,0,sy,0,1,0,-sy,0,cy}),{cz,-sz,0,sz,cz,0,0,0,1}))
 end
 function CF.lookAt(eye,target,up) return cf(eye,M.lookBasis(ar(eye),ar(target),up and ar(up))) end
 cm.__index=function(a,k)
  if k=="Position" then return a._p end
  if k=="Rotation" then return cf(V.new(),a._r) end
  if k=="GetComponents" then return function(self) return self._p.X,self._p.Y,self._p.Z,table.unpack(self._r) end end
 end
 cm.__mul=function(a,b)
  local p=M.world(ar(a._p),a._r,ar(b._p));return cf(V.new(table.unpack(p)),M.matmul(a._r,b._r))
 end
 cm.__eq=function(a,b)
  if a._p~=b._p then return false end
  for i=1,9 do if a._r[i]~=b._r[i] then return false end end
  return true
 end
 local Colors={};local colorMT={__eq=function(a,b) return a.R==b.R and a.G==b.G and a.B==b.B end}
 function Colors.new(r,g,b) return setmetatable({R=r,G=g,B=b,_type="Color3"},colorMT) end
 function Colors.fromRGB(r,g,b) return Colors.new(r/255,g/255,b/255) end
 local methods={};local im={};local all={}
 local function isA(x,kind)
  if x.ClassName==kind then return true end
  if kind=="BasePart" then return x.ClassName=="Part" end
  if kind=="Decal" then return x.ClassName=="Texture" end
  if kind=="LuaSourceContainer" then return x.ClassName=="Script" or x.ClassName=="LocalScript" or x.ClassName=="ModuleScript" end
  return kind=="Instance"
 end
 im.__index=function(self,k) return methods[k] or self._props[k] end
 im.__newindex=function(self,k,v)
  if string.sub(k,1,1)=="_" then rawset(self,k,v);return end
  if k=="Parent" then
   local old=self._props.Parent
   if old then for i,c in ipairs(old._children) do if c==self then table.remove(old._children,i);break end end end
   if v then table.insert(v._children,self) end
  end
  self._props[k]=v
 end
 local Inst={}
 function Inst.new(class)
  calls.created=calls.created+1
  local x=setmetatable({_props={ClassName=class,Name=class,Size=V.new(4,1,2),CFrame=CF.new(),Shape=1,Transparency=0},_children={},_attrs={}},im)
  table.insert(all,x);return x
 end
 function methods:IsA(kind) return isA(self,kind) end
 function methods:GetChildren() return table.clone(self._children) end
 function methods:GetDescendants()
  local list={};local function walk(x) for _,c in ipairs(x._children) do table.insert(list,c);walk(c) end end;walk(self);return list
 end
 function methods:SetAttribute(k,v) self._attrs[k]=v end
 function methods:GetAttribute(k) return self._attrs[k] end
 function methods:FindFirstChild(name) for _,x in ipairs(self._children) do if x.Name==name then return x end end;return nil end
 function methods:GetFullName() return self.Parent and (self.Parent:GetFullName().."."..self.Name) or self.Name end
 function methods:Destroy()
  if self._destroyed then return end
  if self:IsA("LuaSourceContainer") then calls.destroyedScripts=calls.destroyedScripts+1 end
  for _,c in ipairs(table.clone(self._children)) do c:Destroy() end
  self.Parent=nil;self._destroyed=true
 end
 local workspace=Inst.new("Workspace");workspace.Name="Workspace"
 local cameraData={CameraType="Custom",CameraSubject="EXISTING_SUBJECT",CFrame=CF.new(6,7,8),Focus=CF.new(0,4,0),FieldOfView=67}
 workspace.CurrentCamera=setmetatable({}, {__index=cameraData,__newindex=function(_,k,v) calls.cameraWrites=calls.cameraWrites+1;cameraData[k]=v end})
 local serverStorage=Inst.new("ServerStorage")
 local options={denyAsset=false,failFetch=false,invalidType=false}
 local enum={NormalId={Right=0,Top=1,Back=2,Left=3,Bottom=4,Front=5},SurfaceType={Smooth=0},Material={Plastic=256,Glass=1568,Neon=288},PartType={Block=1},InfoType={Asset="Asset"},AssetFetchStatus={Success="Success",Failure="Failure"},CameraType={Scriptable="Scriptable"}}
 local services={
  RunService={IsStudio=function() return true end,IsRunning=function() return false end},
  MarketplaceService={GetProductInfoAsync=function(_,id)
   calls.metadata=calls.metadata+1;if options.denyAsset then error("FAKE_TEST_PERMISSION_DENIED") end
   if id==9454666962 then return {AssetTypeId=10,Name="FAKE_MODEL_FIXTURE"} end
   if id==100000001 then return {AssetTypeId=options.invalidType and 10 or 1,Name="FAKE_IMAGE_FIXTURE_NOT_A_REAL_ASSET"} end
   error("Unknown fictional fixture")
  end},
  ContentProvider={PreloadAsync=function(_,items,callback)
   calls.fetch=calls.fetch+1;for _,item in ipairs(items) do callback(item,options.failFetch and enum.AssetFetchStatus.Failure or enum.AssetFetchStatus.Success) end
  end},
  ChangeHistoryService={SetWaypoint=function() calls.waypoints=calls.waypoints+1 end},
  HttpService={GenerateGUID=function() return "MOCK_SESSION_NOT_REAL_GUID" end},
  ServerStorage=serverStorage,
 }
 local game={}
 function game:GetService(name) assert(services[name],name);return services[name] end
 function game:GetObjects(uri)
  calls.downloads=calls.downloads+1;assert(uri=="rbxassetid://9454666962","Only mock configured Model source")
  local root=Inst.new("Model");root.Name="FAKE_DOWNLOADED_UNPARENTED_MODEL"
  local script=Inst.new("Script");script.Name="MUST_BE_DESTROYED_NEVER_RUN";script.Parent=root
  local module=Inst.new("ModuleScript");module.Parent=root
  local texture=Inst.new("Texture");texture.TextureContent={Uri="rbxassetid://100000001",_type="Content"};texture.Parent=root
  return {root}
 end
 local env={game=game,workspace=workspace,Instance=Inst,Enum=enum,Content={fromUri=function(uri) return {Uri=uri,_type="Content"} end},Vector3=V,CFrame=CF,Color3=Colors,
  typeof=function(v) return type(v)=="table" and (v._type or (v.ClassName and "Instance") or "table") or type(v) end,
  task={wait=function() end},warn=function() end,print=function() end}
 return {env=env,calls=calls,options=options,all=all,workspace=workspace}
end
return R
