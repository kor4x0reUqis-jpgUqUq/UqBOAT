-- Portable numeric export only. NOT Studio and no rendering/asset claims.
local M=require("../tools/Math3")
local h=M.hullMesh({{x=-24,width=4.5},{x=-18,width=11},{x=-8,width=14},{x=6,width=14},{x=17,width=10},{x=24,width=2.5}},-1.2,5.8,.45)
local function array(t)
 local items={}
 for _,v in ipairs(t) do table.insert(items,type(v)=="table" and array(v) or string.format("%.12g",v)) end
 return "["..table.concat(items,",").."]"
end
print('{"kind":"SYNTHETIC_NUMERIC_HULL_NOT_SOURCE_BOAT","vertices":'..array(h.vertices)..',"triangles":'..array(h.triangles)..',"volume":'..string.format("%.12g",h.volume)..',"opening":"INTENTIONAL_OPEN_TOP","studio_execution":"NOT_RUN","thickness":0.45}')
