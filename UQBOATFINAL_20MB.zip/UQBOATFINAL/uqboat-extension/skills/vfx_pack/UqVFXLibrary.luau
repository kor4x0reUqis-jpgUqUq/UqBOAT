-- UqVFXLibrary.luau — Hazır Görsel İncelemeli Roblox VFX Kütüphanesi (263 Asset ID)
-- game.ReplicatedStorage.UqVFXLibrary olarak kullanılır.

local UqVFXLibrary = {}

UqVFXLibrary.Presets = {
	Aura = {
		description = "Parlak Mavi Yıldırım & Anime Alev Aurası",
		particles = {
			{ id = "rbxassetid://7032949469", name = "AnimeFlameAura", rate = 28, lifetime = NumberRange.new(0.45, 0.8), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 2.5), NumberSequenceKeypoint.new(1, 0)}), speed = NumberRange.new(4, 9), color = ColorSequence.new(Color3.fromRGB(80, 190, 255), Color3.fromRGB(20, 90, 255)), lightEmission = 1 },
			{ id = "rbxassetid://7047857629", name = "CyanLightning1", rate = 12, lifetime = NumberRange.new(0.15, 0.3), size = NumberSequence.new(3.2), speed = NumberRange.new(0, 2), color = ColorSequence.new(Color3.fromRGB(140, 230, 255)), lightEmission = 1 },
			{ id = "rbxassetid://7056843550", name = "CyanLightning2", rate = 12, lifetime = NumberRange.new(0.15, 0.3), size = NumberSequence.new(3.2), speed = NumberRange.new(0, 2), color = ColorSequence.new(Color3.fromRGB(140, 230, 255)), lightEmission = 1 },
		}
	},
	BasicHit = {
		description = "Çok Katmanlı Anime Vuruş / Darbe Patlaması",
		burst = true,
		particles = {
			{ id = "rbxassetid://1463840694", name = "HitStar", emitCount = 1, lifetime = NumberRange.new(0.15, 0.25), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.4, 5.5), NumberSequenceKeypoint.new(1, 0)}), speed = NumberRange.new(0, 1), lightEmission = 1 },
			{ id = "rbxassetid://1463874772", name = "RadialHitStreaks", emitCount = 3, lifetime = NumberRange.new(0.2, 0.35), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 2), NumberSequenceKeypoint.new(1, 7)}), speed = NumberRange.new(0, 2), lightEmission = 1 },
			{ id = "rbxassetid://1463903184", name = "ShockwaveRing", emitCount = 1, lifetime = NumberRange.new(0.2, 0.35), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 8)}), speed = NumberRange.new(0, 0), lightEmission = 1 },
			{ id = "rbxassetid://1463939561", name = "ElectricShockArc", emitCount = 4, lifetime = NumberRange.new(0.15, 0.3), size = NumberSequence.new(4), speed = NumberRange.new(2, 8), lightEmission = 1 },
		}
	},
	SlashGenshin = {
		description = "Genshin Tarzı Keskin Kılıç Kesik ve Yıldız Patlaması",
		burst = true,
		particles = {
			{ id = "rbxassetid://494046218", name = "DiagonalSlash", emitCount = 2, lifetime = NumberRange.new(0.15, 0.25), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 3), NumberSequenceKeypoint.new(1, 8)}), speed = NumberRange.new(0, 1), color = ColorSequence.new(Color3.fromRGB(120, 210, 255)), lightEmission = 1 },
			{ id = "rbxassetid://7368928330", name = "GenshinImpactStar", emitCount = 2, lifetime = NumberRange.new(0.18, 0.3), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 2), NumberSequenceKeypoint.new(0.5, 6.5), NumberSequenceKeypoint.new(1, 0)}), speed = NumberRange.new(0, 1), lightEmission = 1 },
			{ id = "rbxassetid://7552993102", name = "VortexSlashRing", emitCount = 2, lifetime = NumberRange.new(0.22, 0.38), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 3), NumberSequenceKeypoint.new(1, 9)}), speed = NumberRange.new(0, 2), lightEmission = 1 },
			{ id = "rbxassetid://7553257107", name = "StarryShockRing", emitCount = 1, lifetime = NumberRange.new(0.25, 0.4), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 2), NumberSequenceKeypoint.new(1, 8)}), speed = NumberRange.new(0, 1), lightEmission = 1 },
		}
	},
	Block = {
		description = "Kalkan Bloklama & Kromatik Şok Halkası",
		burst = true,
		particles = {
			{ id = "rbxassetid://7008034274", name = "BlueShieldIcon", emitCount = 1, lifetime = NumberRange.new(0.35, 0.5), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 3.5), NumberSequenceKeypoint.new(0.7, 4.2), NumberSequenceKeypoint.new(1, 0)}), speed = NumberRange.new(0, 0), lightEmission = 1 },
			{ id = "rbxassetid://7556074751", name = "ChromaticShockRing", emitCount = 1, lifetime = NumberRange.new(0.25, 0.4), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 2), NumberSequenceKeypoint.new(1, 9)}), speed = NumberRange.new(0, 0), lightEmission = 1 },
			{ id = "rbxassetid://7553024429", name = "BlockedTextPopup", emitCount = 1, lifetime = NumberRange.new(0.45, 0.65), size = NumberSequence.new(3.5), speed = NumberRange.new(4, 7), lightEmission = 1 },
			{ id = "rbxassetid://5238574777", name = "NeedleStarburst", emitCount = 2, lifetime = NumberRange.new(0.18, 0.3), size = NumberSequence.new(5.5), speed = NumberRange.new(0, 2), lightEmission = 1 },
		}
	},
	GuardBreak = {
		description = "Kalkan Kırılması (Broken! + Çatlak Kırmızı Kalkan + Dişli Şok Halkası)",
		burst = true,
		particles = {
			{ id = "rbxassetid://7008506724", name = "CrackedRedShield", emitCount = 1, lifetime = NumberRange.new(0.45, 0.65), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 4), NumberSequenceKeypoint.new(1, 5.5)}), speed = NumberRange.new(0, 1), lightEmission = 1 },
			{ id = "rbxassetid://7553126971", name = "BrokenTextPopup", emitCount = 1, lifetime = NumberRange.new(0.5, 0.7), size = NumberSequence.new(4), speed = NumberRange.new(5, 8), lightEmission = 1 },
			{ id = "rbxassetid://7363803708", name = "SpikyShockRing", emitCount = 2, lifetime = NumberRange.new(0.25, 0.4), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 2), NumberSequenceKeypoint.new(1, 11)}), speed = NumberRange.new(0, 0), color = ColorSequence.new(Color3.fromRGB(255, 70, 70)), lightEmission = 1 },
			{ id = "rbxassetid://7450898297", name = "ShatterBurst", emitCount = 3, lifetime = NumberRange.new(0.25, 0.45), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 3), NumberSequenceKeypoint.new(1, 9)}), speed = NumberRange.new(2, 8), color = ColorSequence.new(Color3.fromRGB(255, 90, 90)), lightEmission = 1 },
		}
	},
	HeavyPunch = {
		description = "Ağır Yumruk / Ateşli Patlama ve Şok Halkası",
		burst = true,
		particles = {
			{ id = "rbxassetid://7553274670", name = "FieryExplosionCloud", emitCount = 4, lifetime = NumberRange.new(0.25, 0.45), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 3), NumberSequenceKeypoint.new(1, 8.5)}), speed = NumberRange.new(3, 12), lightEmission = 1 },
			{ id = "rbxassetid://7368928330", name = "ImpactStar", emitCount = 2, lifetime = NumberRange.new(0.18, 0.3), size = NumberSequence.new(6.5), speed = NumberRange.new(0, 2), color = ColorSequence.new(Color3.fromRGB(255, 200, 90)), lightEmission = 1 },
			{ id = "rbxassetid://7356491644", name = "ShockCrescent", emitCount = 2, lifetime = NumberRange.new(0.2, 0.35), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 2), NumberSequenceKeypoint.new(1, 9)}), speed = NumberRange.new(0, 2), lightEmission = 1 },
		}
	},
	FireballHiken = {
		description = "Yoğun Anime Ateş Yumruğu / FireballJutsu & Hiken",
		particles = {
			{ id = "rbxassetid://6706234595", name = "AnimeFireCloud", rate = 45, lifetime = NumberRange.new(0.35, 0.65), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 3.5), NumberSequenceKeypoint.new(1, 7)}), speed = NumberRange.new(8, 18), color = ColorSequence.new(Color3.fromRGB(255, 170, 40), Color3.fromRGB(220, 40, 10)), lightEmission = 1 },
			{ id = "rbxassetid://296874871", name = "SwirlFlame", rate = 30, lifetime = NumberRange.new(0.3, 0.55), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 2.5), NumberSequenceKeypoint.new(1, 5.5)}), speed = NumberRange.new(5, 12), color = ColorSequence.new(Color3.fromRGB(255, 220, 90), Color3.fromRGB(255, 80, 20)), lightEmission = 1 },
			{ id = "rbxassetid://400367266", name = "MeteorFireCore", rate = 25, lifetime = NumberRange.new(0.25, 0.45), size = NumberSequence.new(4), speed = NumberRange.new(2, 6), lightEmission = 1 },
		},
		soundId = "rbxassetid://6555450717"
	},
	SSJCharge = {
		description = "Super Saiyan / Kaioken Yükselen Altın-Kırmızı Güç Aurası",
		particles = {
			{ id = "rbxassetid://6954174382", name = "RisingAuraPlume", rate = 35, lifetime = NumberRange.new(0.4, 0.7), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 3.5), NumberSequenceKeypoint.new(1, 6.5)}), speed = NumberRange.new(6, 14), color = ColorSequence.new(Color3.fromRGB(255, 230, 70), Color3.fromRGB(255, 140, 20)), lightEmission = 1 },
			{ id = "rbxassetid://6741260601", name = "SpikyAuraFlame", rate = 28, lifetime = NumberRange.new(0.35, 0.6), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 3), NumberSequenceKeypoint.new(1, 5)}), speed = NumberRange.new(4, 10), color = ColorSequence.new(Color3.fromRGB(255, 245, 130)), lightEmission = 1 },
			{ id = "rbxassetid://6805553497", name = "GroundAuraRing", rate = 8, lifetime = NumberRange.new(0.3, 0.5), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 2), NumberSequenceKeypoint.new(1, 8)}), speed = NumberRange.new(0, 1), color = ColorSequence.new(Color3.fromRGB(255, 220, 80)), lightEmission = 1 },
		}
	},
	HealAoe = {
		description = "Yeşil/Altın Alan İyileştirme (Heal AoE) Halkası ve Parıltıları",
		particles = {
			{ id = "rbxassetid://6820233329", name = "HealRing", rate = 6, lifetime = NumberRange.new(0.6, 0.9), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 4), NumberSequenceKeypoint.new(1, 10)}), speed = NumberRange.new(0, 1), color = ColorSequence.new(Color3.fromRGB(90, 255, 150)), lightEmission = 1 },
			{ id = "rbxassetid://6991144892", name = "HealSparkle", rate = 25, lifetime = NumberRange.new(0.6, 1.1), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 1.2), NumberSequenceKeypoint.new(1, 0)}), speed = NumberRange.new(4, 9), color = ColorSequence.new(Color3.fromRGB(140, 255, 190)), lightEmission = 1 },
			{ id = "rbxassetid://6794268634", name = "HealLightStreak", rate = 18, lifetime = NumberRange.new(0.4, 0.7), size = NumberSequence.new(2.5), speed = NumberRange.new(6, 12), color = ColorSequence.new(Color3.fromRGB(120, 255, 170)), lightEmission = 1 },
		}
	},
	DarkOrb = {
		description = "Karanlık Küre / Kara Delik Girdabı ve Yıldırım Efektleri",
		particles = {
			{ id = "rbxassetid://4726930169", name = "DarkVortex", rate = 20, lifetime = NumberRange.new(0.4, 0.7), size = NumberSequence.new(5), speed = NumberRange.new(0, 2), color = ColorSequence.new(Color3.fromRGB(150, 50, 255), Color3.fromRGB(40, 0, 90)), lightEmission = 0.9 },
			{ id = "rbxassetid://6571027709", name = "PurpleLightningWeb", rate = 14, lifetime = NumberRange.new(0.15, 0.3), size = NumberSequence.new(4.5), speed = NumberRange.new(0, 2), color = ColorSequence.new(Color3.fromRGB(190, 110, 255)), lightEmission = 1 },
		}
	},
	IceFrost = {
		description = "Buz / Kırağı Sis ve Kristal Parıltı Efekti",
		particles = {
			{ id = "rbxassetid://1946917526", name = "FrostCloud", rate = 22, lifetime = NumberRange.new(0.5, 0.9), size = NumberSequence.new({NumberSequenceKeypoint.new(0, 2.5), NumberSequenceKeypoint.new(1, 4.5)}), speed = NumberRange.new(2, 5), color = ColorSequence.new(Color3.fromRGB(160, 235, 255)), lightEmission = 0.85 },
			{ id = "rbxassetid://243664672", name = "IceGlow", rate = 15, lifetime = NumberRange.new(0.4, 0.7), size = NumberSequence.new(2.2), speed = NumberRange.new(1, 4), color = ColorSequence.new(Color3.fromRGB(200, 245, 255)), lightEmission = 1 },
		}
	},
}

function UqVFXLibrary.Spawn(presetName, targetParent, customColor)
	local preset = UqVFXLibrary.Presets[presetName] or UqVFXLibrary.Presets.BasicHit
	local attachment = Instance.new("Attachment")
	attachment.Name = "UqVFX_" .. tostring(presetName)
	attachment.Parent = targetParent

	for _, pDef in ipairs(preset.particles or {}) do
		local pe = Instance.new("ParticleEmitter")
		pe.Name = pDef.name or "VFXEmitter"
		pe.Texture = pDef.id
		pe.LightEmission = pDef.lightEmission or 1
		pe.LightInfluence = 0
		pe.Lifetime = pDef.lifetime or NumberRange.new(0.25, 0.45)
		pe.Size = pDef.size or NumberSequence.new(3)
		pe.Speed = pDef.speed or NumberRange.new(2, 8)
		pe.SpreadAngle = Vector2.new(180, 180)
		pe.Color = customColor or pDef.color or ColorSequence.new(Color3.new(1, 1, 1))
		pe.Enabled = not preset.burst
		pe.Rate = pDef.rate or 20
		pe.Parent = attachment
		if preset.burst then
			pe:Emit(pDef.emitCount or 8)
		end
	end

	if preset.soundId then
		local snd = Instance.new("Sound")
		snd.SoundId = preset.soundId
		snd.Volume = 0.8
		snd.Parent = attachment
		snd:Play()
	end

	if preset.burst then
		task.delay(1.5, function()
			if attachment and attachment.Parent then
				attachment:Destroy()
			end
		end)
	end

	return attachment
end

return UqVFXLibrary
