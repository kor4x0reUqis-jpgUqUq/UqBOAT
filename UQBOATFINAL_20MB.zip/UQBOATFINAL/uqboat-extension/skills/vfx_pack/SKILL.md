# UqBOAT FX Pack & Görsel İncelemeli VFX Kütüphanesi (`vfx_pack`)

Bu skill paketi, Roblox Studio'da **VFX (Görsel Efekt), Aura, Kılıç Kesik (Slash), Vuruş (Hit Impact), Blok / Kalkan (Block / Guard Break), Yıldırım (Lightning), Ateş (Fireball / Hiken / Meteor), Anime Güçlenme (SSJ / Kaioken / Buso Haki)** ve büyü efektleri oluştururken kullanman gereken **263 doğrulanmış Roblox Asset ID**'sini ve hazır Luau kod yapısını içerir.

## Hızlı Kullanım Kuralları
1. **Hazır Modül (`game.ReplicatedStorage.UqVFXLibrary`):**
   UqBOAT bu paketi otomatik olarak `game.ReplicatedStorage.UqVFXLibrary` içine de kurabilir. Ayrıca `execute_luau` veya `multi_edit` içinde doğrudan `ParticleEmitter.Texture = "rbxassetid://ID"`, `Beam.Texture = "rbxassetid://ID"`, `Decal.Texture = "rbxassetid://ID"`, `Sound.SoundId = "rbxassetid://ID"` olarak kullanabilirsin.
2. **Görünürlük ve Parlaklık (Çok Önemli):**
   - Siyah arka planlı VFX dokularında (Listedeki neredeyse tüm Particle ve Beam'ler) siyah arka planın şeffaf olması ve efektin parlaması için **mutlaka** `LightEmission = 1` (veya `0.85 - 1.0`), `LightInfluence = 0` ayarla!
   - Beyaz dokulu efektleri (`7032949469`, `6954174382`, `6986730276`, `7368928330`, `6706234595` vb.) `Color = ColorSequence.new(...)` ile istediğin renge (Kırmızı Ateş, Mavi Yıldırım, Mor Karanlık Enerji, Altın Aura, Yeşil İyileştirme) boyayabilirsin.
3. **Anlık Vuruş / Patlama (Burst) Efektleri İçin:**
   - Sürekli akan (`Enabled = true`) efektler Aura/Ateş içindir.
   - Vuruş (`Hit`, `Slash`, `Block`, `Guard Break`, `Explosion`) efektlerinde `emitter.Enabled = false`, `emitter.Speed = NumberRange.new(15, 35)`, `emitter.Lifetime = NumberRange.new(0.2, 0.45)` yapıp `emitter:Emit(15)` ile anlık patlat!


================================================================================
   GÖRSEL İNCELEMELİ & İSİMLENDİRİLMİŞ VFX KATALOĞU (263 ASSET GÖRÜNÜM REHBERİ)
   (Tüm Asset ID'lerin gerçek Roblox dokuları incelenerek görünüşlerine göre
    isimlendirilmiş ve kategorize edilmiştir — rbxassetid://ID olarak kullanın)
================================================================================

1. YILDIRIM / ELEKTRİK / ŞİMŞEK EFEKTLERİ (LIGHTNING & ELECTRICITY)
  - rbxassetid://7047857629 -> [Particle] Parlak Turkuaz-Mavi Dallı Yıldırım Çarpması 1 (Aura / Elektrik)
  - rbxassetid://7056843550 -> [Particle] Parlak Turkuaz-Mavi Dallı Yıldırım Çarpması 2 (Aura / Elektrik)
  - rbxassetid://5511876855 -> [Particle] Mavi Elektrik Şimşek Arkı 1 (Electrocuted)
  - rbxassetid://5511887359 -> [Particle] Mavi Çember Elektrik Arkı 2 (Electrocuted / Silva Orbs)
  - rbxassetid://5511893461 -> [Particle/Beam] Mavi Dikey Elektrik Şimşeği 3 (Electrocuted)
  - rbxassetid://302958406  -> [Particle] Parlak Mavi-Beyaz Elektrik Çekirdek Parlaması (Electrocuted Core)
  - rbxassetid://301851161  -> [Particle] Mavi Elektrik Ağı / Zemin Yıldırım Çatlağı (agagsadg -> ElectricWeb)
  - rbxassetid://257173628  -> [Particle] Mavi-Beyaz Keskin Kırık Şimşek Çizgisi
  - rbxassetid://886346568  -> [Particle] Dikey Mavi Yıldırım Düşmesi (Lightning Strike)
  - rbxassetid://6571027709 -> [Particle] Yoğun Mor-Beyaz Elektrik Yıldırım Ağı (Meteor / Electric Storm)
  - rbxassetid://1277447946 -> [Beam] Yoğun Beyaz Dallı Yıldırım Sütunu Beam (DarkOrbSkill / Lightning Beam)
  - rbxassetid://5179105576 -> [Beam] Kalın Çatırdayan Beyaz Yıldırım Sütunu Beam
  - rbxassetid://6493333927 -> [Beam] Geniş Zikzak Elektrik / Yıldırım Işını Beam (Meteor Beam)
  - rbxassetid://6333489569 -> [Beam] İkili Çapraz Beyaz Yıldırım Beam
  - rbxassetid://3693756254 -> [Beam] Testere Dişli Elektrik Dalga Işını Beam
  - rbxassetid://1084955012 -> [Particle] Beyaz Elektrikli Yıldırım Halkası (Electric Ring)
  - rbxassetid://1084959312 -> [Particle] İnce Beyaz Kırık Elektrik Arkı
  - rbxassetid://1463939561 -> [Particle/Beam] Dallı Beyaz Elektrik Çarpma Arkı (BasicHit / Shock)
  - rbxassetid://7024022846 -> [Particle] Beyaz Kıvrımlı Elektrik Arkı 1 (Pure Majin)
  - rbxassetid://7024029708 -> [Particle] Beyaz Kıvrımlı Elektrik Arkı 2 (Mystic / Omni)
  - rbxassetid://7328190505 -> [Particle] Yatay Kırık Yıldırım / Zemin Çatlağı
  - rbxassetid://6842608743, 6842610167, 6842615123, 6842631505, 6842632995 -> [Particle] SSJ3 Elektrik Kıvılcım Kareleri (5'li Set)
  - rbxassetid://3487287017 -> [Particle] Çatırdayan Beyaz Elektrik Küresi Çekirdeği

2. ATEŞ / ALEV / PATLAMA / METEOR EFEKTLERİ (FIRE, FLAME & EXPLOSION)
  - rbxassetid://6706234595 -> [Particle] Yoğun Kıvrımlı Anime Alev & Haki Dumanı (Hiken / Diable Jambe / Buso / Meteor)
  - rbxassetid://7032949469 -> [Particle] Beyaz Anime Alev Aurası (ColorSequence ile her renge boyanabilir Aura Alevi)
  - rbxassetid://248625108  -> [Particle] Gerçekçi Turuncu-Kırmızı Ateş Patlaması (Realistic Fire Puff)
  - rbxassetid://400367266  -> [Particle] Gerçekçi Meteor Ateş Topu Alevi (Meteor Fireball)
  - rbxassetid://296874871  -> [Particle] Kıvrımlı Anime Alev / Duman Bulutu (FireballJutsu)
  - rbxassetid://5228741725 -> [Beam] Altın-Turuncu Yükselen Alev Konisi (Meteor Flame Trail Beam)
  - rbxassetid://6428770095 -> [Beam] Turuncu Uçuşan Ateş Kıvılcımları Beam 1
  - rbxassetid://6428800497 -> [Beam] Yoğun Turuncu Alev Dalgası Beam 2
  - rbxassetid://6428810016 -> [Decal] Turuncu Dönen Ateş Halkası (Fire Whirl Ring Decal)
  - rbxassetid://6428867170 -> [Beam] Turuncu Alev Girdabı / Hortumu Beam (Fire Tornado)
  - rbxassetid://7553274670 -> [Particle] Altın-Turuncu Yoğun Ateş Patlama Bulutu (HEAVY Punch Genshin)
  - rbxassetid://3071902048 -> [Particle] Altın Sarısı Anime Çarpışma Patlaması (hit small - Golden Burst)
  - rbxassetid://3071903961 -> [Particle] Kırmızı-Turuncu Ateşli Şok Halkası (hit small - Fire Ring)
  - rbxassetid://3176084492 -> [Particle] Çapraz Parlayan Ateş Kıvılcımı / Kor İzi (Ember Streak)
  - rbxassetid://258126401  -> [Particle] Anka Ateşi / Fraktal Plazma Dumanı (Phoenix Punch & Slash)

3. KILIÇ KESİK / SLASH / HİLAL DALGASI EFEKTLERİ (SWORD SLASHES & CRESCENTS)
  - rbxassetid://494046218  -> [Particle] Çapraz Mavi-Beyaz Keskin Kılıç Kesik İzi (Slash Genshin Pack)
  - rbxassetid://6986730276 -> [Particle] Çok Katmanlı Dönen Beyaz Kılıç Kesik Halkası (Slashes)
  - rbxassetid://6874938467 -> [Particle] Dinamik Dairesel Kılıç Kesik Halkası (Slashes)
  - rbxassetid://5726444189 -> [Particle] Yumuşak Dairesel Dönen Kılıç Rüzgarı (Slashes Wind)
  - rbxassetid://7502239145 -> [Particle] Kalın Beyaz C-Hilal Kılıç Kesik Halkası (R6 Crescent Slash)
  - rbxassetid://6887062144 -> [Particle] Beyaz Hilal Kılıç Dalgası (White Crescent Wave)
  - rbxassetid://6887527039 -> [Particle] Altın Sarısı Hilal Kılıç Dalgası (Golden Crescent Wave)
  - rbxassetid://6703717304 -> [Particle] Altın Sarısı Dönen İkili Kesik Halkası (Golden Swirl Slash)
  - rbxassetid://5958561575 -> [TextureId] Hilal Rüzgar Kesik Dokusu (Meshes/air2_Circle.003)
  - rbxassetid://4548000747 -> [Particle] İnce Yatay Kılıç Kesik Çizgisi (Sword Hits)
  - rbxassetid://5954439166 -> [Particle] Keskin Yatay Kılıç Parıltısı (Blade Glint)
  - rbxassetid://6564161415 -> [Particle] Dikey Çoklu Pençe / Kılıç Kesik Çizikleri
  - rbxassetid://4718897358 -> [Beam] Dikey Çoklu Hız ve Kesik Çizgileri Beam
  - rbxassetid://6022076252, 6022076585, 6022076851, 6022077167, 6022077415, 6022077733 -> [Decal] 6 Kare Dairesel Hilal Slash Animasyon Seti (circleslash)
  - rbxassetid://6824059098 (MeshId) + rbxassetid://6825099800 (TextureId) -> [Mesh] 3D Hilal Kılıç Dalgası Mesh (Outer Crescent)

4. VURUŞ / DARBE / YILDIZ PARLAMASI EFEKTLERİ (HIT IMPACTS & STARBURSTS)
  - rbxassetid://7368928330 -> [Particle] Genshin Tarzı Keskin Vuruş Yıldızı (Punch & Slash Genshin Pack)
  - rbxassetid://7417147728 -> [Particle] Çok Kollu Parlak Vuruş Yıldızı (Stuff -> Multi-Star Impact)
  - rbxassetid://4609120431 -> [Particle] Mor-Mavi Kromatik Vuruş Yıldız Patlaması (Hit Effect [Kit])
  - rbxassetid://4609089148 -> [Particle] Asimetrik Keskin Anime Vuruş Yıldızı (Hit Effect [Kit])
  - rbxassetid://6255933390 -> [Particle] Kırmızı-Beyaz Anime Vuruş Yıldızı (Red Hit Flash)
  - rbxassetid://1463840694 -> [Particle] 7 Köşeli Çizgi Roman Vuruş Yıldızı (BasicHit)
  - rbxassetid://7495617513 -> [Particle] Çok Uçlu Sivri Patlama Yıldızı (R6 Burst Star)
  - rbxassetid://5238574777 -> [Particle] İnce Çok İğneli Yıldız Patlaması (Block Needle Star)
  - rbxassetid://6659468252 -> [Particle] Parlak Çok Kollu Yıldız Parlaması
  - rbxassetid://243728166  -> [Particle] Parlak Beyaz Yıldız Patlaması (Jajanken Rock)
  - rbxassetid://298984512  -> [Particle] 4 Köşeli Haç Işık Parlaması (Light Beam / Light Slash)
  - rbxassetid://5403480383 -> [Particle] Keskin 4 Köşeli Savuşturma (Parry) Parlaması
  - rbxassetid://6887003614 -> [Particle] Altın Sarısı 4 Köşeli Haç Parlaması
  - rbxassetid://5043599095 -> [Particle] Büyük 4 Köşeli Elmas Yıldız Parıltısı
  - rbxassetid://5812378274 -> [Particle] Orta 4 Köşeli Elmas Yıldız Parıltısı
  - rbxassetid://1053546634 -> [Particle] Yumuşak 4 Köşeli Elmas Parıltısı
  - rbxassetid://7536237546 -> [Particle] Kalın 4 Köşeli Parlayan Yıldız (R6 Star)
  - rbxassetid://134531274  -> [Particle] Sarı-Yeşil Parlayan Yıldız (Yes -> Yellow-Green Star)
  - rbxassetid://6594529149 -> [Particle] Çapraz Kesik + Halka Hedef Vuruş Efekti (Parry burst)
  - rbxassetid://991687067  -> [Particle] Anime Çarpışma / Vuruş Patlama Halkası (ball / hit small)
  - rbxassetid://311395391  -> [Particle] Gerçekçi Metal Kıvılcım Saçılması (Sparks)
  - rbxassetid://3499610614 -> [Particle] Beyaz Radyal Kıvılcım Yağmuru (agagsadg -> Spark Shower)
  - rbxassetid://6886859912 -> [Particle] Sarı Radyal Kıvılcım Saçılması
  - rbxassetid://7524787479 -> [Particle] Keskin Yatay Enerji Mermisi / Hız İzi (Genshin / Orange / Purple / Red / Teal)

5. KALKAN / BLOK / GUARD BREAK / SAVUNMA EFEKTLERİ (SHIELDS, BLOCK & PARRY)
  - rbxassetid://7008034274 -> [Particle] Mavi Parlayan Kalkan İkonu (Blocked - Blue Shield)
  - rbxassetid://7008088022 -> [Particle] Kırmızı Parlayan Kalkan İkonu (Blocked - Red Shield)
  - rbxassetid://7008506724 -> [Particle] Kırılmış Çatlak Kırmızı Kalkan İkonu (Block Break Genshin Pack)
  - rbxassetid://7468976277 -> [Particle] Beyaz Kalkan Silüeti (R6 Shield)
  - rbxassetid://7553024429 -> [Particle] "Blocked!" Yazı Efekti (Blocked Popup Text)
  - rbxassetid://7553126971 -> [Particle] "Broken!" Yazı Efekti (Block Break Popup Text)
  - rbxassetid://3283071087 -> [Particle] Sekizgen Teknoloji / Enerji Kalkan Halkası (Tech Sphere)
  - rbxassetid://459960092  -> [Particle] Hücresel Enerji Küresi / Kalkan Dokusu (Cellular Forcefield)
  - rbxassetid://3524228573 -> [Particle] Parlak Şeffaf Enerji / Su Baloncuğu Küresi (D / Particle5 -> Glossy Bubble Shield)
  - rbxassetid://7458821155 -> [Particle] Dikey Parlak Blok / Parry Çizgisi (Block / parry / guard break)

6. ŞOK HALKALARI / DALGALAR / GİRDAPLAR (SHOCKWAVE RINGS & VORTEXES)
  - rbxassetid://7556074751 -> [Particle] Gökkuşağı Kromatik Şok Halkası (Block - Chromatic Aberration Ring)
  - rbxassetid://7363803708 -> [Particle] Dişli Radyal Genshin Şok Halkası (Block Break / Blocked)
  - rbxassetid://7417145436 -> [Particle] Geniş Dişli Şok Çemberi (Stuff -> Spiky Shockwave Ring)
  - rbxassetid://4507224751 -> [Particle] Radyal Çizgili Anime Şok Halkası
  - rbxassetid://7553257107 -> [Particle] Yıldızlı Parlayan Şok Halkası (Slash Genshin Pack)
  - rbxassetid://244221613  -> [Particle] Kalın Beyaz Şok Halkası (Meteor Ring)
  - rbxassetid://1084991215 -> [Particle/Beam] İçten Parlayan Şok Halkası (Ball / GigChain)
  - rbxassetid://6801156215 -> [Particle] Yumuşak Parlayan Beyaz Halka (R6 Ring)
  - rbxassetid://6820233329 -> [Particle] Parlak Kenarlı İyileştirme / Alan Halkası (HealAoe Ring)
  - rbxassetid://4609193944 -> [Particle/Decal] İnce Keskin Dış Şok Çemberi (Ring / parry / Hit Effect)
  - rbxassetid://5259803254 -> [Particle] Fırça Darbeli Anime Şok Çemberi
  - rbxassetid://2450392732 -> [Particle] Parçalı Dönen Rüzgar / Şok Halkası (R6 Segmented Vortex)
  - rbxassetid://7552993102 -> [Particle] Dönen Girdap Kesik Halkası (Block Break / Slash Genshin)
  - rbxassetid://7556244791, 7556077455 -> [Particle] Dönen Rüzgar Girdap Halkaları (guard break)
  - rbxassetid://6887149763 -> [Particle] Altın Sarısı Sarmal Girdap (Golden Spiral Vortex)
  - rbxassetid://4726930095, 4726930169 -> [Particle] Karanlık Enerji Girdabı / Kara Delik (DarkOrbSkill)
  - rbxassetid://7450898297, 7524756305 -> [Particle] Parçalanan Enerji Patlama Halkaları (guard break / Orange / Purple / Red)

7. AURA / ENERJİ SÜTUNU / BEAM / ZİNCİR / DOKU EFEKTLERİ (AURAS, BEAMS & TEXTURES)
  - rbxassetid://6954174382 -> [Particle] Yükselen Dikey Enerji Aura Sütunu (Kaioken / SSJ / Mystic / Omni / Pure Majin)
  - rbxassetid://6741260601 -> [Particle] Sivri Yükselen Anime Aura Alevi (Kaioken / SSJ / Mystic / Omni)
  - rbxassetid://6594369527, 6594386804 -> [Particle] Koni Şeklinde Yükselen Güç Aurası (GiganticCrush / SSJ3)
  - rbxassetid://250186345  -> [Beam] Sivri Anime Zemin Aura Patlaması
  - rbxassetid://1882230139 -> [Particle] Dikey Yükselen Rüzgar / Aura Çizgileri
  - rbxassetid://2316283203 -> [Beam] Yıldızlı Dikey Işık Sütunu Beam (Holy / Magic Pillar)
  - rbxassetid://3029306948 -> [Beam] Gerçekçi Metal Zincir Halkası Beam (GigChain)
  - rbxassetid://1135136643 -> [Beam] Beyaz Çift Sarmal (DNA) Enerji Işını Beam (Buso)
  - rbxassetid://5942218263 -> [Beam] Mor Çift Sarmal Karanlık Enerji Beam (MeshPart Beam)
  - rbxassetid://1946917526 -> [Particle] Buz / Kırağı Sis Bulutu (HeadIce / RightArmIce / TorsoIce)
  - rbxassetid://6002738749 -> [Particle] Kırmızı Kan Damlaları Efekti (HEAVY Punch)
  - rbxassetid://785035165  -> [Particle] Kan Sıçrama Efekti (blood splat)
  - rbxassetid://6127709348 -> [Particle] Beyaz Sıvı / Su Sıçrama Efekti (Water Splash)
  - rbxassetid://626588936, 6760190948 -> [Particle] 3D Kaya / Taş Parçası Efekti (DarkOrbSkill / Debris)
  - rbxassetid://7075251005 (Mavi), 7075253643 (Kırmızı), 7075343009 (Mor) -> [Decal] Voronoi Enerji / Magma Hücre Dokuları

8. SES EFEKTLERİ (VFX SOUND ASSETS)
  - rbxassetid://6435645749, 6435646111 -> Enerji Topu / Ball Ses Efektleri
  - rbxassetid://6555450717 -> FireballJutsu Ateş Topu Patlama Sesi
  - rbxassetid://6650544248, 3744389456, 6340511690, 5650258743, 1885498697, 1677094219 -> Anime Vuruş / Patlama / Şimşek Ses Efektleri
================================================================================


## Tam FX Pack Listesi (Orijinal Grup Listesi)
```text
========================================
   FX PACK - TÜM VFX ASSET ID LİSTESİ
========================================

=== Aura ===
  Particle: 7047857629
  Particle: 7056843550
  Particle: 7032949469

=== Ball ===
  Sound: 6435645749
  Sound: 6435646111
  Particle: 1084991215

=== BasicHit ===
  Particle: 6489454124
  Particle: 6486908530
  Particle: 6487659613
  Particle: 6280384227
  Particle: 2916153928
  Particle: 1463840694
  Particle: 1463874772
  Particle: 1463939561
  Particle: 1463903184
  Particle: 6150099806
  Particle: 6219939930
  Particle: 6149990816
  Particle: 2286297003
  Particle: 6569118042
  Particle: 4998927913

=== Block ===
  Particle: 7225262171
  Particle: 7556074751
  Particle: 5238525822
  Particle: 5238478413
  Particle: 5420292447
  Particle: 5238574777
  Particle: 5239271518
  Particle: 7458821155

=== Block Break Genshin Pack ===
  Particle: 6943856265
  Particle: 7008506724
  Particle: 6839837500
  Particle: 6930625149
  Particle: 7552993102
  Particle: 7363803708
  Particle: 7524787479
  Particle: 7363690160
  Particle: 7553126971

=== Blocked ===
  Particle: 6943856265
  Particle: 7008088022
  Particle: 7524787479
  Particle: 7008034274
  Particle: 6930625149
  Particle: 7363690160
  Particle: 7363803708
  Particle: 7552993102
  Particle: 7553024429

=== Buso ===
  Beam: 1135136643
  Beam: 1771082037
  Particle: 6706234595
  Beam: 3517446796

=== DarkOrbSkill ===
  Particle: 5234964512
  Particle: 4726930169
  Particle: 217245118
  Beam: 4813316821
  Particle: 626588936
  Beam: 1277447946
  Beam: 5406968633

=== D ===
  Particle: 3524228573

=== Diable Jambe ===
  Decal: 132155326
  Particle: 6706234595
  Decal: 2123464591

=== Electrocuted ===
  Particle: 302958406
  Particle: 5511893461
  Particle: 5511887359
  Particle: 5511876855

=== FireballJutsu ===
  Sound: 6555450717
  Particle: 1084962479
  Particle: 296874871

=== GigChain ===
  Beam: 3029306948
  Beam: 1084991215

=== GiganticCrush ===
  Particle: 6594369527
  Particle: 6594386804
  Particle: 867619398
  Particle: 6555389740

=== HEAVY Punch Genshin Pack ===
  Particle: 7450825347
  Particle: 7356491644
  Particle: 7368928330
  Particle: 7356492741
  Particle: 7450871048
  Particle: 6002738749
  Particle: 7553274670
  Particle: 7524787479
  Particle: 6839837500

=== HeadIce ===
  Particle: 1946917526
  Particle: 243664672

=== HealAoe ===
  Particle: 6991144892
  Particle: 6781947608
  Particle: 6794268634
  Particle: 6820233329
  Particle: 7153799399

=== Hiken ===
  Particle: 6706234595

=== Hilt ===
  Particle: 387288028

=== Hit ===
  Particle: 6921558158
  Particle: 6921540370
  Particle: 6921954102
  Particle: 6921954728
  Particle: 6921525952
  Particle: 5881440642

=== Hit Effect [Kit] ===
  Particle: 4525311852
  Particle: 4609193944
  Particle: 1084999891
  Particle: 4609120431
  Particle: 4609089148
  Particle: 5259803254

=== hit (small) ===
  Particle: 3071902048
  Particle: 3071903961
  Particle: 991687067

=== Jajanken Paper ===
  Particle: 506441968

=== Jajanken Rock ===
  Beam: 356008990
  Particle: 243728166

=== Jajanken Scissors ===
  Particle: 347730682

=== Kaioken ===
  Particle: 6954174382
  Particle: 6741260601

=== Kaioken x4 ===
  Particle: 6954174382
  Particle: 6741260601

=== Kaioken x20 ===
  Particle: 6954174382
  Particle: 6741260601

=== Light Beam ===
  Particle: 298984512

=== Light Slash ===
  Particle: 298984512

=== Meteor ===
  Particle: 400367266
  Particle: 213222519
  Particle: 6571027709
  Particle: 2916153928
  Particle: 244221613
  Particle: 6706234595
  Beam: 5228741725
  Beam: 6493333927
  Particle: 502107146

=== Meteor Spawn ===
  Particle: 2916153928
  Particle: 2515337227
  Particle: 348103573

=== Mystic ===
  Particle: 7024029708
  Particle: 6741260601
  Particle: 6954174382

=== Omni ===
  Particle: 7024029708
  Particle: 6741260601
  Particle: 6954174382

=== Orange ===
  Particle: 7524756305
  Particle: 7524776499
  Particle: 7524787479

=== Outer Crescent ===
  MeshId: 6824059098
  TextureId: 6825099800

=== Parry burst ===
  Particle: 1075864321
  Particle: 6390608047
  Particle: 1021559161
  Particle: 6594529149
  Particle: 5403480383

=== parry ===
  Particle: 7458821155
  Particle: 7225262171
  Particle: 4728868369
  Particle: 4609193944

=== Particles ===
  Particle: 6569253302
  Particle: 6569253722
  Particle: 6569254155
  Particle: 6569118042
  Particle: 272050333
  Particle: 3524228573
  Particle: 3048527478
  Particle: 4998927913

=== Particle5 ===
  Particle: 3524228573

=== Pheonix Punch ===
  Particle: 258126401

=== Pheonix Slash ===
  Particle: 258126401

=== Pull ===
  Particle: 6820835549
  Particle: 6779878570
  Particle: 6820821916
  Particle: 6820871121
  Particle: 6820785776
  Particle: 6820806418
  Particle: 5513790059

=== Punch Genshin Pack ===
  Particle: 7450825347
  Particle: 7356491644
  Particle: 7368928330
  Particle: 7356492741
  Particle: 7450871048
  Particle: 6839837500
  Particle: 7524787479

=== Pure Majin ===
  Particle: 6954174382
  Particle: 6741260601
  Particle: 7024022846

=== Purple ===
  Particle: 7524756305
  Particle: 7524776499
  Particle: 7524787479

=== R6 ===
  Particle: 6801156215
  Particle: 7468976277
  Particle: 7276091574
  Particle: 7502239145
  Particle: 7502810450
  Particle: 7536237546
  Particle: 7495681722
  Particle: 7276073147
  Particle: 7495617513
  Particle: 2450392732

=== Red ===
  Particle: 7524756305
  Particle: 7524776499
  Particle: 7524787479

=== RightArmIce ===
  Particle: 1946917526
  Particle: 243664672

=== RightLegIce ===
  Particle: 243664672
  Particle: 1946917526

=== Ring ===
  Decal: 4609193944

=== SSJ ===
  Particle: 6954174382
  Particle: 6741260601

=== SSJ2 ===
  Particle: 6954174382
  Particle: 6741260601

=== SSJ3 ===
  Particle: 867619398
  Particle: 6594386804
  Particle: 6594369527
  Particle: 6555389740
  Particle: 6842610167
  Particle: 6842608743
  Particle: 6842615123
  Particle: 6842632995
  Particle: 6842631505

=== SSJCharge ===
  Particle: 6954174382
  Particle: 6741260601
  Particle: 6805553497
  Particle: 1085001473
  Particle: 6682535486

=== SSJGCharge ===
  Particle: 6682535486
  Particle: 6954174382
  Particle: 6741260601
  Particle: 1085001473
  Particle: 6805553497

=== Silva orbs2 ===
  Particle: 5511887359
  Particle: 1084959312
  Particle: 867619398
  Particle: 1084955012

=== Slash Genshin Pack ===
  Particle: 7450825347
  Particle: 7363737733
  Particle: 494046218
  Particle: 7552993102
  Particle: 7553257107
  Particle: 6839837500
  Particle: 7368928330

=== Slashes ===
  Particle: 6986730276
  Particle: 5726444189
  Particle: 6874938467

=== Stuff ===
  Particle: 7458821155
  Particle: 4728868369
  Particle: 7417145436
  Particle: 2733909040
  Particle: 7225262171
  Particle: 4609193944
  Particle: 7417147728
  Particle: 7428241836

=== Super Namekian ===
  Particle: 6954174382
  Particle: 6741260601

=== Sword Hits ===
  Particle: 4548000747

=== Teal ===
  Particle: 7524756305
  Particle: 7524776499
  Particle: 7524787479

=== Tech Sphere ===
  Particle: 3283071087
  Particle: 4609193944
  Particle: 3386621521
  Beam: 1315202524

=== TorsoIce ===
  Particle: 1946917526
  Particle: 243664672

=== Yes ===
  MeshId: 5779776741
  Decal: 5779776825
  Particle: 134531274

=== agagsadg ===
  Particle: 3499610614
  Particle: 301851161

=== base ===
  Decal: 7045573215

=== ball ===
  Particle: 991687067

=== blood splat ===
  Particle: 785035165

=== boulder rock ===
  (Mesh - no external asset ID)

=== circleslash ===
  Decal: 6022076252
  Decal: 6022076851
  Decal: 6022076585
  Decal: 6022077167
  Decal: 6022077415
  Decal: 6022077733

=== guard break ===
  Particle: 7458821155
  Particle: 4728868369
  Particle: 7556244791
  Particle: 7556077455
  Particle: 7450898297
  Particle: 7553323419

=== ice spike ===
  (Custom mesh - no external asset ID)

=== Dark Hole ===
  (Custom setup - no external asset ID)

=== Dragon ===
  (Custom setup - no external asset ID)

=== FBXImportGeneric ===
  (FBX Import - no external asset ID)

=== IceBirdOld ===
  (Custom setup - no external asset ID)

=== Normal Light Beam ===
  (Custom setup - no external asset ID)

=== Orb ===
  (Custom setup - no external asset ID)

=== Model (İsimsiz VFX'ler - Ek Asset ID'ler) ===
  Particle: 6781947608
  Particle: 7153799399
  Particle: 7524756305
  Particle: 7524776499
  Beam: 4718897358
  Beam: 2316283203
  Particle: 3487287017
  Particle: 4525311852
  Particle: 4753492159
  Particle: 4507224751
  Particle: 4685807388
  Particle: 1746829167
  Decal: 7075251005
  Decal: 7075253643
  Decal: 6428810016
  Beam: 6428770095
  Beam: 6428800497
  Beam: 6428867170
  Beam: 250186345
  Particle: 296874871
  Particle: 1315202524
  Particle: 867619398
  Particle: 129110349
  Particle: 6703717304
  Particle: 6887062144
  Particle: 6255933390
  Particle: 6887149763
  Particle: 6659468252
  Particle: 1463874772
  Particle: 6886859912
  Beam: 6444655780
  Beam: 6333489569
  Beam: 6234354298
  Particle: 257173628
  Particle: 886346568
  Particle: 7032949469
  Particle: 626588936
  Sound: 6650544248
  Particle: 6127709348
  Particle: 6986730276
  Particle: 6571027709
  Particle: 400367266
  Particle: 3176084492
  Particle: 248625108
  Particle: 619393574
  Particle: 5898549549
  Particle: 5898511947
  Beam: 5898982019
  Decal: 7075343009
  Beam: 5511893461
  Particle: 311395391
  Particle: 387288028
  Particle: 6756260136
  Particle: 6760190948
  Particle: 6594386804
  Particle: 6594369527
  Particle: 6555389740
  Particle: 7024022846
  Particle: 459960092
  Particle: 5043599095
  Particle: 5043715023
  Particle: 1882230139
  Particle: 476778304
  Particle: 1084997326
  Sound: 3744389456
  Beam: 1463939561
  Sound: 6340511690
  Sound: 5650258743
  Beam: 3693756254
  Beam: 1851669703
  Particle: 1053546634
  Particle: 1084999891
  Sound: 1885498697
  Sound: 1677094219
  Decal: 6372755229
  Particle: 7328190505
  Particle: 7450871048
  Particle: 7363926794
  Particle: 7356491644
  Particle: 7363737733
  Particle: 6497432385
  Particle: 6601476680
  Particle: 6564161415
  Particle: 5001001365
  Particle: 6887527039
  Particle: 6887003614

=== MeshPart (İsimsiz) ===
  Particle: 6706234595
  Beam: 5942218263

=== Meshes/air2_Circle.003 ===
  TextureId: 5958561575

=== Part (İsimsiz VFX'ler - Ek Asset ID'ler) ===
  Particle: 459960092
  Particle: 5043715023
  Particle: 5043599095
  Particle: 6246398215
  Particle: 456477850
  Particle: 5954439166
  Particle: 258126401
  Particle: 4705368203
  Particle: 4753492159
  Particle: 5155117633
  Beam: 1277447946
  Beam: 1849531275
  Beam: 5179105576
  Particle: 4585154705
  Particle: 5812378274
  Particle: 4726930095
  Particle: 4685807388
  Particle: 3339563854
  Particle: 1946917526

=== Particle (İsimsiz) ===
  Particle: 1746829167
  Particle: 311395391

=== Dummy ===
  Particle: 6706234595

========================================
  KULLANIM: rbxassetid://ID_NUMARASI
  Örnek: rbxassetid://6954174382
========================================

```
