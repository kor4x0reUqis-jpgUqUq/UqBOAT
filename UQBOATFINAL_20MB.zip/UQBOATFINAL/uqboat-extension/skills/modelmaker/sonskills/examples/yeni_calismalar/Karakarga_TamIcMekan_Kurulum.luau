--[[
BABAAR YAPAR | KARAKARGA — FULL INTERIOR PIRATE SHIP
Paste the ENTIRE file into Roblox Studio Command Bar in EDIT mode.
Only a static ship. No sea, island, prompts, runtime scripts, sounds or mechanics.
Walkable cargo hold / lower gun deck / weather deck / captain cabin / quarterdeck.
Clearance targets: standard R6 and R15; broad doors, open stairs, high ceilings.
No external meshes. Studs use 2D textures, NOT individual 3D stud parts.
Actual Roblox avatar traversal must still be checked in Studio Play mode.
]]
local Config={
 ModelName="BabaarYapar_Karakarga_FullInterior",
 Origin=Vector3.new(0,0,0), -- keel baseline; put your sea at approximately Y=4
 StudTextures=true,
 StudSourceModelId=9454666962,
 StudImageOverride="", -- actual Texture/Decal image URI, if automatic resolution fails
 Tile=.85,
 TextureTransparency=.53,
 YieldEvery=220,
 FrameCamera=true,
 LanternLights=true,
}
local W = game:GetService("Workspace")
local History = game:GetService("ChangeHistoryService")
local Selection = game:GetService("Selection")
local Lighting = game:GetService("Lighting")
local V, CF, A = Vector3.new, CFrame.new, CFrame.Angles
local rad, sin, cos, pi = math.rad, math.sin, math.cos, math.pi
local O = Config.Origin
local P = {
 abyss=Color3.fromRGB(12,46,66), water=Color3.fromRGB(23,111,134),
 shallows=Color3.fromRGB(47,161,165), foam=Color3.fromRGB(165,224,212),
 sand=Color3.fromRGB(218,186,125), sandLight=Color3.fromRGB(241,213,157),
 sandDark=Color3.fromRGB(168,130,78), grass=Color3.fromRGB(78,126,81),
 grassLight=Color3.fromRGB(107,151,91), grassDark=Color3.fromRGB(48,86,65),
 rock=Color3.fromRGB(75,90,95), rockDark=Color3.fromRGB(46,61,70),
 rockLight=Color3.fromRGB(104,119,119), wood=Color3.fromRGB(103,62,37),
 woodLight=Color3.fromRGB(149,98,53), woodDark=Color3.fromRGB(53,34,28),
 plank=Color3.fromRGB(170,119,66), gold=Color3.fromRGB(203,151,71),
 goldLight=Color3.fromRGB(242,195,104), iron=Color3.fromRGB(34,41,48),
 ironLight=Color3.fromRGB(67,76,84), sail=Color3.fromRGB(30,34,45),
 sailLight=Color3.fromRGB(43,48,59), ivory=Color3.fromRGB(232,225,202),
 rope=Color3.fromRGB(166,128,77), glow=Color3.fromRGB(255,194,95),
 red=Color3.fromRGB(139,49,42), teal=Color3.fromRGB(40,119,117),
}
local counts={parts=0,textures=0,lights=0}
local root=Instance.new("Model")
root.Name=Config.ModelName
root:SetAttribute("Generator","BabaarYapar_Standalone_InteriorShip_2.0")
local function folder(name,parent)
 local f=Instance.new("Folder"); f.Name=name; f.Parent=parent or root; return f
end
local G={hull=folder("01_Hull_And_Keel"), floors=folder("02_Three_Walkable_Decks"), stairs=folder("03_Stairs_And_Safety_Rails"), cabins=folder("04_Cabins_And_Doors"), interior=folder("05_Full_Interior"), guns=folder("06_Cannons_And_Ports"), rig=folder("07_Masts_And_Rigging"), sails=folder("08_Billowed_Black_Sails"), trim=folder("09_Gold_Trim_And_Figurehead"), decor=folder("10_Deck_Equipment"), lights=folder("11_Lanterns")}
local function resolveImage()
 if not Config.StudTextures then return "" end
 if Config.StudImageOverride~="" then
  local s=tostring(Config.StudImageOverride)
  return tonumber(s) and "rbxassetid://"..s or s
 end
 local old=W:FindFirstChild(Config.ModelName)
 if old and old:GetAttribute("StudImage") and old:GetAttribute("StudImage")~="" then return old:GetAttribute("StudImage") end
 local image,score="",-1
 local function inspect(asset)
  local all={asset}; for _,d in ipairs(asset:GetDescendants()) do table.insert(all,d) end
  for _,d in ipairs(all) do if d:IsA("LuaSourceContainer") then d:Destroy() end end
  for _,d in ipairs(all) do
   local uri,s="",0
   if d:IsA("Texture") then uri,s=d.Texture,20 elseif d:IsA("Decal") then uri,s=d.Texture,10 end
   if string.find(string.lower(d.Name),"stud",1,true) then s+=30 end
   if uri~="" and uri~="rbxassetid://"..Config.StudSourceModelId and s>score then image,score=uri,s end
  end
  asset:Destroy()
 end
 local loaders={
  function() return game:GetObjects("rbxassetid://"..Config.StudSourceModelId) end,
  function() return {game:GetService("InsertService"):LoadAsset(Config.StudSourceModelId)} end,
 }
 for _,load in ipairs(loaders) do
  local ok,assets=pcall(load)
  if ok and type(assets)=="table" then for _,a in ipairs(assets) do inspect(a) end end
  if image~="" then break end
 end
 if image=="" then warn("[Karakarga Ship] Stud image could not be resolved. Set StudImageOverride to a Texture/Decal image URI. Geometry will still build; no 3D studs added.") end
 return image
end
local StudImage=resolveImage()
root:SetAttribute("StudImage",StudImage)
local function texture(p,faces,alpha,tile)
 if StudImage=="" then return end
 for _,face in ipairs(faces or {Enum.NormalId.Top,Enum.NormalId.Front,Enum.NormalId.Back}) do
  local t=Instance.new("Texture"); t.Name="Classic_Stud_Surface"; t.Texture=StudImage
  t.Face=face; t.Color3=p.Color; t.Transparency=alpha or Config.TextureTransparency
  t.StudsPerTileU=tile or Config.Tile; t.StudsPerTileV=tile or Config.Tile
  t.Parent=p; counts.textures+=1
 end
end
local function part(name,size,cf,color,parent,textured,mat,collide,class)
 assert(math.min(size.X,size.Y,size.Z)>0,"Invalid size: "..name)
 local p=Instance.new(class or "Part"); p.Name=name; p.Size=size; p.CFrame=CF(O)*cf
 p.Color=color; p.Material=mat or Enum.Material.Plastic; p.Anchored=true
 p.CanCollide=collide~=false; p.CanTouch=false; p.CanQuery=true
 p.TopSurface=Enum.SurfaceType.Smooth; p.BottomSurface=Enum.SurfaceType.Smooth
 p.CastShadow=true; p.Parent=parent or G.decor
 if textured then texture(p) end
 counts.parts+=1
 if counts.parts%Config.YieldEvery==0 then task.wait() end
 return p
end
local function beam(name,a,b,width,color,parent,textured,height)
 local d=b-a; if d.Magnitude<0.01 then return end
 local up=math.abs(d.Unit.Y)>0.98 and V(0,0,1) or V(0,1,0)
 return part(name,V(width,height or width,d.Magnitude+0.025),CFrame.lookAt((a+b)/2,b,up),color,parent,textured,nil,false)
end
local function triangle(name,a,b,c,thickness,color,parent,textured)
 local ab,ac,bc=b-a,c-a,c-b
 if ab:Dot(ab)>ac:Dot(ac) and ab:Dot(ab)>bc:Dot(bc) then a,c=c,a
 elseif ac:Dot(ac)>ab:Dot(ab) and ac:Dot(ac)>bc:Dot(bc) then a,b=b,a end
 ab,ac,bc=b-a,c-a,c-b
 local cr=ac:Cross(ab); if cr.Magnitude<0.0001 or bc.Magnitude<0.001 then return {} end
 local right,back=cr.Unit,bc.Unit; local up=back:Cross(right).Unit
 local h=math.abs(ab:Dot(up)); local l1,l2=math.abs(ab:Dot(back)),math.abs(ac:Dot(back))
 local out={}; if h<0.001 then return out end
 local function wedge(n,len,pos,r,u,k)
  if len<0.005 then return end
  local p=part(n,V(thickness,h,len),CFrame.fromMatrix(pos,r,u,k),color,parent,false,nil,false,"WedgePart")
  if textured then texture(p,{Enum.NormalId.Left,Enum.NormalId.Right},0.48) end
  table.insert(out,p)
 end
 wedge(name.."_A",l1,(a+b)/2,right,up,back)
 wedge(name.."_B",l2,(a+c)/2,-right,up,-back)
 return out
end
local function quad(name,a,b,c,d,t,color,parent,textured)
 triangle(name.."_1",a,b,c,t,color,parent,textured)
 triangle(name.."_2",a,c,d,t,color,parent,textured)
end
local function sign(name,cf,size,title,subtitle,parent)
 local p=part(name,size,cf,P.woodDark,parent,true)
 local gui=Instance.new("SurfaceGui"); gui.Name="Readable_Sign"; gui.Face=Enum.NormalId.Front
 gui.SizingMode=Enum.SurfaceGuiSizingMode.PixelsPerStud; gui.PixelsPerStud=55; gui.LightInfluence=0.3; gui.Parent=p
 local pad=Instance.new("UIPadding"); pad.PaddingLeft=UDim.new(0.05,0); pad.PaddingRight=UDim.new(0.05,0); pad.Parent=gui
 local text=Instance.new("TextLabel"); text.Size=UDim2.fromScale(1,0.61); text.BackgroundTransparency=1
 text.Font=Enum.Font.GothamBold; text.Text=title; text.TextColor3=P.goldLight; text.TextScaled=true; text.TextWrapped=true; text.Parent=gui
 local sub=Instance.new("TextLabel"); sub.Position=UDim2.fromScale(0,0.65); sub.Size=UDim2.fromScale(1,0.27)
 sub.BackgroundTransparency=1; sub.Font=Enum.Font.Gotham; sub.Text=subtitle; sub.TextColor3=P.ivory; sub.TextScaled=true; sub.Parent=gui
 return p
end
local function pointLight(p,brightness,range,color)
 if not Config.LanternLights then return end
 local l=Instance.new("PointLight"); l.Color=color or P.glow; l.Brightness=brightness; l.Range=range; l.Shadows=true; l.Parent=p; counts.lights+=1
end
local function lantern(name,cf,scale,parent,lit)
 local s=scale or 1
 part(name.."_Base",V(.82,.16,.82)*s,cf*CF(0,-.58*s,0),P.iron,parent,false)
 local glass=part(name.."_Warm_Core",V(.58,.91,.58)*s,cf,P.glow,parent,false,Enum.Material.Neon,false)
 glass.Transparency=.18
 for _,x in ipairs({-1,1}) do for _,z in ipairs({-1,1}) do
  part(name.."_Corner",V(.09,1.15,.09)*s,cf*CF(x*.36*s,0,z*.36*s),P.iron,parent,false,nil,false)
 end end
 part(name.."_Cap",V(.94,.18,.94)*s,cf*CF(0,.61*s,0),P.iron,parent,false)
 part(name.."_Gold_Edge",V(1,.08,1)*s,cf*CF(0,.75*s,0),P.gold,parent,false,nil,false)
 part(name.."_Handle",V(.1,.36,.1)*s,cf*CF(0,.98*s,0),P.iron,parent,false,nil,false)
 if lit then pointLight(glass,1.25,13*s) end
 return glass
end
local function barrel(name,cf,s,parent)
 s=s or 1
 for i=0,7 do
  local q=i*pi/4
  part(name.."_Stave_"..i,V(.54,1.75,.18)*s,cf*A(0,q,0)*CF(0,0,.60*s),i%2==0 and P.wood or P.woodLight,parent,true)
 end
 part(name.."_Lid",V(1.1,.12,1.1)*s,cf*CF(0,.88*s,0),P.woodLight,parent,true)
 for _,y in ipairs({-.58,.58}) do for i=0,7 do
  part(name.."_Hoop",V(.56,.12,.12)*s,cf*A(0,i*pi/4,0)*CF(0,y*s,.69*s),P.iron,parent,false)
 end end
end
local function crate(name,cf,s,parent)
 part(name.."_Box",V(1.65,1.65,1.65)*s,cf,P.wood,parent,true)
 for _,y in ipairs({-.65,.65}) do part(name.."_Band",V(1.78,.16,1.78)*s,cf*CF(0,y*s,0),P.woodLight,parent,false) end
 for _,x in ipairs({-.64,.64}) do part(name.."_Brace",V(.15,1.7,1.79)*s,cf*CF(x*s,0,0),P.gold,parent,false) end
end

-- Entire ship is in local map coordinates, translated once by Config.Origin.
local PROFILE={{-52,.35},{-48,3.6},{-42,7.6},{-34,11.8},{-24,14.8},{-10,16},{8,16},{26,15},{42,12.6},{49,10.7}}
local FLOOR={hold=3.0,lower=12.2,main=22.0,quarter=33.0}
local function halfWidth(z)
 for i=1,#PROFILE-1 do
  local a,b=PROFILE[i],PROFILE[i+1]
  if z>=a[1] and z<=b[1] then return a[2]+(b[2]-a[2])*(z-a[1])/(b[1]-a[1]) end
 end
 return z< -52 and .35 or 10.7
end
local function widthFactor(y)
 return .23+.77*(sin(math.clamp(y/22.5,0,1)*pi/2)^.82)
end
local function hullV(z,y,side) return V(side*halfWidth(z)*widthFactor(y),y,z) end
local function surface(name,a,b,c,d,t,col,parent,studs,collision)
 local all=triangle(name.."_a",a,b,c,t,col,parent,studs)
 local more=triangle(name.."_b",a,c,d,t,col,parent,studs)
 for _,p in ipairs(more) do table.insert(all,p) end
 for _,p in ipairs(all) do p.CanCollide=collision==true end
end
local function ring(name,cf,radius,thick,color,parent,n)
 n=n or 12
 for i=0,n-1 do
  local a,b=i*2*pi/n,(i+1)*2*pi/n
  beam(name,cf:PointToWorldSpace(V(cos(a)*radius,sin(a)*radius,0)),cf:PointToWorldSpace(V(cos(b)*radius,sin(b)*radius,0)),thick,color,parent,false)
 end
end
local function rail(name,a,b,parent)
 local n=math.max(1,math.ceil((b-a).Magnitude/3))
 for i=0,n do
  local p=a:Lerp(b,i/n)
  part(name.."_Baluster",V(.16,2.35,.16),CF(p+V(0,1.2,0)),P.woodDark,parent,false)
  part(name.."_PostCap",V(.28,.15,.28),CF(p+V(0,2.45,0)),P.gold,parent,false,nil,false)
 end
 local top=beam(name.."_Handrail",a+V(0,2.40,0),b+V(0,2.40,0),.25,P.woodLight,parent,true)
 if top then top.CanCollide=true end
 local mid
 if name~="Deck_Edge" then mid=beam(name.."_Safety_Midrail",a+V(0,1.2,0),b+V(0,1.2,0),.13,P.gold,parent,false) end
 if mid then mid.CanCollide=true end
end
local function floorDeck(name,y,zmin,zmax,factor,holes,parent)
 local dz=.84; local n=math.ceil((zmax-zmin)/dz); dz=(zmax-zmin)/n
 for i=0,n-1 do
  local z=zmin+(i+.5)*dz; local width=halfWidth(z)*factor
  local intervals={{-width,width}}
  for _,hole in ipairs(holes or {}) do
   if z+dz/2>hole.z0 and z-dz/2<hole.z1 then
    local nextIntervals={}
    for _,v in ipairs(intervals) do
     if hole.x0>v[1] then table.insert(nextIntervals,{v[1],math.min(v[2],hole.x0)}) end
     if hole.x1<v[2] then table.insert(nextIntervals,{math.max(v[1],hole.x1),v[2]}) end
    end
    intervals=nextIntervals
   end
  end
  for j,v in ipairs(intervals) do if v[2]-v[1]>.06 then
   local p=part(name.."_Plank_"..i.."_"..j,V(v[2]-v[1],.30,dz-.018),CF((v[1]+v[2])/2,y-.15,z),i%6==0 and P.woodLight or P.plank,parent,true)
   -- Nails are flat metal square accents, never 3D stud cylinders.
   if i%3==0 and v[2]-v[1]>2 then for _,x in ipairs({v[1]+.3,v[2]-.3}) do
    part(name.."_Square_Nail",V(.075,.018,.075),CF(x,y+.015,z),P.iron,parent,false,nil,false)
   end end
  end end
 end
end
local function stairs(name,x,z0,z1,y0,y1,width)
 local n=math.ceil((y1-y0)/.43); local rise=(y1-y0)/n; local run=(z1-z0)/n
 for i=0,n-1 do
  local y=y0+(i+1)*rise
  part(name.."_Tread_"..i,V(width,.20,run+.045),CF(x,y-.10,z0+(i+.5)*run),P.woodLight,G.stairs,true)
  part(name.."_Riser_"..i,V(width,rise,.12),CF(x,y-rise/2,z0+i*run),P.wood,G.stairs,false)
  part(name.."_Nosing_"..i,V(width+.03,.055,.10),CF(x,y+.02,z0+i*run+.06),P.gold,G.stairs,false,nil,false)
 end
 for _,side in ipairs({-1,1}) do
  local xx=x+side*(width/2+.08)
  beam(name.."_Stringer",V(xx,y0-.3,z0),V(xx,y1-.3,z1),.22,P.woodDark,G.stairs,true,.45)
  local nposts=5
  for i=0,nposts do
   local t=i/nposts
   part(name.."_Rail_Post",V(.15,2.1,.15),CF(xx,y0+(y1-y0)*t+1.05,z0+(z1-z0)*t),P.woodDark,G.stairs,false)
  end
  local r=beam(name.."_Sloping_Handrail",V(xx,y0+2.15,z0),V(xx,y1+2.15,z1),.18,P.gold,G.stairs,false)
  if r then r.CanCollide=true end
 end
end
local function portZs() return {-24,-16,-8,0,8,16} end
local function inPort(za,zb)
 for _,z in ipairs(portZs()) do if za<z+1.4 and zb>z-1.4 then return true end end
 return false
end
local function buildHull()
 -- Thin, outward-facing planking leaves the internal volume truly empty.
 local rows={0,1.2,2.5,3.8,5.2,6.6,8,9.4,10.8,12.2,13.6,14.6,16.2,17.8,19.2,20.7,22.5}
 for row=1,#rows-1 do
  local ya,yb=rows[row],rows[row+1]
  local t=(row-1)/(#rows-2)
  local color=P.woodDark:Lerp(P.woodLight,.15+.60*t)
  if row==8 or row==15 then color=P.gold:Lerp(P.wood,.25) end
  if row>=11 and row<=14 then color=P.iron:Lerp(P.wood,.16) end
  for i=0,100 do
   local za,zb=-52+i,-51+i
   for _,side in ipairs({-1,1}) do
    if not ((row==12 or row==13) and inPort(za,zb)) then
     surface("Hull_Strake_"..row.."_"..i.."_"..side,hullV(za,ya,side),hullV(zb,ya,side),hullV(zb,yb,side),hullV(za,yb,side),.18,color,G.hull,true,true)
    end
   end
  end
 end
 -- Transom has real openings where cabin windows will be, not luminous overlays on solid walls.
 for row=0,7 do
  local y0,y1=row*2.8,(row+1)*2.8
  surface("Lower_Transom",hullV(49,y0,-1),hullV(49,y0,1),hullV(49,y1,1),hullV(49,y1,-1),.20,row%3==0 and P.gold or P.wood,G.hull,true,true)
 end
 beam("Deep_Keel",V(0,.12,-49),V(0,.12,49),.65,P.woodDark,G.hull,true,.9)
 beam("Raked_Bow_Stem",V(0,.1,-50),V(0,25.2,-54),.7,P.woodDark,G.trim,true)
 -- Actual interior frames and knees follow the hull curvature.
 for z=-40,43,5 do
  for _,side in ipairs({-1,1}) do
   for k=0,5 do
    local y0,y1=2.2+k*3.25,2.2+(k+1)*3.25
    local a,b=hullV(z,y0,side),hullV(z,y1,side)
    a-=V(side*.24,0,0); b-=V(side*.24,0,0)
    beam("Interior_Curved_Rib",a,b,.22,P.woodDark,G.interior,true,.28)
   end
   local edge=halfWidth(z)*.94
   beam("Deck_Knee_Brace",V(side*(edge-.4),20.1,z),V(side*(edge-2),21.6,z),.25,P.woodDark,G.interior,true)
  end
  -- Underbeams are split at stair voids, never spanning an avatar's ascent.
  local lw=halfWidth(z)*.74
  if z>=-10 and z<=10.4 then
   beam("Lower_Underbeam_Port",V(-lw,11.55,z),V(2.25,11.55,z),.22,P.woodDark,G.interior,true,.38)
   if lw>7.45 then beam("Lower_Underbeam_Starboard",V(7.45,11.55,z),V(lw,11.55,z),.22,P.woodDark,G.interior,true,.38) end
  else beam("Lower_Deck_Underbeam",V(-lw,11.55,z),V(lw,11.55,z),.22,P.woodDark,G.interior,true,.38) end
  local mw=halfWidth(z)*.91
  if z>=-8 and z<=14 then
   if mw>11.3 then beam("Main_Underbeam_Port",V(-mw,21.4,z),V(-11.3,21.4,z),.23,P.woodDark,G.interior,true,.38) end
   beam("Main_Underbeam_Starboard",V(-4.7,21.4,z),V(mw,21.4,z),.23,P.woodDark,G.interior,true,.38)
  else beam("Main_Deck_Underbeam",V(-mw,21.4,z),V(mw,21.4,z),.23,P.woodDark,G.interior,true,.38) end
 end
 for _,side in ipairs({-1,1}) do
  for _,y in ipairs({8.0,19.2,22.6}) do
   for z=-48,46,2 do
    local a,b=hullV(z,y,side),hullV(z+2,y,side)
    beam("Continuous_Gold_Strake",a+V(side*.16,0,0),b+V(side*.16,0,0),.12,P.gold,G.trim,false)
   end
  end
 end
end
local function buildDecks()
 local mainHole={x0=-11.0,x1=-5.0,z0=-8.0,z1=14.0}
 local lowerHole={x0=2.5,x1=7.2,z0=-10.0,z1=10.4}
 floorDeck("Cargo_Hold",FLOOR.hold,-33,39,widthFactor(FLOOR.hold)-.035,{},G.floors)
 floorDeck("Lower_Gun_Deck",FLOOR.lower,-43,46,widthFactor(FLOOR.lower)-.035,{lowerHole},G.floors)
 floorDeck("Weather_Deck",FLOOR.main,-46,48,.96,{mainHole},G.floors)
 floorDeck("Quarterdeck",FLOOR.quarter,28,49,1.01,{},G.floors)
 -- Lower flight: 4 studs wide, ~0.42 stud rise; upper flight: 5 studs wide.
 stairs("Hold_To_GunDeck",4.85,-9.3,10.2,FLOOR.hold,FLOOR.lower,4)
 stairs("GunDeck_To_WeatherDeck",-8,-7.2,13.5,FLOOR.lower,FLOOR.main,5)
 stairs("WeatherDeck_To_Quarterdeck",11.5,6.2,28.0,FLOOR.main,FLOOR.quarter,4.6)
 -- Coamings and guardrails surround open stair wells, but not their landing mouths.
 rail("Main_Hatch_Port_Rail",V(-11.1,22,-8),V(-11.1,22,14),G.stairs)
 rail("Main_Hatch_Inner_Rail",V(-4.9,22,-8),V(-4.9,22,11.6),G.stairs)
 rail("Main_Hatch_Low_End",V(-11.1,22,-8),V(-4.9,22,-8),G.stairs)
 rail("Lower_Hatch_Outer_Rail",V(7.3,12.2,-10),V(7.3,12.2,10.4),G.stairs)
 rail("Lower_Hatch_Inner_Rail",V(2.4,12.2,-10),V(2.4,12.2,8),G.stairs)
 rail("Lower_Hatch_Low_End",V(2.4,12.2,-10),V(7.3,12.2,-10),G.stairs)
 -- Bordered opening lips are below rail level, not spanning any walking gap.
 for _,x in ipairs({-11.15,-4.85}) do part("Main_Hatch_Coaming",V(.18,.32,22.3),CF(x,22.08,3),P.woodDark,G.stairs,true) end
 for _,side in ipairs({-1,1}) do
  for z=-43,45,3 do
   local zz=math.min(z+3,48)
   local w,w2=halfWidth(z)*.985,halfWidth(zz)*.985
   local a,b=V(side*w,22,z),V(side*w2,22,zz)
   part("Solid_Bulwark",V(.32,1.45,3.03),CFrame.lookAt((a+b)/2+V(0,.7,0),b+V(0,.7,0)),P.iron,G.trim,true)
   rail("Deck_Edge",a+V(0,.45,0),b+V(0,.45,0),G.trim)
  end
 end
 -- Quarterdeck rail deliberately omits starboard stair arrival at z=28.
 rail("Quarterdeck_Port",V(-14.7,33,28),V(-10.8,33,49),G.trim)
 rail("Quarterdeck_Starboard",V(14.7,33,30.5),V(10.8,33,49),G.trim)
 rail("Quarterdeck_Aft",V(-10.8,33,49),V(10.8,33,49),G.trim)
 rail("Quarterdeck_Front",V(-14.7,33,28),V(8.7,33,28),G.trim)
end
-- Open doorway with stationary hinged leaves; no prompt or moving joint.
local function doorway(name,cf,wallWidth,wallHeight,openingWidth,parent,doorLeaves)
 local ow=openingWidth or 7.2; local oh=math.min(8.8,wallHeight-.45)
 local sideWidth=(wallWidth-ow)/2
 if sideWidth>.01 then for _,side in ipairs({-1,1}) do
  part(name.."_Wall",V(sideWidth,wallHeight,.28),cf*CF(side*(ow/2+sideWidth/2),wallHeight/2,0),P.wood,parent,true)
 end end
 if wallHeight>oh then part(name.."_Lintel_Wall",V(ow,wallHeight-oh,.28),cf*CF(0,oh+(wallHeight-oh)/2,0),P.wood,parent,true) end
 for _,side in ipairs({-1,1}) do
  part(name.."_Door_Jamb",V(.18,oh+.3,.43),cf*CF(side*(ow/2+.07),oh/2,0),P.gold,parent,true)
 end
 part(name.."_Gold_Lintel",V(ow+.45,.22,.46),cf*CF(0,oh+.16,0),P.goldLight,parent,true)
 if doorLeaves then
  local leafWidth=ow/2-.15
  for _,side in ipairs({-1,1}) do
   local hinge=cf*CF(side*(ow/2),0,0)*A(0,side*rad(100),0)
   local leaf=hinge*CF(-side*leafWidth/2,oh/2-.08,0)
   part(name.."_Fixed_Open_Leaf",V(leafWidth,oh-.18,.22),leaf,P.woodDark,parent,true)
   for _,y in ipairs({-2.6,2.6}) do part(name.."_Door_Strap",V(leafWidth+.05,.18,.30),leaf*CF(0,y,0),P.iron,parent,false) end
   for i=1,3 do part(name.."_Door_Plank_Seam",V(.045,oh-.4,.025),leaf*CF(-leafWidth/2+i*leafWidth/4,0,-.13),P.wood,parent,false,nil,false) end
   ring(name.."_Door_Handle",leaf*CF(-side*leafWidth*.27,-.05,-.19),.19,.055,P.gold,parent,8)
  end
 end
end
local function window(name,cf,w,h,parent)
 -- Clear glass allows a real view through cabin shell. Neon is restricted to the sill lamp.
 local pane=part(name.."_Transparent_Glass",V(w,h,.065),cf,P.shallows,parent,false,Enum.Material.Glass,false)
 pane.Transparency=.78; pane.Reflectance=.08; pane.CanCollide=true
 for _,x in ipairs({-w/2,0,w/2}) do part(name.."_Vertical_Frame",V(.13,h+.22,.17),cf*CF(x,0,0),P.gold,parent,false) end
 for _,y in ipairs({-h/2,0,h/2}) do part(name.."_Cross_Frame",V(w+.22,.13,.17),cf*CF(0,y,0),P.gold,parent,false) end
end
local function bed(name,cf,parent)
 part(name.."_Frame",V(3.8,.55,6.4),cf*CF(0,.65,0),P.woodDark,parent,true)
 part(name.."_Mattress",V(3.5,.35,6),cf*CF(0,1.08,0),P.ivory,parent,true)
 part(name.."_Blanket",V(3.55,.10,4.2),cf*CF(0,1.30,.85),P.teal,parent,true)
 part(name.."_Pillow",V(2.7,.24,1.2),cf*CF(0,1.37,-2.0),P.ivory,parent,true)
 for _,x in ipairs({-1.6,1.6}) do for _,z in ipairs({-2.8,2.8}) do part(name.."_Post",V(.22,1.9,.22),cf*CF(x,.95,z),P.wood,parent,true) end end
 part(name.."_Headboard",V(3.5,1.1,.18),cf*CF(0,1.3,-3),P.woodLight,parent,true)
end
local function tableModel(name,cf,w,d,parent)
 part(name.."_Top",V(w,.25,d),cf*CF(0,2.5,0),P.woodLight,parent,true)
 for _,x in ipairs({-w/2+.35,w/2-.35}) do for _,z in ipairs({-d/2+.35,d/2-.35}) do
  part(name.."_Leg",V(.28,2.4,.28),cf*CF(x,1.2,z),P.woodDark,parent,true)
 end end
end
local function chair(name,cf,parent)
 part(name.."_Seat",V(1.7,.18,1.7),cf*CF(0,1.45,0),P.woodLight,parent,true)
 for _,x in ipairs({-.65,.65}) do for _,z in ipairs({-.65,.65}) do part(name.."_Leg",V(.16,1.45,.16),cf*CF(x,.72,z),P.woodDark,parent,true) end end
 part(name.."_Back",V(1.7,1.5,.16),cf*CF(0,2.25,.72),P.wood,parent,true)
end
local function shelf(name,cf,parent)
 for _,x in ipairs({-2,2}) do part(name.."_Upright",V(.18,5.8,1.6),cf*CF(x,2.9,0),P.woodDark,parent,true) end
 for y=.4,5.4,1.65 do part(name.."_Shelf",V(4.1,.17,1.7),cf*CF(0,y,0),P.woodLight,parent,true) end
 for i=0,8 do
  part(name.."_Book",V(.18+(i%2)*.08,1.2+(i%3)*.15,.72),cf*CF(-1.7+(i%5)*.65,1.12+math.floor(i/5)*1.65,-.1),i%3==0 and P.red or (i%3==1 and P.teal or P.ivory),parent,false)
 end
end

local function chest(name,cf,s,parent,open)
 part(name.."_Body",V(2.4,1.3,1.5)*s,cf,P.wood,parent,true)
 for _,x in ipairs({-.9,.9}) do part(name.."_GoldBand",V(.14,1.4,1.58)*s,cf*CF(x*s,0,0),P.gold,parent,false) end
 local lid=cf*CF(0,.75*s,.58*s)*A(rad(open and -48 or 0),0,0)*CF(0,0,-.58*s)
 part(name.."_Lid",V(2.5,.42,1.58)*s,lid,P.woodLight,parent,true)
 part(name.."_Latch",V(.35,.45,.12)*s,cf*CF(0,.25*s,-.82*s),P.goldLight,parent,false)
 if open then
  for i=0,14 do
   part(name.."_Coin",V(.33,.08,.33)*s,cf*CF(((i*7)%9-4)*.2*s,.72*s+(i%3)*.07,((i*5)%7-3)*.15*s)*A(0,i,0),P.goldLight,parent,false,nil,false)
  end
 end
end

local function buildCabinsAndInterior()
 -- Captain's cabin: 20.4 studs clear width, 10.7 studs wall height.
 doorway("Captain_Double_Door",CF(0,22,29),20.4,10.7,8.2,G.cabins,true)
 for _,side in ipairs({-1,1}) do
  local x=side*10.2
  part("Cabin_Side_Lower",V(.24,2.5,20),CF(x,23.25,39),P.wood,G.cabins,true)
  part("Cabin_Side_Upper",V(.24,3.2,20),CF(x,31.1,39),P.wood,G.cabins,true)
  for _,z in ipairs({30,36,42,48}) do part("Cabin_Side_Pier",V(.24,5,2),CF(x,27,z),P.wood,G.cabins,true) end
  for _,z in ipairs({33,39,45}) do window("Gallery_Side_Window",CF(x,27,z)*A(0,-side*pi/2,0),4,5,G.cabins) end
  for _,y in ipairs({22.2,24.5,29.5,32.6}) do part("Cabin_Side_Gilt_Trim",V(.40,.15,20.4),CF(x,y,39),P.gold,G.trim,true) end
 end
 part("Cabin_Stern_Lower",V(20.4,2.5,.25),CF(0,23.25,49),P.wood,G.cabins,true)
 part("Cabin_Stern_Upper",V(20.4,3.2,.25),CF(0,31.1,49),P.wood,G.cabins,true)
 for i=0,5 do part("Stern_Window_Pier",V(.30,5,.32),CF(-10.2+i*4.08,27,49),P.woodDark,G.cabins,true) end
 for i=0,4 do window("Five_Light_Stern_Gallery",CF(-8.16+i*4.08,27,49),3.76,5,G.cabins) end
 for _,y in ipairs({22.2,24.5,29.5,32.7}) do part("Stern_Gold_Cornice",V(21.4,.18,.46),CF(0,y,49.15),P.goldLight,G.trim,true) end
 -- Ceiling is built from discrete beams under the quarterdeck; lowest face above 32.
 for z=30,48,3 do part("Captain_Ceiling_Beam",V(20.2,.3,.28),CF(0,32.5,z),P.woodDark,G.cabins,true) end
 -- Real furniture, placed beside the central passage, not filling the doorway.
 bed("Captain_Bed",CF(-6.3,22,43),G.interior)
 part("Captain_Rug",V(6,.035,7.5),CF(0,22.035,39),P.red,G.interior,false,nil,false)
 for _,x in ipairs({-2.8,2.8}) do part("Rug_Border",V(.12,.04,7.1),CF(x,22.06,39),P.gold,G.interior,false,nil,false) end
 tableModel("Navigation_Desk",CF(5.7,22,43),6.3,3.0,G.interior)
 chair("Captain_Chair",CF(5.7,22,45.3)*A(0,pi,0),G.interior)
 local map=part("Navigation_Parchment",V(3.8,.025,2.0),CF(5.5,24.65,42.8)*A(0,rad(8),0),P.ivory,G.interior,false,nil,false)
 for i=0,10 do part("Chart_Dotted_Route",V(.13,.022,.08),CF(4.1+i*.25,24.68,42.8+sin(i*.8)*.45),P.red,G.interior,false,nil,false) end
 ring("Desk_Compass",CF(7.5,24.69,42.6)*A(pi/2,0,0),.29,.05,P.gold,G.interior,10)
 shelf("Captain_Bookcase",CF(-7.6,22,33.7)*A(0,pi/2,0),G.interior)
 chest("Captain_Strongbox",CF(-6.8,22.7,37),.85,G.interior,false)
 for _,x in ipairs({-8,8}) do lantern("Captain_Cabin_Lamp",CF(x,29.6,47.7),.8,G.lights,true) end
 sign("Captain_Entry_Plaque",CF(0,31.7,28.76),V(7.2,.85,.10),"KAPTAN KAMARASI","",G.cabins)
 -- Crew quarters, down one full level; doors retain at least 8 studs clear width.
 doorway("Crew_Quarters_Open_Door",CF(0,12.2,24),halfWidth(24)*widthFactor(12.2)*1.90,9.45,8.0,G.cabins,true)
 for _,side in ipairs({-1,1}) do
  for _,z in ipairs({30.5,39}) do
   local x=side*(halfWidth(z)*widthFactor(12.2)-2.65)
   bed("Crew_Lower_Bunk",CF(x,12.2,z),G.interior)
   bed("Crew_Upper_Bunk",CF(x,16.1,z),G.interior)
   for _,dx in ipairs({-1.7,1.7}) do
    for _,dz in ipairs({-2.9,2.9}) do part("Bunk_Stanchion",V(.18,6.0,.18),CF(x+dx,15.2,z+dz),P.woodDark,G.interior,true) end
   end
   for j=0,5 do part("Bunk_Ladder_Rung",V(1.2,.12,.16),CF(x-side*1.5,12.6+j*.62,z-3),P.woodLight,G.interior,false) end
  end
 end
 tableModel("Crew_Mess_Table",CF(0,12.2,34.5),4,7.8,G.interior)
 for _,side in ipairs({-1,1}) do
  part("Mess_Bench",V(.85,.22,7),CF(side*3,13.65,34.5),P.woodLight,G.interior,true)
  for _,z in ipairs({32,37}) do part("Mess_Bench_Leg",V(.5,1.35,.25),CF(side*3,12.9,z),P.woodDark,G.interior,true) end
 end
 shelf("Crew_Locker_Shelf",CF(0,12.2,44.7)*A(0,pi,0),G.interior)
 sign("Crew_Plaque",CF(0,21.3,23.76),V(6,.6,.10),"MÜRETTEBAT GÜVERTESİ","",G.cabins)
 -- Forward galley: walls split around the doorway; no solid collision sheet across the opening.
 doorway("Galley_Doorway",CF(0,12.2,-27)*A(0,pi,0),halfWidth(-27)*widthFactor(12.2)*1.90,9.45,7.4,G.cabins,false)
 part("Galley_Stove",V(3.4,2.7,3),CF(-5.6,13.55,-34),P.iron,G.interior,true)
 part("Stove_Top",V(3.6,.18,3.2),CF(-5.6,15.02,-34),P.ironLight,G.interior,false)
 for _,x in ipairs({-6.4,-4.9}) do ring("Stove_Burner",CF(x,15.14,-34)*A(pi/2,0,0),.43,.09,P.iron,G.interior,10) end
 part("Stove_Firebox",V(1.5,1.1,.08),CF(-5.6,13.5,-32.45),P.woodDark,G.interior,false)
 for x=-6.2,-5.0,.3 do part("Stove_Grate",V(.08,1.1,.08),CF(x,13.5,-32.37),P.ironLight,G.interior,false) end
 beam("Galley_Chimney",V(-5.6,15.1,-34.7),V(-5.6,21.5,-34.7),.55,P.iron,G.interior,false)
 tableModel("Galley_Workbench",CF(5.1,12.2,-34),3,6,G.interior)
 part("Chopping_Block",V(1.9,.12,1.2),CF(5.1,14.9,-34),P.sandDark,G.interior,true)
 for i=0,2 do barrel("Galley_Provision_Barrel",CF(-1.8+i*2.1,13.1,-39),.85,G.interior) end
 for i=0,3 do part("Galley_Sack",V(1.2,1.5,1.2),CF(3.5+(i%2)*1.4,13,-38.5+math.floor(i/2)*1.5)*A(0,i*.7,rad(3)),P.sand,G.interior,true) end
 sign("Galley_Plaque",CF(0,21.3,-26.76)*A(0,pi,0),V(5,.6,.10),"KUZİNE & ERZAK","",G.cabins)
 -- Cargo hold: large empty central lane, port supply racks, aft powder stores.
 for _,z in ipairs({-24,-18,-12,17,23,29}) do
  local x=-halfWidth(z)*widthFactor(3)+1.3
  crate("Hold_Cargo_Crate",CF(x,3.9,z)*A(0,rad(z%7),0),.9,G.interior)
  if z%3==0 then crate("Hold_Stacked_Crate",CF(x,5.45,z),.78,G.interior) end
 end
 for _,z in ipairs({-23,-17,19,25,31}) do
  local x=halfWidth(z)*widthFactor(3)-1.0
  barrel("Hold_Water_Barrel",CF(x,3.9,z),.80,G.interior)
 end
 -- Partition at aft end has a broad open gate, never a blocked textured door.
 doorway("Powder_Store_Door",CF(0,3,32),halfWidth(32)*(widthFactor(3)-.03)*2,8.4,6.4,G.cabins,false)
 for i=0,3 do crate("Powder_Chest",CF(-3+i*1.9,3.7,36),.75,G.interior) end
 for _,z in ipairs({-25,-9,8,25,39}) do
  local x=halfWidth(z)*widthFactor(11.8)-.7
  lantern("Lower_Deck_Lantern",CF(-x,19.5,z),.65,G.lights,z==-9 or z==25)
  lantern("Hold_Lantern",CF(-2.2,9.8,z),.50,G.lights,z==-9 or z==25)
 end
 lantern("Galley_Lantern",CF(0,19.8,-34),.65,G.lights,true)
end
local function cannon(name,z,side,mainDeck)
 local y=mainDeck and 24.1 or 16.15
 local x=mainDeck and halfWidth(z)*.94 or halfWidth(z)*widthFactor(y)
 local cf=CF(side*x,y,z)*A(0,-side*pi/2,0)
 -- Outside -> barrel points along local -Z. Inside -> breech and carriage at +Z.
 local radius=mainDeck and .54 or .66
 for i=0,9 do
  local a=i*2*pi/10
  part(name.."_Barrel_Facet",V(radius*.66,.16,4.4),cf*CF(cos(a)*radius,sin(a)*radius,.10)*A(0,0,a-pi/2),P.iron,G.guns,false,nil,false)
  for _,zz in ipairs({-2.0,-.5,1.4}) do part(name.."_Metal_Band",V(radius*.71,.13,.15),cf*CF(cos(a)*(radius+.08),sin(a)*(radius+.08),zz)*A(0,0,a-pi/2),P.ironLight,G.guns,false,nil,false) end
 end
 part(name.."_Dark_Bore",V(radius*1.3,radius*1.3,.05),cf*CF(0,0,-1.5),Color3.fromRGB(6,8,11),G.guns,false,nil,false)
 part(name.."_Breech",V(radius*1.55,radius*1.55,.38),cf*CF(0,0,2.2),P.iron,G.guns,false,nil,false)
 part(name.."_Breech_Knob",V(.35,.35,.4),cf*CF(0,0,2.6),P.ironLight,G.guns,false,nil,false)
 local floor=mainDeck and 22 or 12.2
 local cartX=side*(halfWidth(z)*widthFactor(floor)-1.7)
 part(name.."_Carriage",V(2.6,.65,3.4),CF(cartX,floor+.8,z),P.wood,G.guns,true)
 for _,dx in ipairs({-1.2,1.2}) do for _,dz in ipairs({-1.1,1.1}) do
  -- Wheels are polygonal static detail, not functional moving constraints.
  local wc=CF(cartX+dx,floor+.6,z+dz)*A(0,pi/2,0)
  ring(name.."_Wheel_Rim",wc,.45,.15,P.woodDark,G.guns,8)
  part(name.."_Wheel_Hub",V(.20,.30,.30),CF(cartX+dx,floor+.6,z+dz),P.gold,G.guns,false,nil,false)
 end end
 if not mainDeck then
  for _,xx in ipairs({-2.0,2.0}) do part(name.."_Port_Jamb",V(.18,3.7,.4),cf*CF(xx,0,0),P.gold,G.guns,true) end
  for _,yy in ipairs({-1.85,1.85}) do part(name.."_Port_Sill",V(4.2,.18,.45),cf*CF(0,yy,0),P.gold,G.guns,true) end
  -- Raised lid, open from both outside and inside.
  part(name.."_Raised_Port_Lid",V(4.0,.18,3.4),cf*CF(0,2.3,-1.5)*A(rad(-15),0,0),P.wood,G.guns,true,nil,false)
 end
 -- Breeching ropes stay beside the cart, never across the central walkway.
 for _,q in ipairs({-1,1}) do
  beam(name.."_Breeching_Rope",cf:PointToWorldSpace(V(q*1.7,-1.1,.2)),V(cartX,floor+.8,z+q*1.8),.075,P.rope,G.guns,false)
 end
end
local function buildGuns()
 for _,side in ipairs({-1,1}) do
  for _,z in ipairs(portZs()) do cannon("Lower_Battery",z,side,false) end
  for _,z in ipairs({-31,-21,-12,0,19}) do
   -- Upper battery leaves all three stair flights free.
   cannon("Weather_Deck_Gun",z,side,true)
  end
 end
end

local function skull(cf,scale,parent)
 -- All markings are actual low-relief rectangular parts; no skull image dependency.
 local function piece(n,size,offset,color)
  return part("JollyRoger_"..n,size*scale,cf*CF(offset*scale),color,parent,false,nil,false)
 end
 piece("Cranium",V(1.22,1.05,.075),V(0,.44,0),P.ivory)
 piece("Temple",V(1.55,.60,.08),V(0,.48,0),P.ivory)
 piece("Jaw",V(.83,.54,.085),V(0,-.22,-.005),P.ivory)
 piece("LeftEye",V(.34,.34,.11),V(-.37,.45,-.075),P.sail)
 piece("RightEye",V(.34,.34,.11),V(.37,.45,-.075),P.sail)
 piece("Nose",V(.19,.25,.12),V(0,.09,-.08),P.sail)
 for k=-1,1 do piece("ToothGap",V(.065,.21,.12),V(k*.22,-.42,-.08),P.sail) end
 for _,side in ipairs({-1,1}) do
  part("Crossbones",V(2.65,.18,.07)*scale,cf*CF(0,-1.02*scale,0)*A(0,0,side*rad(28)),P.ivory,parent,false,nil,false)
  for _,x in ipairs({-1,1}) do
   local t=cf*CF(0,-1.02*scale,0)*A(0,0,side*rad(28))*CF(x*1.22*scale,0,0)
   part("Bone_End",V(.28,.4,.085)*scale,t,P.ivory,parent,false,nil,false)
  end
 end
end
local function sail(name,z,bottom,top,halfWidth,emblem)
 local rows,cols=10,14
 local height=top-bottom
 local function vertex(u,v)
  local w=halfWidth*(1-.22*v)
  return V((u*2-1)*w,bottom+v*height-.40*sin(u*pi)*(1-v),z-.25-2.8*sin(u*pi)*sin(v*pi))
 end
 for r=0,rows-1 do for c=0,cols-1 do
  local u0,u1=c/cols,(c+1)/cols; local v0,v1=r/rows,(r+1)/rows
  local col=P.sail:Lerp(P.sailLight,.12+.40*sin(v0*pi)+.08*((r+c)%2))
  surface(name.."_Cloth_"..r.."_"..c,vertex(u0,v0),vertex(u1,v0),vertex(u1,v1),vertex(u0,v1),.08,col,G.sails,true)
 end end
 -- Slightly raised hems and subtle gold-brown stitch seams.
 for _,u in ipairs({0,1}) do for i=0,6 do beam(name.."_Side_Hem",vertex(u,i/7),vertex(u,(i+1)/7),.10,P.ironLight,G.sails,false) end end
 for i=0,9 do beam(name.."_Foot_Hem",vertex(i/10,0),vertex((i+1)/10,0),.10,P.ironLight,G.sails,false) end
 for c=1,4 do for r=0,5 do
  local a=vertex(c/5,r/6); local b=vertex(c/5,(r+1)/6)
  beam(name.."_Panel_Seam",a+V(0,0,-.08),b+V(0,0,-.08),.026,P.ironLight,G.sails,false)
 end end
 if emblem then skull(CF(0,bottom+height*.56,z-3.15),2.0,G.sails); skull(CF(0,bottom+height*.56,z+.13)*A(0,pi,0),2.0,G.sails) end
 beam(name.."_Lower_Yard",V(-halfWidth-.65,bottom,z),V(halfWidth+.65,bottom,z),.38,P.woodLight,G.rig,true)
 beam(name.."_Upper_Yard",V(-halfWidth*.80-.65,top,z),V(halfWidth*.80+.65,top,z),.38,P.woodLight,G.rig,true)
 for _,x in ipairs({-1,1}) do
  beam(name.."_Sheet",V(x*halfWidth,bottom,z),V(x*12.8,24,z+4.5),.065,P.rope,G.rig,false)
 end
end
local function mast(name,z,height)
 beam(name.."_Main_Spar",V(0,22,z),V(0,height,z),.72,P.wood,G.rig,true)
 beam(name.."_Highlight",V(-.23,22.5,z-.12),V(-.23,height-.4,z-.12),.08,P.gold,G.rig,false)
 for y=24,height-1,3.1 do
  part(name.."_Mast_Collar",V(.73,.16,.73),CF(0,y,z),P.iron,G.rig,false)
 end
 local nest=height-7.5
 for k=0,7 do
  local a=k*pi/4
  part(name.."_Nest_Floor",V(1.45,.23,1.35),CF(cos(a)*.8,nest,sin(a)*.8+z)*A(0,-a,0),P.woodLight,G.rig,true)
  part(name.."_Nest_Rail",V(1.07,.7,.15),CF(cos(a)*1.6,nest+.6,sin(a)*1.6+z)*A(0,-a+pi/2,0),P.wood,G.rig,true)
  part(name.."_Nest_Trim",V(1.20,.12,.21),CF(cos(a)*1.64,nest+1,sin(a)*1.64+z)*A(0,-a+pi/2,0),P.gold,G.rig,false)
 end
 for _,side in ipairs({-1,1}) do
  for j=0,2 do
   local low=V(side*(halfWidth(z)-.4),24.0,z-2+j*2)
   local high=V(side*.5,nest+.7,z)
   beam(name.."_Shroud",low,high,.065,P.rope,G.rig,false)
  end
  for k=0,26 do
   local t=k/27
   local a=V(side*(halfWidth(z)-.4),24.0,z-2):Lerp(V(side*.5,nest+.7,z),t)
   local b=V(side*(halfWidth(z)-.4),24.0,z+2):Lerp(V(side*.5,nest+.7,z),t)
   beam(name.."_Ratline",a,b,.055,P.rope,G.rig,false)
  end
 end
 -- Flag is segmented, with a visible wind bend; no hidden image required.
 for i=0,5 do
  part(name.."_Flag_Cloth",V(.55,1.85,.065),CF(.48+i*.52,height-.7,z+sin(i*.6)*.22),P.sail,G.sails,true,nil,false)
 end
 skull(CF(1.75,height-.65,z-.22),.78,G.sails)
end

local function buildRig()
 mast("Foremast",-24,57)
 mast("Mainmast",0,64)
 mast("Mizzenmast",35,56)
 sail("Fore_Course",-24,30.7,43,10.1,true)
 sail("Fore_Topsail",-24,44.4,49.8,7.7,false)
 sail("Main_Course",0,31.0,47,11.3,true)
 sail("Main_Topsail",0,48.5,56.3,8.4,false)
 sail("Mizzen_Black_Course",35,41.0,48.2,6.7,false)
 beam("Bowsprit_Main",V(0,24,-44),V(0,32.2,-73),.72,P.woodLight,G.rig,true)
 beam("Bowsprit_Highlight",V(-.32,24.3,-44),V(-.32,32.5,-73),.09,P.gold,G.rig,false)
 for i=0,11 do
  local t=i/12; local p=V(0,24,-44):Lerp(V(0,32.2,-73),t)
  part("Bowsprit_Binding",V(.92,.18,.92),CF(p)*A(rad(-16),0,0),P.iron,G.rig,false)
 end
 triangle("Forward_Jib",V(0,32,-71),V(0,53.5,-24),V(0,33.5,-28),.09,P.sail,G.sails,true)
 triangle("Upper_Staysail",V(0,40,-46),V(0,54,-24),V(0,43,-26),.09,P.sailLight,G.sails,true)
 beam("Forestay",V(0,32.4,-73),V(0,56.5,-24),.085,P.rope,G.rig,false)
 beam("Fore_To_Main_Stay",V(0,56,-24),V(0,63,0),.08,P.rope,G.rig,false)
 beam("Main_To_Mizzen_Stay",V(0,63,0),V(0,55,35),.08,P.rope,G.rig,false)
 beam("Stern_Backstay",V(0,55,35),V(0,36,49),.08,P.rope,G.rig,false)
 for _,side in ipairs({-1,1}) do
  beam("Bow_Downstay",V(side*.6,7,-49),V(0,32,-73),.08,P.rope,G.rig,false)
  beam("Bowsprit_Side_Stay",V(side*7.6,24,-42),V(0,32,-72),.08,P.rope,G.rig,false)
 end
 -- Belaying pin racks and organised rope coils remain near the bulwarks.
 for _,z in ipairs({-25,1,34}) do for _,side in ipairs({-1,1}) do
  local x=side*(halfWidth(z)-2.0)
  part("Belaying_Pin_Rack",V(1.15,.18,4.5),CF(x,24,z),P.woodLight,G.decor,true)
  for i=0,5 do part("Belaying_Pin",V(.13,.7,.13),CF(x,24.2,z-1.8+i*.65),P.gold,G.decor,false) end
  for j=0,2 do
   ring("Coiled_Rope",CF(x-side*.9,22.10,z-1+j*.8)*A(pi/2,0,0),.36,.065,P.rope,G.decor,10)
  end
 end end
end
local function anchor(name,x,z)
 beam(name.."_Shank",V(x,21,z),V(x,12,z-.4),.32,P.iron,G.trim,false)
 beam(name.."_Stock",V(x-1.8,19.3,z),V(x+1.8,19.3,z),.34,P.woodDark,G.trim,true)
 for _,side in ipairs({-1,1}) do
  beam(name.."_Arm",V(x,12,z-.4),V(x+side*1.5,13.0,z-.4),.32,P.iron,G.trim,false)
  part(name.."_Fluke",V(.7,.75,.18),CF(x+side*1.6,13.15,z-.4)*A(0,0,side*rad(-30)),P.ironLight,G.trim,false,nil,false)
 end
 ring(name.."_Eye",CF(x,21.5,z),.48,.14,P.iron,G.trim,10)
 for j=0,5 do
  ring(name.."_Chain_Link",CF(x,22.1+j*.38,z)*A(0,(j%2)*pi/2,0),.20,.07,P.iron,G.trim,8)
 end
end
local function buildDecorations()
 -- Black-crow figurehead, made from bevel-like layered blocks and swept feathers.
 part("Crow_Figurehead_Torso",V(1.7,3.2,2.0),CF(0,21.3,-54)*A(rad(-18),0,0),P.gold,G.trim,true)
 part("Crow_Figurehead_Head",V(1.5,1.6,1.7),CF(0,23.5,-55),P.goldLight,G.trim,true)
 part("Crow_Hooked_Beak",V(.9,.55,1.7),CF(0,23.2,-56.4)*A(rad(18),0,0),P.gold,G.trim,false)
 for _,side in ipairs({-1,1}) do
  part("Crow_Dark_Eye",V(.08,.28,.35),CF(side*.79,23.8,-55.4),P.iron,G.trim,false)
  for i=1,7 do
   beam("Crow_Wing_Feather",V(side*.8,22.5,-53.8),V(side*(1.7+i*.46),23+i*.36,-52+i*.48),.32,P.gold,G.trim,true,.52)
  end
  for z=-47,-36,2 do
   beam("Gold_Bow_Scroll",V(side*halfWidth(z)*.98,20.5,z),V(side*halfWidth(z+2)*.98,21.0,z+2),.28,P.gold,G.trim,true)
  end
 end
 anchor("Port_Anchor",-8.8,-40); anchor("Starboard_Anchor",8.8,-40)
 -- Foredeck capstan and windlass, static and explicitly non-functional.
 part("Capstan_Base",V(2.9,.35,2.9),CF(0,22.2,-39),P.woodDark,G.decor,true)
 part("Capstan_Drum",V(1.5,2.0,1.5),CF(0,23.25,-39),P.wood,G.decor,true)
 for _,a in ipairs({0,pi/2}) do part("Capstan_Cross_Handle",V(5.6,.18,.25),CF(0,24.4,-39)*A(0,a,0),P.woodLight,G.decor,false) end
 for i=0,7 do local a=i*pi/4
  part("Capstan_Collar",V(.65,.16,.15),CF(cos(a)*.83,23.9,-39+sin(a)*.83)*A(0,-a+pi/2,0),P.iron,G.decor,false)
 end
 -- Quarterdeck helm, spokes and handles.
 part("Helm_Stand",V(.65,2.9,.85),CF(0,34.5,31),P.woodDark,G.decor,true)
 ring("Helm_Wheel",CF(0,36.1,30.6),1.55,.19,P.woodLight,G.decor,14)
 for i=0,9 do local a=i*pi/5
  beam("Helm_Spoke",V(0,36.1,30.6),V(cos(a)*1.98,36.1+sin(a)*1.98,30.6),.13,P.gold,G.decor,false)
 end
 part("Helm_Hub",V(.5,.5,.35),CF(0,36.1,30.6),P.iron,G.decor,false)
 -- Binnacle, lid and compass rose.
 part("Binnacle_Cabinet",V(2.3,2.8,1.7),CF(-4.7,34.4,31.8),P.wood,G.decor,true)
 part("Binnacle_Top",V(2.5,.16,1.9),CF(-4.7,35.85,31.8),P.gold,G.decor,true)
 ring("Binnacle_Compass_Ring",CF(-4.7,35.97,31.8)*A(pi/2,0,0),.64,.08,P.goldLight,G.decor,12)
 part("Compass_Needle",V(.09,.04,1),CF(-4.7,36.01,31.8)*A(0,rad(25),0),P.red,G.decor,false,nil,false)
 -- Bell supported by a timber arch. Its shape is built from layered sections.
 for _,x in ipairs({-1,1}) do part("Bell_Post",V(.24,3.3,.24),CF(x,23.65,-31),P.woodDark,G.decor,true) end
 part("Bell_Crossbar",V(2.5,.24,.3),CF(0,25.3,-31),P.woodLight,G.decor,true)
 for i=0,3 do part("Bell_Tier",V(.5+i*.2,.22,.5+i*.2),CF(0,24.7-i*.21,-31),P.gold,G.decor,false) end
 beam("Bell_Pull_Rope",V(0,24,-31),V(0,22.8,-31),.07,P.rope,G.decor,false)
 -- Aft balcony ornament, nameplate, fixed lantern brackets and rudder.
 sign("Karakarga_Nameplate",CF(0,31.4,49.4)*A(0,pi,0),V(12,1.3,.20),"KARAKARGA","",G.trim)
 for _,side in ipairs({-1,1}) do
  for i=0,6 do
   part("Stern_Gallery_Bracket",V(.55,.45,1.5),CF(side*(8.4-i*.24),23.0-i*.55,49.3)*A(rad(-12),0,side*rad(18)),P.gold,G.trim,true)
  end
  lantern("Grand_Stern_Lantern",CF(side*9.6,35.5,47.7),1.1,G.lights,true)
  lantern("Fore_Deck_Lantern",CF(side*8.8,25,-35),.80,G.lights,true)
 end
 part("Rudder_Blade",V(.5,10.8,3.2),CF(0,6.9,50.6)*A(rad(-8),0,0),P.woodDark,G.trim,true)
 for _,y in ipairs({3.3,7,10.5}) do part("Rudder_Iron_Strap",V(.65,.25,3.5),CF(0,y,50.5)*A(rad(-8),0,0),P.iron,G.trim,false) end
 -- Cargo groups deliberately avoid both main deck stair openings.
 for i=0,3 do barrel("Weather_Deck_Rum",CF(7.5,22.9,-17+i*3),.95,G.decor) end
 for i=0,2 do crate("Deck_Crate",CF(-11.7,22.9,18+i*2.2),1,G.decor) end
 for _,z in ipairs({-8,12}) do lantern("Main_Deck_Lantern",CF(halfWidth(z)-.8,25,z),.7,G.lights,true) end
 -- Outer chainplates / deadeyes, deliberately square toy geometry, no 3D stud caps.
 for _,z in ipairs({-24,0,35}) do for _,side in ipairs({-1,1}) do for j=-2,2 do
  local x=side*(halfWidth(z)+.15)
  part("Chainplate",V(.12,2.8,.18),CF(x,21.2,z+j*.8),P.iron,G.trim,false)
  part("Square_Deadeye",V(.28,.45,.38),CF(x,22.9,z+j*.8),P.woodDark,G.trim,true,nil,false)
 end end end
end
local function validateStaticShip()
 local scripts=0; local doors=0
 for _,p in ipairs(root:GetDescendants()) do
  if p:IsA("LuaSourceContainer") or p:IsA("ProximityPrompt") then scripts+=1 end
  if p:IsA("BasePart") then
   assert(p.Anchored,"Unanchored part: "..p.Name)
   assert(math.min(p.Size.X,p.Size.Y,p.Size.Z)>0,"Zero-size part: "..p.Name)
   if string.find(p.Name,"Door_Jamb",1,true) then doors+=1 end
  end
 end
 assert(scripts==0,"Static ship unexpectedly contains interactive logic")
 assert(doors>=6,"Door frames missing")
 root:SetAttribute("PartCount",counts.parts)
 root:SetAttribute("TextureCount",counts.textures)
 root:SetAttribute("LightCount",counts.lights)
 root:SetAttribute("StaticModel_NoMechanics",true)
 root:SetAttribute("MainDeckY",22+O.Y)
 root:SetAttribute("LowerDeckY",12.2+O.Y)
 root:SetAttribute("CargoHoldY",3+O.Y)
 root:SetAttribute("QuarterdeckY",33+O.Y)
 root:SetAttribute("MinDoorOpeningWidth",6.4)
 root:SetAttribute("AvatarDesignTarget","Standard R6 and R15; validate custom avatar scaling in Play")
end
pcall(function() History:SetWaypoint("Before_Karakarga_FullInterior") end)
local previous=W:FindFirstChild(Config.ModelName)
local ok,err=xpcall(function()
 buildHull(); buildDecks(); buildCabinsAndInterior(); buildGuns(); buildRig(); buildDecorations()
 validateStaticShip()
end,debug.traceback)
if not ok then root:Destroy(); error("[Karakarga Ship] Build failed; old model preserved.\n"..tostring(err)) end
root.Parent=W
if previous then previous:Destroy() end
-- A visible structural keel beam is the primary part; no invisible root or spawn added.
local keel=G.hull:FindFirstChild("Deep_Keel")
if keel then root.PrimaryPart=keel end
if Config.FrameCamera and W.CurrentCamera then
 W.CurrentCamera.CFrame=CFrame.lookAt(O+V(107,73,-124),O+V(0,25,-2))
 W.CurrentCamera.Focus=CF(O+V(0,25,-2))
end
pcall(function() Selection:Set({root}); History:SetWaypoint("Created_Karakarga_FullInterior") end)
print(string.format("[KARAKARGA FULL INTERIOR] %d Parts | %d Textures | %d lights. STATIC SHIP ONLY. Standard R6/R15 traversal must be checked in Play.",counts.parts,counts.textures,counts.lights))
