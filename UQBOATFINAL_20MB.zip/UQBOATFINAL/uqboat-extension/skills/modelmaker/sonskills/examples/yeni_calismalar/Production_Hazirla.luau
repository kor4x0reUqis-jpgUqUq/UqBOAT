-- Optional EDIT-mode Command Bar utility.
-- Select one or more Series01 asset models (or the entire collection).
-- Requires valid published animation IDs for EVERY clip before removing bake data.
-- Backs up AnimSaves in ServerStorage; ClipSpecs + runtime stay inside the asset.
local Selection=game:GetService("Selection")
local Storage=game:GetService("ServerStorage")
local History=game:GetService("ChangeHistoryService")
local chosen,seen={},{}
local function add(m)
 if m:IsA("Model") and m:GetAttribute("AssetKey") and not seen[m] then
  seen[m]=true;table.insert(chosen,m)
 end
end
for _,item in ipairs(Selection:Get()) do add(item);for _,d in ipairs(item:GetDescendants()) do add(d) end end
assert(#chosen>0,"Select a generated Series01 asset model or collection first.")
local backup=Storage:FindFirstChild("Babaar_Series01_SourceBackups")
if not backup then backup=Instance.new("Folder");backup.Name="Babaar_Series01_SourceBackups";backup.Parent=Storage end
pcall(function() History:SetWaypoint("Before_Series01_ProductionPrep") end)
local completed=0
for index,model in ipairs(chosen) do
 local specs=model:FindFirstChild("ClipSpecs")
 local saves=model:FindFirstChild("AnimSaves")
 local missing={}
 if specs then
  for _,meta in ipairs(specs:GetChildren()) do
   local raw=tostring(model:GetAttribute(meta.Name.."AnimationId") or "")
   local id=raw:match("^rbxassetid://(%d+)$") or raw:match("^(%d+)$")
   if not id or tonumber(id)<=0 then table.insert(missing,meta.Name) end
  end
 else table.insert(missing,"ClipSpecs missing") end
 if #missing>0 then
  warn("["..model.Name.."] Unchanged. Publish/set IDs: "..table.concat(missing,", "))
 elseif not saves then
  print("["..model.Name.."] Already production-prepared; AnimSaves absent.")
 else
  local f=Instance.new("Folder");f.Name=model.Name.."_"..os.time().."_"..index
  f:SetAttribute("AssetKey",model:GetAttribute("AssetKey"));f.Parent=backup
  saves.Parent=f
  model:SetAttribute("StudioPreview",false);model:SetAttribute("ProductionPrepared",true)
  completed+=1
  print("["..model.Name.."] Bake data backed up; published-ID runtime and ClipSpecs retained.")
 end
end
pcall(function() History:SetWaypoint("Prepared_Series01_ProductionAssets") end)
print("[Series01] Production-prepared "..completed.." asset(s). ID format checks do NOT verify ownership, permissions or actual playback. Test the exported model in a fresh place.")
