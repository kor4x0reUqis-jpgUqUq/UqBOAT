--[[
 BABAAR YAPAR | KARAKARGA KOYU — PIRATE LOBBY
 Roblox Studio > EDIT mode > View > Command Bar. Paste this ENTIRE file.
 Builds real Parts/WedgeParts, not a screenshot. No external mesh dependency.
 Studs are 2D Texture objects, never individual 3D stud cylinders.
 The provided ship image is a design reference, not an imported 3D asset.
 Source must run with Studio edit permissions (creates a server Script).
 Set Config.GamePlaceId to your published game place for the expedition gate.
]]
local Config = {
 ModelName = "BabaarYapar_KarakargaKoyu",
 Origin = Vector3.new(0, 0, 0), -- ocean surface height = Origin.Y
 GamePlaceId = 0,
 SetLighting = true,
 FrameCamera = true,
 StudTextures = true,
 StudSourceModelId = 9454666962,
 StudImageOverride = "", -- actual image URI/ID, NOT a model asset ID
 Tile = 0.82,
 TextureTransparency = 0.50,
 WaterSize = 360,
 YieldEvery = 220,
 EnableAmbientParticles = true,
}
local W = game:GetService("Workspace")
local History = game:GetService("ChangeHistoryService")
local Selection = game:GetService("Selection")
local Lighting = game:GetService("Lighting")
local V, CF, A = Vector3.new, CFrame.new, CFrame.Angles
local rad, sin, cos, pi = math.rad, math.sin, math.cos, math.pi
local O = Config.Origin
local P = {
 abyss=Color3.fromRGB(12,46,66), water=Color3.fromRGB(23,111,134),
 shallows=Color3.fromRGB(47,161,165), foam=Color3.fromRGB(165,224,212),
 sand=Color3.fromRGB(218,186,125), sandLight=Color3.fromRGB(241,213,157),
 sandDark=Color3.fromRGB(168,130,78), grass=Color3.fromRGB(78,126,81),
 grassLight=Color3.fromRGB(107,151,91), grassDark=Color3.fromRGB(48,86,65),
 rock=Color3.fromRGB(75,90,95), rockDark=Color3.fromRGB(46,61,70),
 rockLight=Color3.fromRGB(104,119,119), wood=Color3.fromRGB(103,62,37),
 woodLight=Color3.fromRGB(149,98,53), woodDark=Color3.fromRGB(53,34,28),
 plank=Color3.fromRGB(170,119,66), gold=Color3.fromRGB(203,151,71),
 goldLight=Color3.fromRGB(242,195,104), iron=Color3.fromRGB(34,41,48),
 ironLight=Color3.fromRGB(67,76,84), sail=Color3.fromRGB(30,34,45),
 sailLight=Color3.fromRGB(43,48,59), ivory=Color3.fromRGB(232,225,202),
 rope=Color3.fromRGB(166,128,77), glow=Color3.fromRGB(255,194,95),
 red=Color3.fromRGB(139,49,42), teal=Color3.fromRGB(40,119,117),
}
local counts={parts=0,textures=0,lights=0}
local root=Instance.new("Model")
root.Name=Config.ModelName
root:SetAttribute("Generator","BabaarYapar_PirateLobby_1.0")
root:SetAttribute("GamePlaceId",Config.GamePlaceId)
local function folder(name,parent)
 local f=Instance.new("Folder"); f.Name=name; f.Parent=parent or root; return f
end
local G={sea=folder("01_Ocean_And_Reefs"),island=folder("02_Layered_Island"),
 dock=folder("03_Harbor_And_Boarding"),town=folder("04_Pirate_Outpost"),
 palms=folder("05_Palms_Rocks_Foliage"),ship=folder("06_Black_Crow_Frigate"),
 decor=folder("07_Story_Details"),fx=folder("08_Ambience"),logic=folder("09_Interactions")}
local function resolveImage()
 if not Config.StudTextures then return "" end
 if Config.StudImageOverride~="" then
  local s=tostring(Config.StudImageOverride)
  return tonumber(s) and "rbxassetid://"..s or s
 end
 local old=W:FindFirstChild(Config.ModelName)
 if old and old:GetAttribute("StudImage") and old:GetAttribute("StudImage")~="" then return old:GetAttribute("StudImage") end
 local image,score="",-1
 local function inspect(asset)
  local all={asset}; for _,d in ipairs(asset:GetDescendants()) do table.insert(all,d) end
  for _,d in ipairs(all) do if d:IsA("LuaSourceContainer") then d:Destroy() end end
  for _,d in ipairs(all) do
   local uri,s="",0
   if d:IsA("Texture") then uri,s=d.Texture,20 elseif d:IsA("Decal") then uri,s=d.Texture,10 end
   if string.find(string.lower(d.Name),"stud",1,true) then s+=30 end
   if uri~="" and uri~="rbxassetid://"..Config.StudSourceModelId and s>score then image,score=uri,s end
  end
  asset:Destroy()
 end
 local loaders={
  function() return game:GetObjects("rbxassetid://"..Config.StudSourceModelId) end,
  function() return {game:GetService("InsertService"):LoadAsset(Config.StudSourceModelId)} end,
 }
 for _,load in ipairs(loaders) do
  local ok,assets=pcall(load)
  if ok and type(assets)=="table" then for _,a in ipairs(assets) do inspect(a) end end
  if image~="" then break end
 end
 if image=="" then warn("[Karakarga] Stud image could not be resolved. Set StudImageOverride to a Texture/Decal image URI. Geometry will still build; no 3D studs added.") end
 return image
end
local StudImage=resolveImage()
root:SetAttribute("StudImage",StudImage)
local function texture(p,faces,alpha,tile)
 if StudImage=="" then return end
 for _,face in ipairs(faces or {Enum.NormalId.Top,Enum.NormalId.Front,Enum.NormalId.Back}) do
  local t=Instance.new("Texture"); t.Name="Classic_Stud_Surface"; t.Texture=StudImage
  t.Face=face; t.Color3=p.Color; t.Transparency=alpha or Config.TextureTransparency
  t.StudsPerTileU=tile or Config.Tile; t.StudsPerTileV=tile or Config.Tile
  t.Parent=p; counts.textures+=1
 end
end
local function part(name,size,cf,color,parent,textured,mat,collide,class)
 assert(math.min(size.X,size.Y,size.Z)>0,"Invalid size: "..name)
 local p=Instance.new(class or "Part"); p.Name=name; p.Size=size; p.CFrame=CF(O)*cf
 p.Color=color; p.Material=mat or Enum.Material.Plastic; p.Anchored=true
 p.CanCollide=collide~=false; p.CanTouch=false; p.CanQuery=true
 p.TopSurface=Enum.SurfaceType.Smooth; p.BottomSurface=Enum.SurfaceType.Smooth
 p.CastShadow=true; p.Parent=parent or G.decor
 if textured then texture(p) end
 counts.parts+=1
 if counts.parts%Config.YieldEvery==0 then task.wait() end
 return p
end
local function beam(name,a,b,width,color,parent,textured,height)
 local d=b-a; if d.Magnitude<0.01 then return end
 local up=math.abs(d.Unit.Y)>0.98 and V(0,0,1) or V(0,1,0)
 return part(name,V(width,height or width,d.Magnitude+0.025),CFrame.lookAt((a+b)/2,b,up),color,parent,textured,nil,false)
end
local function triangle(name,a,b,c,thickness,color,parent,textured)
 local ab,ac,bc=b-a,c-a,c-b
 if ab:Dot(ab)>ac:Dot(ac) and ab:Dot(ab)>bc:Dot(bc) then a,c=c,a
 elseif ac:Dot(ac)>ab:Dot(ab) and ac:Dot(ac)>bc:Dot(bc) then a,b=b,a end
 ab,ac,bc=b-a,c-a,c-b
 local cr=ac:Cross(ab); if cr.Magnitude<0.0001 or bc.Magnitude<0.001 then return {} end
 local right,back=cr.Unit,bc.Unit; local up=back:Cross(right).Unit
 local h=math.abs(ab:Dot(up)); local l1,l2=math.abs(ab:Dot(back)),math.abs(ac:Dot(back))
 local out={}; if h<0.001 then return out end
 local function wedge(n,len,pos,r,u,k)
  if len<0.005 then return end
  local p=part(n,V(thickness,h,len),CFrame.fromMatrix(pos,r,u,k),color,parent,false,nil,false,"WedgePart")
  if textured then texture(p,{Enum.NormalId.Left,Enum.NormalId.Right},0.48) end
  table.insert(out,p)
 end
 wedge(name.."_A",l1,(a+b)/2,right,up,back)
 wedge(name.."_B",l2,(a+c)/2,-right,up,-back)
 return out
end
local function quad(name,a,b,c,d,t,color,parent,textured)
 triangle(name.."_1",a,b,c,t,color,parent,textured)
 triangle(name.."_2",a,c,d,t,color,parent,textured)
end
local function prompt(p,label,object,action,destination)
 local pr=Instance.new("ProximityPrompt"); pr.Name="Interact_"..action
 pr.ActionText=label; pr.ObjectText=object; pr.HoldDuration=0.25
 pr.MaxActivationDistance=11; pr.RequiresLineOfSight=false
 pr:SetAttribute("Action",action)
 if destination then pr:SetAttribute("Destination",destination+O) end
 pr.Parent=p; return pr
end
local function sign(name,cf,size,title,subtitle,parent)
 local p=part(name,size,cf,P.woodDark,parent,true)
 local gui=Instance.new("SurfaceGui"); gui.Name="Readable_Sign"; gui.Face=Enum.NormalId.Front
 gui.SizingMode=Enum.SurfaceGuiSizingMode.PixelsPerStud; gui.PixelsPerStud=55; gui.LightInfluence=0.3; gui.Parent=p
 local pad=Instance.new("UIPadding"); pad.PaddingLeft=UDim.new(0.05,0); pad.PaddingRight=UDim.new(0.05,0); pad.Parent=gui
 local text=Instance.new("TextLabel"); text.Size=UDim2.fromScale(1,0.61); text.BackgroundTransparency=1
 text.Font=Enum.Font.GothamBold; text.Text=title; text.TextColor3=P.goldLight; text.TextScaled=true; text.TextWrapped=true; text.Parent=gui
 local sub=Instance.new("TextLabel"); sub.Position=UDim2.fromScale(0,0.65); sub.Size=UDim2.fromScale(1,0.27)
 sub.BackgroundTransparency=1; sub.Font=Enum.Font.Gotham; sub.Text=subtitle; sub.TextColor3=P.ivory; sub.TextScaled=true; sub.Parent=gui
 return p
end
local function pointLight(p,brightness,range,color)
 local l=Instance.new("PointLight"); l.Color=color or P.glow; l.Brightness=brightness; l.Range=range; l.Shadows=true; l.Parent=p; counts.lights+=1
end
local function lantern(name,cf,scale,parent,lit)
 local s=scale or 1
 part(name.."_Base",V(.82,.16,.82)*s,cf*CF(0,-.58*s,0),P.iron,parent,false)
 local glass=part(name.."_Warm_Core",V(.58,.91,.58)*s,cf,P.glow,parent,false,Enum.Material.Neon,false)
 glass.Transparency=.18
 for _,x in ipairs({-1,1}) do for _,z in ipairs({-1,1}) do
  part(name.."_Corner",V(.09,1.15,.09)*s,cf*CF(x*.36*s,0,z*.36*s),P.iron,parent,false,nil,false)
 end end
 part(name.."_Cap",V(.94,.18,.94)*s,cf*CF(0,.61*s,0),P.iron,parent,false)
 part(name.."_Gold_Edge",V(1,.08,1)*s,cf*CF(0,.75*s,0),P.gold,parent,false,nil,false)
 part(name.."_Handle",V(.1,.36,.1)*s,cf*CF(0,.98*s,0),P.iron,parent,false,nil,false)
 if lit then pointLight(glass,1.25,13*s) end
 return glass
end
local function barrel(name,cf,s,parent)
 s=s or 1
 for i=0,7 do
  local q=i*pi/4
  part(name.."_Stave_"..i,V(.54,1.75,.18)*s,cf*A(0,q,0)*CF(0,0,.60*s),i%2==0 and P.wood or P.woodLight,parent,true)
 end
 part(name.."_Lid",V(1.1,.12,1.1)*s,cf*CF(0,.88*s,0),P.woodLight,parent,true)
 for _,y in ipairs({-.58,.58}) do for i=0,7 do
  part(name.."_Hoop",V(.56,.12,.12)*s,cf*A(0,i*pi/4,0)*CF(0,y*s,.69*s),P.iron,parent,false)
 end end
end
local function crate(name,cf,s,parent)
 part(name.."_Box",V(1.65,1.65,1.65)*s,cf,P.wood,parent,true)
 for _,y in ipairs({-.65,.65}) do part(name.."_Band",V(1.78,.16,1.78)*s,cf*CF(0,y*s,0),P.woodLight,parent,false) end
 for _,x in ipairs({-.64,.64}) do part(name.."_Brace",V(.15,1.7,1.79)*s,cf*CF(x*s,0,0),P.gold,parent,false) end
end
local function palm(name,base,height,lean)
 local top=base+V(lean or 2,height,0)
 local prev=base
 for i=1,8 do
  local t=i/8; local q=base+V((lean or 2)*t*t,height*t,sin(t*pi)*.25)
  beam(name.."_Trunk_"..i,prev,q,.85*(1-t*.4),i%2==0 and P.wood or P.woodLight,G.palms,true)
  prev=q
 end
 for j=0,6 do
  local a=j*2*pi/7+.3
  local dir=V(cos(a),0,sin(a))
  for k=1,4 do
   local t0=(k-1)/4; local t1=k/4
   local function at(t) return top+dir*(t*7)+V(0,1.8*sin(t*pi)-t*t*2.1,0) end
   local aa,bb=at(t0),at(t1); local mid=(aa+bb)/2
   local side=V(-dir.Z,0,dir.X)*(1.25*sin((t0+t1)/2*pi)+.2)
   quad(name.."_Frond_"..j.."_"..k,aa,mid+side,bb,mid-side,.11,k%2==0 and P.grass or P.grassDark,G.palms,true)
   beam(name.."_Leaf_Rib",aa,bb,.09,P.grassLight,G.palms,false)
  end
 end
 for j=0,2 do part(name.."_Coconut",V(.5,.65,.5),CF(top+V(cos(j*2)*.5,-.5,sin(j*2)*.5)),P.woodDark,G.palms,true,nil,false) end
end

local function buildOcean()
 local sea=part("Deep_Blue_Ocean",V(Config.WaterSize,1,Config.WaterSize),CF(0,-.8,0),P.water,G.sea,false,Enum.Material.Plastic,false)
 sea.Transparency=.18; sea.Reflectance=.12; sea.CastShadow=false
 part("Seabed",V(Config.WaterSize,1,Config.WaterSize),CF(0,-8,0),P.abyss,G.sea,false,nil,true)
 -- Sparse flat painted ripples: no giant blanket of expensive particles.
 for i=1,74 do
  local x=((i*47)%311)-155; local z=((i*79)%307)-153
  if (V(x,0,z)-V(-27,0,7)).Magnitude>34 then
   local p=part("Water_Ripple_"..i,V(1.6+(i%5)*.6,.025,.12),CF(x,-.265,z)*A(0,rad(-12+i%7),0),P.foam,G.sea,false,nil,false)
   p.Transparency=.72; p.CastShadow=false
  end
 end
 -- Low silhouettes at the horizon.
 for i=1,9 do
  local a=i*2*pi/9+.1; local pos=V(cos(a)*145,-3,sin(a)*145)
  part("Distant_Reef_"..i,V(9+i%3*3,6+i%4*2,8+i%2*5),CF(pos)*A(rad(8),a,rad(14)),P.rockDark,G.sea,true)
 end
end
local IC=V(-27,0,7)
local function coast(a) return 1+.07*sin(a*3+.4)+.045*cos(a*7) end
local function islandTier(name,radius,y,depth,col)
 local n=44
 for i=0,n-1 do
  local a,b=i*2*pi/n,(i+1)*2*pi/n
  local va=IC+V(cos(a)*radius*coast(a),y,sin(a)*radius*coast(a))
  local vb=IC+V(cos(b)*radius*coast(b),y,sin(b)*radius*coast(b))
  local mid=IC+V(0,y,0)
  -- Top triangles have a vertical thickness axis; therefore walkable.
  local tris=triangle(name.."_Top_"..i,mid,va,vb,depth,i%4==0 and col:Lerp(P.sandLight,.08) or col,G.island,true)
  for _,p in ipairs(tris) do p.CanCollide=true end
 end
end
local function buildIsland()
 islandTier("Submerged_Sandbank",34,-1.3,1.8,P.sandDark)
 islandTier("Wet_Sand_Rim",30.5,.32,1.2,P.sandDark)
 islandTier("Golden_Beach",28.5,1.15,1.7,P.sand)
 islandTier("Upper_Sand",25.6,2.05,1.4,P.sandLight)
 islandTier("Grass_Plateau",20.8,2.95,1.5,P.grass)
 -- Curved, broken surf outlines.
 for i=0,57 do
  local a=i*2*pi/58; local b=a+.065
  local r=31.5
  local q=beam("Shore_Foam",IC+V(cos(a)*r*coast(a),-.19,sin(a)*r*coast(a)),IC+V(cos(b)*r*coast(b),-.19,sin(b)*r*coast(b)),.21,P.foam,G.sea,false,.045)
  if q then q.Transparency=.48; q.CastShadow=false end
 end
 -- Walkable plaza, ringed with individual stone blocks.
 for x=-3,3 do for z=-3,3 do
  part("Plaza_Cobble_"..x.."_"..z,V(1.8,.2,1.8),CF(IC+V(x*1.9,3.77,z*1.9)),(x+z)%3==0 and P.rockLight or P.rock,G.town,true)
 end end
 for i=0,23 do local a=i*2*pi/24
  part("Plaza_Edge",V(1.7,.3,.65),CF(IC+V(cos(a)*8,3.72,sin(a)*8))*A(0,-a+pi/2,0),P.sandLight,G.town,true)
 end
 -- North-east path to harbor, south-west to lighthouse.
 for i=0,10 do
  part("Harbor_Path",V(2.25,.22,2.9),CF(-25+i*2.2,3.78,1-i*.8)*A(0,rad(15),0),i%2==0 and P.sand or P.sandLight,G.town,true)
 end
 for i=0,6 do
  part("Lighthouse_Steps",V(3,.25,1.7),CF(-35-i*1.35,3.75+i*.08,15+i*.9)*A(0,rad(-38),0),P.sandLight,G.town,true)
 end
 for _,d in ipairs({{-47,9,10,2},{-44,-8,12,-2},{-18,23,11,3},{-11,12,9,-2},{-36,-15,10,2}}) do
  palm("Wind_Palm",V(d[1],3.3,d[2]),d[3],d[4])
 end
 for i=1,20 do
  local a=i*2.399; local r=23+(i%4)*1.2
  local pos=IC+V(cos(a)*r,1.6,sin(a)*r)
  if pos.X< -8 or pos.Z>7 then
   part("Beach_Rock_"..i,V(1.2+i%3,1+i%3*.5,1.5+i%2),CF(pos)*A(rad(i%4*7),a,rad(12)),i%2==0 and P.rock or P.rockDark,G.palms,true)
  end
 end
 for i=1,22 do
  local a=i*2.4; local r=14+(i%4)*2
  local pos=IC+V(cos(a)*r,3.8,sin(a)*r)
  for k=0,2 do part("Coastal_Grass",V(.18,.9+k*.15,.5),CF(pos+V(k*.22,0,0))*A(0,a,rad((k-1)*17)),P.grassDark,G.palms,false,nil,false) end
 end
end

local function buildDock()
 -- Main pier runs east from island toward the port side of the ship.
 for i=0,23 do
  part("Dock_Plank_"..i,V(.96,.28,5.4),CF(-5+i*1.1,3.7,-8),i%4==0 and P.wood or P.plank,G.dock,true)
 end
 for _,z in ipairs({-10.2,-5.8}) do
  beam("Dock_Stringer",V(-5,3.25,z),V(21,3.25,z),.45,P.woodDark,G.dock,true)
 end
 for i=0,5 do for _,z in ipairs({-10.1,-5.9}) do
  local x=-4+i*4.6
  part("Pier_Piling",V(.65,7,.65),CF(x,.3,z),P.woodDark,G.dock,true)
  part("Piling_Cap",V(.88,.2,.88),CF(x,3.92,z),P.woodLight,G.dock,true)
  if i%2==0 then lantern("Pier_Lantern",CF(x,5.0,z),.65,G.dock,i==2) end
 end end
 for _,x in ipairs({1,10}) do
  beam("Safety_Rope",V(x,4.45,-10.2),V(x+4,4.25,-10.2),.11,P.rope,G.dock,false)
 end
 -- A genuinely walkable incline; decorative cross battens are not the collision surface.
 local a,b=V(19,3.87,-8),V(31.8,8.7,-8)
 local d=b-a; local center=(a+b)/2
 local slope=part("Boarding_Ramp_Walkable",V(d.Magnitude,.24,3.1),CF(center)*A(0,0,math.atan2(d.Y,d.X)),P.wood,G.dock,true)
 for i=0,17 do
  local p=a:Lerp(b,i/17)
  part("Ramp_AntiSlip_Batten",V(.13,.12,3.12),CF(p+V(0,.19,0))*A(0,0,math.atan2(d.Y,d.X)),P.woodLight,G.dock,false)
 end
 for _,z in ipairs({-9.65,-6.35}) do
  for i=0,3 do
   local p=a:Lerp(b,i/3); part("Gangway_Post",V(.16,1.7,.16),CF(p+V(0,.85,z+8)),P.woodDark,G.dock,false)
  end
  beam("Gangway_Handrail",a+V(0,1.55,z+8),b+V(0,1.55,z+8),.13,P.rope,G.dock,false)
 end
 barrel("Dock_Rum",CF(12,4.7,-6.4),.85,G.dock)
 crate("Dock_Cargo",CF(15,4.8,-9),.9,G.dock)
 local bollard=part("Boarding_Interaction",V(.7,1.5,.7),CF(18,4.7,-6),P.gold,G.dock,true)
 prompt(bollard,"Güverteye çık","KARAKARGA","Move",V(36,10.4,-8))
 sign("Dock_Sign",CF(5,6.1,-10.3)*A(0,pi,0),V(5.5,1.8,.22),"KARAKARGA","GÜVERTE ZİYARETE AÇIK",G.dock)
end

local ShipCF=CF(39,0,-25)*A(0,rad(-4),0)
local SG={hull=folder("A_Curved_Plank_Hull",G.ship),deck=folder("B_Walkable_Decks",G.ship),
 guns=folder("C_Open_Gunports",G.ship),stern=folder("D_Captains_Gallery",G.ship),
 rig=folder("E_Three_Masts_And_Rigging",G.ship),sails=folder("F_Billowed_Black_Sails",G.ship),
 trim=folder("G_Gold_Trim_And_Figurehead",G.ship),details=folder("H_Deck_Equipment",G.ship)}
local function sv(v) return ShipCF:PointToWorldSpace(v) end
local function sp(name,size,cf,color,parent,textured,mat,collide,class)
 return part(name,size,ShipCF*cf,color,parent or SG.details,textured,mat,collide,class)
end
local function sb(name,a,b,width,color,parent,textured,height)
 return beam(name,sv(a),sv(b),width,color,parent or SG.rig,textured,height)
end
local function sq(name,a,b,c,d,t,color,parent,textured)
 quad(name,sv(a),sv(b),sv(c),sv(d),t,color,parent,textured)
end
local profile={{-31,.20},{-28,2.4},{-24,4.5},{-18,6.5},{-10,7.8},{0,8.1},{10,7.7},{20,6.8},{27,5.3}}
local function widthAt(z)
 for i=1,#profile-1 do
  local a,b=profile[i],profile[i+1]
  if z>=a[1] and z<=b[1] then return a[2]+(b[2]-a[2])*(z-a[1])/(b[1]-a[1]) end
 end
 return z< -31 and .2 or 5.3
end
local function sheer(z) return .0014*(z+3)^2 end
local function hullPoint(z,row,side)
 local t=row/10
 local factor=.24+.76*(sin(t*pi/2)^.8)
 return V(side*widthAt(z)*factor,.05+t*7.85+sheer(z)*t,z)
end
local portZ={-19,-13,-7,-1,5,11,17}
local function nearPort(z)
 for _,p in ipairs(portZ) do if math.abs(z-p)<1.12 then return true end end
 return false
end
local function cannon(z,side)
 local w=widthAt(z); local y=6.2+sheer(z)
 local cf=CF(side*(w+.28),y,z)*A(0,-side*pi/2,0)
 -- A dark recessed backplate is inside an actual omitted belt section.
 sp("Gunport_Inner_Shadow",V(1.95,1.55,.14),cf*CF(0,0,.64),P.woodDark,SG.guns,false,nil,false)
 for _,x in ipairs({-.98,.98}) do sp("Gunport_Gold_Jamb",V(.14,1.72,.24),cf*CF(x,0,0),P.gold,SG.guns,true) end
 for _,h in ipairs({-.82,.82}) do sp("Gunport_Sill",V(2.1,.16,.28),cf*CF(0,h,0),P.gold,SG.guns,true) end
 -- Octagonal barrel, hollow muzzle and hoops: no expensive CSG required.
 for k=0,7 do
  local a=k*pi/4
  sp("Cannon_Barrel_Facet",V(.30,.17,2.25),cf*CF(cos(a)*.38,sin(a)*.38,-.3)*A(0,0,a-pi/2),P.iron,SG.guns,false,nil,false)
  sp("Cannon_Muzzle_Rim",V(.34,.13,.18),cf*CF(cos(a)*.46,sin(a)*.46,-1.48)*A(0,0,a-pi/2),P.ironLight,SG.guns,false,nil,false)
 end
 sp("Cannon_Bore_Shadow",V(.55,.55,.05),cf*CF(0,0,-1.14),Color3.fromRGB(8,10,13),SG.guns,false,nil,false)
 sp("Gunport_Lid",V(2.04,.12,1.50),cf*CF(0,1.02,-.62)*A(rad(-16),0,0),P.wood,SG.guns,true,nil,false)
end
local function skull(cf,scale,parent)
 -- All markings are actual low-relief rectangular parts; no skull image dependency.
 local function piece(n,size,offset,color)
  return sp("JollyRoger_"..n,size*scale,cf*CF(offset*scale),color,parent,false,nil,false)
 end
 piece("Cranium",V(1.22,1.05,.075),V(0,.44,0),P.ivory)
 piece("Temple",V(1.55,.60,.08),V(0,.48,0),P.ivory)
 piece("Jaw",V(.83,.54,.085),V(0,-.22,-.005),P.ivory)
 piece("LeftEye",V(.34,.34,.11),V(-.37,.45,-.075),P.sail)
 piece("RightEye",V(.34,.34,.11),V(.37,.45,-.075),P.sail)
 piece("Nose",V(.19,.25,.12),V(0,.09,-.08),P.sail)
 for k=-1,1 do piece("ToothGap",V(.065,.21,.12),V(k*.22,-.42,-.08),P.sail) end
 for _,side in ipairs({-1,1}) do
  sp("Crossbones",V(2.65,.18,.07)*scale,cf*CF(0,-1.02*scale,0)*A(0,0,side*rad(28)),P.ivory,parent,false,nil,false)
  for _,x in ipairs({-1,1}) do
   local t=cf*CF(0,-1.02*scale,0)*A(0,0,side*rad(28))*CF(x*1.22*scale,0,0)
   sp("Bone_End",V(.28,.4,.085)*scale,t,P.ivory,parent,false,nil,false)
  end
 end
end
local function sail(name,z,bottom,top,halfWidth,emblem)
 local rows,cols=7,10
 local height=top-bottom
 local function vertex(u,v)
  local w=halfWidth*(1-.22*v)
  return V((u*2-1)*w,bottom+v*height-.40*sin(u*pi)*(1-v),z-.25-1.65*sin(u*pi)*sin(v*pi))
 end
 for r=0,rows-1 do for c=0,cols-1 do
  local u0,u1=c/cols,(c+1)/cols; local v0,v1=r/rows,(r+1)/rows
  local col=P.sail:Lerp(P.sailLight,.12+.40*sin(v0*pi)+.08*((r+c)%2))
  sq(name.."_Cloth_"..r.."_"..c,vertex(u0,v0),vertex(u1,v0),vertex(u1,v1),vertex(u0,v1),.08,col,SG.sails,true)
 end end
 -- Slightly raised hems and subtle gold-brown stitch seams.
 for _,u in ipairs({0,1}) do for i=0,6 do sb(name.."_Side_Hem",vertex(u,i/7),vertex(u,(i+1)/7),.10,P.ironLight,SG.sails,false) end end
 for i=0,9 do sb(name.."_Foot_Hem",vertex(i/10,0),vertex((i+1)/10,0),.10,P.ironLight,SG.sails,false) end
 for c=1,4 do for r=0,5 do
  local a=vertex(c/5,r/6); local b=vertex(c/5,(r+1)/6)
  sb(name.."_Panel_Seam",a+V(0,0,-.08),b+V(0,0,-.08),.026,P.ironLight,SG.sails,false)
 end end
 if emblem then skull(CF(0,bottom+height*.56,z-2.01),1.45,SG.sails); skull(CF(0,bottom+height*.56,z+.13)*A(0,pi,0),1.45,SG.sails) end
 sb(name.."_Lower_Yard",V(-halfWidth-.65,bottom,z),V(halfWidth+.65,bottom,z),.27,P.woodLight,SG.rig,true)
 sb(name.."_Upper_Yard",V(-halfWidth*.80-.65,top,z),V(halfWidth*.80+.65,top,z),.27,P.woodLight,SG.rig,true)
 for _,x in ipairs({-1,1}) do
  sb(name.."_Sheet",V(x*halfWidth,bottom,z),V(x*6.6,9,z+3.5),.065,P.rope,SG.rig,false)
 end
end
local function mast(name,z,height)
 sb(name.."_Main_Spar",V(0,8.3,z),V(0,height,z),.52,P.wood,SG.rig,true)
 sb(name.."_Highlight",V(-.23,9,z-.12),V(-.23,height-.4,z-.12),.08,P.gold,SG.rig,false)
 for y=10,height-1,3.1 do
  sp(name.."_Mast_Collar",V(.73,.16,.73),CF(0,y,z),P.iron,SG.rig,false)
 end
 local nest=height-6.1
 for k=0,7 do
  local a=k*pi/4
  sp(name.."_Nest_Floor",V(1.45,.23,1.35),CF(cos(a)*.8,nest,sin(a)*.8+z)*A(0,-a,0),P.woodLight,SG.rig,true)
  sp(name.."_Nest_Rail",V(1.07,.7,.15),CF(cos(a)*1.6,nest+.6,sin(a)*1.6+z)*A(0,-a+pi/2,0),P.wood,SG.rig,true)
  sp(name.."_Nest_Trim",V(1.20,.12,.21),CF(cos(a)*1.64,nest+1,sin(a)*1.64+z)*A(0,-a+pi/2,0),P.gold,SG.rig,false)
 end
 for _,side in ipairs({-1,1}) do
  for j=0,2 do
   local low=V(side*(widthAt(z)-.4),9.4,z-2+j*2)
   local high=V(side*.5,nest+.7,z)
   sb(name.."_Shroud",low,high,.065,P.rope,SG.rig,false)
  end
  for k=0,16 do
   local t=k/17
   local a=V(side*(widthAt(z)-.4),9.4,z-2):Lerp(V(side*.5,nest+.7,z),t)
   local b=V(side*(widthAt(z)-.4),9.4,z+2):Lerp(V(side*.5,nest+.7,z),t)
   sb(name.."_Ratline",a,b,.055,P.rope,SG.rig,false)
  end
 end
 -- Flag is segmented, with a visible wind bend; no hidden image required.
 for i=0,5 do
  sp(name.."_Flag_Cloth",V(.55,1.85,.065),CF(.48+i*.52,height-.7,z+sin(i*.6)*.22),P.sail,SG.sails,true,nil,false)
 end
 skull(CF(1.75,height-.65,z-.22),.53,SG.sails)
end
local function buildShip()
 -- Hull cross sections: real faceted surfaces, not stacked rectangular boxes.
 for row=0,9 do
  local col
  if row<2 then col=P.woodDark:Lerp(P.wood,row*.2)
  elseif row==4 or row==8 then col=P.gold:Lerp(P.wood,.30)
  elseif row>=6 then col=P.iron:Lerp(P.wood,.12)
  else col=P.wood:Lerp(P.woodLight,(row-2)*.12) end
  for seg=0,57 do
   local za=-31+seg; local zb=za+1
   for _,side in ipairs({-1,1}) do
    -- Leave genuine rectangular cannon openings in the belt; frame them separately.
    if not ((row==7 or row==8) and nearPort((za+zb)/2)) then
     sq("Hull_Strake_"..row.."_"..seg.."_"..side,hullPoint(za,row,side),hullPoint(zb,row,side),hullPoint(zb,row+1,side),hullPoint(za,row+1,side),.19,col,SG.hull,true)
    end
   end
  end
 end
 -- Stern closure, keel, bow stem.
 for row=0,9 do
  local a,b=hullPoint(27,row,-1),hullPoint(27,row,1)
  local c,d=hullPoint(27,row+1,1),hullPoint(27,row+1,-1)
  sq("Transom_Layer_"..row,a,b,c,d,.22,row%3==0 and P.gold or P.woodDark,SG.hull,true)
 end
 sb("Long_Keel",V(0,.05,-29),V(0,.05,27),.48,P.woodDark,SG.hull,true)
 sb("Raked_Bow_Stem",V(0,.2,-30),V(0,11,-32),.55,P.woodDark,SG.trim,true)
 -- Continuous flat walkable main deck, each cross-plank follows hull width.
 for i=0,68 do
  local z=-28+i*.79; local w=widthAt(z)*.94
  sp("Main_Deck_Plank_"..i,V(w*2,.25,.765),CF(0,8.45,z),i%5==0 and P.woodLight or P.plank,SG.deck,true)
 end
 -- Slim collision backing beneath faceted hull; no invisible floating ship wall.
 sp("Deck_Core",V(13.5,.45,36),CF(0,8.12,-1),P.woodDark,SG.deck,false)
 for _,side in ipairs({-1,1}) do
  for i=0,27 do
   local z=-28+i*1.95; local w=widthAt(z)
   if not(side==-1 and z>14 and z<20) then
    sp("Bulwark_Panel",V(.32,.72,1.75),CF(side*w,9.07,z),P.iron,SG.hull,true)
    sp("Bulwark_Gold_Cap",V(.46,.15,1.89),CF(side*w,9.5,z),P.gold,SG.trim,true)
   sp("Rail_Stanchion",V(.25,.7,.25),CF(side*w,9.9,z),P.woodLight,SG.trim,false)
   sp("Upper_Rail",V(.27,.17,1.95),CF(side*w,10.29,z),P.gold,SG.trim,false)
   end
  end
  for _,z in ipairs(portZ) do cannon(z,side) end
  -- Long uninterrupted rubbing strakes define ship's elegant sheer.
  for i=0,27 do
   local z=-29+i*2; local zz=math.min(z+2,27)
   sb("Outer_Gold_Rubbing_Strake",V(side*(widthAt(z)+.14),4.30+sheer(z)*.55,z),V(side*(widthAt(zz)+.14),4.30+sheer(zz)*.55,zz),.14,P.gold,SG.trim,false)
  end
 end
 -- Raised forecastle.
 for i=0,9 do local z=-27+i*.7
  sp("Forecastle_Plank",V(widthAt(z)*1.75,.23,.68),CF(0,10.1,z),P.woodLight,SG.deck,true)
 end
 for i=0,4 do sp("Forecastle_Step",V(3,.30,.65),CF(0,8.65+i*.30,-18.8-i*.63),P.plank,SG.deck,true) end
 -- Bowsprit and twin rails.
 sb("Great_Bowsprit",V(0,9.6,-25),V(0,14.1,-44),.55,P.woodLight,SG.rig,true)
 for _,side in ipairs({-1,1}) do
  sb("Bow_Gold_Sweep",V(side*5,7.1,-24),V(side*.7,10.4,-34),.24,P.gold,SG.trim,true)
  sb("Bow_Safety_Stay",V(side*3.8,10.3,-26),V(0,14,-43),.075,P.rope,SG.rig,false)
  sb("Bow_Keel_Stay",V(side*.3,3,-30),V(0,14,-44),.075,P.rope,SG.rig,false)
 end
 for i=0,7 do sp("Bowsprit_Binding",V(.72,.16,.72),CF(0,10.15+i*.43,-27.3-i*1.8)*A(rad(-13),0,0),P.iron,SG.rig,false) end
 -- Gold bird figurehead: hooked beak, swept segmented wings.
 sp("Figurehead_Body",V(.95,1.5,1.2),CF(0,8.7,-32.4)*A(rad(-16),0,0),P.gold,SG.trim,true)
 sp("Figurehead_Head",V(.85,.8,.9),CF(0,9.7,-33),P.goldLight,SG.trim,true)
 sp("Figurehead_Beak",V(.5,.35,.9),CF(0,9.55,-33.7)*A(rad(18),0,0),P.gold,SG.trim,false)
 for _,side in ipairs({-1,1}) do
  sp("Figurehead_Eye",V(.07,.18,.22),CF(side*.45,9.8,-33.2),P.iron,SG.trim,false)
  for k=1,4 do
   sb("Figurehead_Wing_Feather",V(side*.5,9.3,-32.4),V(side*(1.2+k*.34),9.9+k*.18,-31.8+k*.35),.25,P.gold,SG.trim,true,.42)
  end
 end
 -- Captain's cabin: a solid, accessible room with framed luminous windows.
 for i=0,13 do sp("Cabin_Floor",V(11.3,.23,.58),CF(0,9.1,18.6+i*.61),P.plank,SG.stern,true) end
 sp("Cabin_Back",V(10.6,4.2,.3),CF(0,11.25,27),P.woodDark,SG.stern,true)
 for _,side in ipairs({-1,1}) do
  sp("Cabin_Side_Wall",V(.28,4.25,8),CF(side*5.55,11.25,23),P.woodDark,SG.stern,true)
  for z=20,26,2 do
   local cf=CF(side*5.73,11.45,z)*A(0,-side*pi/2,0)
   sp("Cabin_Glass_Side",V(1.25,2.2,.06),cf,P.glow,SG.stern,false,Enum.Material.Neon,false)
   for _,x in ipairs({-.7,0,.7}) do sp("Window_Mullion",V(.10,2.5,.13),cf*CF(x,0,-.08),P.gold,SG.stern,false) end
   for _,y in ipairs({-1.2,0,1.2}) do sp("Window_Crossbar",V(1.55,.10,.13),cf*CF(0,y,-.08),P.gold,SG.stern,false) end
  end
 end
 -- Front wall has a real doorway rather than a painted door on a solid wall.
 for _,side in ipairs({-1,1}) do sp("Cabin_Front_Jamb",V(3.85,4.2,.35),CF(side*3.48,11.25,18.8),P.wood,SG.stern,true) end
 sp("Cabin_Door_Lintel",V(3.2,.75,.38),CF(0,13,18.8),P.gold,SG.stern,true)
 for _,x in ipairs({-1.65,1.65}) do sp("Door_Frame",V(.20,3.3,.45),CF(x,10.65,18.65),P.gold,SG.stern,true) end
 for x=-4,4,2 do
  local cf=CF(x,11.5,27.22)*A(0,pi,0)
  sp("Stern_Glass",V(1.35,2.15,.08),cf,P.glow,SG.stern,false,Enum.Material.Neon,false)
  for _,dx in ipairs({-.77,0,.77}) do sp("Stern_Mullion",V(.12,2.5,.18),cf*CF(dx,0,-.10),P.gold,SG.stern,false) end
  for _,dy in ipairs({-1.2,0,1.2}) do sp("Stern_Crossbar",V(1.65,.12,.18),cf*CF(0,dy,-.10),P.gold,SG.stern,false) end
 end
 for _,y in ipairs({9.4,13.4}) do
  sp("Stern_Gold_Belt",V(12,.2,.38),CF(0,y,27.3),P.goldLight,SG.stern,true)
  for _,side in ipairs({-1,1}) do sp("Gallery_Side_Trim",V(.4,.20,9),CF(side*5.8,y,22.9),P.gold,SG.stern,true) end
 end
 for i=0,14 do sp("Quarterdeck_Plank",V(12.1,.23,.62),CF(0,13.7,18.4+i*.62),P.woodLight,SG.deck,true) end
 -- Port stairs reach the upper deck; starboard remains open for cabin approach.
 for i=0,10 do sp("Quarterdeck_Stair",V(2.8,.40,.68),CF(-4.1,8.8+i*.44,11.6+i*.63),P.plank,SG.deck,true) end
 for _,side in ipairs({-1,1}) do for z=18,27,1.5 do
  sp("Stern_Baluster",V(.2,1,.2),CF(side*6.05,14.3,z),P.gold,SG.trim,false)
  sp("Stern_Rail",V(.26,.18,1.5),CF(side*6.05,14.9,z),P.woodDark,SG.trim,true)
 end end
 for x=-6,6,1.5 do sp("Aft_Baluster",V(.2,1,.2),CF(x,14.3,27.8),P.gold,SG.trim,false) end
 sp("Aft_Handrail",V(12.3,.2,.26),CF(0,14.9,27.8),P.gold,SG.trim,true)
 for _,side in ipairs({-1,1}) do
  lantern("Stern_Lantern",ShipCF*CF(side*5.4,15.8,26.4),.85,SG.stern,true)
 end
 -- Cabin furniture and chart table.
 sp("Chart_Table",V(4,.22,2.5),CF(0,10.65,23),P.woodLight,SG.details,true)
 for _,x in ipairs({-1.6,1.6}) do for _,z in ipairs({22.1,23.9}) do sp("Table_Leg",V(.2,1.6,.2),CF(x,9.8,z),P.woodDark,SG.details,false) end end
 sp("Parchment_Map",V(2.5,.025,1.7),CF(0,10.79,23)*A(0,rad(7),0),P.ivory,SG.details,false,nil,false)
 for i=0,5 do sp("Map_Route_Dash",V(.16,.026,.09),CF(-.8+i*.3,10.82,23+sin(i)*.35),P.red,SG.details,false,nil,false) end
 lantern("Cabin_Desk_Lamp",ShipCF*CF(1.5,11.3,23.5),.48,SG.details,true)
 -- Helm: polygon ring, spokes, handles; upright on the quarterdeck.
 sp("Helm_Pedestal",V(.6,1.7,.6),CF(0,14.6,20.2),P.wood,SG.details,true)
 for i=0,9 do
  local a=i*2*pi/10; local b=(i+1)*2*pi/10
  sb("Wheel_Rim",V(cos(a)*1.05,15.5+sin(a)*1.05,20),V(cos(b)*1.05,15.5+sin(b)*1.05,20),.16,P.woodLight,SG.details,false)
  sb("Wheel_Spoke",V(0,15.5,20),V(cos(a)*1.35,15.5+sin(a)*1.35,20),.11,P.gold,SG.details,false)
 end
 -- Hatch with raised coaming and grating.
 sp("Hatch_Shadow",V(4.8,.15,4.2),CF(0,8.64,2),P.woodDark,SG.details,false)
 for i=-2,2 do sp("Hatch_Grating",V(.13,.15,3.9),CF(i*.85,8.8,2),P.iron,SG.details,false) end
 for i=-2,2 do sp("Hatch_Cross_Grating",V(4.6,.16,.13),CF(0,8.82,2+i*.7),P.iron,SG.details,false) end
 for _,x in ipairs({-2.45,2.45}) do sp("Hatch_Coaming",V(.2,.45,4.5),CF(x,8.8,2),P.woodLight,SG.details,true) end
 for _,z in ipairs({-.15,4.15}) do sp("Hatch_Coaming",V(4.9,.45,.2),CF(0,8.8,z),P.woodLight,SG.details,true) end
 for i=1,5 do barrel("Ship_Rum",ShipCF*CF(4.8,9.5,-15+i*4),.88,SG.details) end
 for i=1,3 do crate("Powder_Crate",ShipCF*CF(-4.9,9.4,-14+i*5),.8,SG.details) end
 -- Capstan and anchor cable.
 sp("Capstan_Base",V(1.7,.25,1.7),CF(0,10.35,-24),P.iron,SG.details,true)
 sp("Capstan_Drum",V(.8,1,.8),CF(0,10.95,-24),P.wood,SG.details,true)
 sp("Capstan_Arm",V(3.3,.15,.20),CF(0,11.35,-24),P.gold,SG.details,false)
 for _,side in ipairs({-1,1}) do
  sb("Anchor_Shank",V(side*5.6,7.8,-22),V(side*5.9,3.5,-22.5),.20,P.iron,SG.trim,false)
  sb("Anchor_Stock",V(side*5.9-1,6.8,-22.2),V(side*5.9+1,6.8,-22.2),.18,P.wood,SG.trim,false)
  for _,q in ipairs({-1,1}) do
   sb("Anchor_Fluke",V(side*5.9,3.6,-22.5),V(side*5.9+q*1,4.2,-22.5),.24,P.iron,SG.trim,false)
  end
 end
 mast("Foremast",-15,34.5); mast("Mainmast",1,38); mast("Mizzenmast",18,30)
 sail("Fore_Course",-15,14.2,24,6.2,true)
 sail("Fore_Topsail",-15,25.3,30.6,4.8,false)
 sail("Main_Course",1,15.2,26,6.8,true)
 sail("Main_Topsail",1,27.3,33.6,5,false)
 sail("Mizzen_Sail",18,17.5,25.1,3.9,false)
 -- Jib between bowsprit and foremast.
 sq("Triangular_Jib",V(0,14.1,-42),V(0,28.6,-15),V(0,17.4,-19),V(0,14.1,-42),.10,P.sail,SG.sails,true)
 for _,x in ipairs({-.07,.07}) do
  sb("Forestay",V(x,14.15,-44),V(x,33.5,-15),.075,P.rope,SG.rig,false)
 end
 sb("Main_Stay",V(0,34,-15),V(0,37,1),.07,P.rope,SG.rig,false)
 sb("Aft_Stay",V(0,37,1),V(0,29.8,18),.07,P.rope,SG.rig,false)
 sb("Stern_Backstay",V(0,29.8,18),V(0,15.5,27.5),.07,P.rope,SG.rig,false)
 -- Mooring lines from port side to pier.
 beam("Fore_Mooring_Line",sv(V(-7.3,9,-4)),V(14,4.2,-10),.095,P.rope,G.dock,false)
 beam("Aft_Mooring_Line",sv(V(-6.4,10,23)),V(19,4.2,-6),.095,P.rope,G.dock,false)
 local returnPost=sp("Return_To_Harbor",V(.65,1.4,.65),CF(-5.4,9.4,15),P.gold,SG.details,true)
 prompt(returnPost,"Adaya dön","İSKELE","Move",V(14,5.5,-8))
 sign("Ship_Nameplate",ShipCF*CF(0,14,28.05)*A(0,pi,0),V(6.2,.7,.13),"KARAKARGA","",SG.stern)
end

local function hut(name,cf,w,d,accent)
 local f=folder(name,G.town)
 local function hp(n,size,c,col,tex,mat,collide) return part(name.."_"..n,size,cf*c,col,f,tex,mat,collide) end
 hp("Floor",V(w+.5,.35,d+.5),CF(0,.18,0),P.woodLight,true)
 for _,x in ipairs({-w/2,w/2}) do
  for i=0,5 do hp("Side_Plank",V(.25,.52,d),CF(x,.65+i*.55,0),i%2==0 and P.wood or P.woodLight,true) end
 end
 for i=0,5 do hp("Rear_Plank",V(w,.52,.25),CF(0,.65+i*.55,d/2),P.wood,true) end
 -- Front counter open to the visitor.
 hp("Counter",V(w+.3,.25,1.6),CF(0,1.8,-d/2-.5),P.woodLight,true)
 hp("Counter_Front",V(w,.95,.22),CF(0,1,-d/2-.45),accent,true)
 for _,x in ipairs({-w/2,w/2}) do hp("Corner_Post",V(.38,4.5,.38),CF(x,2.3,-d/2),P.woodDark,true) end
 -- Individually angled roof planks, clean ridge, overhang and gold fascia.
 for _,side in ipairs({-1,1}) do for i=0,9 do
  hp("Roof_Panel",V((w/2+.9),.20,(d+1.6)/10-.025),CF(side*(w/4+.28),4.2,-d/2-.8+(i+.5)*(d+1.6)/10)*A(0,0,side*rad(-21)),i%3==0 and accent:Lerp(P.iron,.25) or accent,true)
 end end
 hp("Ridge",V(.25,.3,d+1.7),CF(0,4.93,0),P.woodDark,true)
 hp("Sign_Frame",V(w*.85,1,.2),CF(0,3.4,-d/2-.16),P.woodDark,true)
 lantern(name.."_Lamp",cf*CF(-w/2+.6,2.6,-d/2-.55),.55,f,true)
 return f
end
local function chest(name,cf,s,parent,open)
 part(name.."_Body",V(2.4,1.3,1.5)*s,cf,P.wood,parent,true)
 for _,x in ipairs({-.9,.9}) do part(name.."_GoldBand",V(.14,1.4,1.58)*s,cf*CF(x*s,0,0),P.gold,parent,false) end
 local lid=cf*CF(0,.75*s,.58*s)*A(rad(open and -48 or 0),0,0)*CF(0,0,-.58*s)
 part(name.."_Lid",V(2.5,.42,1.58)*s,lid,P.woodLight,parent,true)
 part(name.."_Latch",V(.35,.45,.12)*s,cf*CF(0,.25*s,-.82*s),P.goldLight,parent,false)
 if open then
  for i=0,14 do
   part(name.."_Coin",V(.33,.08,.33)*s,cf*CF(((i*7)%9-4)*.2*s,.72*s+(i%3)*.07,((i*5)%7-3)*.15*s)*A(0,i,0),P.goldLight,parent,false,nil,false)
  end
 end
end
local function buildOutpost()
 local trading=CF(-35,3.85,-5)*A(0,rad(10),0)
 hut("Tide_Market",trading,7,5,P.teal)
 sign("Market_Sign",trading*CF(0,3.4,-2.76),V(5.5,.88,.1),"GANİMET PAZARI","LİMAN TÜCCARI",G.town)
 barrel("Merchant_Rum",trading*CF(-2,1,-.3),.8,G.town)
 chest("Merchant_Chest",trading*CF(1.7,.8,0),.65,G.town,false)
 local inn=CF(-39,3.85,9)*A(0,rad(73),0)
 hut("Crooked_Compass_Tavern",inn,8,6,P.red)
 sign("Tavern_Sign",inn*CF(0,3.4,-3.26),V(6.2,.9,.12),"KIRIK PUSULA","KAPTANLARIN SIĞINAĞI",G.town)
 for i=0,2 do barrel("Tavern_Supply",inn*CF(2-i*1.6,1,1.5),.75,G.town) end
 -- Outdoor bench and low table overlooking the harbor.
 part("Tavern_Table",V(4,.24,2.2),CF(-31,5,12),P.woodLight,G.town,true)
 for _,x in ipairs({-32.4,-29.6}) do part("Table_Leg",V(.25,1.2,1.6),CF(x,4.3,12),P.woodDark,G.town,true) end
 for _,z in ipairs({9.9,14.1}) do
  part("Bench",V(4,.22,.7),CF(-31,4.55,z),P.plank,G.town,true)
  for _,x in ipairs({-32.4,-29.6}) do part("Bench_Support",V(.3,.8,.5),CF(x,4.05,z),P.woodDark,G.town,false) end
 end
 lantern("Table_Lantern",CF(-31,5.65,12),.48,G.town,true)
 -- Expedition arch; game destination is explicit and configurable.
 local gate=CF(-20,3.85,-8)*A(0,rad(-12),0)
 for _,side in ipairs({-1,1}) do
  for i=0,5 do part("Gate_Stone",V(1.1,.70,1.2),gate*CF(side*3.1,.45+i*.72,0)*A(0,rad(i%2*3),0),i%2==0 and P.rock or P.rockLight,G.town,true) end
  lantern("Gate_Lantern",gate*CF(side*3.1,5,0),.6,G.town,true)
 end
 part("Gate_Timber",V(7.5,.7,1.25),gate*CF(0,4.5,0),P.woodDark,G.town,true)
 sign("Expedition_Header",gate*CF(0,4.65,-.71),V(6.2,1.4,.16),"AÇIK DENİZ SEFERİ","MÜRETTEBATINI TOPLA",G.town)
 local portal=part("Expedition_Interaction",V(3.7,.15,3.3),gate*CF(0,.03,-.1),P.teal,G.logic,true)
 prompt(portal,Config.GamePlaceId>0 and "Sefere başla" or "Sefer bilgisi","AÇIK DENİZ","Expedition")
 for i=0,3 do
  local width=4.8-i*.5
  part("Portal_Inlay",V(width,.035,.09),gate*CF(0,.13,-1.3+i*.65),P.gold,G.town,false,nil,false)
 end
 if Config.GamePlaceId==0 then sign("Setup_PlaceId_Note",gate*CF(0,1.25,1.9)*A(0,pi,0),V(4.5,1.4,.16),"SEFER HAZIRLANIYOR","HEDEF OYUN HENÜZ AYARLANMADI",G.town) end
 -- Map board is a physical relief map, not an external image.
 local board=CF(-15,6,4)*A(0,rad(48),0)
 part("Quest_Board",V(5,3.5,.25),board,P.woodDark,G.town,true)
 part("Quest_Parchment",V(4.3,2.9,.05),board*CF(0,0,-.16),P.ivory,G.town,false)
 for i=0,5 do part("Chart_Island",V(.4+i%2*.2,.35,.06),board*CF(-1.4+i*.53,sin(i*1.8)*.6,-.22)*A(0,0,i),P.sandDark,G.town,false,nil,false) end
 for _,x in ipairs({-1.9,1.9}) do part("Board_Post",V(.25,3,.25),board*CF(x,-2,0),P.wood,G.town,true) end
 sign("Chart_Header",board*CF(0,2.1,0),V(5, .65,.22),"KAYIP ADALAR HARİTASI","",G.town)
 -- Treasure nook: broken wall, chest, shovel, coins.
 chest("Hidden_Captains_Treasure",CF(-22,4.35,20)*A(0,rad(-25),0),1,G.decor,true)
 for i=0,8 do part("Treasure_Coin_Spill",V(.30,.065,.30),CF(-23+(i%4)*.5,3.65,18.5+math.floor(i/4)*.6)*A(0,i,0),P.goldLight,G.decor,false,nil,false) end
 beam("Shovel_Handle",V(-19,3.4,21),V(-18.8,6.1,21.3),.13,P.woodLight,G.decor,false)
 part("Shovel_Blade",V(.7,.85,.12),CF(-19,3.5,21)*A(rad(-12),0,0),P.iron,G.decor,false)
 for i=0,7 do part("Ruined_Sea_Wall",V(1.3,1.3+(i%3)*.4,1.4),CF(-25+i*1.3,3.5,23.1)*A(0,rad(i%2*9),0),P.rock,G.decor,true) end
 -- Arrival pad: functional Roblox SpawnLocation.
 local spawn=Instance.new("SpawnLocation"); spawn.Name="Lobby_Spawn"; spawn.Size=V(5,.18,5)
 spawn.CFrame=CF(O+IC+V(0,4.03,0)); spawn.Color=P.sandLight; spawn.Material=Enum.Material.Plastic
 spawn.Anchored=true; spawn.Neutral=true; spawn.Duration=0; spawn.AllowTeamChangeOnTouch=false
 spawn.TopSurface=Enum.SurfaceType.Smooth; spawn.BottomSurface=Enum.SurfaceType.Smooth
 spawn.Parent=G.logic; counts.parts+=1
 -- Native SpawnLocation decoration is intentionally hidden with an opaque plate.
 part("Arrival_Compass_Back",V(5.2,.12,5.2),CF(IC+V(0,4.18,0)),P.woodDark,G.town,true)
 for i=0,7 do local a=i*pi/4
  part("Compass_Ray",V(.22,.05,i%2==0 and 2.2 or 1.45),CF(IC+V(sin(a)*.95,4.28,cos(a)*.95))*A(0,a,0),P.gold,G.town,false,nil,false)
 end
 sign("Welcome_To_Karakarga",CF(-27,7.4,8.9),V(8,2.1,.28),"KARAKARGA KOYU","BİR MÜRETTEBAT • SONSUZ MACERA",G.town)
 for _,x in ipairs({-31,-23}) do part("Welcome_Support",V(.27,3.7,.3),CF(x,5.3,9),P.woodDark,G.town,true) end
end
local function buildLighthouse()
 local base=V(-46,4.1,20)
 local f=folder("Old_Harbor_Lighthouse",G.town)
 part("Lighthouse_Stone_Foundation",V(5.6,2.6,5.6),CF(base-V(0,1.3,0)),P.rockDark,f,true)
 for layer=0,11 do
  local y=layer*.64; local r=2.15-layer*.065
  for k=0,7 do
   local a=k*pi/4
   part("Lighthouse_Masonry",V(r*.82,.62,.42),CF(base+V(cos(a)*r,y,sin(a)*r))*A(0,-a+pi/2,0),layer%4==2 and P.red or P.sandLight,f,true)
  end
 end
 part("Beacon_Platform",V(5.2,.28,5.2),CF(base+V(0,7.8,0)),P.woodDark,f,true)
 local lamp=part("Lighthouse_Beacon",V(1.5,1.65,1.5),CF(base+V(0,9,0)),P.glow,f,false,Enum.Material.Neon,false)
 pointLight(lamp,2.2,34)
 for _,x in ipairs({-1.6,1.6}) do for _,z in ipairs({-1.6,1.6}) do
  part("Beacon_Frame",V(.16,2.5,.16),CF(base+V(x,9,z)),P.iron,f,false)
 end end
 for _,side in ipairs({-1,1}) do
  part("Beacon_Cap",V(2.8,.18,4.4),CF(base+V(side*1.15,10.6,0))*A(0,0,side*rad(-24)),P.iron,f,true)
 end
 part("Beacon_Finial",V(.17,1,.17),CF(base+V(0,11.5,0)),P.gold,f,false)
 -- External ladder with a real truss climb surface.
 local ladder=Instance.new("TrussPart"); ladder.Name="Lighthouse_Climbable_Ladder"
 ladder.Size=V(2,8,2); ladder.CFrame=CF(O+base+V(0,3.7,-2.2)); ladder.Anchored=true
 ladder.Color=P.woodDark; ladder.Material=Enum.Material.Plastic; ladder.Parent=f; counts.parts+=1
 for i=0,9 do beam("Lighthouse_Gallery_Rail",base+V(-2.3+i*.51,8.7,-2.4),base+V(-2.3+i*.51,7.9,-2.4),.10,P.gold,f,false) end
 part("Gallery_Handrail",V(5,.15,.15),CF(base+V(0,8.8,-2.4)),P.gold,f,false)
end
local function buildAmbience()
 -- A tiny wrecked rowboat on the beach.
 local cf=CF(-7,1.8,19)*A(rad(5),rad(-33),rad(-8))
 for i=-3,3 do
  local width=1.35*(1-(math.abs(i)/4)^2)
  part("Rowboat_Floor",V(width*2,.15,.58),cf*CF(0,0,i*.58),P.woodLight,G.decor,true)
  for _,s in ipairs({-1,1}) do part("Rowboat_Gunwale",V(.14,.65,.62),cf*CF(s*width,.32,i*.58),P.wood,G.decor,true) end
 end
 for _,z in ipairs({-.8,.8}) do part("Rowboat_Seat",V(2.4,.15,.4),cf*CF(0,.55,z),P.woodDark,G.decor,true) end
 beam("Abandoned_Oar",V(-9,2.8,18),V(-5,3,21),.15,P.woodLight,G.decor,false)
 part("Oar_Blade",V(.65,.13,1),CF(-5,3,21)*A(0,rad(50),0),P.wood,G.decor,true)
 -- Sparse seabirds: static silhouettes, no unnecessary frame loop.
 for i=1,6 do
  local pos=V(-55+i*15,24+(i%3)*4,-34-i*5)
  for _,side in ipairs({-1,1}) do
   beam("Seabird_Wing",pos,pos+V(side*1.2,.35,.14),.11,P.ivory,G.fx,false,.16)
   beam("Seabird_Wingtip",pos+V(side*1.2,.35,.14),pos+V(side*1.7,.20,.35),.08,P.ivory,G.fx,false,.12)
  end
 end
 if Config.EnableAmbientParticles then
  local fire=part("Brazier_Firebed",V(1.2,.22,1.2),CF(-17,4.6,9),P.iron,G.fx,true)
  for k=0,5 do
   local a=k*pi/3
   part("Brazier_Stone",V(.6,.45,.45),CF(-17+cos(a)*.9,4.4,9+sin(a)*.9)*A(0,-a,0),P.rock,G.fx,true)
  end
  local att=Instance.new("Attachment"); att.Parent=fire
  local function emit(name,id,rate,life,speed,size,col)
   local e=Instance.new("ParticleEmitter"); e.Name=name; e.Texture="rbxassetid://"..id
   e.Rate=rate; e.Lifetime=life; e.Speed=speed; e.Size=size
   e.Color=col; e.LightEmission=.8; e.LightInfluence=0
   e.SpreadAngle=Vector2.new(15,15); e.EmissionDirection=Enum.NormalId.Top
   e.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,.2),NumberSequenceKeypoint.new(.55,.3),NumberSequenceKeypoint.new(1,1)})
   e.Parent=att; return e
  end
  emit("Small_Harbor_Fire",6706234595,9,NumberRange.new(.45,.8),NumberRange.new(.8,1.6),NumberSequence.new(.6,1.1),ColorSequence.new(P.glow,Color3.fromRGB(233,91,24)))
  local sparks=emit("Drifting_Embers",867619398,3,NumberRange.new(.7,1.2),NumberRange.new(1.2,2.1),NumberSequence.new(.10,0),ColorSequence.new(P.goldLight,P.red))
  sparks.Acceleration=V(.35,1,.15)
  pointLight(fire,1.5,15)
 end
end
local function installRuntime()
 local s=Instance.new("Script"); s.Name="Karakarga_Lobby_Server"
 s.Source=[==[
local model=script.Parent
local Players=game:GetService("Players")
local TeleportService=game:GetService("TeleportService")
local cooldown={}
local home=model:FindFirstChild("Lobby_Spawn",true)
local function notify(player,message)
 local gui=Instance.new("ScreenGui"); gui.Name="Harbor_Notice"; gui.ResetOnSpawn=false
 local label=Instance.new("TextLabel"); label.AnchorPoint=Vector2.new(.5,0)
 label.Position=UDim2.fromScale(.5,.10); label.Size=UDim2.fromScale(.62,.09)
 label.BackgroundColor3=Color3.fromRGB(24,32,40); label.BackgroundTransparency=.12
 label.TextColor3=Color3.fromRGB(242,211,150); label.Text=message
 label.TextWrapped=true; label.Font=Enum.Font.GothamBold; label.TextScaled=true; label.Parent=gui
 local corner=Instance.new("UICorner"); corner.CornerRadius=UDim.new(0,10); corner.Parent=label
 local pad=Instance.new("UIPadding"); pad.PaddingLeft=UDim.new(0,14); pad.PaddingRight=UDim.new(0,14); pad.Parent=label
 local pg=player:FindFirstChildOfClass("PlayerGui"); if pg then gui.Parent=pg; task.delay(4,function() gui:Destroy() end) else gui:Destroy() end
end
for _,pr in ipairs(model:GetDescendants()) do
 if pr:IsA("ProximityPrompt") and pr:GetAttribute("Action") then
  pr.Triggered:Connect(function(player)
   if cooldown[player] and os.clock()-cooldown[player]<1 then return end
   cooldown[player]=os.clock()
   local char=player.Character; local hrp=char and char:FindFirstChild("HumanoidRootPart")
   local hum=char and char:FindFirstChildOfClass("Humanoid")
   if not hrp or not hum or hum.Health<=0 then return end
   -- Server checks proximity as well as the native prompt UI.
   local source=pr.Parent
   if not source:IsA("BasePart") or (hrp.Position-source.Position).Magnitude>pr.MaxActivationDistance+8 then return end
   if pr:GetAttribute("Action")=="Move" then
    local pos=pr:GetAttribute("Destination")
    if typeof(pos)=="Vector3" then
     char:PivotTo(CFrame.new(pos)); hrp.AssemblyLinearVelocity=Vector3.zero; hrp.AssemblyAngularVelocity=Vector3.zero
    end
   elseif pr:GetAttribute("Action")=="Expedition" then
    local placeId=model:GetAttribute("GamePlaceId")
    if type(placeId)~="number" or placeId<=0 then
     notify(player,"Sefer henüz açılmadı. Harita sahibi hedef PlaceId'yi ayarlamalı."); return
    end
    notify(player,"Mürettebat hazırlanıyor… Açık denize çıkılıyor!")
    local ok,err=pcall(function() TeleportService:TeleportAsync(placeId,{player}) end)
    if not ok then warn("[Karakarga] Teleport failed: "..tostring(err)); notify(player,"Sefer başlatılamadı. Yayın, erişim ve PlaceId ayarlarını kontrol edin.") end
   end
  end)
 end
end
TeleportService.TeleportInitFailed:Connect(function(player,result,message,placeId)
 if placeId==model:GetAttribute("GamePlaceId") then notify(player,"Işınlanma tamamlanamadı. Lütfen yeniden deneyin.") end
end)
Players.PlayerRemoving:Connect(function(player) cooldown[player]=nil end)
-- Ocean is decorative and non-collidable. Return swimmers to the island.
local elapsed=0
local connection
connection=game:GetService("RunService").Heartbeat:Connect(function(dt)
 elapsed+=dt; if elapsed<.7 then return end; elapsed=0
 if not model.Parent then connection:Disconnect(); return end
 if not home then return end
 for _,player in ipairs(Players:GetPlayers()) do
  local ch=player.Character; local hrp=ch and ch:FindFirstChild("HumanoidRootPart")
  if hrp and hrp.Position.Y<home.Position.Y-7 then
   local p=hrp.Position; local origin=model:GetAttribute("WorldOrigin") or Vector3.zero
   if math.abs(p.X-origin.X)<190 and math.abs(p.Z-origin.Z)<190 then
    ch:PivotTo(home.CFrame + Vector3.new(0,4,0))
    hrp.AssemblyLinearVelocity=Vector3.zero; hrp.AssemblyAngularVelocity=Vector3.zero
   end
  end
 end
end)
]==]
 s.Parent=root
end
local function setupLighting()
 if not Config.SetLighting then return end
 -- Only our own post-processing instances are replaced. Existing project effects remain.
 Lighting.ClockTime=17.55; Lighting.Brightness=2.25
 Lighting.Ambient=Color3.fromRGB(83,101,120)
 Lighting.OutdoorAmbient=Color3.fromRGB(115,130,143)
 Lighting.ColorShift_Top=Color3.fromRGB(255,225,185)
 Lighting.GlobalShadows=true
 local function effect(class,name)
  local old=Lighting:FindFirstChild(name); if old then old:Destroy() end
  local e=Instance.new(class); e.Name=name; e.Parent=Lighting; return e
 end
 local cc=effect("ColorCorrectionEffect","Babaar_Harbor_Color")
 cc.Contrast=.08; cc.Saturation=.04; cc.TintColor=Color3.fromRGB(255,244,229)
 local bloom=effect("BloomEffect","Babaar_Harbor_Bloom")
 bloom.Intensity=.18; bloom.Size=20; bloom.Threshold=1.7
 -- Reuse the engine's single atmosphere if present, rather than stacking conflicting ones.
 local at=Lighting:FindFirstChildOfClass("Atmosphere") or effect("Atmosphere","Babaar_Harbor_Atmosphere")
 at.Density=.20; at.Offset=.12; at.Color=Color3.fromRGB(189,211,220)
 at.Decay=Color3.fromRGB(121,146,166); at.Glare=.15; at.Haze=1.1
end

pcall(function() History:SetWaypoint("Before_Babaar_PirateLobby") end)
local previous=W:FindFirstChild(Config.ModelName)
local ok,err=xpcall(function()
 buildOcean(); buildIsland(); buildDock(); buildShip()
 buildOutpost(); buildLighthouse(); buildAmbience(); installRuntime()
 root:SetAttribute("WorldOrigin",O)
 root:SetAttribute("PartCount",counts.parts); root:SetAttribute("TextureCount",counts.textures)
 root:SetAttribute("LightCount",counts.lights)
end,debug.traceback)
if not ok then root:Destroy(); error("[Karakarga] Build stopped; previous map was preserved.\n"..tostring(err)) end
-- Commit only after successful generation.
root.Parent=W
if previous then previous:Destroy() end
setupLighting()
local pivot=root:FindFirstChild("Lobby_Spawn",true)
if pivot then root.PrimaryPart=pivot end
if Config.FrameCamera and W.CurrentCamera then
 W.CurrentCamera.CFrame=CFrame.lookAt(O+V(112,84,-128),O+V(1,10,-7))
 W.CurrentCamera.Focus=CF(O+V(1,10,-7))
end
pcall(function() Selection:Set({root}); History:SetWaypoint("Created_Babaar_PirateLobby") end)
print(string.format("[KARAKARGA KOYU] Built: %d Parts | %d Textures | %d Lights. Press Play to test spawn, boarding, sea recovery and expedition prompt.",counts.parts,counts.textures,counts.lights))
if Config.GamePlaceId==0 then warn("[Karakarga] Expedition destination not configured. Set model attribute GamePlaceId to your published place ID.") end
