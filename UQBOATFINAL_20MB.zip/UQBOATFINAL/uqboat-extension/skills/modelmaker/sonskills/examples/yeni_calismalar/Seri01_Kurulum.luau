--[[
BABAAR YAPAR | CREATURES & MACHINES — SERIES 01 / 10 DISTINCT ASSETS
Studio EDIT mode Command Bar installer. NOT a normal server Script.
Builds 10 separate self-contained rigs, baked clips and conservative VFX.
No AI, damage, driving, combat or missile-launch gameplay is included.
Publish each baked clip and assign AnimationId attributes for production.
Studio preview tries KeyframeSequenceProvider, with an explicit warning on failure.
No meshes, imported scripts, CSG or physical 3D studs are required.
]]
local Config={
 CollectionName="BabaarYapar_Assets_Seri01",
 Only={}, -- empty = all; e.g. {"f16"} or {"griffin","wolf"}
 Origin=Vector3.new(0,1,0),
 Spacing=48,
 Scale=1,
 Detail="High", -- "High" / "Medium". Changes decorative geometry, NOT the rig.
 StudTextures=true,
 StudImageOverride="", -- actual image URI; model IDs are not image IDs
 StudSourceModelId=9454666962,
 StudTile=.72,
 TextureAlpha=.56,
 BakeFPS=12, -- offline baked poses; rendering/Animator are not locked to 12fps
 UseExternalVFX=true, -- false: built-in particle images; also verify stud image rights
 CreateQueryHitbox=true,
 InstallRuntime=true,
 StudioPreview=true,
 MaxPartBudgetPerAsset=950,
 YieldEvery=150,
 FrameCamera=true,
}
local V,CF,ANG=Vector3.new,CFrame.new,CFrame.Angles
local rad,pi,tau=math.rad,math.pi,math.pi*2
local sin,cos=math.sin,math.cos
local Workspace=game:GetService("Workspace")
local History=game:GetService("ChangeHistoryService")
local Selection=game:GetService("Selection")
local S=Config.Scale
assert(S>0 and Config.BakeFPS>=4 and Config.BakeFPS<=30,"Scale/FPS out of range")
assert(Config.Detail=="High" or Config.Detail=="Medium","Detail must be High or Medium")
local HIGH=Config.Detail=="High"
local function rgb(r,g,b) return Color3.fromRGB(r,g,b) end
local C={black=rgb(23,28,36),dark=rgb(45,50,57),ivory=rgb(236,225,194),
 gold=rgb(200,151,71),goldLight=rgb(239,198,108),red=rgb(139,46,42),
 ember=rgb(255,115,31),hot=rgb(255,228,135),blue=rgb(72,178,233),
 steel=rgb(103,120,130),steelLight=rgb(151,166,165),olive=rgb(106,119,94),
 brown=rgb(112,72,43),tan=rgb(174,135,81),white=rgb(220,228,227)}
local function smooth(x) x=math.clamp(x,0,1);return x*x*(3-2*x) end
local function unit(v,f) return v.Magnitude>.00001 and v.Unit or (f or V(0,1,0)) end
local function frameAt(a,b)
 local d=unit(b-a,V(0,0,1));return CFrame.lookAt((a+b)/2,b,math.abs(d.Y)>.97 and V(0,0,1) or V(0,1,0))
end
local function folder(name,parent,class)
 local f=Instance.new(class or "Folder");f.Name=name;f.Parent=parent;return f
end
local function scaled(cf) return CF(cf.Position*S)*cf.Rotation end
local function resolveStud()
 if not Config.StudTextures then return "" end
 if Config.StudImageOverride~="" then
  local s=tostring(Config.StudImageOverride);return tonumber(s) and "rbxassetid://"..s or s
 end
 local old=Workspace:FindFirstChild(Config.CollectionName)
 if old and old:GetAttribute("StudImage") and old:GetAttribute("StudImage")~="" then return old:GetAttribute("StudImage") end
 local uri,best="",-1
 local function inspect(asset)
  local all={asset};for _,p in ipairs(asset:GetDescendants()) do table.insert(all,p) end
  for _,p in ipairs(all) do if p:IsA("LuaSourceContainer") then p:Destroy() end end
  for _,p in ipairs(all) do
   local image,score="",0
   if p:IsA("Texture") then image,score=p.Texture,20 elseif p:IsA("Decal") then image,score=p.Texture,10 end
   if string.find(string.lower(p.Name),"stud",1,true) then score+=30 end
   if image~="" and image~="rbxassetid://"..Config.StudSourceModelId and score>best then uri,best=image,score end
  end
  asset:Destroy()
 end
 for _,loader in ipairs({
  function() return game:GetObjects("rbxassetid://"..Config.StudSourceModelId) end,
  function() return {game:GetService("InsertService"):LoadAsset(Config.StudSourceModelId)} end,
 }) do
  local ok,assets=pcall(loader)
  if ok and type(assets)=="table" then for _,a in ipairs(assets) do inspect(a) end end
  if uri~="" then break end
 end
 if uri=="" then warn("[Series01] Stud image unavailable. Set StudImageOverride. No physical studs will be substituted.") end
 return uri
end
local StudImage=resolveStud()
local collection=Instance.new("Model");collection.Name=Config.CollectionName
collection:SetAttribute("StudImage",StudImage)
local CTX={};CTX.__index=CTX
local function newAsset(key,name,position,palette)
 local self=setmetatable({},CTX)
 self.key=key;self.name=name;self.palette=palette;self.count=0;self.textureCount=0;self.motorCount=0
 self.nodes={};self.order={};self.world=CF(position)
 self.model=Instance.new("Model");self.model.Name=name;self.model.Parent=collection
 self.model:SetAttribute("AssetKey",key);self.model:SetAttribute("Series",1)
 self.model:SetAttribute("Scale",S);self.model:SetAttribute("Detail",Config.Detail)
 self.model:SetAttribute("ActiveClip","Idle");self.model:SetAttribute("AnimationEnabled",true)
 self.model:SetAttribute("VFXQuality",1);self.model:SetAttribute("ActivationDistance",120*S)
 self.model:SetAttribute("StudioPreview",Config.StudioPreview)
 self.model:SetAttribute("RigContract","Babaar_Series01_PivotRig_v1")
 self.geo=folder("Geometry",self.model);self.rig=folder("Rig",self.model)
 self.fx=folder("VFX",self.model);self.clips=folder("AnimSaves",self.model,"Model");self.clipMeta=folder("ClipSpecs",self.model)
 local root=Instance.new("Part");root.Name="RootPart";root.Size=V(.5,.5,.5)*S
 root.CFrame=self.world;root.Transparency=1;root.Anchored=true;root.CanCollide=false
 root.CanTouch=false;root.CanQuery=false;root.CastShadow=false;root.Parent=self.rig
 self.root=root;self.model.PrimaryPart=root
 self.nodes.RootPart={name="RootPart",part=root,rest=CF(),children={}}
 self.order[1]=self.nodes.RootPart
 local controller=Instance.new("AnimationController");controller.Parent=self.model
 local animator=Instance.new("Animator");animator.Parent=controller
 return self
end
function CTX:bone(name,parent,pos)
 assert(not self.nodes[name],"Duplicate bone "..name)
 local pn=assert(self.nodes[parent],"Missing parent "..parent)
 local rest=typeof(pos)=="CFrame" and pos or CF(pos)
 local p=Instance.new("Part");p.Name=name;p.Size=V(.22,.22,.22)*S
 p.CFrame=self.world*scaled(rest);p.Transparency=1;p.Anchored=false;p.Massless=true
 p.CanCollide=false;p.CanTouch=false;p.CanQuery=false;p.CastShadow=false;p.Parent=self.rig
 local motor=Instance.new("Motor6D");motor.Name="Joint_"..name
 motor.Part0=pn.part;motor.Part1=p;motor.C0=scaled(pn.rest:ToObjectSpace(rest));motor.C1=CF();motor.Parent=pn.part
 local node={name=name,part=p,rest=rest,parent=pn,children={},motor=motor}
 self.nodes[name]=node;table.insert(pn.children,node);table.insert(self.order,node);self.motorCount+=1
 return node
end
function CTX:texture(p,faces,alpha)
 if StudImage=="" then return end
 for _,face in ipairs(faces or {Enum.NormalId.Top,Enum.NormalId.Front}) do
  local t=Instance.new("Texture");t.Name="StudSurface";t.Texture=StudImage;t.Face=face
  t.Color3=p.Color;t.Transparency=alpha or Config.TextureAlpha
  t.StudsPerTileU=Config.StudTile*S;t.StudsPerTileV=Config.StudTile*S;t.Parent=p
  self.textureCount+=1
 end
end
function CTX:part(name,bone,size,cf,color,textured,mat,class,alpha)
 assert(self.count<Config.MaxPartBudgetPerAsset,"Part budget exceeded: "..self.key)
 assert(math.min(size.X,size.Y,size.Z)>0,"Nonpositive geometry "..name)
 local node=assert(self.nodes[bone],"No bone "..bone)
 local p=Instance.new(class or "Part");p.Name=name;p.Size=size*S;p.CFrame=self.world*scaled(cf)
 p.Color=color;p.Material=mat or Enum.Material.Plastic;p.Anchored=false;p.Massless=true
 p.CanCollide=false;p.CanTouch=false;p.CanQuery=false;p.CastShadow=true
 p.TopSurface=Enum.SurfaceType.Smooth;p.BottomSurface=Enum.SurfaceType.Smooth
 p.Transparency=alpha or 0;p:SetAttribute("CarrierBone",bone);p.Parent=self.geo
 local weld=Instance.new("WeldConstraint");weld.Part0=node.part;weld.Part1=p;weld.Parent=p
 if textured and p.Material~=Enum.Material.Neon then self:texture(p) end
 self.count+=1;if self.count%Config.YieldEvery==0 then task.wait() end
 return p
end
function CTX:beam(name,bone,a,b,w,h,col,textured)
 if (b-a).Magnitude<.005 then return end
 return self:part(name,bone,V(w,h,(b-a).Magnitude+.05),frameAt(a,b),col,textured)
end
function CTX:plate(name,bone,size,cf,col)
 self:part(name.."_Recess",bone,size+V(.07,.02,.07),cf*CF(0,-.035,0),col:Lerp(C.black,.45),false)
 -- Two broad tonal strips are enough for most accent plates; no tiny band explosion.
 for i=1,2 do
  local z=(i-1.5)*size.Z/2
  local p=self:part(name.."_Tone"..i,bone,V(size.X,size.Y,size.Z/2+.002),cf*CF(0,0,z),col:Lerp(C.ivory,i*.045),false)
  if HIGH then
   self:texture(p,{Enum.NormalId.Top})
   local t=p:FindFirstChild("StudSurface");if t then t.OffsetStudsV=z*S end
  end
 end
end
function CTX:tri(name,bone,a,b,c,t,col,studs,mat,alpha)
 local ab,ac,bc=b-a,c-a,c-b
 if ab:Dot(ab)>ac:Dot(ac) and ab:Dot(ab)>bc:Dot(bc) then a,c=c,a elseif ac:Dot(ac)>ab:Dot(ab) and ac:Dot(ac)>bc:Dot(bc) then a,b=b,a end
 ab,ac,bc=b-a,c-a,c-b;local cross=ac:Cross(ab)
 if cross.Magnitude<.00001 or bc.Magnitude<.001 then return end
 local right,back=cross.Unit,bc.Unit;local up=back:Cross(right).Unit
 local h,l1,l2=math.abs(ab:Dot(up)),math.abs(ab:Dot(back)),math.abs(ac:Dot(back))
 if h<.008 then return end
 if l1>.008 then local p=self:part(name.."A",bone,V(t,h,l1),CFrame.fromMatrix((a+b)/2,right,up,back),col,false,mat,"WedgePart",alpha);if studs then self:texture(p,{Enum.NormalId.Left,Enum.NormalId.Right},.67) end end
 if l2>.008 then local p=self:part(name.."B",bone,V(t,h,l2),CFrame.fromMatrix((a+c)/2,-right,up,-back),col,false,mat,"WedgePart",alpha);if studs then self:texture(p,{Enum.NormalId.Left,Enum.NormalId.Right},.67) end end
end
function CTX:fin(name,bone,a,b,c,col)
 self:tri(name.."_DarkHem",bone,a,b,c,.18,col:Lerp(C.black,.45),false)
 local mid=(a+b+c)/3
 self:tri(name,bone,mid+(a-mid)*.94,mid+(b-mid)*.94,mid+(c-mid)*.94,.23,col,true)
end
function CTX:taper(name,bone,points,widths,col)
 for i=1,#points-1 do
  local n=HIGH and 3 or 2
  for k=1,n do
   local u,v=(k-1)/n,k/n;local w=widths[i]+((widths[i+1] or .045)-widths[i])*(u+v)/2
   self:beam(name.."_"..i.."_"..k,bone,points[i]:Lerp(points[i+1],u),points[i]:Lerp(points[i+1],v),w,w,col:Lerp(C.ivory,(i-1)/(#points-1)*.12),false)
  end
 end
end
function CTX:eye(bone,pos,side,col,size)
 size=size or .3
 self:part("Eye_Socket",bone,V(.09,size*1.7,size*1.8),CF(pos),C.black,false)
 self:part("Eye_Iris",bone,V(.12,size,size),CF(pos+V(side*.055,0,0)),col,false,Enum.Material.Neon)
 self:part("Eye_Pupil",bone,V(.14,size*.8,size*.22),CF(pos+V(side*.09,0,-.02)),C.black,false)
 if HIGH then self:part("Eye_Glint",bone,V(.15,size*.20,size*.20),CF(pos+V(side*.1,size*.23,-size*.20)),C.ivory,false) end
end
function CTX:emitter(name,bone,pos,kind,col,rate)
 local n=self.nodes[bone];local a=Instance.new("Attachment");a.Name=name.."_Origin"
 a.CFrame=scaled(n.rest:ToObjectSpace(CF(pos)));a.Parent=n.part
 local e=Instance.new("ParticleEmitter");e.Name=name;e.Enabled=false;e.Rate=rate or 9
 e:SetAttribute("BaseRate",e.Rate);e:SetAttribute("BurstCount",kind=="dust" and 10 or 14)
 local ids={fire=6706234595,spark=867619398,dust=1084955012,energy=7524756305,feather=258126401,bubble=1084991215}
 e.Texture=Config.UseExternalVFX and ("rbxassetid://"..(ids[kind] or ids.spark)) or ("rbxasset://textures/particles/"..(kind=="dust" and "smoke_main.dds" or (kind=="fire" and "fire_main.dds" or "sparkles_main.dds")))
 e.Color=ColorSequence.new(col,col:Lerp(C.ivory,.35));e.LightEmission=kind=="dust" and .05 or .6
 e.LightInfluence=kind=="dust" and 1 or 0;e.Lifetime=NumberRange.new(.25,.65)
 e.Speed=NumberRange.new(1.0*S,3.2*S);e.SpreadAngle=Vector2.new(18,18)
 e.Size=NumberSequence.new({NumberSequenceKeypoint.new(0,.25*S),NumberSequenceKeypoint.new(.35,.6*S),NumberSequenceKeypoint.new(1,0)})
 e.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,.2),NumberSequenceKeypoint.new(.7,.55),NumberSequenceKeypoint.new(1,1)})
 e.Rotation=NumberRange.new(0,360);e.RotSpeed=NumberRange.new(-35,35)
 e.LockedToPart=false;e.EmissionDirection=Enum.NormalId.Back;e.Drag=1
 if kind=="dust" then e.Acceleration=V(0,.4*S,0) else e.Acceleration=V(0,.7*S,0) end
 if name=="Resonance_Breath" or name=="Cold_Howl_Breath" or name=="Venom_Mist" then e.EmissionDirection=Enum.NormalId.Front end
 if kind=="fire" then e.Size=NumberSequence.new(.65*S,1.65*S);e.Speed=NumberRange.new(4*S,9*S);e.Acceleration=V() end
 if name=="Resonance_Breath" or name=="Venom_Mist" or name=="Cold_Howl_Breath" then e:SetAttribute("EffectClip","Action") end
 e.Parent=a
 local ref=Instance.new("ObjectValue");ref.Name=name;ref.Value=e;ref.Parent=self.fx
 return e
end
-- Reusable anatomy helpers share construction logic, not complete silhouettes.
local function birdWing(ctx,prefix,parent,root,span,chord,col,tipColor)
 for _,side in ipairs({-1,1}) do
  local id=prefix..(side<0 and "L" or "R")
  local shoulder=root+V(side*.65,0,0);local elbow=root+V(side*span*.47,.35,.3)
  local tip=root+V(side*span,.10,chord*.35)
  ctx:bone(id.."Shoulder",parent,shoulder);ctx:bone(id.."Outer",id.."Shoulder",elbow)
  ctx:beam("Wing_Humerus",id.."Shoulder",shoulder,elbow,.48,.45,col,false)
  ctx:beam("Wing_Forearm",id.."Outer",elbow,tip,.30,.32,col,false)
  local n=HIGH and 9 or 6
  for i=0,n-1 do
   local t=(i+.25)/n;local p=shoulder:Lerp(tip,t)
   local bone=t<.47 and id.."Shoulder" or id.."Outer"
   local len=chord*(.6+.45*sin(t*pi))
   local cf=CF(p+V(0,-.09,len*.35))*ANG(rad(-8),side*rad(-9-12*t),side*rad(-3))
   ctx:plate("Primary_Feather",bone,V(span/n*.83,.14,len),cf,i>n*.64 and tipColor or col)
  end
  for i=0,(HIGH and 5 or 3) do
   local t=i/(HIGH and 6 or 4);local p=shoulder:Lerp(elbow,t)
   ctx:part("Layered_Covert",id.."Shoulder",V(.60,.22,chord*.62),CF(p+V(0,.13,.40))*ANG(0,side*rad(-8),0),col:Lerp(C.ivory,.13),true)
  end
 end
end
local function quadrupedLegs(ctx,body,frontZ,rearZ,x,height,col,pawcol)
 ctx.legs={}
 for _,front in ipairs({true,false}) do for _,side in ipairs({-1,1}) do
  local id=(front and "F" or "H")..(side<0 and "L" or "R")
  local z=front and frontZ or rearZ
  local hip=V(side*x,height,z);local knee=V(side*(x+.15),height*.50,z+(front and .25 or -.65));local foot=V(side*(x+.13),.55,z-.10)
  ctx:bone(id.."Upper",body,hip);ctx:bone(id.."Lower",id.."Upper",knee);ctx:bone(id.."Paw",id.."Lower",foot)
  table.insert(ctx.legs,{id=id,hip=hip,knee=knee,foot=foot,front=front,side=side,L1=(knee-hip).Magnitude,L2=(foot-knee).Magnitude})
  local dust=ctx:emitter("Foot_Dust_"..id,id.."Paw",foot-V(0,.38,0),"dust",C.tan,0);dust:SetAttribute("FootId",id)
  ctx:beam("Muscular_UpperLeg",id.."Upper",hip,knee,.72,.80,col,true)
  ctx:beam("Tapered_Shin",id.."Lower",knee,foot,.45,.48,col:Lerp(C.black,.12),false)
  ctx:part("Paw_Pad",id.."Paw",V(.90,.52,1.30),CF(foot+V(0,-.12,-.22)),pawcol,true)
  for j=-1,1 do ctx:part("Toe_Claw",id.."Paw",V(.15,.15,.38),CF(foot+V(j*.27,-.12,-.87))*ANG(rad(-7),0,0),C.ivory,false) end
 end end
end
local function featherTail(ctx,bone,base,spread,len,col)
 for i=-2,2 do
  ctx:plate("Tail_Fan",bone,V(.72,.13,len),CF(base+V(i*spread*.30,0,len*.35))*ANG(rad(-12),rad(i*11),0),col:Lerp(C.black,math.abs(i)*.08))
 end
end

local function loft(ctx,name,bone,stations,sides,col,omitCockpit,mat,alpha,offset)
 for j=1,#stations-1 do
  local a,b=stations[j],stations[j+1]
  for k=0,sides-1 do
   if not(omitCockpit and a[1]>=-10 and b[1]<=-3 and (k==1 or k==2)) then
    local p,q=k*tau/sides,(k+1)*tau/sides
    local function pt(s,t) return V(cos(t)*s[3],s[2]+sin(t)*s[4],s[1])+(offset or V()) end
    local aa,bb,cc,dd=pt(a,p),pt(b,p),pt(b,q),pt(a,q)
    local shade=col:Lerp(C.ivory,.04+.09*math.max(0,sin((p+q)/2)))
    ctx:tri(name,bone,aa,bb,cc,.075,shade,HIGH,mat,alpha)
    ctx:tri(name,bone,aa,cc,dd,.075,shade,HIGH,mat,alpha)
   end
  end
 end
end

local function mantle(ctx,name,bone,center,width,height,length,rows,cols,col)
 rows=HIGH and rows or math.max(2,rows-1);cols=HIGH and cols or math.max(4,cols-2)
 for r=0,rows-1 do for c=0,cols-1 do
  local a=rad(-112+224*c/(cols-1));local normal=V(sin(a),cos(a),0)
  local position=center+V(sin(a)*width/2,cos(a)*height/2,(r+.5)/rows*length-length/2)
  local cf=CFrame.fromMatrix(position,V(normal.Y,-normal.X,0),normal,V(0,0,1))
  ctx:plate(name,bone,V(width*.38,.13,length/rows*.92),cf,col:Lerp(C.ivory,((r+c)%3)*.045))
 end end
end

local Builders={}
-- MODEL: griffin
Builders.griffin=function(ctx)
 local fur,feather=rgb(151,100,47),rgb(217,208,174)
 ctx:bone("Body","RootPart",V(0,4.9,0));ctx:bone("Chest","Body",V(0,5.4,-2.0))
 ctx:bone("Head","Chest",V(0,7.1,-3.3));ctx:bone("Jaw","Head",V(0,6.8,-4.0))
 ctx:part("Leonine_Ribcage","Body",V(2.45,2.68,5.5),CF(0,4.8,.5),fur,true)
 ctx:part("Griffin_Lateral_Core","Body",V(3.08,1.65,5.4),CF(0,4.8,.5),fur,false)
 mantle(ctx,"Lion_Flank_Fur","Body",V(0,4.8,.5),3.2,2.8,5.4,3,7,fur)
 ctx:part("Haunches","Body",V(3.0,2.5,2.5),CF(0,4.5,2.6),fur:Lerp(C.black,.17),true)
 ctx:plate("Cream_Underbelly","Body",V(1.9,.35,4.5),CF(0,3.35,.3),C.tan)
 ctx:part("Eagle_Breast","Chest",V(3.1,3.3,2.6),CF(0,5.9,-2.0),feather,true)
 for r=0,3 do for j=-2,2 do
  ctx:plate("Neck_Ruff","Chest",V(.60,.16,1.25),CF(j*.54,5.2+r*.50,-3.1+math.abs(j)*.15)*ANG(rad(55),rad(j*8),0),feather:Lerp(C.tan,r*.07))
 end end
 ctx:part("Eagle_Cranium","Head",V(2.0,1.7,2.4),CF(0,7.35,-3.55),feather,true)
 ctx:taper("Hooked_Beak","Head",{V(0,7.15,-4.5),V(0,7.0,-5.45),V(0,6.45,-5.5)},{.95,.65,.12},C.gold)
 ctx:part("Lower_Beak","Jaw",V(.72,.22,1.12),CF(0,6.64,-4.63),C.goldLight,false)
 for _,s in ipairs({-1,1}) do
  ctx:eye("Head",V(s*1.03,7.55,-4.03),s,C.goldLight,.34)
  ctx:part("Angled_Brow","Head",V(.25,.23,1.0),CF(s*1.04,7.86,-3.96)*ANG(0,0,s*rad(12)),C.brown,false)
  ctx:taper("Crest_Ear","Head",{V(s*.68,8.0,-3),V(s*.85,8.95,-2.6),V(s*.95,9.25,-2.35)},{.4,.25,.04},feather)
 end
 quadrupedLegs(ctx,"Body",-1.8,2.3,1.3,4.5,fur,C.tan)
 birdWing(ctx,"Wing","Chest",V(0,6.5,-1.35),8.6,3.9,feather,C.brown)
 ctx:bone("Tail1","Body",V(0,4.3,3.0));ctx:bone("Tail2","Tail1",V(0,4.2,5.0))
 ctx:taper("Lion_Tail","Tail1",{V(0,4.3,3),V(0,4.2,4),V(0,4.2,5)},{.38,.31,.28},fur)
 ctx:taper("Tail_Curl","Tail2",{V(0,4.2,5),V(.6,4.6,6.2),V(.8,5.3,6.6)},{.28,.22,.18},fur)
 ctx:part("Tail_Tuft","Tail2",V(.8,.9,.8),CF(.8,5.3,6.6)*ANG(0,0,rad(-18)),C.brown,true)
 ctx:emitter("Golden_Wing_Wake","Chest",V(0,6.4,0),"feather",C.goldLight,7)
 ctx:emitter("Landing_Dust","RootPart",V(0,.25,0),"dust",C.tan,0)
end
-- MODEL: owl
Builders.owl=function(ctx)
 local plumage,light=rgb(113,86,62),rgb(214,193,151)
 ctx:bone("Body","RootPart",V(0,3.6,0));ctx:bone("Head","Body",V(0,5.9,-.35))
 ctx:part("Round_Chest","Body",V(2.6,3.75,2.7),CF(0,3.5,0),plumage,true)
 ctx:part("Owl_Lateral_Core","Body",V(3.35,2.35,2.7),CF(0,3.5,0),plumage,false)
 mantle(ctx,"Owl_Mantle_Feather","Body",V(0,3.5,0),3.5,3.9,2.8,4,7,plumage)
 ctx:part("Owl_Skull","Head",V(4.1,3.0,2.7),CF(0,6.0,-.45),plumage,true)
 for _,s in ipairs({-1,1}) do
  ctx:part("Facial_Disc_Shadow","Head",V(1.95,2.35,.20),CF(s*1.00,6.0,-1.84),C.brown,false)
  ctx:part("Ivory_Facial_Disc","Head",V(1.70,2.12,.22),CF(s*1.00,6.04,-1.98),light,true)
  ctx:part("Front_Eye_Socket","Head",V(1.05,1.13,.26),CF(s*.95,6.27,-2.15),C.black,false)
  ctx:part("Amber_Front_Iris","Head",V(.78,.84,.28),CF(s*.95,6.27,-2.23),C.goldLight,false,Enum.Material.Neon)
  ctx:part("Front_Pupil","Head",V(.37,.60,.30),CF(s*.95,6.27,-2.30),C.black,false)
  ctx:part("Front_Eye_Glint","Head",V(.15,.18,.32),CF(s*.95-.16,6.49,-2.36),C.ivory,false)
  ctx:taper("Ear_Tuft","Head",{V(s*1.45,7.0,-.2),V(s*1.95,8.1,.15),V(s*2.0,8.5,.4)},{.6,.31,.04},plumage)
  ctx:bone((s<0 and "L" or "R").."Foot","Body",V(s*.85,1.5,0))
  local b=(s<0 and "L" or "R").."Foot"
  ctx:beam("Feathered_Tarsus",b,V(s*.85,1.5,0),V(s*.85,.4,-.1),.42,.45,light,false)
  for j=-1,1 do ctx:beam("Owl_Talon",b,V(s*.85,.4,-.1),V(s*.85+j*.28,.15,-1.05),.12,.12,C.gold,false) end
 end
 ctx:taper("Owl_Beak","Head",{V(0,5.85,-1.9),V(0,5.45,-2.5),V(0,5.1,-2.3)},{.45,.28,.04},C.black)
 for r=0,4 do for j=-2,2 do ctx:part("Breast_Speckle","Body",V(.15,.35,.08),CF(j*.55,2.2+r*.52,-1.41),C.brown,false) end end
 birdWing(ctx,"Wing","Body",V(0,4.7,.2),5.6,3.0,plumage,C.tan)
 ctx:bone("Tail","Body",V(0,2.6,1.15));featherTail(ctx,"Tail",V(0,2.4,1.3),.55,2.3,plumage)
 ctx:emitter("Moon_Dust","Head",V(0,6.4,.4),"spark",rgb(164,187,231),5)
end
-- MODEL: titanoboa
Builders.titanoboa=function(ctx)
 local skin,dark=rgb(65,101,70),rgb(33,56,40)
 ctx:bone("Body","RootPart",V(0,1.35,-8))
 local n=15 -- fixed rig topology across quality variants
 local prev="Body"
 for i=1,n do
  local z=-8+(i-1)*1.45;local x=sin((i-1)*.48)*2.6
  local y=1.3+(i>10 and (i-10)*.1 or 0)
  local name="Spine"..i;ctx:bone(name,prev,V(x,y,z))
  local zz=z+1.45;local xx=sin(i*.48)*2.6;local w=2.5*(1-(i-1)/n*.80)
  ctx:beam("Serpentine_Muscle",name,V(x,y,z),V(xx,y,zz),w,w*.79,skin,true)
  ctx:plate("Belly_Scute",name,V(w*.71,.14,1.35),CF((x+xx)/2,y-w*.37,z+.7),C.tan)
  if HIGH or i%2==0 then
   for _,s in ipairs({-1,1}) do ctx:part("Diamond_Scale_Pattern",name,V(w*.34,.08,.65),CF((x+xx)/2+s*w*.27,y+w*.39,z+.65)*ANG(0,s*rad(35),0),dark,false) end
  end
  prev=name
 end
 ctx:bone("Neck","Body",V(0,1.5,-8.3));ctx:bone("Head","Neck",V(0,2.4,-10.1));ctx:bone("Jaw","Head",V(0,2.0,-10.0))
 ctx:beam("Reared_Neck","Neck",V(0,1.4,-8.3),V(0,2.5,-10.3),2.0,1.65,skin,true)
 ctx:part("Broad_Serpent_Head","Head",V(2.8,1.7,3.2),CF(0,2.6,-11.0),skin,true)
 ctx:part("Lower_Serpent_Jaw","Jaw",V(2.55,.45,2.9),CF(0,1.85,-10.9),C.tan,true)
 for _,s in ipairs({-1,1}) do
  ctx:eye("Head",V(s*1.43,3.05,-11.4),s,C.gold,.33)
  ctx:part("Nostril","Head",V(.2,.13,.25),CF(s*.74,3.43,-12.05),C.black,false)
  ctx:taper("Venom_Fang","Head",{V(s*.83,2.1,-11.6),V(s*.83,1.55,-11.8),V(s*.78,1.25,-11.65)},{.16,.11,.035},C.ivory)
 end
 ctx:bone("Tongue","Jaw",V(0,1.83,-12.0))
 ctx:beam("Tongue_Stem","Tongue",V(0,1.83,-12),V(0,1.83,-13.1),.10,.07,C.red,false)
 for _,s in ipairs({-1,1}) do ctx:beam("Tongue_Fork","Tongue",V(0,1.83,-13.1),V(s*.28,1.83,-13.6),.055,.055,C.red,false) end
 ctx:emitter("Venom_Mist","Jaw",V(0,1.9,-12.4),"dust",rgb(112,187,74),5)
end
-- MODEL: kaiju
Builders.kaiju=function(ctx)
 local hide,plate=rgb(53,70,71),rgb(68,155,165)
 ctx:bone("Body","RootPart",V(0,7.8,0));ctx:bone("Chest","Body",V(0,10,-1))
 ctx:bone("Neck","Chest",V(0,12,-2));ctx:bone("Head","Neck",V(0,13.7,-3.3));ctx:bone("Jaw","Head",V(0,13,-3.2))
 ctx:part("Titan_Pelvis","Body",V(5.3,4.0,4.0),CF(0,7.4,.5),hide,true)
 ctx:part("Upright_Thorax","Chest",V(5.4,5.5,4.4),CF(0,10.3,-.8)*ANG(rad(-9),0,0),hide,true)
 for r=0,4 do ctx:plate("Ventral_Armor","Chest",V(3.0,.25,1.05),CF(0,8.3+r*.78,-3.14)*ANG(rad(87),0,0),hide:Lerp(C.tan,.22)) end
 mantle(ctx,"Titan_Side_Scutes","Chest",V(0,10.3,-.8),5.7,5.7,4.3,4,7,hide)
 ctx:beam("Thick_Neck","Neck",V(0,11.7,-1.9),V(0,13.6,-3.2),2.4,2.6,hide,true)
 ctx:part("Original_Kaiju_Skull","Head",V(3.1,2.3,3.9),CF(0,13.9,-3.9),hide,true)
 ctx:part("Jaw_Armor","Jaw",V(2.7,.65,3.8),CF(0,12.85,-3.9),hide:Lerp(C.black,.18),true)
 for _,s in ipairs({-1,1}) do
  ctx:eye("Head",V(s*1.6,14.35,-4.7),s,plate,.37)
  for j=0,5 do ctx:taper("Titan_Tooth","Head",{V(s*1.2,13.1,-5.3+j*.47),V(s*1.15,12.69,-5.3+j*.47)},{.19,.04},C.ivory) end
  local id=s<0 and "L" or "R"
  ctx:bone(id.."Thigh","Body",V(s*1.85,7.4,.5));ctx:bone(id.."Shin",id.."Thigh",V(s*2.15,3.8,-.35));ctx:bone(id.."Foot",id.."Shin",V(s*2.15,.8,-.85))
  ctx:beam("Massive_Thigh",id.."Thigh",V(s*1.85,7.4,.5),V(s*2.15,3.8,-.35),1.95,2.2,hide,true)
  ctx:beam("Titan_Shin",id.."Shin",V(s*2.15,3.8,-.35),V(s*2.15,.8,-.85),1.25,1.5,hide,true)
  ctx:part("Titan_Foot",id.."Foot",V(1.85,.75,2.8),CF(s*2.15,.65,-1.65),hide,true)
  for j=-1,1 do ctx:taper("Titan_Claw",id.."Foot",{V(s*2.15+j*.52,.65,-2.8),V(s*2.15+j*.52,.36,-3.4)},{.29,.055},C.ivory) end
  ctx:bone(id.."Arm","Chest",V(s*2.5,11.0,-1.4));ctx:bone(id.."Hand",id.."Arm",V(s*3.45,8.7,-3.1))
  ctx:beam("Titan_Forearm",id.."Arm",V(s*2.5,11,-1.4),V(s*3.45,8.7,-3.1),.75,.85,hide,true)
  ctx:part("Titan_Hand",id.."Hand",V(.9,.6,1.1),CF(s*3.45,8.5,-3.4),hide,true)
  for j=-1,1 do ctx:taper("Hand_Claw",id.."Hand",{V(s*3.45+j*.25,8.5,-3.8),V(s*3.45+j*.30,8.0,-4.3)},{.15,.035},C.ivory) end
 end
 local prev="Body"
 for i=1,7 do
  local z=2+(i-1)*2.0;local y=5.9-(i-1)*.63;local w=2.7-i*.32;local bone="Tail"..i
  ctx:bone(bone,prev,V(0,y,z));ctx:beam("Heavy_Tail",bone,V(0,y,z),V(0,y-.55,z+2),w,w,hide,true)
  ctx:fin("Tail_Crystal",bone,V(0,y+w*.5,z),V(0,y+w*.5+1.1-i*.1,z+.6),V(0,y+w*.5,z+1.6),plate)
  prev=bone
 end
 for r=0,4 do
  local y=7.5+r*1.1
  for _,s in ipairs({-1,1}) do ctx:fin("Original_Twin_Crystal_Ridge","Chest",V(s*1.25,y,1.2),V(s*2.25,y+1.4,2.6),V(s*1.15,y+2,1.3),plate:Lerp(C.blue,r*.045)) end
 end
 ctx:emitter("Resonance_Breath","Head",V(0,13.5,-6),"energy",C.blue,11)
 local aa,bb=Instance.new("Attachment"),Instance.new("Attachment")
 aa.Name="Resonance_Start";bb.Name="Resonance_End"
 aa.CFrame=scaled(ctx.nodes.Head.rest:ToObjectSpace(CF(0,13.5,-6)))
 bb.CFrame=scaled(ctx.nodes.Head.rest:ToObjectSpace(CF(0,13.5,-15)))
 aa.Parent=ctx.nodes.Head.part;bb.Parent=ctx.nodes.Head.part
 local beam=Instance.new("Beam");beam.Name="Resonance_Beam";beam.Attachment0=aa;beam.Attachment1=bb
 beam.Width0=.75*S;beam.Width1=.32*S;beam.FaceCamera=true;beam.Segments=8
 beam.Color=ColorSequence.new(C.blue,C.ivory);beam.LightEmission=1
 beam.Transparency=NumberSequence.new(.15,.75);beam.Enabled=false;beam:SetAttribute("EffectClip","Action")
 beam.Texture=Config.UseExternalVFX and "rbxassetid://1135136643" or "";beam.TextureSpeed=1.2;beam.Parent=ctx.nodes.Head.part
 local ref=Instance.new("ObjectValue");ref.Name="Resonance_Beam";ref.Value=beam;ref.Parent=ctx.fx
 ctx:emitter("Foot_Impact","RootPart",V(0,.25,-1),"dust",C.tan,0)
end
-- MODEL: wolf
Builders.wolf=function(ctx)
 local fur,light=rgb(92,111,126),rgb(187,201,198)
 ctx:bone("Body","RootPart",V(0,3.9,0));ctx:bone("Chest","Body",V(0,4.4,-1.9));ctx:bone("Head","Chest",V(0,5.25,-3.25));ctx:bone("Jaw","Head",V(0,4.9,-3.6))
 ctx:part("Lean_Wolf_Ribcage","Body",V(1.75,2.1,5.0),CF(0,3.9,.4),fur,true)
 ctx:part("Wolf_Lateral_Core","Body",V(2.18,1.3,4.9),CF(0,3.9,.4),fur,false)
 mantle(ctx,"Wolf_Fur_Tuft","Body",V(0,3.9,.4),2.3,2.25,4.9,4,7,fur)
 ctx:part("Deep_Wolf_Chest","Chest",V(2.4,2.6,2.3),CF(0,4.35,-1.8),fur,true)
 ctx:plate("Belly_Fur","Body",V(1.45,.26,3.8),CF(0,2.75,.3),light)
 ctx:part("Canine_Skull","Head",V(1.65,1.65,2.0),CF(0,5.4,-3.4),fur,true)
 ctx:part("Long_Muzzle","Head",V(1.05,.68,1.9),CF(0,5.04,-4.7),light,true)
 ctx:part("Wet_Nose","Head",V(.91,.42,.28),CF(0,5.22,-5.66),C.black,false)
 ctx:part("Wolf_Lower_Jaw","Jaw",V(.95,.30,1.9),CF(0,4.65,-4.6),light,false)
 for _,s in ipairs({-1,1}) do
  ctx:eye("Head",V(s*.86,5.68,-3.95),s,C.goldLight,.27)
  ctx:fin("Upright_Wolf_Ear","Head",V(s*.45,6,-3.5),V(s*.85,7.4,-2.9),V(s*1.02,6.05,-2.55),fur)
  ctx:fin("Pink_Inner_Ear","Head",V(s*.51,6.17,-3.43),V(s*.82,7.15,-2.98),V(s*.94,6.2,-2.68),rgb(153,113,108))
  for i=0,3 do ctx:plate("Layered_Neck_Ruff","Chest",V(.60,.18,1.5),CF(s*(1.0+i*.09),4.3+i*.43,-1.55)*ANG(rad(14),s*rad(19),s*rad(-21)),fur:Lerp(light,i*.08)) end
 end
 quadrupedLegs(ctx,"Body",-1.8,2.1,.92,3.8,fur,light)
 ctx:bone("Tail1","Body",V(0,4.0,2.7));ctx:bone("Tail2","Tail1",V(0,3.3,4.7))
 ctx:taper("Bushy_Tail_Base","Tail1",{V(0,4,2.7),V(0,3.65,3.8),V(0,3.3,4.7)},{.65,.95,.8},fur)
 ctx:taper("Bushy_Tail_Tip","Tail2",{V(0,3.3,4.7),V(0,2.6,5.7),V(0,2.2,6.0)},{.8,.5,.09},light)
 ctx:emitter("Cold_Howl_Breath","Jaw",V(0,4.8,-5.6),"dust",rgb(185,218,228),6)
 ctx:emitter("Paw_Dust","RootPart",V(0,.15,0),"dust",C.tan,0)
end
-- MODEL: eagle
Builders.eagle=function(ctx)
 local dark,white=rgb(70,51,39),rgb(227,225,210)
 ctx:bone("Body","RootPart",V(0,4,0));ctx:bone("Neck","Body",V(0,5,-1.65));ctx:bone("Head","Neck",V(0,5.65,-2.5));ctx:bone("Jaw","Head",V(0,5.2,-3.0))
 ctx:part("Aerodynamic_Chest","Body",V(2.5,2.65,4.4),CF(0,4,0),dark,true)
 mantle(ctx,"Eagle_Mantle","Body",V(0,4,0),2.6,2.75,4.3,3,5,dark)
 ctx:plate("Breast_Feather_Keel","Body",V(1.9,.25,3.3),CF(0,2.6,-.1),C.brown)
 ctx:beam("White_Neck","Neck",V(0,4.9,-1.65),V(0,5.6,-2.5),1.55,1.5,white,true)
 ctx:part("Eagle_White_Head","Head",V(1.6,1.5,2),CF(0,5.75,-2.7),white,true)
 ctx:taper("Golden_Hooked_Beak","Head",{V(0,5.55,-3.5),V(0,5.4,-4.5),V(0,4.9,-4.4)},{.65,.42,.04},C.gold)
 ctx:part("Lower_Beak","Jaw",V(.55,.15,.9),CF(0,5.12,-3.75),C.goldLight,false)
 for _,s in ipairs({-1,1}) do
  ctx:eye("Head",V(s*.84,6.0,-3.15),s,C.goldLight,.26)
  ctx:part("Fierce_Brow","Head",V(.15,.15,.65),CF(s*.85,6.25,-3.1)*ANG(0,0,s*rad(-12)),white,false)
  local b=s<0 and "LFoot" or "RFoot";ctx:bone(b,"Body",V(s*.65,2.8,.3))
  ctx:beam("Scaled_Tarsus",b,V(s*.65,2.8,.3),V(s*.65,1.6,-.1),.30,.33,C.gold,false)
  for j=-1,1 do ctx:taper("Raptor_Talon",b,{V(s*.65,1.6,-.1),V(s*.65+j*.3,1.25,-.8),V(s*.65+j*.3,1.0,-.7)},{.14,.11,.03},C.black) end
 end
 birdWing(ctx,"Wing","Body",V(0,4.7,-.45),10.4,3.8,dark,rgb(37,30,29))
 ctx:bone("Tail","Body",V(0,3.6,1.7));featherTail(ctx,"Tail",V(0,3.5,1.9),.6,3.6,white)
 ctx:emitter("Wind_Feathers","Body",V(0,4.5,1),"feather",C.ivory,5)
end
-- MODEL: megalodon
Builders.megalodon=function(ctx)
 local skin,belly=rgb(64,101,123),rgb(186,205,201)
 ctx:bone("Body","RootPart",V(0,5.3,0));ctx:bone("Head","Body",V(0,5.3,-5));ctx:bone("Jaw","Head",V(0,4.3,-5.8))
 loft(ctx,"Fusiform_Shark_Body","Body",{{-4.3,5.3,2.6,2.15},{0,5.3,2.65,2.2},{4.5,5.3,1.85,1.55}},HIGH and 8 or 6,skin,false)
 ctx:part("Pale_Ventral_Surface","Body",V(4.4,.60,7.8),CF(0,3.26,-.2),belly,true)
 loft(ctx,"Tapered_Shark_Head","Head",{{-8.5,5.2,2.1,1.15},{-6.4,5.3,2.5,1.8},{-4.3,5.3,2.6,2.15}},HIGH and 8 or 6,skin,false)
 ctx:part("Snout_Roof","Head",V(4.4,.6,2.2),CF(0,4.9,-8.3),skin,true)
 ctx:part("Open_Mouth_Shadow","Head",V(3.9,1.8,.16),CF(0,4.15,-7.98),rgb(44,24,31),false)
 ctx:part("Massive_Lower_Jaw","Jaw",V(4.3,.65,4),CF(0,3.55,-6.0),belly,true)
 for _,s in ipairs({-1,1}) do
  ctx:eye("Head",V(s*2.58,5.95,-6.8),s,C.black,.34)
  for i=0,4 do ctx:part("Five_Gill_Slit","Body",V(.09,1.65,.15),CF(s*2.69,5.3,-3.8+i*.50)*ANG(0,0,s*rad(-9)),C.black,false) end
  local b=s<0 and "PectoralL" or "PectoralR";ctx:bone(b,"Body",V(s*2,4.6,-2.8))
  ctx:fin("Long_Pectoral",b,V(s*1.9,4.5,-3),V(s*8,3.2,.1),V(s*3.1,4.3,1.4),skin)
 end
 for row=0,1 do for j=0,8 do
  local x=-1.65+j*.41;local y=row==0 and 4.95 or 3.85
  ctx:tri("Triangular_Serrated_Tooth",row==0 and "Head" or "Jaw",V(x-.16,y,-8.15+row*.1),V(x+.16,y,-8.15+row*.1),V(x,y+(row==0 and -.55 or .5),-8.18+row*.1),.10,C.ivory,false)
 end end
 ctx:fin("Iconic_Dorsal","Body",V(0,7.2,-1.7),V(0,12.0,1.7),V(0,7.2,3.0),skin)
 ctx:bone("Tail1","Body",V(0,5.2,4));ctx:bone("Tail2","Tail1",V(0,5.2,7.5));ctx:bone("Fluke","Tail2",V(0,5.2,10))
 ctx:beam("Caudal_Peduncle","Tail1",V(0,5.2,4),V(0,5.2,7.5),3.4,2.9,skin,true)
 ctx:beam("Tapered_Tail","Tail2",V(0,5.2,7.5),V(0,5.2,10),1.55,1.7,skin,true)
 ctx:fin("Upper_Caudal_Lobe","Fluke",V(0,5.2,9.2),V(0,10.1,13.2),V(0,5.5,11.4),skin)
 ctx:fin("Lower_Caudal_Lobe","Fluke",V(0,5.2,9.2),V(0,1.8,12),V(0,5.5,11.4),skin)
 ctx:emitter("Hydrodynamic_Bubbles","Body",V(0,5.2,5),"bubble",rgb(153,218,229),8)
end
-- MODEL: f16
local function missile(ctx,name,bone,x,y,z,len)
 ctx:beam(name.."_Body",bone,V(x,y,z-len*.38),V(x,y,z+len*.42),.26,.26,C.white,false)
 ctx:taper(name.."_Seeker",bone,{V(x,y,z-len*.38),V(x,y,z-len*.61)},{.26,.035},C.black)
 for _,s in ipairs({-1,1}) do
  ctx:fin(name.."_Fin",bone,V(x,y,z+len*.18),V(x+s*.6,y,z+len*.43),V(x,y,z+len*.40),C.steel)
 end
 ctx:fin(name.."_VerticalFin",bone,V(x,y,z+len*.18),V(x,y+.56,z+len*.43),V(x,y,z+len*.40),C.steel)
end
Builders.f16=function(ctx)
 local paint,upper=rgb(112,131,129),rgb(143,154,138)
 ctx:bone("Body","RootPart",V(0,5,0));ctx:bone("Canopy","Body",V(0,6.6,-3.4))
 for _,s in ipairs({-1,1}) do
  ctx:bone(s<0 and "ElevonL" or "ElevonR","Body",V(s*7.2,4.95,5.5))
  ctx:bone(s<0 and "TailplaneL" or "TailplaneR","Body",V(s*2.2,5.1,10))
 end
 ctx:bone("Rudder","Body",V(0,7.2,10));ctx:bone("GearNose","Body",V(0,3.6,-7.0))
 ctx:bone("GearL","Body",V(-1.45,3.9,2.3));ctx:bone("GearR","Body",V(1.45,3.9,2.3))
 loft(ctx,"Faceted_Fuselage","Body",{{-17,5,.10,.10},{-13,5,.85,.85},{-9.7,5,1.5,1.5},{-4,5,1.82,1.65},{2,5,1.70,1.55},{8,5,1.35,1.25},{11.4,5,1.1,1.02}},HIGH and 8 or 6,paint,true)
 loft(ctx,"Dark_Radome","Body",{{-17.05,5,.045,.045},{-15.5,5,.48,.50},{-13.1,5,.84,.84}},HIGH and 8 or 6,C.steel,false)
 ctx:beam("Pitot_Probe","Body",V(0,5,-17),V(0,5,-19),.045,.045,C.steelLight,false)
 -- Chin intake: dark opening framed with individual lips, rather than a solid black box.
 ctx:part("Intake_Inner_Darkness","Body",V(2.45,1.3,.08),CF(0,3.5,-5.0),C.black,false)
 for _,s in ipairs({-1,1}) do ctx:beam("Intake_Cheek","Body",V(s*1.3,3.4,-5.1),V(s*1.3,3.7,-.8),.22,1.25,paint,false) end
 ctx:part("Intake_Lower_Lip","Body",V(2.8,.18,1.2),CF(0,2.8,-4.6)*ANG(rad(-5),0,0),upper,true)
 ctx:part("Intake_Upper_Lip","Body",V(2.8,.15,1.1),CF(0,4.15,-4.7),paint,false)
 for _,s in ipairs({-1,1}) do
  -- Swept main wing and root leading-edge extension, silhouette taken from supplied reference.
  ctx:fin("Wing_Root_LEX","Body",V(s*1.5,5.25,-7.4),V(s*5.7,5.0,.2),V(s*1.9,5.0,5.2),upper)
  ctx:fin("Swept_Main_Wing","Body",V(s*2.0,4.95,-2.6),V(s*11.7,4.55,3.7),V(s*9.4,4.6,6.4),upper)
  ctx:fin("Main_Wing_Inner_Panel","Body",V(s*2,4.95,-2.6),V(s*9.4,4.6,6.4),V(s*2.2,4.9,6.4),paint)
  local eb=s<0 and "ElevonL" or "ElevonR"
  ctx:fin("Separate_Flaperon",eb,V(s*3.2,4.92,5.65),V(s*10.3,4.6,6.0),V(s*7.7,4.72,7.25),paint:Lerp(C.black,.12))
  ctx:beam("Wing_Leading_Edge","Body",V(s*2.1,5.05,-2.5),V(s*11.7,4.65,3.7),.08,.08,C.steelLight,false)
  local tb=s<0 and "TailplaneL" or "TailplaneR"
  ctx:fin("All_Moving_Horizontal_Tail",tb,V(s*1.1,5.1,8.2),V(s*6.7,5.0,11.7),V(s*2.0,5.0,13.1),paint)
  ctx:part("Wing_Pylon","Body",V(.25,1.1,1.5),CF(s*6.4,4.0,2.4),C.steel,false)
  loft(ctx,"External_Fuel_Tank","Body",{{-2.5,3.2,.06,.06},{-.8,3.2,.72,.72},{3.8,3.2,.65,.65},{5.2,3.2,.06,.06}},6,upper,false,nil,nil,V(s*6.4,0,0))
  missile(ctx,"Wingtip_Missile","Body",s*11.8,4.65,3.8,5.1)
  missile(ctx,"Outer_Payload","Body",s*8.7,3.9,3.8,4.0)
  ctx:beam("Payload_Rail","Body",V(s*11.8,4.65,1.4),V(s*11.8,4.65,5.9),.14,.15,C.steel,false)
  if HIGH then
   for j=0,3 do ctx:part("Wing_Service_Panel","Body",V(1.6,.025,.10),CF(s*(3+j*1.8),5.04-j*.07,2.7+j*.6)*ANG(0,s*rad(-22),0),C.steel,false) end
  end
 end
 -- Single vertical stabiliser with separately hinged rudder; not a twin-tail aircraft.
 ctx:fin("Swept_Vertical_Stabiliser","Body",V(0,5.7,6.7),V(0,13.2,11.5),V(0,6.0,13.0),paint)
 ctx:fin("Separate_Rudder","Rudder",V(0,8.0,11.0),V(0,12.8,11.8),V(0,6.2,13.7),upper)
 for i=0,5 do ctx:part("Rudder_Seam","Body",V(.10,.5,.06),CF(.14,7.3+i*.72,11.9-i*.06)*ANG(rad(-14),0,0),C.black,false) end
 -- Bubble canopy: individual glass facets, framing and cockpit furniture.
 local canopyRows,canopyColumns=HIGH and 5 or 3,HIGH and 6 or 4
 for i=0,canopyRows-1 do
  local za=-9.4+i*5.85/canopyRows;local zb=za+5.85/canopyRows
  local function canopy(z,a)
   local u=(z+9.4)/5.85;local w=1.35*sin(pi*(.11+.77*u))
   return V(cos(a)*w,6.4+sin(a)*(1.4+sin(u*pi)*.7),z)
  end
  for k=0,canopyColumns-1 do
   local a,b=k*pi/canopyColumns,(k+1)*pi/canopyColumns
   local aa,bb,cc,dd=canopy(za,a),canopy(zb,a),canopy(zb,b),canopy(za,b)
   ctx:tri("Tinted_Bubble_Canopy","Canopy",aa,bb,cc,.035,rgb(128,184,176),false,Enum.Material.Glass,.47)
   ctx:tri("Tinted_Bubble_Canopy","Canopy",aa,cc,dd,.035,rgb(128,184,176),false,Enum.Material.Glass,.47)
  end
 end
 for _,s in ipairs({-1,1}) do ctx:beam("Canopy_Rim","Canopy",V(s*1.15,6.45,-9.2),V(s*1.10,6.45,-3.5),.10,.11,C.black,false) end
 ctx:part("Ejection_Seat","Body",V(1.25,1.5,.55),CF(0,7.0,-5.3)*ANG(rad(-13),0,0),C.black,false)
 ctx:part("Pilot_Helmet","Body",V(.78,.73,.85),CF(0,7.6,-6.25),C.tan,false)
 ctx:part("Pilot_Visor","Body",V(.67,.26,.18),CF(0,7.68,-6.72),C.black,false)
 ctx:part("Instrument_Coaming","Body",V(1.7,.55,.9),CF(0,6.95,-8.4),C.black,false)
 for j=-1,1 do ctx:part("Cockpit_MFD","Body",V(.35,.25,.06),CF(j*.46,7.19,-8.0)*ANG(rad(20),0,0),rgb(58,150,112),false,Enum.Material.Neon) end
 for _,gear in ipairs({{"GearNose",0,-7},{"GearL",-1.45,2.3},{"GearR",1.45,2.3}}) do
  local b,x,z=gear[1],gear[2],gear[3];local wx=x+(x==0 and 0 or (x<0 and -.55 or .55))
  ctx:beam("Landing_Gear_Strut",b,V(x,3.65,z),V(wx,1.3,z+.4),.17,.18,C.steelLight,false)
  ctx:beam("Gear_Torque_Link",b,V(x,3.2,z),V(wx+.3,1.8,z+.65),.09,.10,C.steel,false)
  for k=0,7 do local a=k*pi/4
   ctx:part("Tyre_Tread",b,V(.37,.34,.35),CF(wx,1.02+cos(a)*.46,z+.4+sin(a)*.46)*ANG(a,0,0),C.black,false)
  end
  ctx:part("Wheel_Hub",b,V(.40,.42,.42),CF(wx,1.02,z+.4),C.steelLight,false)
 end
 for i=0,11 do
  local a=i*tau/12
  ctx:part("Exhaust_Petal","Body",V(.55,.13,1.1),CF(cos(a)*1.1,5+sin(a)*1.1,11.65)*ANG(0,0,a-pi/2),C.steel,false)
 end
 ctx:part("Exhaust_Throat","Body",V(1.45,1.45,.08),CF(0,5,11.5),C.black,false)
 ctx:emitter("Afterburner_Core","Body",V(0,5,12.25),"fire",C.blue,16)
 ctx:emitter("Hot_Exhaust","Body",V(0,5,12.35),"spark",C.hot,8)
end
-- MODEL: rocket
Builders.rocket=function(ctx)
 local white,accent=rgb(223,225,216),rgb(111,72,56)
 ctx:bone("Body","RootPart",V(0,10,0));ctx:bone("Stage2","Body",V(0,16,0));ctx:bone("Payload","Stage2",V(0,22,0))
 for _,s in ipairs({-1,1}) do ctx:bone(s<0 and "BoosterL" or "BoosterR","Body",V(s*2.6,6.7,0)) end
 -- Vertical faceted cylinder assembled from flat staves; no per-stud geometry.
 local function tube(name,bone,x,y0,y1,r,col)
  local sides=HIGH and 10 or 8
  for k=0,sides-1 do local a=k*tau/sides
   ctx:part(name.."_Stave",bone,V(2*r*math.tan(pi/sides)+.015,y1-y0,.15),CF(x+cos(a)*r,(y0+y1)/2,sin(a)*r)*ANG(0,-a+pi/2,0),col,true)
  end
  for _,y in ipairs({y0+.18,y1-.18}) do for k=0,sides-1 do local a=k*tau/sides
   ctx:part(name.."_Separation_Band",bone,V(2*r*math.tan(pi/sides)+.04,.17,.19),CF(x+cos(a)*(r+.04),y,sin(a)*(r+.04))*ANG(0,-a+pi/2,0),C.black,false)
  end end
 end
 tube("Main_Stage","Body",0,3.4,15.7,2.1,white)
 tube("Upper_Stage","Stage2",0,16.0,22.0,1.8,accent)
 tube("Payload_Fairing","Payload",0,22.1,25.0,2.0,white)
 for k=0,9 do
  local a,b=k*tau/10,(k+1)*tau/10
  ctx:tri("Pointed_Fairing","Payload",V(cos(a)*2,25,sin(a)*2),V(cos(b)*2,25,sin(b)*2),V(0,29,0),.13,white,HIGH)
 end
 for _,s in ipairs({-1,1}) do
  local bone=s<0 and "BoosterL" or "BoosterR";tube("Solid_Booster",bone,s*3.1,2.6,14.2,1.0,white)
  ctx:taper("Booster_Nose",bone,{V(s*3.1,14.1,0),V(s*3.1,16.3,0)},{1.7,.08},C.steelLight)
  ctx:beam("Booster_Upper_Mount","Body",V(s*1.8,12.9,0),V(s*2.9,12.9,0),.23,.3,C.steel,false)
  ctx:beam("Booster_Lower_Mount","Body",V(s*1.8,5,0),V(s*2.9,5,0),.23,.3,C.steel,false)
  ctx:emitter("Booster_Exhaust",bone,V(s*3.1,2.5,0),"fire",C.ember,10)
 end
 for k=0,3 do
  local a=k*pi/2;local dir=V(cos(a),0,sin(a));local base=dir*1.9
  ctx:fin("Swept_Stabiliser","Body",base+V(0,3.7,0),dir*4.7+V(0,1.3,0),base+V(0,8.5,0),accent)
 end
 for k=0,11 do
  local a=k*tau/12
  ctx:part("Engine_Bell_Lip","Body",V(.57,.20,.18),CF(cos(a)*1.1,1.1,sin(a)*1.1)*ANG(0,-a+pi/2,0),C.steel,false)
  ctx:beam("Engine_Bell_Facet","Body",V(cos(a)*.55,3.3,sin(a)*.55),V(cos(a)*1.1,1.1,sin(a)*1.1),.30,.12,C.dark,false)
 end
 for j=0,3 do ctx:part("Service_Raceway","Body",V(.14,2.4,.13),CF(.4,5+j*2.5,-2.15),C.steel,false) end
 for j=0,5 do ctx:part("Identification_Stripe","Stage2",V(.85,.22,.10),CF(0,17.1+j*.45,-1.91),C.black,false) end
 ctx:part("Payload_Access_Panel","Payload",V(1.2,1.4,.10),CF(0,23.4,-2.1),C.steelLight,true)
 local e=ctx:emitter("Main_Engine_Plume","Body",V(0,1.2,0),"fire",C.hot,18)
 e.EmissionDirection=Enum.NormalId.Bottom;e.Speed=NumberRange.new(7*S,12*S)
 for _,d in ipairs(ctx.model:GetDescendants()) do if d:IsA("ParticleEmitter") and d.Name=="Booster_Exhaust" then d.EmissionDirection=Enum.NormalId.Bottom end end
end
-- MODEL: phoenix
Builders.phoenix=function(ctx)
 local red,orange=rgb(161,45,34),rgb(230,115,31)
 ctx:bone("Body","RootPart",V(0,5.3,0));ctx:bone("Neck","Body",V(0,6.7,-1.8));ctx:bone("Head","Neck",V(0,8,-2.7));ctx:bone("Jaw","Head",V(0,7.6,-3.1))
 ctx:part("Phoenix_Chest","Body",V(2.7,3.1,4.4),CF(0,5.2,0),red,true)
 mantle(ctx,"Phoenix_Flame_Feather","Body",V(0,5.2,0),2.8,3.2,4.3,3,7,red)
 ctx:plate("Golden_Breast","Body",V(1.8,.30,3.6),CF(0,3.55,-.25),orange)
 ctx:beam("Long_Phoenix_Neck","Neck",V(0,6.4,-1.6),V(0,7.95,-2.7),1.35,1.45,orange,true)
 ctx:part("Phoenix_Skull","Head",V(1.65,1.5,2),CF(0,8.05,-2.8),orange,true)
 ctx:taper("Phoenix_Beak","Head",{V(0,7.85,-3.5),V(0,7.6,-4.8),V(0,7.1,-4.6)},{.65,.36,.04},C.goldLight)
 ctx:part("Phoenix_Lower_Beak","Jaw",V(.53,.16,1.1),CF(0,7.48,-3.9),C.gold,false)
 for _,s in ipairs({-1,1}) do
  ctx:eye("Head",V(s*.86,8.4,-3.2),s,C.hot,.27)
  local b=s<0 and "LFoot" or "RFoot";ctx:bone(b,"Body",V(s*.72,3.6,.7))
  ctx:beam("Phoenix_Tarsus",b,V(s*.72,3.6,.7),V(s*.72,2.1,.2),.28,.32,C.gold,false)
  for j=-1,1 do ctx:taper("Phoenix_Talon",b,{V(s*.72,2.1,.2),V(s*.72+j*.28,1.7,-.65),V(s*.72+j*.28,1.4,-.5)},{.14,.1,.03},C.black) end
 end
 for i=-2,2 do ctx:taper("Flame_Crest","Head",{V(i*.22,8.4,-2.0),V(i*.42,9.6+(.4-math.abs(i)*.15),-1.5),V(i*.47,10.1,-.9)},{.30,.20,.035},orange:Lerp(C.hot,(i+2)*.1)) end
 birdWing(ctx,"Wing","Body",V(0,6.2,-.25),9.1,4.3,red,orange)
 local prev="Body"
 for i=1,3 do
  local b="Tail"..i;ctx:bone(b,prev,V(0,4.8-(i-1)*.45,2+(i-1)*2))
  for j=-2,2 do
   ctx:plate("Long_Ribbon_Feather",b,V(.42,.11,3.2),CF(j*(.28+i*.15),4.7-i*.45,3.2+(i-1)*2)*ANG(rad(-9),rad(j*7),0),i==3 and C.goldLight or orange:Lerp(red,j%2*.15))
  end
  prev=b
 end
 ctx:emitter("Wing_Embers","Body",V(0,6.4,0),"spark",C.ember,9)
 ctx:emitter("Tail_Flame","Tail3",V(0,3.5,8.5),"fire",C.hot,8)
end

-- OFFLINE MOTION GENERATION: solved once at installation, not every frame in game.
local function rotationBetween(a,b)
 a,b=unit(a),unit(b);local dot=math.clamp(a:Dot(b),-1,1)
 if dot>.99999 then return CF() end
 if dot<-.99999 then return CFrame.fromAxisAngle(unit(a:Cross(math.abs(a.Y)<.9 and V(0,1,0) or V(1,0,0))),pi) end
 return CFrame.fromAxisAngle(a:Cross(b).Unit,math.acos(dot))
end
local OFFSETS={FL=.25,FR=.75,HL=0,HR=.5}
local function solveQuadruped(ctx,P,f,walking,flying)
 if not ctx.legs then return end
 local bodyFrame=ctx.nodes.Body.rest*(P.Body or CF())
 for _,leg in ipairs(ctx.legs) do
  local id=leg.id
  if flying then
   P[id.."Upper"]=ANG(rad(leg.front and -30 or 40),0,leg.side*rad(5))
   P[id.."Lower"]=ANG(rad(leg.front and 62 or -68),0,0);P[id.."Paw"]=ANG(rad(-15),0,0)
  else
   local goal=leg.foot;local pitch=0
   if walking then
    local cycle=(f+OFFSETS[id])%1;local duty=.66;local stride=ctx.key=="wolf" and 2.0 or 1.7
    if cycle<duty then
     goal+=V(0,0,-stride/2+stride*smooth(cycle/duty))
    else
     local u=(cycle-duty)/(1-duty);local lift=sin(pi*u)^2
     goal+=V(0,.65*lift,stride/2-stride*smooth(u));pitch=rad(13)*lift
    end
   end
   local hip=bodyFrame:PointToWorldSpace(leg.hip-ctx.nodes.Body.rest.Position)
   local delta=goal-hip;local dir=unit(delta,V(0,-1,0))
   local distance=math.clamp(delta.Magnitude,math.abs(leg.L1-leg.L2)+.008,leg.L1+leg.L2-.008)
   goal=hip+dir*distance
   local pole=V(leg.side*.14,0,leg.front and 1 or -1)
   local bend=unit(pole-dir*pole:Dot(dir),V(leg.side,0,0))
   local projection=(leg.L1^2+distance^2-leg.L2^2)/(2*distance)
   local knee=hip+dir*projection+bend*math.sqrt(math.max(leg.L1^2-projection^2,0))
   local upper=CF(hip)*rotationBetween(leg.knee-leg.hip,knee-hip)
   local lower=CF(knee)*rotationBetween(leg.foot-leg.knee,goal-knee)
   local paw=CF(goal)*ANG(pitch,0,0)
   local un,ln,pn=ctx.nodes[id.."Upper"],ctx.nodes[id.."Lower"],ctx.nodes[id.."Paw"]
   P[un.name]=(bodyFrame*un.parent.rest:ToObjectSpace(un.rest)):Inverse()*upper
   P[ln.name]=(upper*ln.parent.rest:ToObjectSpace(ln.rest)):Inverse()*lower
   P[pn.name]=(lower*pn.parent.rest:ToObjectSpace(pn.rest)):Inverse()*paw
  end
 end
end
local function sample(ctx,clip,f)
 local P={};local q=tau*f;local action=clip=="Action"
 local moving=clip=="Locomotion";local flying=clip=="Flight" or (moving and (ctx.key=="owl" or ctx.key=="eagle" or ctx.key=="phoenix"))
 local pulse=sin(pi*f)^2
 local function rot(name,x,y,z) if ctx.nodes[name] then P[name]=ANG(x or 0,y or 0,z or 0) end end
 local function move(name,x,y,z) if ctx.nodes[name] then P[name]=CF(x or 0,y or 0,z or 0)*(P[name] or CF()) end end
 if ctx.key=="f16" then
  rot("ElevonL",rad(6)*sin(q),0,0);rot("ElevonR",-rad(6)*sin(q),0,0)
  rot("TailplaneL",rad(3)*sin(q-.4),0,0);rot("TailplaneR",rad(3)*sin(q-.4),0,0)
  rot("Rudder",0,rad(7)*sin(q-.2),0)
  if moving or action then
   for _,n in ipairs({"GearNose","GearL","GearR"}) do rot(n,rad(moving and 82 or 78*pulse),0,0) end
   move("Body",0,(moving and .20 or .035)*sin(q),0)
  end
  if action then rot("Canopy",rad(22)*pulse,0,0) end
 elseif ctx.key=="rocket" then
  if moving then rot("Body",rad(.6)*sin(q),0,rad(.4)*cos(q));move("Body",0,.12*sin(q),0) end
  if action then
   move("Stage2",0,3.2*pulse,0);move("Payload",0,.5*pulse,0)
   rot("BoosterL",0,0,rad(-7)*pulse);rot("BoosterR",0,0,rad(7)*pulse)
   move("BoosterL",-1.6*pulse,-.5*pulse,0);move("BoosterR",1.6*pulse,-.5*pulse,0)
  end
 elseif ctx.key=="titanoboa" then
  for i=1,15 do rot("Spine"..i,0,(moving and .14 or .035)*sin(q-i*.48),0) end
  rot("Neck",0,rad(5)*sin(q-.3),0);rot("Head",0,rad(8)*sin(q-.7),0)
  rot("Jaw",action and rad(-30)*pulse or rad(-1.2)*(1+sin(q)),0,0)
  move("Tongue",0,0,action and -.7*pulse or -.12*sin(q)^2)
  if action then rot("Head",rad(-8)*pulse,rad(5)*sin(q),0) end
 elseif ctx.key=="megalodon" then
  for i=1,2 do rot("Tail"..i,0,(moving and .19 or .055)*sin(q-i*.5),0) end
  rot("Fluke",0,(moving and .28 or .08)*sin(q-1.35),0)
  rot("PectoralL",0,0,rad(3)*sin(q));rot("PectoralR",0,0,-rad(3)*sin(q))
  move("Body",0,.08*sin(q),0);rot("Jaw",action and rad(-26)*pulse or -.015,0,0)
  if action then move("Head",0,0,-.45*pulse) end
 elseif ctx.key=="kaiju" then
  rot("Body",rad(moving and 2 or .35)*sin(q),0,rad(moving and 2 or .4)*cos(q))
  move("Body",0,moving and .12*cos(2*q) or .04*sin(q),0)
  for _,side in ipairs({-1,1}) do
   local id=side<0 and "L" or "R";local p=q+(side>0 and pi or 0)
   rot(id.."Thigh",moving and .28*sin(p) or .015*sin(p),0,0)
   rot(id.."Shin",moving and -.30*math.max(0,sin(p)) or 0,0,0)
   rot(id.."Foot",moving and .12*sin(p) or 0,0,0)
   rot(id.."Arm",rad(action and -18*pulse or -2*sin(p)),0,side*rad(3))
  end
  for i=1,7 do rot("Tail"..i,0,.045*(.5+i*.1)*sin(q-i*.45),0) end
  rot("Neck",action and rad(9)*pulse or .015*sin(q-.4),0,0)
  rot("Head",action and rad(11)*pulse or .02*sin(q-.7),0,0)
  rot("Jaw",action and rad(-28)*pulse or -.012,0,0)
 else
  -- Mammal breathing and layered avian FK.
  move("Body",0,(flying and .2 or .035)*sin(q),0)
  rot("Chest",.015*sin(q-.25),0,0)
  rot("Neck",.025*sin(q-.3),.035*sin(q),0)
  rot("Head",.025*sin(q-.7),rad(ctx.key=="owl" and 17 or 5)*sin(q),.018*sin(q-.5))
  rot("Jaw",action and rad(ctx.key=="wolf" and -25 or -17)*pulse or -.012,0,0)
  for _,side in ipairs({-1,1}) do
   local id="Wing"..(side<0 and "L" or "R")
   if flying then
    local flap=q*(ctx.key=="owl" and 4 or 2)
    rot(id.."Shoulder",rad(2)*sin(flap),-side*.06,side*.62*sin(flap))
    rot(id.."Outer",rad(1)*sin(flap-.4),-side*.06,side*.29*sin(flap-.55))
   elseif action and ctx.key~="wolf" then
    rot(id.."Shoulder",0,-side*.80*(1-pulse),side*.42*pulse)
    rot(id.."Outer",0,-side*.35*(1-pulse),side*.20*pulse)
   else
    rot(id.."Shoulder",0,-side*.95,side*.09)
    rot(id.."Outer",0,-side*.38,side*.03)
   end
   local foot=side<0 and "LFoot" or "RFoot"
   rot(foot,flying and rad(48) or .025*sin(q),0,0)
  end
  for i=1,3 do rot("Tail"..i,.035*sin(q-.3*i),.06*sin(q-i*.45),0) end
  rot("Tail",.045*sin(q-.5),.05*sin(q-.7),0)
  if action then
   rot("Head",rad(ctx.key=="owl" and 4 or (ctx.key=="wolf" and 23 or 10))*pulse,ctx.key=="owl" and rad(65)*sin(q) or 0,0)
   move("Body",0,-.10*pulse,0)
  end
  solveQuadruped(ctx,P,f,moving,flying)
 end
 return P
end
local function bake(ctx)
 local specs={{name="Idle",duration=4,loop=true},{name="Locomotion",duration=3.2,loop=true},{name="Action",duration=3,loop=false}}
 if ctx.key=="griffin" then table.insert(specs,{name="Flight",duration=3.2,loop=true}) end
 for _,spec in ipairs(specs) do
  local seq=Instance.new("KeyframeSequence");seq.Name=spec.name;seq.Loop=spec.loop
  seq.Priority=spec.name=="Idle" and Enum.AnimationPriority.Idle or (spec.name=="Locomotion" and Enum.AnimationPriority.Movement or Enum.AnimationPriority.Action)
  seq:SetAttribute("Generator","Series01_OfflineFK_QuadrupedIK");seq:SetAttribute("Duration",spec.duration)
  seq:SetAttribute("BakedFPS",Config.BakeFPS);seq:SetAttribute("RigContract","Babaar_Series01_PivotRig_v1")
  local meta=folder(spec.name,ctx.clipMeta,"Configuration")
  meta:SetAttribute("Loop",spec.loop);meta:SetAttribute("Priority",seq.Priority.Name);meta:SetAttribute("Duration",spec.duration)
  local count=math.ceil(spec.duration*Config.BakeFPS)
  local markerFrames={}
  local function mark(time,name,value)
   local idx=math.clamp(math.floor(time/spec.duration*count+.5),0,count)
   markerFrames[idx]=markerFrames[idx] or {};table.insert(markerFrames[idx],{name,value or ""})
  end
  if spec.name~="Idle" then mark(.08,"FXOn");mark(spec.duration-.13,"FXOff") end
  if spec.name=="Action" then mark(spec.duration*.50,"Burst") end
  if spec.name=="Locomotion" and ctx.legs then
   for _,leg in ipairs(ctx.legs) do mark(math.max(.03,((1-OFFSETS[leg.id])%1)*spec.duration),"Footstep",leg.id) end
  elseif spec.name=="Locomotion" and ctx.key=="kaiju" then mark(.04,"Footstep","L");mark(spec.duration*.5,"Footstep","R") end
  for k=0,count do
   local P=sample(ctx,spec.name,k/count)
   local frame=Instance.new("Keyframe");frame.Name="Frame_"..k;frame.Time=spec.duration*k/count;frame.Parent=seq
   local poses={}
   for _,node in ipairs(ctx.order) do
    local pose=Instance.new("Pose");pose.Name=node.name;pose.CFrame=scaled(P[node.name] or CF())
    pose.Weight=node.parent and 1 or 0;pose.EasingStyle=Enum.PoseEasingStyle.Linear
    pose.EasingDirection=Enum.PoseEasingDirection.InOut;pose.Parent=node.parent and poses[node.parent.name] or frame
    poses[node.name]=pose
   end
   for _,m in ipairs(markerFrames[k] or {}) do local marker=Instance.new("KeyframeMarker");marker.Name=m[1];marker.Value=m[2];marker.Parent=frame end
   if k%24==0 then task.wait() end
  end
  seq.Parent=ctx.clips;ctx.model:SetAttribute(spec.name.."AnimationId","")
 end
end

local RUNTIME=[==[
-- Self-contained Animator + VFX runtime. No AI, steering or damage.
local model=script.Parent
local RunService=game:GetService("RunService")
local Players=game:GetService("Players")
local animator=model:FindFirstChildOfClass("AnimationController"):FindFirstChildOfClass("Animator")
local saves=model:FindFirstChild("AnimSaves")
local specs=model:FindFirstChild("ClipSpecs")
local root=model.PrimaryPart
local tracks,emitters,beams,connections={},{},{},{}
local current,currentName=nil,nil
local near=false;local loading=false;local running=true
for _,d in ipairs(model:GetDescendants()) do if d:IsA("ParticleEmitter") then table.insert(emitters,d) elseif d:IsA("Beam") then table.insert(beams,d) end end
local function quality() return math.clamp(tonumber(model:GetAttribute("VFXQuality")) or 1,0,2) end
local function effects(on)
 local q=quality()
 for _,e in ipairs(emitters) do
  local base=e:GetAttribute("BaseRate") or 0
  e.Rate=base*(q==2 and 1 or .60)
  local clip=e:GetAttribute("EffectClip")
  e.Enabled=on and near and q>0 and base>0 and (not clip or clip==currentName)
 end
 for _,b in ipairs(beams) do local clip=b:GetAttribute("EffectClip");b.Enabled=on and near and q>0 and (not clip or clip==currentName) end
end
local function burst(foot)
 if not near or quality()==0 then return end
 local matched=false
 if foot then
  for _,e in ipairs(emitters) do
   if e:GetAttribute("FootId")==foot then e:Emit(quality()==2 and 9 or 5);matched=true end
  end
 end
 if not matched then
  for _,e in ipairs(emitters) do
   if (e:GetAttribute("BaseRate") or 0)==0 then e:Emit(quality()==2 and 12 or 7) end
  end
 end
 -- Action bursts also briefly accent the existing continuous emitters, with a fixed cap.
 if not foot then for _,e in ipairs(emitters) do if (e:GetAttribute("BaseRate") or 0)>0 then e:Emit(quality()==2 and 7 or 4) end end end
end
local function getId(name)
 local raw=tostring(model:GetAttribute(name.."AnimationId") or "")
 local digits=raw:match("^rbxassetid://(%d+)$") or raw:match("^(%d+)$")
 if digits and tonumber(digits)>0 then return "rbxassetid://"..digits end
 if RunService:IsStudio() and model:GetAttribute("StudioPreview")~=false then
  local sequence=saves and saves:FindFirstChild(name)
  if sequence then
   local ok,id=pcall(function() return game:GetService("KeyframeSequenceProvider"):RegisterKeyframeSequence(sequence) end)
   if ok then return id end
  end
 end
 return nil
end
local warned={}
local function trackFor(name)
 if tracks[name] then return tracks[name] end
 if warned[name] then return nil end
 local id=getId(name)
 if not id then
  if not warned[name] then warn("["..model.Name.."] Publish AnimSaves/"..name.." and set "..name.."AnimationId. No fake runtime fallback is being used.");warned[name]=true end
  return nil
 end
 local animation=Instance.new("Animation");animation.AnimationId=id
 local ok,track=pcall(function() return animator:LoadAnimation(animation) end)
 animation:Destroy()
 if not ok then warned[name]=true;warn("["..model.Name.."] Animation load failed: "..tostring(track));return nil end
 local seq=saves and saves:FindFirstChild(name)
 local meta=specs and specs:FindFirstChild(name)
 if meta then
  track.Looped=meta:GetAttribute("Loop")==true
  local priority=meta:GetAttribute("Priority") or "Action"
  track.Priority=Enum.AnimationPriority[priority]
 elseif seq then track.Looped=seq.Loop;track.Priority=seq.Priority end
 table.insert(connections,track:GetMarkerReachedSignal("FXOn"):Connect(function() if current==track then effects(true) end end))
 table.insert(connections,track:GetMarkerReachedSignal("FXOff"):Connect(function() if current==track then effects(false) end end))
 table.insert(connections,track:GetMarkerReachedSignal("Burst"):Connect(function() if current==track then burst() end end))
 table.insert(connections,track:GetMarkerReachedSignal("Footstep"):Connect(function(value) if current==track then burst(value) end end))
 table.insert(connections,track.Stopped:Connect(function()
  if current==track and currentName=="Action" then model:SetAttribute("ActiveClip","Idle") end
 end))
 tracks[name]=track;return track
end
local function stop()
 current=nil;currentName=nil
 for _,t in pairs(tracks) do t:Stop(.15) end
 effects(false)
end
local function update()
 if not running or loading then return end
 if not near or model:GetAttribute("AnimationEnabled")==false then stop();return end
 local name=tostring(model:GetAttribute("ActiveClip") or "Idle")
 if not ((specs and specs:FindFirstChild(name)) or (saves and saves:FindFirstChild(name))) then name="Idle" end
 if current and currentName==name and current.IsPlaying then return end
 loading=true
 local track=trackFor(name)
 if track then
  local old=current;current=nil;if old then old:Stop(.18) end
  effects(false);current=track;currentName=name;track:Play(.18)
 end
 loading=false
end
for _,attribute in ipairs({"ActiveClip","AnimationEnabled","VFXQuality"}) do
 table.insert(connections,model:GetAttributeChangedSignal(attribute):Connect(function()
  if attribute=="VFXQuality" then effects(false) end
  update()
 end))
end
for _,attribute in ipairs({"IdleAnimationId","LocomotionAnimationId","ActionAnimationId","FlightAnimationId"}) do
 table.insert(connections,model:GetAttributeChangedSignal(attribute):Connect(function()
  stop();for _,t in pairs(tracks) do t:Destroy() end;tracks={};warned={};update()
 end))
end
local function isNearPlayer()
 if not root or not root.Parent then return false end
 local maxDistance=tonumber(model:GetAttribute("ActivationDistance")) or 120
 for _,player in ipairs(Players:GetPlayers()) do
  local ch=player.Character;local hrp=ch and ch:FindFirstChild("HumanoidRootPart")
  if hrp and (hrp.Position-root.Position).Magnitude<=maxDistance then return true end
 end
 return false
end
-- One coarse check per asset per second; no per-frame procedural geometry or IK.
while model.Parent and running do
 near=isNearPlayer();update();task.wait(1)
end
running=false;stop()
for _,c in ipairs(connections) do c:Disconnect() end
for _,t in pairs(tracks) do t:Destroy() end
]==]
local CATALOG={
 {key="griffin",name="01_Aurum_Griffin",actions="Idle / Walk / Roar-WingDisplay / Flight"},
 {key="owl",name="02_Moonwatch_Owl",actions="Idle / Flight / HeadScan"},
 {key="titanoboa",name="03_Verdant_Titanoboa",actions="Idle / Slither / VenomDisplay"},
 {key="kaiju",name="04_Abyssal_Crystal_Titan",actions="Idle / Walk / ResonanceRoar"},
 {key="wolf",name="05_Frostmane_Wolf",actions="Idle / Walk / Howl"},
 {key="eagle",name="06_Cliffguard_Eagle",actions="Idle / Flight / ThreatDisplay"},
 {key="megalodon",name="07_Trench_Megalodon",actions="Idle / Swim / Bite"},
 {key="f16",name="08_F16_Reference_Fighter",actions="Idle / FlightPose / EngineCanopyCheck"},
 {key="rocket",name="09_Orbital_Pathfinder",actions="Idle / PoweredFlightPose / StageSeparationDisplay"},
 {key="phoenix",name="10_Cindercrest_Phoenix",actions="Idle / Flight / FlareDisplay"},
}
local wanted={};for _,key in ipairs(Config.Only) do wanted[key]=true end
for key in pairs(wanted) do assert(Builders[key],"Unknown asset key: "..tostring(key)) end
local report={};local built=0
pcall(function() History:SetWaypoint("Before_Babaar_Series01") end)
local previous=Workspace:FindFirstChild(Config.CollectionName)
local ok,err=xpcall(function()
 for _,entry in ipairs(CATALOG) do
  if #Config.Only==0 or wanted[entry.key] then
   built+=1
   local column=(built-1)%5;local row=math.floor((built-1)/5)
   local position=Config.Origin+V((column-2)*Config.Spacing*S,0,row*Config.Spacing*S)
   local ctx=newAsset(entry.key,entry.name,position,{})
   Builders[entry.key](ctx)
   if Config.CreateQueryHitbox then
    local boxes={griffin={V(3.8,5.5,9),V(0,4.5,-.8)},owl={V(4.5,7,4),V(0,4,-.4)},titanoboa={V(7,4,27),V(0,2,0)},kaiju={V(7,15,10),V(0,8,-1)},wolf={V(3.5,6.5,10),V(0,3.6,-.4)},eagle={V(3.5,6,8),V(0,4,-.5)},megalodon={V(6,7,21),V(0,5.5,1)},f16={V(5,9,32),V(0,6,-1)},rocket={V(9,29,7),V(0,15,0)},phoenix={V(4,10,14),V(0,5,1)}}
    local spec=boxes[entry.key];local hit=ctx:part("QueryHitbox","RootPart",spec[1],CF(spec[2]),C.black,false,nil,nil,1)
    hit.CanQuery=true;hit.CastShadow=false;ctx.hitbox=hit
   end
   bake(ctx)
   if Config.InstallRuntime then local script=Instance.new("Script");script.Name="AssetAnimator_VFX";script.Source=RUNTIME;script.Parent=ctx.model end
   -- One invisible carrier per bone, visual geometry welded to exactly one carrier.
   local driven={}
   for _,node in ipairs(ctx.order) do if node.parent then assert(not driven[node.part],"Two motors drive one bone");driven[node.part]=true end end
   local baseParts=ctx.count+#ctx.order
   ctx.model:SetAttribute("GeometryParts",ctx.count-(ctx.hitbox and 1 or 0));ctx.model:SetAttribute("TotalBaseParts",baseParts)
   ctx.model:SetAttribute("TextureCount",ctx.textureCount);ctx.model:SetAttribute("MotorCount",ctx.motorCount)
   ctx.model:SetAttribute("AnimationList",entry.actions)
   ctx.model:SetAttribute("BoundsAreVisualOnly",true)
   ctx.model:SetAttribute("CommercialRightsNotVerified",true)
   local line=string.format("%s | Geometry=%d | BaseParts=%d | Textures=%d | Motors=%d",entry.name,ctx.count-(ctx.hitbox and 1 or 0),baseParts,ctx.textureCount,ctx.motorCount)
   table.insert(report,line);print("[Series01] "..line)
  end
 end
end,debug.traceback)
if not ok then collection:Destroy();error("[Series01] Build aborted; previous collection preserved.\n"..tostring(err)) end
collection:SetAttribute("AssetCount",built);collection.Parent=Workspace
if previous then previous:Destroy() end
if Config.FrameCamera and Workspace.CurrentCamera then
 Workspace.CurrentCamera.CFrame=CFrame.lookAt(Config.Origin+V(117,106,-128)*S,Config.Origin+V(0,8,22)*S)
 Workspace.CurrentCamera.Focus=CF(Config.Origin+V(0,8,22)*S)
end
pcall(function() Selection:Set({collection});History:SetWaypoint("Created_Babaar_Series01") end)
print("[Series01] Built "..built.." independent assets. Test in Studio; publish clips before production. No AI/vehicle gameplay included.")
