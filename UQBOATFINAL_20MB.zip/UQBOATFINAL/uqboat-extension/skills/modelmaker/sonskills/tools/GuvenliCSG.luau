-- HarikaModelleme v2. Primitive-only static CSG helper; not a rig retarget tool.
-- Documentation-backed API shape; NOT engine-tested by this skill package.
local GeometryService=game:GetService("GeometryService")
local CSG={}
local ALLOWED={Part=true,WedgePart=true,CornerWedgePart=true}
local function inspect(p,deleteSources)
 assert(typeof(p)=="Instance" and p:IsA("BasePart"),"BasePart source required")
 assert(ALLOWED[p.ClassName],"This helper accepts primitive parts only; no mesh/Beta assumptions")
 assert(p.Anchored,"Only static anchored source geometry is supported")
 assert(#p:GetConnectedParts(true)==0,"Connected sources require an explicit constraint-preservation workflow")
 for _,d in ipairs(p:GetDescendants()) do
  assert(not(d:IsA("Attachment") or d:IsA("JointInstance") or d:IsA("Constraint") or d:IsA("WeldConstraint")),"Rig/attachment source not supported by this small helper")
 end
 if deleteSources then assert(p:GetAttribute("HMSkillOwnedCSGSource")==true,"Deletion requires explicitly tagged owned temporary sources") end
end
function CSG.Build(operation,main,others,settings)
 settings=settings or {};others=others or {}
 assert(operation=="Union" or operation=="Subtract" or operation=="Intersect","Unknown CSG operation")
 assert(#others>0,"At least one secondary source required")
 local deleteSources=settings.DeleteSources==true
 inspect(main,deleteSources)
 local seen={[main]=true}
 for _,p in ipairs(others) do inspect(p,deleteSources);assert(not seen[p],"Duplicate source");seen[p]=true end
 local parent=settings.Parent or main.Parent;assert(parent,"Output parent required")
 local options={
  SplitApart=settings.SplitApart~=false,
  CollisionFidelity=settings.CollisionFidelity or Enum.CollisionFidelity.Default,
  RenderFidelity=settings.RenderFidelity or Enum.RenderFidelity.Automatic,
 }
 local ok,results=pcall(function()
  if operation=="Union" then return GeometryService:UnionAsync(main,others,options)
  elseif operation=="Subtract" then return GeometryService:SubtractAsync(main,others,options)
  else return GeometryService:IntersectAsync(main,others,options) end
 end)
 if not ok then return nil,"CSG call failed; sources preserved: "..tostring(results) end
 if type(results)~="table" or #results==0 then return nil,"Empty/unexpected CSG result; sources preserved" end
 local stage=Instance.new("Folder");stage.Name=settings.Name or (main.Name.."_"..operation)
 local committed,err=pcall(function()
  for i,p in ipairs(results) do
   assert(typeof(p)=="Instance" and p:IsA("BasePart"),"Unexpected result type")
   assert(p.Size.X>0 and p.Size.Y>0 and p.Size.Z>0,"Nonpositive CSG result")
   p.Name=stage.Name.."_"..i;p.Anchored=true
   p.CanCollide=main.CanCollide;p.CanTouch=main.CanTouch;p.CanQuery=main.CanQuery
   -- Preserve the engine-returned transform. Do not force every fragment to main.CFrame.
   if settings.CopyAppearance then
    p.Color=main.Color;p.Material=main.Material;p.Transparency=main.Transparency
    if p:IsA("PartOperation") then p.UsePartColor=true end
   end
   p.Parent=stage
  end
  stage.Parent=parent
 end)
 if not committed then
  stage:Destroy()
  for _,p in ipairs(results) do if typeof(p)=="Instance" then p:Destroy() end end
  return nil,"Result staging failed; sources preserved: "..tostring(err)
 end
 if deleteSources then main:Destroy();for _,p in ipairs(others) do p:Destroy() end end
 return results,stage
end
return CSG
