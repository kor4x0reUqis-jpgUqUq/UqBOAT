-- Pass the required GeometriAraclari module to this test function.
-- Tests descriptors/math, not engine creation, collision, rendering or CSG.
return function(G)
 local V,CF=Vector3.new,CFrame.new
 for _,axis in ipairs({"X","Y","Z"}) do
  local size=V(6,9,12)
  local bands=G.GradientBands(size,CF(),Color3.fromRGB(20,30,40),Color3.fromRGB(200,210,220),3,axis,true,0)
  assert(#bands==3)
  local sum=0
  for _,b in ipairs(bands) do sum+=b.Size[axis];assert(b.Size.X>0 and b.Size.Y>0 and b.Size.Z>0) end
  assert(math.abs(sum-size[axis])<1e-5,"Band extent mismatch")
 end
 local pieces=G.TrianglePieces(V(),V(3,0,0),V(0,0,4),.2)
 assert(#pieces==2,"Right triangle should produce two nondegenerate wedges for this orientation")
 assert(#G.TrianglePieces(V(),V(1,0,0),V(2,0,0),.2)==0)
 local holes={{x0=-3,x1=1,z0=-1,z1=1},{x0=-1,x1=4,z0=-1,z1=1},{x0=30,x1=40,z0=-1,z1=1}}
 local spans=G.DeckSpans(-10,10,-.4,.4,holes)
 assert(#spans==2 and spans[1][1]==-10 and spans[1][2]==-3 and spans[2][1]==4 and spans[2][2]==10)
 assert(#G.DeckSpans(-10,10,-.4,.4,{{x0=-30,x1=30,z0=-1,z1=1}})==0)
 assert(#G.DeckSpans(-10,10,-.4,.4,{{x0=30,x1=40,z0=-1,z1=1}})==1)
 local f=G.SurfaceFrame(V(),V(0,0,1),V(0,0,1))
 local p=f:PointToWorldSpace(V(0,1,0))
 assert((p-V(0,0,1)).Magnitude<1e-5,"Fallback normal frame mismatch")
 return true
end
