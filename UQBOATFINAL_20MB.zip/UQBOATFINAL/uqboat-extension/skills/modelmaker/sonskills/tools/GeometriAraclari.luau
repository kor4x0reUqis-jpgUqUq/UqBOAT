-- HarikaModelleme v2: pure geometry descriptors, not a finished model generator.
-- Put in a ModuleScript when using in Studio; caller creates Parts and rig bindings.
local G={}
local V,CF=Vector3.new,CFrame.new
local function validSize(size)
 assert(size.X>0 and size.Y>0 and size.Z>0,"Dimensions must be positive")
end
function G.Smooth(t)
 t=math.clamp(t,0,1);return t*t*(3-2*t)
end
function G.Along(a,b)
 local delta=b-a;assert(delta.Magnitude>1e-5,"Coincident endpoints")
 local up=math.abs(delta.Unit.Y)>.97 and V(0,0,1) or V(0,1,0)
 return CFrame.lookAt((a+b)/2,b,up),delta.Magnitude
end
function G.SurfaceFrame(position,normal,longitudinal)
 assert(normal.Magnitude>1e-5,"Missing surface normal")
 local y=normal.Unit;local z=longitudinal or V(0,0,1)
 z=z-y*z:Dot(y)
 if z.Magnitude<1e-5 then
  local fallback=math.abs(y.X)<.9 and V(1,0,0) or V(0,0,1)
  z=fallback-y*fallback:Dot(y)
 end
 z=z.Unit
 return CFrame.fromMatrix(position,y:Cross(z).Unit,y,z)
end
function G.GradientBands(size,cf,low,high,count,axis,endpoints,overlap)
 validSize(size);count=count or 3;axis=axis or "Z";overlap=overlap or 0
 assert(count>=1 and count%1==0,"Integer band count required")
 assert(axis=="X" or axis=="Y" or axis=="Z","Axis must be X/Y/Z")
 assert(overlap>=0,"Overlap cannot be negative")
 local extent=size[axis];local out={}
 for i=1,count do
  local u=(i-.5)/count
  local sample=endpoints and (count==1 and .5 or (i-1)/(count-1)) or u
  local shift=axis=="X" and V((u-.5)*extent,0,0) or (axis=="Y" and V(0,(u-.5)*extent,0) or V(0,0,(u-.5)*extent))
  local piece=axis=="X" and V(extent/count+overlap,size.Y,size.Z) or (axis=="Y" and V(size.X,extent/count+overlap,size.Z) or V(size.X,size.Y,extent/count+overlap))
  table.insert(out,{Size=piece,CFrame=cf*CF(shift),Color=low:Lerp(high,G.Smooth(sample)),Index=i,Count=count,Axis=axis,LocalShift=shift})
 end
 return out -- LocalShift is a phase hint; caller maps it to each face's U/V basis.
end
function G.TrianglePieces(a,b,c,thickness)
 assert(thickness>0,"Positive thickness required")
 local ab,ac,bc=b-a,c-a,c-b
 if ab:Dot(ab)>ac:Dot(ac) and ab:Dot(ab)>bc:Dot(bc) then a,c=c,a
 elseif ac:Dot(ac)>ab:Dot(ab) and ac:Dot(ac)>bc:Dot(bc) then a,b=b,a end
 ab,ac,bc=b-a,c-a,c-b
 local cross=ac:Cross(ab)
 if cross.Magnitude<1e-5 or bc.Magnitude<1e-5 then return {} end
 local right,back=cross.Unit,bc.Unit;local up=back:Cross(right).Unit
 local height=math.abs(ab:Dot(up));if height<.005 then return {} end
 local result={};local l1,l2=math.abs(ab:Dot(back)),math.abs(ac:Dot(back))
 if l1>.005 then table.insert(result,{ClassName="WedgePart",Size=V(thickness,height,l1),CFrame=CFrame.fromMatrix((a+b)/2,right,up,back)}) end
 if l2>.005 then table.insert(result,{ClassName="WedgePart",Size=V(thickness,height,l2),CFrame=CFrame.fromMatrix((a+c)/2,-right,up,-back)}) end
 return result
end
function G.DeckSpans(xmin,xmax,zmin,zmax,holes)
 assert(xmax>xmin and zmax>zmin,"Invalid deck row bounds")
 local spans={{xmin,xmax}}
 for _,hole in ipairs(holes or {}) do
  assert(hole.x1>hole.x0 and hole.z1>hole.z0,"Invalid hole rectangle")
  if hole.z0<zmax and hole.z1>zmin then
   local nextSpans={}
   for _,span in ipairs(spans) do
    if hole.x1<=span[1] or hole.x0>=span[2] then
     table.insert(nextSpans,span)
    else
     if hole.x0>span[1] then table.insert(nextSpans,{span[1],math.min(hole.x0,span[2])}) end
     if hole.x1<span[2] then table.insert(nextSpans,{math.max(hole.x1,span[1]),span[2]}) end
    end
   end
   spans=nextSpans
  end
 end
 return spans -- Structural underbeams need the SAME void logic, not just the floor.
end
return G
