ClaudeModelling
===============
Steal An Egg (Roblox) creature models, original resolution (WebP, up to 1254 px).

Pets/        Pets and creatures (one image per pet)
Fantastic/   Fantasy / mythological pets (copies of Pets)
Eggs/        Egg images ("<Pet> Egg.webp")
Mutations/   Mutation variants

index.csv    Every file: game, category, name, file

Not included: trails, treadmills, biomes, updates, shop.
Angle views: the wiki has one image per pet, so rear and side views are not available here.

Sources and rights
------------------
Steal An Egg: https://stealanegg.fandom.com/wiki/Steal_An_Egg_Wiki
The game images belong to their developers. Keep the permission and the source credit with any use.
