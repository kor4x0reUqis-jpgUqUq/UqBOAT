---
name: roblox-shop-ui-asset-to-game
description: Analyze a visual shop reference, generate its UI art as independent importable assets, implement the responsive Roblox ScreenGui, and coordinate authorized asset upload through a user-provided MCP/plugin and secure cloud backend. Use when building or adapting a Roblox shop, inventory, gamepass, vehicle shop, or similar image-led UI from a reference.
---

# Roblox Shop UI: reference → independent art → Roblox UI

## Mission
Deliver an attractive, readable, responsive Roblox UI and a traceable asset package. The UI art and product illustrations must be generated as **separate assets**—not extracted by cropping a finished screenshot. Keep text, prices, localization, and interactive hit targets editable in Roblox wherever possible.

## Non-negotiable rules
1. **Never substitute crops for requested independent art.** Do not crop, slice, mask, or run GrabCut on a composed screenshot and present those pieces as newly-created assets. The prior failure was a flattened screenshot split into rectangular crops; the user correctly rejected the result because edges/background fragments looked poor. Crops are allowed only when explicitly requested, or as temporary analysis/reference—not as final art.
2. **One image-generation request = one standalone asset.** Never ask the image model for a contact sheet, sprite sheet, grid, collage, montage, screenshot with multiple requested layers, or several variants in one image. Use separate image-generation calls for distinct assets. For assets inside a larger build, do not interrupt with style options unless the user asks; make a coherent first pass.
3. **Prompt for alpha, then verify alpha.** Say “isolated on a genuinely transparent background; no checkerboard, no white/colored backdrop, no ground/shadow unless requested.” Inspect the actual PNG alpha channel. A checkerboard shown in a preview might be the viewer's transparency visualization—or it might be baked into RGB. Do not assume: inspect `mode`, alpha extrema and representative border pixels. If baked in, clean carefully and visually verify or regenerate; never ship a fake checker background.
4. **Respect image-generation limits.** Batch independent assets, record completed and remaining items in `examples/progress.json`, and stop when the tool reports a limit. Do not silently replace missing generated art with crops or low-quality hand-drawn stand-ins. Tell the user exactly what is done and what remains; continue next turn.
5. **Maintain style consistency.** Use the reference as style/composition guidance only. Carry forward a short style lock (palette, outline, shading, perspective, amount of detail) in every prompt. Do not reuse brand-protected logos or claim a generated asset is an exact extraction.
6. **Separate art from interface text.** Generate clean background/button surfaces without words when labels need to be dynamic or localized. Build labels, prices, timers and descriptions as `TextLabel`/`TextButton` objects. Use image-baked text only when the user explicitly needs fixed lettering and the output is checked for legibility.
7. **High contrast is part of acceptance.** Test actual text/background pairs: target WCAG contrast ≥4.5:1 for normal text and ≥3:1 for large text and meaningful graphic controls. A thick outline helps but does not replace contrast measurement. Avoid text over busy pattern; add a solid/quiet backing plate or dark stroke. Keep text size readable at mobile scale.
8. **Never invent Roblox asset IDs or API results.** Only set `rbxassetid://<id>` after the authorized upload response returns that ID. Use the exact uploaded asset IDs supplied by the plugin/backend or user.
9. **Secure cloud upload.** Never place Open Cloud keys, cookies, OAuth refresh tokens, or secrets in a LocalScript, Studio plugin source, a zip, browser storage, logs, or a user-visible manifest. The plugin/MCP client should call an authenticated backend; the backend holds secrets in a vault/environment and applies least privilege. Never ask the user to paste secrets into the chat.
10. **Do not publish or overwrite destructively without confirmation.** Show a plan/preview, confirm target experience/group and asset names, then upload. Use versioned names and preserve prior assets; publication/monetization changes require explicit user approval.

## Workflow (execute in order)

### A. Intake and reference analysis
- Identify target platform (Roblox), viewport(s), shop type, style, required pages/states, language, and whether the art should be close to a reference or only inspired by it. Ask only questions that block a useful first pass.
- Inspect the reference. Write a compact visual spec: approximate panel bounds/aspect, header, number/shape of cards, scrolling, palette, contours, ornament, typography, contrast, product subjects, and control positions.
- Make an asset inventory **before generating**. A typical car shop needs: empty panel/frame, header strip, card backgrounds by theme, purchase button, gift button, close button, small shop/cart icon, individual product renders, distinct overlays (snow/shine/fire), and optional repeating texture. Dynamic text is not an image asset.
- Create a progress/manifest file. Mark which assets can be reused from the user's accepted assets and which must be generated fresh. Do not treat past cropped assets as approved independent assets.

### B. Asset generation
- Generate each item separately. Use `prompts/PROMPT_LIBRARY.md`; include shape/aspect, exact subject, view, palette, outline, shading, transparency, exclusions, and intended Roblox role.
- For a UI surface: no product, no text, no unrelated controls. For a product render: one complete object, isolated, all extremities/wheels in frame. For effects: transparent overlay with sparse compositional placement. For button backgrounds: leave a clean label area, unless user asks for integrated text.
- Use a fixed style lock. Example: “playful Roblox game-shop illustration, saturated cyan/blue and lime, dark navy 6–10% contour, glossy cel shading, crisp silhouettes, front/three-quarter orthographic feel.” Adjust to the user's reference, not blindly.
- Save each output under a deterministic filename such as `assets/generated/07_sports_car.png`. Keep the prompt and generation status in the manifest. Use parallel calls only for distinct assets that do not depend on one another.
- If a generation response represents transparency with checker tiles, verify with Pillow. If actual alpha is absent, treat as a defect—not a transparent asset. Prefer regeneration with clearer instructions; only perform background removal when the silhouette is unambiguous and after edge QA.
- Inspect every output at native size and at intended in-UI size. Reject checkerboard artifacts, clipped wheels, malformed UI geometry, unintended text, inconsistent perspective, low contrast, and busy/dirty silhouettes. Regenerate failures as a separate asset, not as a composite.

### C. Compose and validate the UI
- Implement the interface with Roblox GUI objects and the separate artwork. Keep input controls separate from decorative `ImageLabel`s.
- Use `ScreenGui`, centered `ShopWindow`, `ImageLabel` frame/header/card, `ScrollingFrame`, `UIGridLayout` or vertical `UIListLayout`, `TextLabel`s and `ImageButton`s. Use `UIScale` and `UIAspectRatioConstraint` thoughtfully; test desktop and mobile, landscape and portrait, safe areas, and text wrapping.
- Set images `BackgroundTransparency = 1`; use `ScaleType = Fit` for product art and `Slice`/`Tile` only when the image has safe insets or repeatable texture. Avoid stretching ornate corner art. Use nine-slice borders where the asset was designed for it.
- Keep client UI cosmetic. Purchases, currency, ownership, vehicle grants, timers, and entitlements are validated on the server. A client button only requests an action; it cannot be trusted as proof of purchase.
- Run contrast, alpha, dimension, file-format and runtime checks. See `docs/STYLE_AND_QA.md` and `tools/validate_assets.py`.

### D. Authorized MCP/plugin/cloud upload
- Inspect available MCP tools/schema first. Do not assume a tool name or invent request fields. If no authorized connection is available, produce the assets and integration contract; ask the user to connect/configure their plugin/backend rather than pretending to upload.
- Upload only after the user confirms the target experience/group, asset names, visibility and intended use. Upload each PNG as its own image/decal asset using the current official Roblox Open Cloud flow or the user's approved integration.
- The Studio plugin/MCP connector sends asset bytes and metadata to a backend over authenticated transport. Backend validates file type/size, dimensions, ownership context and allowlisted operation; stores credentials in a secret manager; records audit events; calls the current Open Cloud asset endpoint; polls moderation/processing status if required; returns only success/failure and actual returned IDs.
- Handle retries, rate limits, idempotency keys, partial failure and moderation-pending state. Never return success before Roblox confirms the resulting asset identity/status. Store returned IDs in a generated manifest and optionally `AssetIds.lua`; never invent IDs.
- Use returned IDs to update GUI references, run Studio preview, and ask for approval before publishing the experience.

### E. Handoff
- Provide one ZIP containing: this skill's project-specific output if requested, separate generated PNGs, manifest, UI source, setup instructions, QA results, and a clear pending-items list. Keep generated assets separate in the package; a preview gallery is for review only, not an import asset.
- State what is truly generated, what is a placeholder, what is uploaded, and what requires user authorization. Don't claim a cloud upload or live MCP action unless it actually succeeded.

## This skill's example project
The `assets/generated/` folder contains ten independently generated examples from the accepted car-shop art direction. They were not cropped from the finished UI. `examples/progress.json` records known remaining art (orange Halloween card/fire effect) because the previous generation turn hit a tool limit. Continue those as separate image-generation jobs; don't fabricate completion.
