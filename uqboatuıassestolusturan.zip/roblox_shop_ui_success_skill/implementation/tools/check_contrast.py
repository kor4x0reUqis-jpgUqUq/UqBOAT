#!/usr/bin/env python3
"""WCAG 2.x sRGB contrast calculator for '#RRGGBB' foreground/background pairs."""
import argparse

def lum(hexcolor):
    s=hexcolor.strip().lstrip('#')
    if len(s)!=6: raise ValueError(f'Expected #RRGGBB: {hexcolor}')
    rgb=[int(s[i:i+2],16)/255 for i in (0,2,4)]
    def linear(c): return c/12.92 if c<=0.04045 else ((c+0.055)/1.055)**2.4
    r,g,b=map(linear,rgb)
    return 0.2126*r+0.7152*g+0.0722*b

def ratio(a,b):
    x,y=sorted([lum(a),lum(b)],reverse=True)
    return (x+0.05)/(y+0.05)

def main():
    p=argparse.ArgumentParser(); p.add_argument('foreground'); p.add_argument('background'); p.add_argument('--large',action='store_true'); a=p.parse_args()
    r=ratio(a.foreground,a.background); need=3.0 if a.large else 4.5
    print(f'{a.foreground} on {a.background}: {r:.2f}:1 — {"PASS" if r>=need else "FAIL"} (target {need}:1)')
    raise SystemExit(0 if r>=need else 2)
if __name__=='__main__': main()
