# Roblox Shop UI Asset-to-Game Skill

Bu ZIP, yeni sohbetlerde veya farklı ajanlarda aynı çalışma disiplinini sürdürmek için hazırlanmış kapsamlı bir skill paketidir. Referans analizi, bağımsız görsel üretimi, yüksek kontrast, Roblox arayüz kodlaması ve yetkili MCP/plugin + cloud API yükleme sürecini kapsar.

## Dosya yapısı
- `SKILL.md` — ajan için ana talimatlar ve zorunlu kurallar.
- `docs/` — uçtan uca iş akışı, tasarım/QA ve MCP/cloud güvenliği.
- `prompts/` — tekrarlanabilir görsel üretim prompt şablonları ve iyi/kötü örnekler.
- `assets/generated/` — bu konuşmada ayrı ayrı görsel üretimiyle yapılan 10 PNG örnek.
- `assets/reference/` — stil referansı olarak kullanılan tamamlanmış araba mağazası resmi. Bu dosya bileşenleri kırpmak için değil, stil rehberi olarak eklenmiştir.
- `examples/` — manifest, stil tokenları ve devam durumu.
- `roblox/` — güvenli, düzenlenebilir GUI oluşturucu örneği ve asset ID şablonu.
- `tools/validate_assets.py` — PNG/alfa/ölçü ve manifest doğrulama aracı.

## Önemli ders
Önceki denemede düzleştirilmiş ekran görüntüsü kırpılarak parçalanmıştı; bu kötü kenar ve arka plan parçaları üretti. Kullanıcı doğru biçimde reddetti. Bu skill, bunu açık bir anti-pattern olarak tanımlar: istenen final UI varlıkları her biri **ayrı görsel üretim isteğiyle** hazırlanmalı. Kırpma yalnızca kullanıcı özellikle isterse yapılır.

## Kullanım
Yeni ajana önce `SKILL.md` dosyasını okut. Sonra proje isteği, referans görseli, hedef en-boy oranı ve mevcut asset manifestini ver. Ajan önce plan/manifest çıkarır; ayrı görsel assetlerini üretir, kalite kontrol yapar; ardından Roblox UI ve güvenli yükleme entegrasyonunu tamamlar. Tur başına üretim sınırına gelirse ilerlemeyi `examples/progress.json` içine yazar ve eksikleri açıkça bildirir.

## Çalıştırma
Python 3 ve Pillow kuruluysa:
```bash
python tools/validate_assets.py --manifest examples/asset_manifest.json
```

Roblox ID alanları bilerek boştur. Gerçek yükleme ve dönen ID'ler olmadan `rbxassetid://...` değerleri uydurulmaz. API anahtarı, Open Cloud secret'ı veya kullanıcı kimlik bilgileri bu ZIP'e eklenmez.
