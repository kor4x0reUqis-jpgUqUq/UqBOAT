# Bağımsız asset üretimi için prompt kitaplığı

Her prompt tek bir image-gen call içindir. `[STYLE_LOCK]` tüm set boyunca aynı kalmalı. Kullanıcı başka bir boyut istemezse geniş UI yüzeyleri yatay, ikonlar kare, ürünler yatay kesintisiz görsel olarak üretilir. Gerekirse dosya/piksel oranını ayrıca ayarla.

## Genel stil kilidi
`[STYLE_LOCK] = playful polished Roblox game-shop illustration, vivid saturated colors, thick clean dark navy contour, glossy cel-shading, subtle bevel/highlights, crisp readable silhouette at small UI size, consistent three-quarter/front perspective, coherent outline weight and lighting with the supplied style reference.`

Prompt her zaman şunları içersin:
- `Create ONE standalone [exact asset] only.`
- Bu assetin hangi UI rolünde olacağı, şekil ve yaklaşık aspect ratio.
- Renkler, kontur kalınlığı, malzeme/ışık, görünüş açısı.
- `Transparent background, no checkerboard, no white or colored backdrop` (mümkünse); gerçek alfa kanalını sonradan kontrol et.
- Hariç tutulanlar: unrelated icons/text, screenshot, extra buttons, scene/ground, clipping.
- UI yazıları için: `No words or digits; leave a clean area for Roblox TextLabel.`

## Prompt A — panel/frame
`Create ONE isolated wide Roblox game shop outer frame only, about 1.67:1. Empty fully transparent opening in the center, transparent outside the frame. Icy cyan trim, dark navy thick outline, cool slate metallic side/bottom rim, small cloud curls at four corners. [STYLE_LOCK] No header, no text, no product cards, no icons, no background scene. Keep center unobstructed so Roblox GUI content can be layered behind it.`

## Prompt B — header surface
`Create ONE independent long horizontal header-bar background only, about 7:1. Cyan/turquoise icy diamond pattern, glossy bevel, thick navy contour, small icy tips at ends. Empty center. Transparent outside; no logo, no title, no close button, no UI screenshot. [STYLE_LOCK]`.

## Prompt C — reusable purchase surface
`Create ONE standalone reusable rounded green purchase-button surface only, about 3:1. Bright lime upper half, darker green lower edge, thick navy outline, highlight; leave the right 65% blank for a Roblox TextLabel. Optional separate simple white hex coin emblem on left if needed. Transparent outside, no price digits, no gift icon, no panel. [STYLE_LOCK]`.

## Prompt D — icon control
`Create ONE square icon/button only, front view, transparent outside the button bounds. [DESCRIBE ONE ICON]. Clear silhouette, thick navy contour, enough interior padding, no extra object or writing. [STYLE_LOCK]`.

## Prompt E — product art
`Create ONE complete [car/product] render, isolated on transparent background, [view] facing [direction]. Palette [colors], visible [defining features]. Show the entire object, wheels/accessories not cut off, centered with 8–12% padding. No card, no ground, no environment, no caption, no watermark. [STYLE_LOCK]`.

## Prompt F — effect overlay
`Create ONE separate transparent VFX overlay only: [snow/sparkle/fire/glow], [distribution/path/density], transparent negative space, no card, no object, no solid background. Edge glow clean and legible over [blue/orange] UI. [STYLE_LOCK]`.

## Prompt G — product card surface
`Create ONE empty horizontal card background only, about 3.5:1. [blue icy / orange Halloween] diamond patterned fill, thick dark navy border and inner bevel. Leave a large clean empty center for product art and quiet text zones. No product, no price button, no title, no lettering, no screenshot. Transparent outside the rounded card. [STYLE_LOCK]`.

## İyi/kötü örnekler
### İyi
- “Create ONE isolated cyan header bar only. No basket, no Shop text, no close button; empty centre, transparent outside.” (Logo and controls remain independently editable.)
- “Create ONE full blue supercar asset, front three-quarter facing right, all four wheels visible, transparent outside.”
- “Create ONE pale cyan sparkle overlay, no car/card/background.”

### Kötü
- “Make the whole screen and all UI parts as separate things.” → Model may composite a screenshot. Split into one call per asset.
- “Remove every object from this screenshot and give transparent assets.” → invites messy extraction/crops. Generate clean assets instead.
- “A button, gift icon, car, header, frame and snowflakes in one image.” → forbidden composite/sprite sheet.
- “Make it like this exactly.” → underspecified style, dimensions, exclusions and alpha; use explicit asset prompt.
- “Transparent checkerboard background.” → checkerboard is a preview convention, not the desired asset. Ask for alpha and validate.
- Adding `Shop`, `1,000`, timer or long description inside surface art → poor localization/legibility; add editable Roblox text unless fixed art is specifically needed.
