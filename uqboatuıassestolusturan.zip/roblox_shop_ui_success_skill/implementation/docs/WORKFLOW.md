# Uçtan uca üretim akışı

## 1. Görseli çözümle, kopyalama varsayımı yapma
Ölçü ve hiyerarşiyi tahmin et; tam piksel piksele kopya gerekmiyorsa bunun bir yorum olduğunu not et. Örnek araba mağazasında: yaklaşık 16:9 ekran görüntüsü içinde mavi/buz header, kalın lacivert kontur, köşelerde bulut/kıvrım, iki yatay araç kartı, fiyat ve hediye kontrolleri, mavi ve turuncu temalar.

Bir sayfalık tasarım özeti yaz: renkler, oranlar, grid, stroke, gölge, doku, ürün bakış açısı, kullanıcı metinleri. Sonra liste halinde asset ihtiyaçlarını çıkar. Header şeridi, header içindeki sepet, başlık metni, X butonu, çerçeve, kart yüzeyleri, butonlar, hediye ikonu, ürün renderları ve partiküller birbirinden ayrı kalmalı.

## 2. Asset üretim ve dosyalama
Önerilen dosya adlandırması:
`01_panel_frame.png`, `02_header_bar.png`, `03_card_ice.png`, `04_card_halloween.png`, `05_purchase_button.png`, `06_gift_button.png`, `07_close_button.png`, `08_shop_basket.png`, `09_sports_car.png`, `10_halloween_car.png`, `11_ice_sparkle.png`, `12_fire_effect.png`.

Her asset için promptu, dosya yolunu, status'u ve eventual Roblox ID'yi `asset_manifest.json` içinde takip et. Üretim sonucu önizle; düşük kalite/kompozisyon varsa ayrı bir yeniden üretim isteği oluştur. Birden fazla sonucu tek tuvalde birleştirme. Bir referans bütün UI'yi gösteriyorsa onu kompozisyon rehberi olarak kullan, finalde katman diye sunma.

### Tur limiti ve devam
- Büyük bir UI setini doğal gruplara ayır: (A) çerçeve/header, (B) kontrol düğmeleri ve ikonlar, (C) ürün görselleri/kartlar, (D) efektler ve varyantlar.
- Her turda aracın gerçek izin verdiği kadar görsel üret; bu skill'in örnek turunda 10 görsel limiti görüldü. Sistem limiti değişebilir; tahmin etmek yerine araç sonucunu esas al.
- Limit uyarısında o tur için üretimi durdur, progress kaydet, kullanıcıya tamamlanan ve kalanları söyle. Eksik dosyayı kopyalama/placeholder ile sessizce doldurma.

## 3. Görsel setini Roblox GUI'de birleştir
Önerilen ağaç:
```
ScreenGui
└─ ShopWindow (Frame; centered, responsive)
   ├─ PanelFrame (ImageLabel, transparent background)
   ├─ HeaderBar (ImageLabel)
   │  ├─ Basket (ImageLabel)
   │  ├─ ShopTitle (TextLabel)
   │  └─ CloseButton (ImageButton)
   └─ Products (ScrollingFrame)
      ├─ UIListLayout veya UIGridLayout
      └─ ProductCard (ImageLabel/Frame)
         ├─ ProductName (TextLabel)
         ├─ LimitedLabel (TextLabel)
         ├─ VehicleArt (ImageLabel)
         ├─ PurchaseButton (ImageButton)
         │  ├─ CoinIcon (ImageLabel)
         │  └─ Price (TextLabel)
         └─ GiftButton (ImageButton)
```

Düzen: `AnchorPoint = Vector2.new(0.5,0.5)`, panel ortada; genişlik ve yükseklik için `UDim2.fromScale` başlangıç, `UIScale` cihaz testi, `UIAspectRatioConstraint` ile hedef oran. `ScrollingFrame.AutomaticCanvasSize` veya layout'un hesapladığı içerik boyutunu kullan; aynı anda elle ayarlanan sabit canvas ve automatic size kullanma. Her butona erişilebilir `TextButton`/`ImageButton`, hover/pressed/disabled durumları ve mobilde yeterli hitbox ekle.

## 4. Satın alma akışı
Satın alma UI'si yalnızca istemci görünümüdür. Buton `RemoteEvent:FireServer(productId)` gibi bir istek yapabilir; server fiyatı, para durumunu, katalogdaki ürün kimliğini ve entitlement'ı kendisi doğrular. Client'tan gelen fiyat veya ownership bilgisini güvenme. Hediye ve gamepass işlemlerini Roblox'un uygun resmi satın alma akışına göre yönlendir.

## 5. Görsel/işlev QA
- 16:9 masaüstü, 4:3 ve telefon portre/yatay testleri.
- Başlık ve fiyat küçülmüş ölçekte okunuyor mu? Kontrast gerçek metin arka planında ölçüldü mü?
- PNG gerçekten alpha taşıyor mu; şeffaf zeminde dama deseni piksele basılmış mı?
- Kenarlar siyah/bozuk halo bırakıyor mu? Ürün tekerlekleri, sepet sapı veya panel köşeleri kesilmiş mi?
- Butonlar dekoratif olarak görünmekle kalmayıp tıklanabiliyor mu? Focus/selection ve gamepad destekleniyor mu?
- Satın alma doğrulaması server-side mı? Hata ve bekleme durumları var mı?
- Görsel asset yükleme ve moderasyon tamamlandı mı? ID'ler gerçek yanıtla mı manifest'e yazıldı?
