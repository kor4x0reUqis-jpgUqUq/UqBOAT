# Roblox Studio MCP/plugin + cloud upload integration

Bu doküman bir güvenlik ve entegrasyon sözleşmesidir; belli bir MCP server/tool şemasını uydurmaz. Gerçek görevde önce bağlı eklenti araçlarını listele, tool açıklaması ve JSON şemasına uy. Roblox Open Cloud endpoint ve API sürümleri değişebileceği için upload kodunu güncel resmi dokümanla doğrula; ZIP içinde token/secret veya sabit API key bulunmaz.

## Bileşenler
1. **Agent/orchestrator:** Skill'i okur; kullanıcı brief'i, referans, proje envanteri ve mevcut asset manifestini alır; promptları ve GUI kodunu oluşturur. MCP araçlarını yalnızca şemaları biliniyorsa çağırır.
2. **Studio plugin:** Onaylı place/experience context'inde hierarchy'yi okur veya düzenler, UI preview/test başlatır, UI tarafından seçilmiş dosyaları backend'e yollar. Plugin kendisi cloud secret saklamaz.
3. **Backend/proxy:** Kullanıcı/tenant'ı doğrular; sadece gerekli route ve asset türlerine izin verir; upload credential'ı secret manager'da tutar; istekleri Roblox Open Cloud'a yollar; rate limit, idempotency, audit ve status takibi uygular.
4. **Open Cloud:** Resmi API yanıtından asset operation/asset ID/status gelir. Moderation/processing durumu varsa tamamlanana kadar “ready” iddiası yapılmaz.
5. **Result store:** Gerçek upload ID, status, owner, created-at, source-file hash, version, request id manifest'e yazılır; credential hiçbir log/result'e girmez.

## Önerilen tool sözleşmesi (genel isimler; gerçek schema ile eşleştir)
- `list_project_context`: place/experience/group kimliği ve açık Studio projesi (salt okunur).
- `preview_ui_changes`: diff/screenshot veya staged UI hierarchy.
- `upload_image_asset`: dosya bytes/reference + filename + content type + description + confirmed target; yetki ve doğrulama backend tarafında.
- `get_asset_upload_status`: dönen operation id ile gerçek processing/moderation durumu.
- `apply_asset_ids`: sadece server-confirmed ID'leri Studio hierarchy/manifest'e yazar.
- `publish_or_save`: publish etkisi varsa açık onay ve diff gerektirir.
Bu isimler öneridir, bağlı connector tool isimleri değildir. Uygulama sırasında gerçek tool listesine uy.

## Güvenli upload akışı
1. Kullanıcıya hedef experience/group, kaç asset, dosya listesi, adlar ve olası görünürlük/ownership'i göster. Yanlış proje riski varsa dur ve sor.
2. Yerel assetleri doğrula: PNG signature, alpha/dimensions, boyut limitleri, virus scanning/policy (backend), manifest yolu.
3. Her dosya için idempotency key oluştur (ör. project + file hash + version). Aynı request tekrar gelirse duplicate upload yapmamak için backend kontrol etsin.
4. Backend secret'ı server-side'dan alır; allowlist'li image upload dışında generic arbitrary API proxy yapmaz. Secret erişimi dar kapsamlı service identity ve rotasyon kullanır.
5. API response'u asıl kaynak kabul et. Başarısız, beklemede veya moderation durumunda kullanıcıya doğru status ver; onaydan önce ID'yi UI'ye yazma.
6. Hazır olduğunda gerçek dönen id'yi `asset-manifest.json` içine kaydet. Önce Studio preview/test, sonra kullanıcı onayı, sonra gerekiyorsa publish.
7. Audit: kim/tenant, hedef, dosya hash, endpoint version, sonuç ve timestamp; hassas header/body/token yok.

## Güvenlik asgari standardı
- Roblox API key/token asla plugin source, LocalScript, `ReplicatedStorage`, place file, frontend, chat veya zip içinde olmaz.
- MCP plugin → HTTPS backend; kısa ömürlü kullanıcı oturumu/OAuth ve CSRF/replay koruması. Key log filtreleme, per-user quota, file size/type limit, allowlist.
- Backend'de tenant/experience access check; IDOR kontrolü; upload hedefinin kullanıcının yetkisi olduğunun doğrulanması.
- LocalScript güvenilmezdir. İstemci tarafındaki price/product ownership verisi satın alma server doğrulaması değildir.
- Silme, değiştirme, publish, monetization ve group ownership değişikliği için ayrı açık onay.
- Hata mesajlarında secret ya da kişisel bilgi yok; zip içindeki `.gitignore` secrets örneği yalnızca önlem, hiçbir key üretmez.

## Başarısızlık/yeniden deneme
- 401/403: yetki/config hatası; otomatik secret denemesi yapma, kullanıcıya güvenli yönerge sun.
- 429/5xx: exponential backoff + jitter, rate limit header'larına uy; idempotency uygula.
- Upload operation pending: state'i pending tut, belirli aralıkla status sorgula; asset ID dönmüş olsa da usable status bekle.
- Kısmi başarısızlık: başarılı dosyaların ID'sini koru, sadece başarısızları retry et; bütün işi baştan overwrite etme.
- Moderation rejected: bu asseti kullanma; yeni uyumlu görsel üret; eski ID'yi gizlice değiştirme.
- MCP bağlantısı yok: “yükledim” deme. Asset zip'i, UI code ve kullanıcının uygulayacağı setup contract'ı teslim et.

## Secret/ID örneği
- Doğru manifest başlangıcı: `"robloxAssetId": ""`, `"uploadStatus": "not-uploaded"`.
- Yalnız gerçek başarılı API response sonrası: ID alanı dönen ID olarak doldurulur ve status kaydedilir.
- Yanlış: `rbxassetid://123456789` gibi tahmini veya örnek ID'yi çalışan asset gibi kullanmak.
