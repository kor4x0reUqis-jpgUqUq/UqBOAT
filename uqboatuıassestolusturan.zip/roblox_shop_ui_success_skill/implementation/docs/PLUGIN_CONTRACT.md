# Plugin/MCP adapter contract (schema-agnostic)

Bu dosya bir soyut sözleşmedir. MCP tool adları, input alanları ve auth şekli bağlı plugin tarafından belirlenir; uygulamadan önce `list_connector_tools` veya sağlayıcının tool-discovery mekanizması ile şemayı oku. Aşağıdaki JSON alanları doğrudan çağrılacak tool şeması değildir.

## Upload request model
```json
{
  "projectContext": {"experienceId": "USER_CONFIRMED_VALUE", "groupId": null},
  "asset": {"filename": "07_sports_car.png", "contentType": "image/png", "sha256": "computed-by-client-or-backend", "bytes": "binary-or-approved-file-reference"},
  "metadata": {"displayName": "Shop Sports Car", "description": "Independently generated UI product art", "intendedUse": "Image"},
  "idempotencyKey": "project-and-file-hash-derived",
  "userConfirmed": true
}
```
`USER_CONFIRMED_VALUE` yalnızca kullanıcının gerçek project id'si ile değiştirilir. Bu örnek hiçbir Roblox ID, API endpoint veya secret içermez. Eklenti, byte payload'ı güvenli backend'e nasıl taşıyacağını kendi tool schema'sına göre belirler.

## Backend response model
```json
{
  "success": true,
  "operationId": "REAL_BACKEND_RESPONSE",
  "assetId": "REAL_ASSET_ID_ONLY_AFTER_RESPONSE",
  "status": "processing-or-ready-as-returned",
  "displayName": "Shop Sports Car",
  "errorCode": null
}
```
String örnekleri açıklayıcıdır; gerçek ID değil. Ajan placeholder'ı asla `rbxassetid://` olarak kullanmamalı. Pending response'ta polling için operationId kullanılır; asset ready olmadıkça client reference manifest'e yazılmaz.

## Asset lifecycle
`generated → locally-validated → user-approved → upload-requested → processing/moderation-pending → ready/rejected → referenced-in-Studio → preview-approved → published (only after explicit confirmation)`

Her status için manifest alanı tut. Başarılı upload'da returned ID + status + operation id + UTC timestamp + content hash yaz. Retry'de idempotency key kullan; yeni sürüm farklı version/filename olur, eski asset'i silme.

## Studio code wiring
- Asset IDs bir `ModuleScript`/configuration içine gerçek dönüşten sonra konur; secret konmaz.
- Client `ImageLabel.Image` için `rbxassetid://<returned id>` kullanabilir; image permission/processing yüzünden görünmüyorsa status'u kontrol et.
- Üretimde katalog/fiyat/vehicle grant server'da doğrulanır.
- Preview diff gösterilir. Plugin Script Source veya place config yazmadan önce hedef hierarchy ve user approval doğrula.
