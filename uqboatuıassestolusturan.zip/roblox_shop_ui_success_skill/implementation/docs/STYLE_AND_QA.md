# Stil, yüksek kontrast ve kalite kontrol

## Tasarım tokenları
`examples/ui.tokens.json` başlangıç paletini içerir. Referans stili: buz mavisi header, koyu lacivert kenar, metalik slate panel, limon yeşili satın alma kontrolü, pembe kapatma, turuncu Halloween varyantı. Yeni estetik istenirse tokenları değiştir ve her promptta tek stil tanımını güncelle.

## Kontrast ve okunabilirlik
- Normal metin: en az 4.5:1; büyük metin (yaklaşık 24 px normal / 19 px bold üstü): 3:1 hedefle. UI ikon/aktif kontrol sınırları için 3:1 veya daha iyisi.
- Kontrastı sRGB relative luminance ile kontrol et; rastgele RGB farkına bakmak yeterli değil.
- Beyaz yazı kullanılıyorsa altına koyu, sakin bir alan veya siyah/lacivert stroke ekle. Pattern'in en hareketli alanı üzerine küçük yazı koyma.
- Paket örnek tokenlarında hesaplanmış çiftler: `#FFFFFF` / `#071A35` = 17.38:1; `#071A35` / `#72E815` = 10.98:1; `#FFFFFF` / `#075895` = 7.40:1. Bu değerler tekstin gerçekten ilgili zemin üzerinde olduğu durumda geçerlidir; görsel/gradient içindeki lokal renk değişimini ayrıca test et.
- Yazı boyutu ekran genişliğine göre test edilsin; fiyat bir `TextLabel` olarak ölçeklenebilir/uyarlanabilir kalsın. Ürün başlığını görsele gömmek lokalizasyonu engeller.
- Dokunsal hedefler küçük ekranda makul boyutta tutulmalı; görsel düğme ile etkileşim hitbox'ı aynı alanı kaplamalı.

## PNG alfa kontrolü
Python ile `Image.mode`, `getbands()`, `getchannel('A').getextrema()` kontrol et. Gerçek transparan bölgelerde alpha 0 olmalı. Dama tahtası yalnızca viewer'da transparan alanı gösterebilir; `RGB` içinde gri dama renkleri varsa arka plan muhtemelen görsele basılmıştır. Dosyanın alpha kanalını tek başına görmek de yetmez: kenarları ve örnek köşeleri açıp kontrol et.

Kenar ayıklama zorunlu olduğunda:
1. Önce yeniden üretimi dene (temiz alpha promptu, tek obje, sade kenar).
2. Arka planı ayıklama yalnızca net siluetli ve görsel olarak doğrulanmış bir son işlem olarak kullanılabilir; bunu görsel üretim yerine koyma.
3. Kalan halo, checker, kayıp tekerlek, yarı saydam kirli piksel görürsen final yapma.
4. Büyük çizgisel UI yüzeylerini transparan PNG olarak kullan; metni ve interaktif kontrolü Studio'da ayrı tut.

## Kullanıcıdan öğrendiğimiz hatalar / örnekler
### HATA — Düzleştirilmiş ekranı kırpıp parça diye vermek
Kırpımlar başlık/araç/düğme parçalarına bölündü; ama desen, metin, karta ait arka plan ve kontrol aynı raster içinde kaldı. Sonuçta buton kenarlarında kart artıkları ve araçlarda mavi/ateşli arka plan kaldı. Kullanıcı “kırparak ayırmışsın, kötü görüntü” diye düzeltti. **Kural:** final asset'leri bağımsız görsel oluşturma ile üret; referansı sadece stil rehberi yap.

### HATA — Transparan arka planı varsaymak
Görsel üretim önizlemeleri dama tahtası gösterdi. Bu desen gerçek PNG alfa değildi; RGB'ye basılmış olma ihtimalini denetlemek gerekiyordu. İlk 9 asset sonrasında alfa kontrolü yapılıp checker bölgeleri şeffaflaştırıldı ve kenar önizlemesi doğrulandı. **Kural:** alfa ve border örneklerini programatik + görsel kontrol et.

### BAŞARILI — Her bileşen için tek prompt
Başarılı bağımsız üretim örnekleri: boş panel çerçevesi, boş buz header'ı, yazısız yeşil fiyat butonu, hediye düğmesi, pembe X, sepet, mavi spor araba, Halloween muscle car ve buz parıltısı. Sonra ayrı mavi ürün kartı üretildi. Header ve panel yüzeyi yazısız bırakıldı; dinamik metin TextLabel'a kaldı.

### GÖRSEL ÜRETİM LİMİTİ
Bir denemede tur limiti 10 asset'te doldu. Mavi kart üretildi; turuncu kart ve ateş efekti üretilemedi. Doğru davranış eksikliği açıkça kaydetmek ve yeni turda devam etmektir; eksik dosyayı crop ile ikame etmek değil.

## Kabul kontrol listesi
- [ ] Her final parça bağımsız image-gen göreviyle üretildi veya kullanıcı açıkça başka yol istedi.
- [ ] Manifest dosya yolu ve asset rolü doğru.
- [ ] Alpha gerçek; checkerboard basılmamış.
- [ ] Prompt talebi tek obje/tek yüzey; kompozit/sprite sheet değil.
- [ ] Kenar, safe area, tam siluet ve küçük boyutta okunma kontrol edildi.
- [ ] Kontrast en az hedef değerlere ulaşıyor; text ayrı ve düzenlenebilir.
- [ ] Renk, contour, ışık, perspektif set genelinde tutarlı.
- [ ] Roblox image IDs sadece upload cevabından alındı.
- [ ] Upload yetkisi, hedef experience/group ve publish onayı kullanıcıdan doğrulandı.
