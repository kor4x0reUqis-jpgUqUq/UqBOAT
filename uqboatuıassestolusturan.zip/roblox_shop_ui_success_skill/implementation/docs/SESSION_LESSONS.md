# Oturumlar arası bilgi ve örnek vaka

## Bu skill neden var?
Kullanıcı önce görsel referanslarını analiz edip araba mağazası UI'si istedi. İlk asset tesliminde SVG/PNG varlıkları ile ekran görüntüsünden ayrılmış crop dosyaları verildi. Kullanıcı, crop işleminin kötü görüntü oluşturduğunu ve her parçanın image generation ile bağımsız üretilmesi gerektiğini belirtti. Sonraki turda önce panel, header, satın alma düğmesi, hediye düğmesi, kapatma düğmesi, sepet, iki araç ve buz efekti gibi tek tek görseller üretildi; ardından mavi ürün kartı ayrı üretildi.

## Kapsanan varlık örnekleri
`assets/generated/` içindeki görseller bağımsız üretim örnekleri olarak eklenmiştir. Tamamlanan 10: panel çerçevesi, header, yeşil satın alma düğmesi, hediye düğmesi, close düğmesi, sepet, mavi spor araç, Halloween muscle car, buz parıltısı, mavi kart yüzeyi.

Örnek turda görsel oluşturma aracı 10 görselden sonra sınır verdi. Bu yüzden turuncu Halloween kartı ve ateş overlay'i **açıkça eksik** olarak tutuldu. Yeni ajan önce `examples/progress.json` dosyasını okumalı; eksikleri ayrı generation call'larıyla tamamlamalı. Bu, tekrarlanabilir state handoff örneğidir.

## Başarıyı yeniden üretmek için
1. Bu `SKILL.md` dosyasını baştan sona oku.
2. `examples/progress.json` ile `examples/asset_manifest.json` durumunu kontrol et.
3. Önceden üretilmiş bağımsız PNG'leri tekrar kırpma veya yeniden çizme.
4. Eksik assetleri görsel üretimiyle tek tek oluştur; kalanları manifestte güncelle.
5. Alpha channel, checker artifacts, edge, color/contrast ve in-UI size testleri yap.
6. `ShopUIBuilder.lua` örneğini hedef experience/plugin kısıtına göre adapte et; erişilmeyen project/Remote/ID varsayma.
7. MCP tool schema'sını keşfet; user confirms target; server-side secure upload; actual IDs only from responses.

## Kötü sonuçların nedeni ve nasıl önlenir
- **Crop'tan araç cutout'u:** Araba ile kartın pattern/efektleri aynı rasterdaydı. Otomatik cutout, tekerlek ve kenarlarında arka plan bıraktı. Bundan kaçın: araç modeline yalnız araç renderı üretmesini söyle.
- **Checkerboard yanlış varsayımı:** Önizlemedeki damalı zemin bazen şeffaflığın viewer gösterimi, bazen piksellere basılmış desen olabilir. Alpha bandını denetle.
- **Eksik item'ı sessizce doldurma:** Limit nedeniyle yapılmayan görseli varmış gibi sunma. Progress ve handoff'a yaz.
- **Hardcoded fiyat/metin:** Lokalizasyon ve güncelleme zorlaşır; TextLabel kullan.
- **Uydurma Roblox asset ID:** Hiçbir placeholder veya örnek ID'yi gerçek gibi kullanma.
- **Plugin secret'ı:** Cloud key plugin/LocalScript içine gömülürse herkes çıkarabilir; backend proxy kullan.

## Stil referansı
`assets/reference/car_shop_ui_style_reference.png` tamamlanmış tek UI görselidir. Yalnızca palette/outline/composition yönlendirmesi için kullanılabilir; ondan crop ile asset üretmek yasaktır. Bu skill paketindeki AI-generated PNG'ler ayrı asset örnekleridir; Roblox'a yükleme/asset ID'si henüz yapılmamıştır.
