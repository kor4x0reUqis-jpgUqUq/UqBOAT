-- ShopUIBuilder.lua (client-side presentation only)
-- Replace the empty AssetIds table values ONLY with IDs returned by an approved upload flow.
-- Server must independently validate all purchases, vehicle grants and gifting.

local ShopUIBuilder = {}

local COLORS = {
    Navy = Color3.fromRGB(7, 26, 53),
    Slate = Color3.fromRGB(74, 91, 105),
    White = Color3.fromRGB(255, 255, 255),
    Cyan = Color3.fromRGB(31, 211, 242),
    Green = Color3.fromRGB(82, 221, 31),
    Orange = Color3.fromRGB(255, 139, 20),
}

local function validImageId(value)
    return typeof(value) == "string" and value:match("^rbxassetid://%d+$") ~= nil
end

local function setImage(imageObject, id)
    if validImageId(id) then
        imageObject.Image = id
        imageObject.Visible = true
        return true
    end
    imageObject.Visible = false
    return false
end

local function addText(parent, name, text, size, position, dimensions, options)
    options = options or {}
    local label = Instance.new(options.button and "TextButton" or "TextLabel")
    label.Name = name
    label.Text = text
    label.Font = options.font or Enum.Font.GothamBlack
    label.TextColor3 = options.textColor or COLORS.White
    label.TextStrokeColor3 = options.strokeColor or COLORS.Navy
    label.TextStrokeTransparency = options.strokeTransparency or 0.08
    label.TextScaled = options.textScaled ~= false
    label.TextWrapped = true
    label.BackgroundTransparency = options.backgroundTransparency or 1
    label.Size = dimensions
    label.Position = position
    label.AnchorPoint = options.anchorPoint or Vector2.zero
    label.ZIndex = options.zIndex or 10
    label.Parent = parent
    local limit = Instance.new("UITextSizeConstraint")
    limit.MinTextSize = options.minTextSize or 13
    limit.MaxTextSize = options.maxTextSize or 32
    limit.Parent = label
    if options.button then
        label.AutoButtonColor = true
        label.Selectable = true
    end
    return label
end

local function addImage(parent, name, id, position, dimensions, zIndex, scaleType)
    local image = Instance.new("ImageLabel")
    image.Name = name
    image.BackgroundTransparency = 1
    image.BorderSizePixel = 0
    image.Position = position
    image.Size = dimensions
    image.ZIndex = zIndex or 2
    image.ScaleType = scaleType or Enum.ScaleType.Fit
    image.Parent = parent
    setImage(image, id)
    return image
end

local function addRoundStroke(instance, color, thickness)
    local stroke = Instance.new("UIStroke")
    stroke.Color = color or COLORS.Navy
    stroke.Thickness = thickness or 3
    stroke.Parent = instance
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0.06, 0)
    corner.Parent = instance
end

local function createProductCard(parent, product, ids, callbacks, index)
    local card = Instance.new("Frame")
    card.Name = "ProductCard_" .. product.id
    card.Size = UDim2.new(1, -8, 0, 214)
    card.BackgroundColor3 = product.theme == "orange" and Color3.fromRGB(230, 104, 9) or Color3.fromRGB(0, 124, 202)
    card.BorderSizePixel = 0
    card.ZIndex = 3
    card.Parent = parent
    addRoundStroke(card, COLORS.Navy, 4)

    local surface = addImage(card, "CardSurface", product.theme == "orange" and ids.HalloweenProductCard or ids.IceProductCard,
        UDim2.fromScale(0, 0), UDim2.fromScale(1, 1), 3, Enum.ScaleType.Slice)
    surface.SliceCenter = Rect.new(24, 24, 232, 72)

    addText(card, "ProductName", product.name, 24, UDim2.fromScale(0.018, 0.035), UDim2.fromScale(0.48, 0.20), {
        zIndex = 8, minTextSize = 16, maxTextSize = 28,
    })
    if product.limited then
        addText(card, "LimitedLabel", "LIMITED TIME ONLY!", 17, UDim2.fromScale(0.56, 0.04), UDim2.fromScale(0.42, 0.18), {
            zIndex = 8, minTextSize = 12, maxTextSize = 20, textColor = COLORS.Orange,
        })
    end

    local artId = product.artKey == "HalloweenCar" and ids.HalloweenCar or ids.SportsCar
    local car = addImage(card, "VehicleArt", artId, UDim2.fromScale(0.025, 0.27), UDim2.fromScale(0.57, 0.66), 6, Enum.ScaleType.Fit)

    local purchase = Instance.new("ImageButton")
    purchase.Name = "PurchaseButton"
    purchase.BackgroundColor3 = COLORS.Green
    purchase.BackgroundTransparency = validImageId(ids.PurchaseButton) and 1 or 0
    purchase.BorderSizePixel = 0
    purchase.Size = UDim2.fromScale(0.255, 0.40)
    purchase.Position = UDim2.fromScale(0.60, 0.49)
    purchase.ZIndex = 9
    purchase.AutoButtonColor = true
    purchase.Parent = card
    if validImageId(ids.PurchaseButton) then
        purchase.Image = ids.PurchaseButton
        purchase.ScaleType = Enum.ScaleType.Slice
        purchase.SliceCenter = Rect.new(20, 20, 220, 68)
    else
        addRoundStroke(purchase, COLORS.Navy, 3)
    end

    -- Price is editable text; don't bake it into image. Coin is inside the generated button,
    -- so this label is placed to its right. Tune the x offset for your final button design.
    if not validImageId(ids.PurchaseButton) then
        addText(purchase, "CoinFallback", "⬢", 20, UDim2.fromScale(0.04, 0), UDim2.fromScale(0.24, 1), {
            zIndex = 12, minTextSize = 14, maxTextSize = 23,
        })
    end
    addText(purchase, "Price", product.priceText or "1,000", 24,
        UDim2.fromScale(0.30, 0), UDim2.fromScale(0.68, 1), { zIndex = 12, minTextSize = 16, maxTextSize = 27 })

    local gift = Instance.new("ImageButton")
    gift.Name = "GiftButton"
    gift.BackgroundColor3 = Color3.fromRGB(0, 137, 220)
    gift.BackgroundTransparency = validImageId(ids.GiftButton) and 1 or 0
    gift.BorderSizePixel = 0
    gift.Size = UDim2.fromScale(0.09, 0.40)
    gift.Position = UDim2.fromScale(0.87, 0.49)
    gift.ZIndex = 9
    gift.AutoButtonColor = true
    gift.Parent = card
    if validImageId(ids.GiftButton) then
        gift.Image = ids.GiftButton
        gift.ScaleType = Enum.ScaleType.Fit
    else
        addRoundStroke(gift, COLORS.Navy, 3)
        addText(gift, "GiftFallback", "GIFT", 14, UDim2.fromScale(0, 0), UDim2.fromScale(1, 1), { zIndex = 12, minTextSize = 10, maxTextSize = 15 })
    end

    purchase.Activated:Connect(function()
        if callbacks and callbacks.onPurchase then callbacks.onPurchase(product.id) end
    end)
    gift.Activated:Connect(function()
        if callbacks and callbacks.onGift then callbacks.onGift(product.id) end
    end)
    return card
end

function ShopUIBuilder.Build(playerGui, ids, callbacks, products)
    assert(playerGui and playerGui:IsA("PlayerGui"), "Build expects the local player's PlayerGui")
    ids = ids or {}
    products = products or {
        { id = "sports-car", name = "SPORTS CAR", theme = "blue", artKey = "SportsCar", priceText = "1,000", limited = true },
        { id = "halloween-car", name = "HALLOWEEN CAR", theme = "orange", artKey = "HalloweenCar", priceText = "1,000", limited = true },
    }

    local screen = Instance.new("ScreenGui")
    screen.Name = "CarShopGui"
    screen.ResetOnSpawn = false
    screen.IgnoreGuiInset = true
    screen.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
    screen.Parent = playerGui

    local window = Instance.new("Frame")
    window.Name = "ShopWindow"
    window.AnchorPoint = Vector2.new(0.5, 0.5)
    window.Position = UDim2.fromScale(0.5, 0.5)
    window.Size = UDim2.fromScale(0.88, 0.84)
    window.BackgroundColor3 = COLORS.Slate
    window.BorderSizePixel = 0
    window.ZIndex = 1
    window.Parent = screen
    addRoundStroke(window, COLORS.Navy, 4)
    local aspect = Instance.new("UIAspectRatioConstraint")
    aspect.AspectRatio = 1.67
    aspect.DominantAxis = Enum.DominantAxis.Width
    aspect.Parent = window

    addImage(window, "PanelFrame", ids.PanelFrame, UDim2.fromScale(0, 0), UDim2.fromScale(1, 1), 20, Enum.ScaleType.Slice)
    local header = addImage(window, "HeaderBar", ids.HeaderBar, UDim2.fromScale(-0.015, -0.10), UDim2.fromScale(1.03, 0.22), 30, Enum.ScaleType.Fit)
    if not header.Visible then
        local fallback = Instance.new("Frame")
        fallback.Name = "HeaderFallback"
        fallback.Size = UDim2.fromScale(1, 0.16)
        fallback.BackgroundColor3 = COLORS.Cyan
        fallback.BorderSizePixel = 0
        fallback.ZIndex = 30
        fallback.Parent = window
        addRoundStroke(fallback, COLORS.Navy, 4)
    end

    addImage(window, "ShopBasket", ids.ShopBasket, UDim2.fromScale(0.025, -0.065), UDim2.fromScale(0.12, 0.19), 32, Enum.ScaleType.Fit)
    addText(window, "ShopTitle", "Shop", 30, UDim2.fromScale(0.15, -0.055), UDim2.fromScale(0.24, 0.12), {
        zIndex = 33, minTextSize = 20, maxTextSize = 34,
    })

    local close = Instance.new("ImageButton")
    close.Name = "CloseButton"
    close.AnchorPoint = Vector2.new(1, 0)
    close.Position = UDim2.fromScale(0.985, -0.045)
    close.Size = UDim2.fromScale(0.09, 0.145)
    close.BackgroundColor3 = Color3.fromRGB(233, 45, 125)
    close.BackgroundTransparency = validImageId(ids.CloseButton) and 1 or 0
    close.BorderSizePixel = 0
    close.ZIndex = 34
    close.AutoButtonColor = true
    close.Parent = window
    if validImageId(ids.CloseButton) then
        close.Image = ids.CloseButton
    else
        addRoundStroke(close, COLORS.Navy, 3)
        addText(close, "CloseFallback", "X", 22, UDim2.fromScale(0, 0), UDim2.fromScale(1, 1), { zIndex = 36, minTextSize = 16, maxTextSize = 28 })
    end
    if callbacks and callbacks.onClose then close.Activated:Connect(callbacks.onClose) end

    local list = Instance.new("ScrollingFrame")
    list.Name = "Products"
    list.Position = UDim2.fromScale(0.035, 0.16)
    list.Size = UDim2.fromScale(0.93, 0.77)
    list.BackgroundTransparency = 1
    list.BorderSizePixel = 0
    list.ScrollBarThickness = 8
    list.ScrollBarImageColor3 = COLORS.Cyan
    list.AutomaticCanvasSize = Enum.AutomaticSize.Y
    list.CanvasSize = UDim2.new()
    list.ScrollingDirection = Enum.ScrollingDirection.Y
    list.ZIndex = 4
    list.Parent = window

    local layout = Instance.new("UIListLayout")
    layout.Padding = UDim.new(0, 10)
    layout.SortOrder = Enum.SortOrder.LayoutOrder
    layout.Parent = list
    local padding = Instance.new("UIPadding")
    padding.PaddingLeft = UDim.new(0, 4)
    padding.PaddingRight = UDim.new(0, 10)
    padding.PaddingTop = UDim.new(0, 4)
    padding.PaddingBottom = UDim.new(0, 12)
    padding.Parent = list

    for i, product in ipairs(products) do
        local card = createProductCard(list, product, ids, callbacks, i)
        card.LayoutOrder = i
    end

    return screen
end

return ShopUIBuilder
