-- Copy this ModuleScript into ReplicatedStorage after upload. Keep values empty
-- until the authorized Open Cloud response returns real IDs. Never guess IDs.
return {
    PanelFrame = "",
    HeaderBar = "",
    PurchaseButton = "",
    GiftButton = "",
    CloseButton = "",
    ShopBasket = "",
    SportsCar = "",
    HalloweenCar = "",
    IceProductCard = "",
    HalloweenProductCard = "", -- pending separate generation in this example
    IceSparkle = "",
    FireEffect = "", -- pending separate generation in this example
}
