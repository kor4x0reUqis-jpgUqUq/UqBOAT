# Roblox Shop UI Tasarım + Uygulama Skill’i

Bu paket; oyun mağazası arayüzünü **brief’ten görsel konsepte, eleştiri turlarından okunabilirlik/kadraj kontrolüne ve Roblox uygulamasına** kadar tutarlı biçimde üretmek için hazırlanmıştır. Yalnızca prompt koleksiyonu değildir: kullanıcı tercihlerini koruma, hatalı sonuçları teşhis etme, tasarım kararlarını açıklama, gerçek asset’leri kontrol etme ve başarısız denemeleri tekrarlamama kurallarını da içerir.

## Başlangıç
1. Önce `SKILL.md` dosyasını bütünüyle okut.
2. Sonra projeye göre `docs/01_DESIGN_SYSTEM_TR.md`, `docs/02_WORKFLOW_AND_DECISIONS_TR.md`, `docs/03_FAILURE_CATALOG_TR.md`, `docs/04_QA_CHECKLIST_TR.md` dosyalarını oku.
3. Tam ekran örnekler ve işaretlenmiş hata galerisi için `case_studies/GALLERY.html` dosyasını aç.
4. Yeni işte `examples/BRIEF_TEMPLATE_TR.md` doldur; `examples/DECISION_LOG_TEMPLATE.md` ile tercihleri, reddedilenleri ve açık sorunları kaydet.
5. Görsel üretiminde `prompts/PROMPT_PLAYBOOK.md` içindeki ana şablonları kullan; her turda tek bir hata sınıfını düzelt.

## Paket yapısı
- `SKILL.md` — farklı ajanların izleyebileceği ana görev ve kalite sözleşmesi.
- `docs/` — görsel sistem, adım adım süreç, başarısızlık kataloğu, QA, Roblox uygulama notları ve karar günlüğü.
- `prompts/PROMPT_PLAYBOOK.md` — brief, yeni konsept, kontrollü edit, başarısız sonuç düzeltme prompt’ları.
- `prompts/CASE_PROMPTS_VERBATIM.md` — bu projedeki erişilebilir gerçek üretim/edit prompt’ları, çıktıları ve başarısızlık analizleri. V2/V4 ilk prompt’ları kayıtta olmadığı için uydurulmadı.
- `case_studies/images/full/` — örnek görsellerin eksiksiz, değiştirilmemiş halleri.
- `case_studies/images/annotated/` — aynı örneklerin hata/karar noktaları işaretlenmiş kopyaları. Kaynak görüntüyü hiçbir zaman işaretli kopyayla değiştirmeyin.
- `case_studies/GALLERY.html` — tam ve işaretli görselleri, Halloween/Christmas olumlu örneklerini ve diğer referansları inceleme galerisi.
- `case_studies/LIKED_UI_CATALOG_TR.md` — beğenilen UI’leri, yalnızca layout referansı olanları ve statüsü belirsiz görselleri ayıran katalog.
- `examples/` — tekrar kullanılabilir brief, karar kaydı ve kontrol şablonları.
- `implementation/` — önceki `roblox_shop_ui_asset_to_game` skill’i: ayrı asset üretimi, Roblox UI kodlama, güvenli upload/MCP ve validator’lar.

## Bu vakadan çıkan kısa ders
Christmas UI’de kullanıcı V2’nin kompozisyonunu V3/V4 yaklaşımına tercih etti. En iyi iterasyon, V2’nin ürün hiyerarşisini koruyup dış dekor/başlık siluetlerini daha bilinçli kullanmak, LIMITED’i Snowman Pet üzerinde çapraz şerit yapmak ve Sleigh satırındaki butonları aynı ölçü/hizaya çekmek oldu. Ancak görsel üretici, Gamepasses altını birkaç tur boyunca kesti. Bu nedenle konseptin beğenilmesi **tam kadraj QA’sını atlama izni değildir**: kabul edilen yönü koru, kesilme kusurunu açıkça kaydet ve final/production-ready deme.

## Dürüstlük ve tekrar üretilebilirlik
Farklı image model’leri aynı prompt’tan birebir aynı piksel sonucunu vermez. Skill’in hedefi, başka ajana aynı **karar standardını, kısıtları, hata önleme yöntemini ve inceleme sürecini** uygulatmaktır; deterministik kopya vaat etmek değildir. Kritik yerleşimleri mümkünse kod/vektör/layout katmanında denetleyin, generated screenshot’ı tek gerçek kaynak yapmayın.

## Dosyalar
- Ana talimat: `SKILL.md`
- Case study görsel galerisi: `case_studies/GALLERY.html`
- Karar ve prompt rehberi: `docs/02_WORKFLOW_AND_DECISIONS_TR.md`, `prompts/PROMPT_PLAYBOOK.md`
- Uygulama/Roblox ayrıntıları: `implementation/README_TR.md`
