# 01 — Görsel tasarım sistemi: brief’ten okunabilir arayüze

Bu doküman, görsel kararları yalnızca “güzel hissettiriyor” diye değil, içerik, hiyerarşi, referans ve kullanım bağlamıyla gerekçelendirmeyi öğretir. Her proje için yeniden uygulanır; Christmas örneği kararları somutlaştırır.

## 1. Referansları işlevlerine göre ayır

Her görsel referansı için şu sınıflandırmayı yap:

| Referans türü | Örnek olarak alınabilecek şey | Alınmaması gereken şey |
|---|---|---|
| **Kompozisyon / layout** | kartların yataylığı, ürün görselinin solda ve kontrollerin sağda oluşu, ölçek | renk paletini veya temayı otomatik kopyalamak |
| **Stil** | çizgi kalınlığı, cel-shading seviyesi, outline, illüstrasyon yoğunluğu | içeriği veya markalı öğeleri taklit etmek |
| **Dekor tekniği** | yüzeyde düşük kontrastlı siluet pattern’i, köşe overlay’lerinin çerçeveye oturması | tüm renkleri, hayaletleri/temayı veya kart yapısını taşımak |
| **Teknik kaynak** | Roblox GUI bileşen düzeni, aspect ratio ve image fit yaklaşımı | depodaki UI’ı görsel hedef sanmak |
| **Kullanıcı onayı** | açıkça “bunu beğendim” denilen tasarım parçaları | reddedilmiş versiyondan öğe ödünç almak |

Her iş için 1–3 satırlık “referans sözleşmesi” yaz: `A’dan layout; B’den yalnızca dekor tekniği; C teknik kaynak; reddedilen D kullanılmayacak.` Bu satır prompt’a da taşınır.

## 2. İçerik ledger’ı (metin ve fiyatları kilitle)

Üretimden önce, kaynakta görünenleri tabloya al:

| Alan | Değer | Kaynak / güven |
|---|---|---|
| Başlık | CHRISTMAS SHOP | kullanıcı referansı |
| Bölüm 1 | ~ LIMITED GIFTS ~ | kullanıcı kısıtı |
| Ürün 1 | Snowman Pet | referans |
| Açıklama 1 | YOUR LITTLE WINTER COMPANION | referans |
| Robux 1 | 40 | referansta doğrulanmış |
| Cash 1 | $350 | referansta doğrulanmış |
| Bölüm 2 | ~ GAMEPASSES ~ | kullanıcı kısıtı |
| Gamepasses | Winter Flight / Gift Luck | referans |
| Ürün 2 | Candy Cane Sleigh | referans |
| Açıklama 2 | FASTEST RIDE IN TOWN | referans |
| Robux 2 | 75 | referansta doğrulanmış |
| Cash 2 | $30 | referansta doğrulanmış |

`unverified` alanı boş bırakılır veya kullanıcıya sorulur. Bilinmeyen gamepass fiyatı görsele eklenmez. Image model’inin metin üretimi hataya açık olduğundan, üretim sonrası tüm kopya tek tek karşılaştırılır.

## 3. Kadraj ve layout bütçesi

### 3.1 Önce ekran geometrisi
- Hedef oranı ve hedef cihazı yaz. Roblox oyun ekranı için 16:9 ana preview olabilir; mobil/portrait uyumu ayrıca kontrol edilir.
- Ana paneli kanvasın içine yerleştir; çevre dekoru ile panelin güvenli boşluğunu birbirine karıştırma.
- Panelin üst/alt payını ayır. Alt pay sadece boşluk değildir: son kartın alt çerçevesi, gölge/çizgi kalınlığı ve olası UI safe-area da orada yaşar.
- İçerik satırlarının toplam yüksekliğini hesapla: header + section label’lar + kartlar + border’lar + aralıklar + footer/bottom padding. Toplam kanvas yüksekliğini aşarsa, prompt’ta “fit everything” yazmak yerine wireframe’i yeniden düzenle.

### 3.2 Örnek bütçe (16:9 için başlangıç noktası)
Bu oranlar **kural değil**; gerçek yazı, buton ve içerik sayısına göre tekrar hesaplanır:
- üst/alt dış pay: birlikte %10–14;
- header: %12–15;
- kategori ayraçları: her biri %4–7;
- iki yatay teklif satırı: her biri %14–18;
- iki gamepass kartı: %20–26;
- bütün iç boşluk, kontur ve aralıklar: kalan pay.

Önce her satıra bounding box çiz. Köşegen bir ribbon’ın ürün görseline girmesi planlandıysa onun kapladığı alanı da ölç. Şablon sayıları toplayınca %100’ü geçiyorsa render’a geçme.

### 3.3 Hiyerarşi sırası
1. Shop title / kapatma kontrolü
2. Bölüm adı
3. Ürün/gamepass adı
4. Ürün görseli
5. Fiyat ve satın alma eylemi
6. Kısa tanım / fayda
7. Tema dekorasyonu, pattern, snow particles

Bu sıralama her oyunda değişebilir; kullanıcı örneği belirleyicidir. Dekor 1–5’i perdelememeli.

## 4. Satır grid’i ve buton hizası

Her offer row için grid bölmeleri belirle. Örnek oran: art 20–28%, name/description 30–40%, controls 34–45%; badge alanı boşluğu paylaşır, ayrıca rastgele yer kaplamaz. Uzun adlar/satır kırılımları için rezerv bırak.

Aynı row’daki fiyat ve gift controls:
- ortak görsel yükseklik ve optik merkez;
- aynı üst/alt baseline; button padding’leri tutarlı;
- dış border kalınlığı ve corner radius tutarlı;
- ikon optik boyutu, iç boşluk ve label contrast tutarlı;
- genişlik metne göre değişebilir ama butonlar birbiriyle yarışmamalı;
- title/subtitle veya badge ile çakışmamalı.

Christmas vakasında V10 düzeltmesi: Candy Cane Sleigh’de yeşil cash ve gift kontrolleri mor Robux ile aynı satıra/same height çizgisine alınır. “Aynı hiza”yı yalnız x/y yakınlığı değil, yüksekliğin ve optik ağırlığın denkliği olarak yorumla.

## 5. Renk sistemi ve gerekçelendirme

### 5.1 Palet rollerle seçilir
Renk isimleri yerine yüzey rollerini tanımla:
- `frame/base`: paneli sabitleyen koyu nötr/tema rengi;
- `header`: odak, başlık alanı;
- `offer.primary`: ana teklif yüzeyi;
- `offer.secondary`: ikinci teklif, ilkinden değer/hue ile ayrışır;
- `gamepass.a / b`: iki kartı ayrıştıran eşdeğer yüzeyler;
- `text.primary`, `text.secondary`, `outline`;
- `action.robux`, `action.cash`, `action.gift`;
- `accent/badge`;
- `ambient decoration`.

### 5.2 Christmas örneği — neden cranberry/navy/evergreen/icy blue/gold
- **Cranberry/bordo**: sezonluk sıcak odak; header’ı koyu navy gövdeden ayırır.
- **Midnight navy**: çerçeve ve arka planı taşıyan sakin, yüksek değer kontrastlı zemin.
- **Evergreen**: sezonu tanır; kullanıldığında navy’den yeterince farklı parlaklık/değer seçilir.
- **Icy blue / snow-white**: kar/soğuk temasını taşır, koyu text outline ile okunur alan kurar.
- **Warm gold**: sınırlı vurgu: küçük ribbon, minik ışık ve ikon glint’i. Her köşeyi altın yapma.

Bunlar tasarım konvansiyonları ve sık rastlanan çağrışımlardır; kültürden bağımsız, kesin psikoloji kuralı değildir. Renk-duygu çağrışımları toplum, dil, bağlam ve kişiye göre değişebilir. Rengi tek başına “neşe/korku” garantisi gibi sunma.

### 5.3 Kontrast kontrolü
- Normal metin için WCAG 2.2’in 4.5:1, büyük metin için 3:1 oranlarını referans al.
- Yüksek outline, harf iç dolgusunun düşük kontrastını her zaman telafi etmez; fill ile panel değerini ayrı kontrol et.
- Aynı hue’ya sahip iki kartı yalnızca border ile ayırma; luminance/value farkını da görünür yap.
- Pattern’in üstündeki metin için quiet zone/backing kullan.
- Saturated neon yeşil, mor, cyan’ı aynı anda büyük alanlarda kullanma; eylem kontrollerine rol ver.

## 6. Tipografi

### 6.1 Hiyerarşi
- Display title: güçlü, kompakt, kısa; all caps yalnızca yer varsa.
- Product name: başlıkla karışmayacak boyda, tek/iki satır.
- Subtitle/benefit: kısa, daha küçük ama küçültülünce de okunur.
- Price: güçlü rakam, para birimi/ikonla ayrık; simge metni ezmemeli.
- Section label: görsel ara başlık; kullanıcının istemediği `~ CASH ~`/`~ ROBUX ~` gibi fiyat grupları yaratma.

### 6.2 Stil seçimi
Round/bold game display için Fredoka, Baloo 2, Nunito ExtraBold, Lilita One gibi lisansı kontrol edilmiş uygun fontlar *örnek* olabilir. Bunlar zorunlu değil; font seçerken okunabilirlik, dildeki karakter kapsamı, lisans, küçük boyutta biçim, benzer ağırlık/outline incelenir. Görsel üreticide harf formu bozuluyorsa metni sonradan gerçek fontla typeset et.

### 6.3 Outline ve shadow
- Koyu outline açık/koyu yüzeyde harfi ayırmak için kullanılabilir.
- Kontur çok kalın olursa harf counter’ları kapanır, font çocukça/çamur gibi görünür.
- Text shadow, ayrı bir ikinci outline üretmeyecek kadar hafif olmalı.
- All-caps başlıklarda harf aralığını kontrol et; satırı frame sınırından sıkıştırma.

### 6.4 Image generation ve metin gerçeği
Image model’den exact text basmasını istemek konsept aşamasında kabul edilebilir ama sonucu **her zaman** kopya doğrulamasından geçir. Üretim/UI katmanında ürün adı, fiyat ve açıklama tercihen gerçek GUI text olarak yapılır; baked-in text değişmez/localize edilemez.

## 7. Çizim, render ve materyal dili

Style lock şu başlıkları içermeli:
- illüstrasyon türü (ör. hand-painted/cel-shaded casual-game, flat icon, soft airbrush);
- outline kalınlığı ve rengi;
- ışık yönü ve gölge sertliği;
- yüzey/materyal (mat boyalı, az parlak, plastik parlak değil);
- ürün perspektifi/ölçeği;
- konturda detay yoğunluğu;
- UI yüzeylerinin pattern/gürültü seviyesi.

Kullanıcı “çok yapay” dediğinde bunu hemen “bütün render stilini reddetti” diye genelleme. Hangi öğe yapay görünüyor? Kullanıcı düzeltmesiyle belirli badge arka planı gibi tek bölgeye daralt. Yüzeyleri daha mat, çeşitlenmiş çizgi ağırlığıyla kontrollü güncelle; ama temel referansın çizgi dilini kaybetme.

## 8. Dekor katmanları ve kompozisyon

### 8.1 Üç derinlik düzlemi
1. **Ambient background:** uzak kar, kenar ağaçları, arka fon parçacıkları.
2. **Frame-attached overlay:** panel/frame köşesine oturan fir, bow, ornament, light strand; kullanıcı overlay istediyse görünür ve panelle temaslı olmalı.
3. **Surface pattern:** header/card üstünde düşük kontrastlı snowman silhouette, snowflake, fir repeat.

Dış çevre dekoru frame-corner overlay yerine geçmez. Her katmanda zıtlık/detay sınırı belirle. Logo, X, ürün başlığı ve controls üzerine dekor düşürme.

### 8.2 Zengin ama kontrollü görünüm
- Dört köşe birbirinin klonu olmak zorunda değil; dekor ağırlığını sol/sağda dengele.
- Header pattern’i title arkasında düşük contrast; boş alanlarda daha görünür olabilir.
- Overlay’in nerede frame’in önünden/arkasından geçtiği prompt’ta tariflenir. Contact shadow çok ağır olmamalı.
- Snow particles küçük olabilir; ürün yüzü, fiyat, label üstüne denk gelen taneleri sil.
- Bir kartta birden fazla rozet varsa her birinin rolünü gerekçelendir; tekrar eden “LIMITED TIME” yazılarını kaldır.

## 9. Badge/label karar ağacı

1. Etiket gerçek ürün statüsünü anlatıyor mu? `LIMITED` yalnızca limited üründe.
2. Badge UI hierarchy’de nereye ait? Ürün satırı mı, offer grid mi, kampanya banner’ı mı?
3. En uygun negative space nerede? Önce title/controls gibi kilit alanları dışla.
4. Etiket düz backing mi, rozet mi, ribbon mı? Kullanıcı örneği ve style lock belirlesin.
5. Ürünün arkasına girecekse z-order açık: frame > ribbon (arka) > ürün art > foreground controls? Ürün sanatını kesmediğini denetle.
6. Görsel hiyerarşiyi bozuyorsa küçükleştir/konum değiştir; otomatik sağ-üst etiketi kullanma.

Christmas örneğinde: Snowman Pet için kardan adamın üst/yan arkasında çapraz ribbon yönü kullanıcı tarafından tercih edildi; düz sarı label’ın sırıttığı bildirildi. Sleigh’e ikinci limited etiketi koyma.

## 10. Renk/duygu kaynaklarını kullanırken
Renk araştırmasını kültürlerarası “evrensel” kural gibi sunma. Bu pakette önceki vaka için bakılan kaynaklar:
- Jonauskaite et al. (2020), 30 ülke / 4598 katılımcı, renk-duygu ortaklıkları yanında kültür/dil/coğrafya farkları: https://www.psychologicalscience.org/journals/psychological-science/0956797620948810/
- Renk-duygu üzerine sistematik derleme: https://pmc.ncbi.nlm.nih.gov/articles/PMC12325498/
- WCAG 2.2 contrast guidance: https://www.w3.org/TR/WCAG22/

Kaynaklara dayanarak yalnızca “bu palet hangi hissi uyandırabilir ve neden?” sorusunu tartış. Tercihi sonunda okunabilirlik, marka/tema ve kullanıcı onayı belirler.
