# 03 — Hata kataloğu ve görsel kanıtlar

Aç `case_studies/GALLERY.html` ile tam görselleri ve numaralı işaretli kopyaları incele. `images/full/` altındaki dosyalar orijinal full-frame kopyalardır; `images/annotated/` yalnızca inceleme amaçlıdır. İşaretleme örneklerin üstüne yazılmaz. Kullanıcının beğendiği ve yalnızca referans olarak verdiği UI’lerin ayrımı `case_studies/LIKED_UI_CATALOG_TR.md` içindedir.

## Görseller ve teşhis

### F-01 — Christmas V2: tercih edilen kompozisyon, alt kırpma
- **Full:** `images/full/christmas_v2_user_preferred.png`
- **Annotated:** `images/annotated/christmas_v2_user_preferred.png`
- **01:** Gamepasses başlığı ve üst içeriği görünse de alt kartlar/alt sınır kesiliyor.
- **02:** LIMITED TIME metni iki üründe de var. Kullanıcı sonradan yalnızca ilgili ürün üzerinde, uygun boşlukta tek badge tercih etti.
- **Status:** V2 layout direction is preferred; image itself is not a complete full UI.
- **Correction:** preserve row hierarchy; fit all gamepass cards and frame before decoration.

### F-02 — V4: full layout ama yanlış kaynak/hiyerarşi riski
- **Full:** `images/full/christmas_v4_full_layout_alternative.png`
- **Annotated:** matching file under `images/annotated/`
- **01:** Yeni/uydurulmuş price values, source content ledger ile eşleşmiyor. Bir konseptte hiç doğrulanmayan fiyat basma.
- **02:** Badge/title/button alanları yerleşim olarak birbirine yaklaşabiliyor; badge için açık bir zone tanımla.
- **Outcome:** Sections fit better, but user preferred V2 composition. Completeness alone isn't aesthetic acceptance.

### F-03 — V5/V6: prompt’a “fit all” yazmak yetmez
- **Full:** `christmas_v5_decor_color_pass_crop_failure.png`, `christmas_v6_repeated_crop_failure.png`
- **Annotated:** same names in annotated folder
- **01:** Alt gamepass cards/base are still cut off. V6 repeated the same failure despite a more explicit height budget.
- **02 (V5):** Decoration/contrast improved, but the lower interface was not fixed; this is a QA blocker.
- **Correction:** do a wireframe/height sum; simplify/recompose, reserve bottom margin; if the tool keeps failing, use deterministic UI composition.

### F-04 — V8: local badge issue vs broad art rejection
- **Full:** `christmas_v8_pattern_corner_badge_issue.png`
- **Annotated:** same name in annotated folder
- **01:** Large rectangular textured yellow plaque behind LIMITED became visually dominant/awkward relative to row and controls.
- **02:** Gamepass bottom still cropped.
- **User correction:** overall image direction was liked; the issue was localized to the LIMITED label background/position. Do not interpret a specific badge correction as rejection of all illustration/decor.
- **Correction:** use one diagonal strip in the product's upper negative-space zone, tucked behind/near the snowman; maintain readability and avoid text/control overlap.

### F-05 — V9: badge texture refined but location not settled
- **Full:** `christmas_v9_badge_refinement.png`
- **Annotated:** same name in annotated folder
- **01:** Plaque is simpler but remains a horizontal box and still does not satisfy the later preferred diagonal-ribbon composition.
- **02:** Bottom gamepass crop persists.
- **Correction:** change shape/placement, not only texture.

### F-06 — V10: accepted design direction + known crop defect
- **Full:** `christmas_v10_user_accepted_direction.png`
- **Annotated:** same name in annotated folder
- **01:** Diagonal LIMITED ribbon is now in the Snowman area; preserve this user-approved direction.
- **02:** Sleigh purchase controls are in a common aligned row; preserve common scale/baseline.
- **03:** Lower Gamepass content remains cut off at the image edge. Even though the user called the direction successful, do not mark the image full-production-ready until this crop is repaired or explicitly accepted as a cropped concept.

### F-07 — Halloween V5: decoration-technique reference only
- **Full:** `images/full/halloween_v5_overlay_reference.png`
- Use as evidence of how silhouette patterns and layered themed corner overlays can enrich a frame, because the user explicitly cited that technique.
- It is not the Christmas palette or layout source. Do not transfer clouds, Halloween motifs, excessive UI labels or any unrelated composition.

### F-08 — UI layout reference
- `images/full/car_shop_layout_reference.png` is the user's car-shop reference for offer scale, readable controls and hierarchy only. It is not a request to copy the car theme or cyan palette.
- `images/full/christmas_environment_reference.png` informs Christmas season/decor. It does not replace the chosen shop layout.

## General failure patterns

### 1. Repeating a failed render with stronger wording
If the model crops the same gamepass section twice, the cause is likely spatial/composition constraints, not weak adjectives. Rebuild the proportions or use a deterministic layout; don't call it fixed when it isn't.

### 2. Treating detail as decoration quality
Adding many snowflakes/ornaments is not the same as frame-attached intentional decoration. Map background, header surface, and corner overlay separately. Add some, inspect hierarchy, then stop before buttons/text are crowded.

### 3. Badge auto-placement
A badge at the same top-right position on every row ignores content and negative space. Mark its container and z-order; locate based on item art/title/actions.

### 4. Changing too much in one edit
If palette, layout, text, ribbon, and button scale all move simultaneously, it becomes impossible to know what corrected/worsened the design. Keep versions and change one primary issue per pass.

### 5. Mistaking ambiguous feedback
When user says “the yellow background behind LIMITED” they may mean it should be added, removed, simplified, or moved. Reflect and ask a narrow question if image context does not disambiguate. Do not alter the whole concept from a local comment.

### 6. Overconfidence from image preview
A visually attractive preview can still contain clipped cards, wrong prices, duplicated symbols, or unreadable small text. Inspect at full resolution, and independently verify the boundary and content ledger.

## Deleted/rejected evidence
- Christmas V3 was rejected by the user as very bad and then deleted. It is **not** in this package and must not be reconstructed or reused. The failure is documented by description only.
- Earlier rejected spider concepts are not approved examples and are not in this package.
- Older broken Halloween drafts were cleaned; retained Halloween reference/art is explicitly listed in workspace state, and car/Halloween assets were not deleted.
