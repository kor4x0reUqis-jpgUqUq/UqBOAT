# 05 — Reference notes / color / accessibility

## Color evidence
Earlier work checked three sources to avoid presenting color preferences as universal rules:
- Systematic review of color-emotion research (128 years of studies): https://pmc.ncbi.nlm.nih.gov/articles/PMC12325498/
- Jonauskaite et al. 2020, 30 countries and 4,598 participants, reporting common patterns alongside cultural/language/geographic differences: https://www.psychologicalscience.org/journals/psychological-science/0956797620948810/
- W3C WCAG 2.2: https://www.w3.org/TR/WCAG22/

Use sources as context, not as a palette generator. Color association depends on context and culture; UI contrast and brand/theme constraints can matter more than a general emotion association. WCAG contrast levels are useful reference goals; a stylized game UI still needs review at target size and an actual contrast check on relevant text.

## Original project assets represented in this package
- `case_studies/images/full/christmas_v2_user_preferred.png`: user-provided Christmas V2 source/reference. User preferred its composition over V3.
- `case_studies/images/full/christmas_v4_full_layout_alternative.png`: generated full layout alternative; do not inherit its unverified values.
- `case_studies/images/full/christmas_v10_user_accepted_direction.png`: later accepted visual direction; known crop defect documented.
- `case_studies/images/full/halloween_v5_overlay_reference.png`: Halloween decorative treatment, used only for low-contrast motif/overlay technique.
- `case_studies/images/full/car_shop_layout_reference.png`: layout/scale reference, not a color/style target.
- `case_studies/images/full/christmas_environment_reference.png`: Christmas theme/decor environment reference.

## Notes on intellectual property and assets
The examples are provided as user/project reference files inside this case-study package. They are not independent Roblox upload assets and do not establish rights to any third-party artwork. For a production asset set, make original art or use assets with appropriate rights, and keep dynamic labels/prices editable whenever practical.
