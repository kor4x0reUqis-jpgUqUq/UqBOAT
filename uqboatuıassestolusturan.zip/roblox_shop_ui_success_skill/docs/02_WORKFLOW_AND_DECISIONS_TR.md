# 02 — İş akışı ve Christmas vaka karar günlüğü

Bu doküman, yeni bir ajan için iki şeyi sağlar: baştan sona operasyon akışı ve gerçek vaka üzerinden hangi kararların neden alındığı. Tarihler/versiyon numaraları aday kimliği olarak kullanılır; dosyayı açmadan “başarılı” varsayılmaz.

## A. Uçtan uca çalışma akışı

### A1. İstekten tasarım şartnamesine
1. Kullanıcının her açık talimatını ayrı kaydet: `MUST`, `MUST NOT`, `PREFERENCE`, `REFERENCE ONLY`, `UNRESOLVED`.
2. Görselleri inceleyip içerik ledger’ı çıkar.
3. Birincil layout referansını belirle; teknik repo/görsel referans ayrımını belirt.
4. Onaylanmış tasarım parçalarını “do not regress” listesine taşı.
5. Kullanıcıya açıklama gerektiren kritik bilinmeyeni sor; soru gerektirmeyen işte ilerle.

### A2. Önce wireframe
Renderdan önce katmanlı bir wireframe hazırla:
- outer frame + safe margins;
- header bandı, icon, title, X;
- category separator’ları;
- offer row sayısı, art/name/control bölgeleri;
- gamepass grid’i;
- overlay/pattern safe zone’ları.

Wireframe üzerinde alt satırın tamlığına yer ayır. Image model’in yüksekliği daraltacağına güvenme.

### A3. İlk render
- Birincil referans tek olsun. Birden fazla image ref veriliyorsa her birinin rolünü tek cümleyle yaz.
- İstek hangi dosyayı edit ettiğini ve hangi unsurları koruması gerektiğini söylesin.
- exact item copy ve fiyat listesi ekle.
- Layout en-boy/outer margin ve minimum içeriği say.
- Prompt’a “do not crop” demenin tek başına yetmeyeceğini bil; çıktı denetlenecek.

### A4. Hata değerlendirme
Kullanıcıya göstermeden şu sırayla bak:
1. Required copy/price/icons.
2. Full canvas: header ve bottom border görünür mü?
3. Layout: sıra, boyut, alignment.
4. Contrast/text size.
5. Theme/style consistency.
6. Decoration, overlays, badge.

Birinci kalite sorunu çözülmeden beşinci/altıncı düzeltmeye geçme.

### A5. Geri bildirim turları
Her tur için 4 satır kaydet:
- `Feedback:` kullanıcının kısa alıntısı/parafrazı.
- `Keep:` ne değişmeden kalacak.
- `Change:` tek ana düzeltme.
- `Verify:` hangi piksel/alanla kontrol edilecek.

Örnek: `Keep: V2 kompozisyonu. Change: LIMITED’i Snowman Pet arkasında çapraz ribbon; Sleigh button group ortak yükseklik. Verify: badge artık boşlukta yüzmüyor mu; green/gift ile purple baseline eşit mi?`

### A6. Aynı hatayı model tekrarlarsa
- İkinci kez aynı kompozisyon/aynı crop gelirse promptu sadece sertleştirme. Görsel üreticinin yerleşim sınırını kabul et.
- Layout’ı küçült, content density azalt (yalnızca kullanıcı onayıyla), portrait/landscape canvas oranını tekrar seç veya deterministic SVG/HTML/Figma/Roblox layout gibi kontrollü bir yol kullan.
- Hata crop ise “daha iyi decoration” üretme; önce frame bounds ve last-row space çöz.
- Hata tek badge ise local edit dene; edit başka alanı bozduysa undo/revert için version dosyasını tut.

## B. Christmas shop karar günlüğü

### B1. Kullanıcı brief’inin kilitleri
- Kullanıcı Christmas V2’yi V3’ten daha başarılı buldu; V3 “çok kötü” olarak reddedildi. V3’ü temel alma.
- V2’nin ürün satırı ölçeği ve genel pencere dengesi tercih edildi; V2’de gamepass alanı kesikti.
- Renk/kontrast ve dekor yoğunluğu zayıf bulunmuştu; kullanıcı daha belirgin header surface silhouettes ve UI frame corner decoration istedi.
- Header tek şerit: sol ikon, yanında sola hizalı title, sağ kare X; cyan car palette ve bulut kullanılmayacak.
- `~ LIMITED GIFTS ~` ve `~ GAMEPASSES ~` section headings; `~ ROBUX ~`/`~ CASH ~` section headings istenmiyor. Fiyat button’larında sadece icon/fiyat.
- LIMITED badge aynı yere otomatik basılmayacak; Snowman Pet özelinde çapraz/üst konum tercihi bildirildi.
- Kullanıcı V10’u “başarılı” olarak onayladı; bu tasarım yönünü koru. V10’da gamepass altı hâlâ crop olarak görünse de, kullanıcı onayı kusuru teknik olarak ortadan kaldırmaz. State’i `APPROVED DIRECTION + KNOWN CROP DEFECT` şeklinde yaz.
- V10 Sleigh controls: green cash + gift button’ları purple Robux button ile hizalama/ölçü için istenen değişiklik yapıldı.

### B2. Content ledger (kaynağı belli olan değerler)
| UI field | Exact value | Source/notes |
|---|---|---|
| Header | CHRISTMAS SHOP | user's reference |
| Section | ~ LIMITED GIFTS ~ | explicit preference |
| Snowman title | SNOWMAN PET | reference |
| Snowman description | YOUR LITTLE WINTER COMPANION | reference |
| Snowman Robux | 40 | reference |
| Snowman cash | $350 | reference |
| Sleigh title | CANDY CANE SLEIGH | reference |
| Sleigh description | FASTEST RIDE IN TOWN | reference |
| Sleigh Robux | 75 | reference |
| Sleigh cash | $30 | reference |
| Section | ~ GAMEPASSES ~ | explicit preference |
| Gamepasses | WINTER FLIGHT / GIFT LUCK | reference |
| Winter Flight benefit | INCREASED MOVEMENT SPEED | reference |
| Gift Luck benefit | GET BETTER GIFTS | reference |

Source did not reliably expose gamepass prices in the full, uncropped preferred version; do not invent. V4 displayed new numbers, but those are not source-of-truth.

### B3. Version history, outcome, lesson

| Version | What changed | Outcome | Reusable lesson |
|---|---|---|---|
| V2 | User's original preferred composition; header silhouettes already present; product art left, controls right; seasonal outer edge art | User said it was better than V3; bottom gamepass content clipped; some contrast/deco issues | Preserve its hierarchy, do not copy its crop. |
| V3 | New generation with all sections nominally visible | User rejected it strongly | A technical checkmark (all sections present) cannot override user's layout taste. Never use this approach. The actual V3 file was deleted; do not claim it is included. |
| V4 | Recreated V2-led concept, complete gamepass cards, burgundy header/green offers/navy gamepass, one badge | Not user’s preferred direction vs V2; it included values not present in original and looked like a more different composition | Complete layout but do not silently invent price/copy; maintain preference, not just feature count. |
| V5 | Added contrast and more outside seasonal decoration; one gold badge | Bottom gamepass section remained cropped | Prompt with crop constraints was insufficient. Inspect full image. |
| V6 | More explicit height-budget prompt | Repeated essentially same crop | Same issue repeated despite stronger prompt. Stop repeating; recompose deterministically. |
| V8 | Added header silhouette pattern/strings, frame treatment; yellow rectangular LIMITED backing | User liked general visual, then identified the LIMITED backing/placement as the specific issue | Don't over-generalize “artificial” to reject whole artwork; respond to precise local defect. |
| V9 | Simplified gold backing | Did not solve accepted ribbon direction; lower crop persisted | Badge design needs location/hierarchy, not just texture simplification. |
| V10 | Diagonal LIMITED ribbon positioned by snowman; Sleigh green/gift controls scaled/aligned to purple | User called it successful | Preserve this direction. Yet record lower crop separately; acceptance of art direction is not proof of full-canvas correctness. |

### B4. Color decision rationale
- Cranberry header creates a seasonal focal band against deep navy.
- Evergreen/dark navy anchor the window; pale ice blue creates a bright reading surface for Snowman Pet.
- Sleigh uses a strong red field with white title and clear product art.
- Purple Robux, green cash, blue gift controls retain familiar semantic differentiation from the reference. Keep their size/alignment consistent.
- Gold is reserved for small emphasis (e.g. one limited ribbon) so it does not become a large competing field.
- These are pragmatic UI choices, not claims that a color universally means a specific emotion.

### B5. Layout decision rationale
The user's V2 preference was not just “Christmas decoration.” It was the balance of offer-card scale, left-to-right reading path, image size, title/subtitle, and right-side purchase controls. Later edits should conserve these relationships. Decoration should enrich header/panel edge without changing row proportions or displacing the purchase area.

## C. Decision log template rules
- Save decision logs beside project files and version them.
- Keep accepted and rejected constraints in plain language.
- State whether each item is visual direction approved or production-ready.
- Never erase rejected history when it can prevent a repeat failure.
