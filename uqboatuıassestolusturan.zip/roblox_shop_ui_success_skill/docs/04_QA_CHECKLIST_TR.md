# 04 — QA, kabul kriterleri ve durum isimleri

## 1. Puanlama rubriği (0–5)
Her başlık için puan ve tek cümle kanıt yaz. Ağırlıklı puan tek başına gerekli hata sınıflarını geçersiz kılamaz.

| Alan | 0–1 | 3 | 5 |
|---|---|---|---|
| İçerik doğruluğu | fiyat/isim yanlış veya eksik | küçük kopya/ikon kusuru | ledger’la birebir eşleşiyor |
| Kompozisyon | kaynak hiyerarşisi kayıp | tanınabilir ama dengesiz | tercih edilen layout korunmuş, temiz okuma akışı |
| Kadraj/tamlık | zorunlu kart kesik | içerik var ama margin yetersiz | bütün UI/alt border ve güvenli pay görünür |
| Kontrast | metin kayboluyor | çoğunlukla okunur | ana/ikincil metinler boyut küçülünce de ayrışıyor |
| Kontrol hizası | boyut/baseline dağınık | küçük farklar | row içi tutarlı ölçü, merkez ve spacing |
| Dekor/hiyerarşi | dekor içerikle çarpışıyor ya da düz | tema var, bazı kısımlar rastgele | frame’e/plane’lere oturuyor; süsler ürünü/eylemi destekliyor |
| Stil tutarlılığı | karışık render | çoğunlukla tutarlı | line, light, material ve ölçek tutarlı |
| Kullanıcı tercihi | açıkça reddedilmiş yön | nötr/yeni | açık onay alınmış |

`production-ready` için: content ≥5, composition ≥4, crop ≥5, contrast ≥4, controls ≥4, user approval required. Eksik gamepass bölümü otomatik fail’dir.

## 2. Kadraj kontrolü (manuel, zorunlu)
1. Kanvasın dört kenarını sırayla tara.
2. Frame’in dış çizgisinin tamamı görünür mü? Shadow/outer border canvas’a çarpıyor mu?
3. Her offer card’ın border’ı ve son kontrol görünür mü?
4. Bölüm başlığı card’ı örtüyor mu?
5. Gamepass kartında title, art, benefit, purchase control ve alt border var mı?
6. Frame dışı corner decoration paneli örtmeden duruyor mu?
7. Küçük/mobile ölçekte text ve ikonlar ayakta mı?
8. Varsa kırpılan içerik, skorda ve teslim metninde açık yaz.

### Neden generation prompt yetmiyor?
Image model önceden belirlenmiş bir pixel layout engine değildir. “Full gamepass visible” cümlesini görse bile örnek kompozisyonu tekrar edip bottom crop yapabilir. Bu vakada V5/V6/V8/V9/V10 boyunca kesilme sürdü. Kural: istenen geometriyi wireframe’de matematiksel yerleştir, sonra generated image’i ölç/incele; problem sürerse tool değiştir.

## 3. İçerik doğruluk testi
- Her title/description karakter karakter ledger ile eşleşiyor mu?
- Robux ikonu gerçekten hex/token biçiminde mi, yalnızca bozuk şekil mi?
- Her fiyat sembolü bir kere mi? Örn. `$30`, `$350`; yinelenen `$` yok.
- Robux/Cash section headings eklenmiş mi? Kullanıcı istemediyse kaldır.
- Gift icon doğru sayıda mı?
- LIMITED yalnızca limited item’da mı? Tekrar var mı?
- Gamepass price yoksa uydurulmuş mu?

## 4. Kontrast ve tipografi testi
- Ana title, product title, subtitle, price ve badge ayrı ayrı okunuyor mu?
- Image’ı 50% veya telefon boyutunda açıp kontrol et.
- Harf outline ile panel arasında yeterli ayrım var mı? Outline iç harf boşluğunu kapatıyor mu?
- Kar tanesi/pattern harfin arkasından geçiyorsa başlık quiet zone’a taşınmalı mı?
- Renkleri yalnız hue ile değil brightness/value ayrımıyla test et.
- Normal/büyük metin için 4.5:1 / 3:1 WCAG oranlarını yardımcı hedef olarak ölç; görsel konturunun kontrasta dair eksikliği gizlemesine izin verme.

## 5. Alignment/spacing testi
- Button row ortak top/bottom/centerline mı?
- Purple/green/gift height tutarlı mı? Hacim optik olarak dengeli mi?
- Icon ve text button padding’i eşit mi?
- Badge, title, art ve controls arasında en az bir net boşluk var mı?
- Frame stroke, card stroke ve button stroke ağırlıkları arasında hiyerarşi var mı?
- Kenar radius’ları tutarlı mı; outer frame gereksiz yuvarlaklaştı mı?

## 6. Durum etiketleri
- `REFERENCE`: kullanıcı kaynağı; edit yetkisi yok veya source-of-truth.
- `DRAFT`: üretilmiş ama user feedback bekliyor.
- `PREFERRED DIRECTION`: kullanıcı diğerlerine göre tercih etti, açık final onayı yok.
- `USER-ACCEPTED CONCEPT`: kullanıcı açıkça başarılı/onaylı dedi.
- `USER-ACCEPTED DIRECTION + KNOWN DEFECT`: yön kabul edildi ama crop/typo gibi kusur sürüyor.
- `PRODUCTION-READY`: content/layout/crop/contrast/device/approval testleri tamam.
- `REJECTED`: yeniden kullanım yok; yalnızca failure catalog için saklanabilir.

## 7. Handoff kontrolü
- Ana deliverable dosyası var ve açılabilir mi?
- Gerekirse editable sources ve separate asset’ler için onay alındı mı?
- Known defects listelendi mi?
- Tam ve annotated örnekler ayrılmış mı?
- Version isimleri birbirine karışmıyor mu?
- ZIP’te kaynak dosya/README/SKILL/örnekler bulunuyor mu?
- Son mesajda yalnızca doğru deliverable açıldı mı? Scratch/generated intermediate sunulmadı mı?
