# Decision log — [project]

## State
- Current candidate:
- Status: REFERENCE / DRAFT / PREFERRED DIRECTION / ACCEPTED CONCEPT / ACCEPTED WITH KNOWN DEFECT / PRODUCTION READY / REJECTED
- Open defects:
- Source of truth:

## Explicit constraints
### Must
-
### Must not
-
### User-preferred
-
### Rejected
-

## Content ledger
| Field | Exact source content | Source path | Confidence | Notes |
|---|---|---|---|---|

## Reference contract
- Primary layout source + preserved properties:
- Style reference + borrowed properties:
- Technical source only:
- Do-not-copy:

## Iteration record
| Version | What changed | User feedback | QA result | Status / next step |
|---|---|---|---|---|

## Color rationale
| Role | Color/value | Why in hierarchy | Contrast checked? |
|---|---|---|---|

## Typography and drawing lock
- Font characteristics:
- Exact installed/licensed font if used:
- Outline/shadow:
- Material/lighting/render:
- Style exclusions:

## Geometry / viewport
- Aspect and resolution:
- Frame bounds:
- Header height:
- Offer rows:
- Gamepass row:
- Bottom safe margin:
- Button heights/baselines:

## Final QA evidence
- Content exact:
- Full border/last card:
- Contrast/size:
- Button alignment:
- Badge placement:
- User approval:
- Remaining defect:
