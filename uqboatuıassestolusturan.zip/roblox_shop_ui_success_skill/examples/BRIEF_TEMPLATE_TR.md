# Shop UI brief — copy and fill

## Project
- Game / shop type:
- Target platform(s): Roblox / other
- Target aspect(s) and viewport(s):
- Language/locales:
- Deliverable now: concept image / editable mockup / separate art / Roblox implementation

## Reference hierarchy
- Primary layout source (what exactly to preserve):
- Primary style source (what exactly to preserve):
- Secondary source(s) (one property each):
- Technical repository/source (implementation only or visual reference?):
- Accepted user examples:
- Rejected versions or styles (must not reuse):

## Content lock
| UI element | Exact wording/value | Source | Verified? |
|---|---|---|---|
| Header | | | |
| Section 1 | | | |
| Product 1 | | | |
| Price/currency 1 | | | |
| Product 2 | | | |
| Price/currency 2 | | | |
| Other sections/cards | | | |

## User constraints
- Must:
- Must not:
- Preference:
- Unresolved question:

## Visual direction
- Mood/use context:
- Layout/hierarchy:
- Palette roles:
- Typography:
- Drawing/render style:
- Decoration layers:
- Badge rules:
- Corner geometry:
- Safe zones:

## Acceptance gates
- Required copy/values:
- Full-frame/bottom margin:
- Button alignment:
- Contrast/text size:
- User acceptance needed before separate assets? yes/no
- Production-ready definition:

## Source files
- References:
- Candidate versions:
- Decision log:
