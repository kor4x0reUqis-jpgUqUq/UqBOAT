# Prompt Playbook — robust image-UI direction, revisions, and recovery

## 0. Core principle
Prompt prose is a design contract, not a geometry engine. Exact text, prices, button alignment, and full-canvas fit must be inspected after every output. Use reference files with explicit roles; the model should not infer which one is source of truth.

## 1. Project-specific style lock — Christmas case
Reuse only when the project has this exact direction:
- Preserve the user's V2 offer-row proportions/order and left-art / center-copy / right-actions path.
- One cranberry header band; icon left, left-aligned title, square X right.
- Surface treatment: low-contrast snowman/snowflake silhouettes in header; frame-attached snowy fir/light/ornament corners; avoid clouds and cyan header.
- Frame/cards use deliberate crisp corners. Button size/radius consistent with source.
- Deep navy/evergreen structural surfaces, pale ice blue, cranberry red, white text with dark outline, very limited gold.
- Casual game illustration with clear hand-rendered outlines; no hyper-glossy plastic look.
- Two limited gift offers plus two-column gamepass section; exact words/values from the verified content ledger.
- One diagonal LIMITED ribbon only for Snowman Pet, tucked at upper area behind/near snowman; no large detached yellow rectangle and no second badge.
- In sleigh row, purple Robux, green cash and gift buttons share height/alignment/visual scale.
- Entire gamepass row and bottom frame must be visible. If reference crops it, don't repeat that crop.

## 2. New-concept prompt template
Replace bracketed variables; remove any contradictory sentence.

```text
Create one [aspect ratio] game shop UI concept for [game/platform/context]. The user's primary visual reference is [file/name]; preserve [exactly list layout properties]. Secondary reference [file/name] is for [one isolated property only]. Do not copy its [palette/layout/motifs].

CONTENT LOCK — render these exact labels/prices and no other copy:
Header: [exact]
Sections in order: [exact]
Products: [exact names, descriptions, values, buttons]
Unknown values: omit them, do not invent.

LAYOUT:
[Frame bounds as % of canvas, header, row count/order, art zone, copy zone, action zone, gamepass cards]. Reserve [X%] top and [Y%] bottom margin. Include full outside frame stroke, every card base, icons, prices, and last-row lower border. Do not let the UI touch the canvas edge. Layout takes precedence over decorations.

STYLE LOCK:
[outline/line weight], [render type], [surface material], [lighting], [palette roles], [font characteristics]. Maintain [accepted style]. Avoid [rejected style].

DECORATION PLAN:
Layer 1 background: [ambient]. Layer 2 frame-attached overlays: [which corners, how attached, z-order]. Layer 3 surface patterns: [where, contrast]. Keep all critical text and controls in quiet zones. [Badge rules].

BUTTON SYSTEM:
[common height, baseline, icon scale, outline weight, gap, corner treatment].

EXCLUSIONS:
No [clouds, extra labels, fake text, duplicated symbols, extra products, watermark, crop, overlap].

After generation, check exact copy, all prices, full outer bounds, alignment, contrast and small-size legibility. The prompt is not considered proof of those checks.
```

## 3. Localized edit template

```text
Edit only [named region] of the provided image. Keep the whole rest exactly as-is: composition, item art, layout, colors, labels, frame and background.
Change: [one observable correction].
Current defect: [what looks wrong and where].
Target state: [shape, size, position, color, z-order, readable text].
Do not cover [title/face/price/controls]. Keep exact text [text].
Do not add/remove any other object or reflow the rest of the UI.
After the edit, compare the requested region and the whole screenshot. If the edit damages other regions, revert to the previous version rather than accepting collateral changes.
```

Example badge edit:
```text
Replace only the detached yellow rectangular LIMITED plaque. Keep a single LIMITED label as a small diagonal gold ribbon tucked behind the upper side of the snowman illustration. The ribbon may overlap empty card space, but not the snowman's face, title, description, currency buttons, gift button or frame. Keep the rest unchanged. No other badge.
```

Example button alignment edit:
```text
In the Candy Cane Sleigh row only, make the green cash and blue gift controls share the purple Robux button's height and vertical centerline. Keep their own contents, width appropriate to label/icon, matched border thickness and consistent gaps. Do not enlarge the row or move title/art. Do not alter the Snowman row.
```

## 4. Crop-recovery prompt / strategy
Do not keep repeating “show everything”. Switch from text constraint to geometric solution:
1. State the **frame** should occupy a smaller fraction of canvas.
2. Give each region a height budget including strokes/gaps/margins; verify arithmetic.
3. Reduce card heights and copy length only where approved; preserve main text size.
4. Make the last-row bottom edge and outer bottom margin explicit.
5. If another generated image repeats the crop, stop image editing and use a deterministic mockup/wireframe/layout app. Do not call the repeated crop complete.

A suitable prompt might say:
```text
The frame occupies no more than 82% of image height, with 6% top margin and 8% bottom margin. Inside it reserve [x%] for header, [x%] section labels, [x%] offer rows, [x%] gamepass cards, [x%] gaps and borders. All percentages sum to 100% of the frame. Render the full bottom stroke and blank margin below it. If content does not fit, compact spacing before shrinking type. Do not extend cards beyond canvas.
```

## 5. Bad prompt / better prompt pairs

### Bad: vague, incompatible reference roles
> Make this cooler, like the car and Halloween images, more Christmas, very detailed, but clean and simple, include everything, don't crop.

Why it fails: “cooler” has no criterion; two references may conflict; detailed and simple conflict; no content ledger/geometry; “include everything” cannot be audited.

Better:
> Use Christmas V2 as the layout source. Use Halloween V5 only for the technique of low-contrast motif patterns and frame-attached corners; do not borrow its cyan palette/clouds. Preserve the two offer row proportions and exact labels/prices. Fit header + two rows + two gamepass cards into a frame occupying 82% of canvas height; reserve the last 8% as empty bottom margin. Inspect the full gamepass borders after rendering.

### Bad: badge location by habit
> Add a limited badge top right.

Why it fails: it may collide with price controls or product title and can look pasted on.

Better:
> Place the single LIMITED ribbon in Snowman Pet's upper negative-space, diagonally tucked behind the snowman art. Preserve its face/title/control zones. Do not add one to sleigh.

### Bad: global rewrite for a local problem
> Make the whole UI less artificial, fix badge, improve buttons, add decorations, change colors.

Why it fails: too many simultaneous variables; cannot identify successful correction; collateral drift.

Better:
> Preserve this exact image direction. Edit only the LIMITED backing: remove the oversize horizontal plaque and use one small diagonal ribbon behind the snowman. Keep all other pixels/regions unchanged. Then inspect only badge and whole-image drift.

### Bad: false guarantee
> This will definitely show all items and match the reference exactly.

Why it fails: no prompt guarantees model compliance.

Better:
> This prompt reserves space for all items. I will inspect the output and mark any remaining crop as a defect; if repeated, I will switch to a controlled layout.

## 6. Revision record template
```text
Version: [vNN]
User feedback: [short quote/paraphrase]
Preserve: [accepted elements]
Change one: [exact defect]
Prompt file/hash: [path]
Result check: [what changed]
Regression check: [what accidentally changed]
Status: DRAFT / PREFERRED / ACCEPTED DIRECTION + DEFECT / PRODUCTION READY / REJECTED
```
