# Case prompt archive — gerçek üretim/edit istemleri

Bu dosya `PROMPT_PLAYBOOK.md` içindeki genel şablonlardan farklı olarak, Christmas Shop konuşmasında görsel araçlarına gönderilen prompt’ların kaydını ve sonuç değerlendirmesini tutar. Ajan prompt’la birlikte sonucu da okumalı; başarısız prompt’u başarılı örnek gibi sunmamalı.

> **Doğruluk notu:** V2 ve V4 ilk üretim çağrılarının tam prompt metinleri mevcut oturum kaydında bulunmadığı için burada yeniden oluşturulmadı. V5/V6/V8/V9/V10 için erişilebilir tam metinler aşağıdadır. Görsel araçları stochastic olduğundan aynı metin aynı piksel çıktısını garanti etmez.

## V5 — V2 yönünde, dekor ve kontrast edit/yeniden üretim prompt’u

**Sonuç:** Kenar dekoru ve yüzey ayrımı iyileşti; alt Gamepasses yine kadraj dışında kaldı. Tamamlanmış UI olarak kullanma.

```text
Refine the user's uploaded Christmas shop concept image as the PRIMARY master. Preserve its layout, visual balance, product order, dark navy window, cranberry header, illustrated snowman and sleigh, section-dividers, and square close X. The user explicitly prefers this source concept over the newer v4. Do NOT redesign it into a different layout. Make a careful improvement pass only.

Preserve the same structure: cranberry header with gift/tree icon and 'CHRISTMAS SHOP'; centered '~ LIMITED GIFTS ~' divider; Snowman Pet offer; Candy Cane Sleigh offer; '~ GAMEPASSES ~' divider; Winter Flight and Gift Luck cards beneath. Do not add currency-category labels above buttons. Place only one small gold 'LIMITED' ribbon on the Snowman Pet offer, positioned where the offer's empty space fits naturally; remove repeated 'LIMITED TIME ONLY!' text from the other item. Prices remain inside their buttons with a clean white hexagonal Robux symbol and the price; no extra Robux word label. Keep the header as a simple straight-edged bar, icon at left, title left aligned, pink square white-X far right. No rounded card corners, no cloud decoration, no cyan header.

Improve contrast while respecting the exact source look: make the snowman item row pale icy blue with deep navy edging and dark/white readable type; make the sleigh row a saturated cranberry/red panel with a slightly different value from the dark navy body; keep gamepass cards clearly separated, one icy-blue and one evergreen, each with a sharp inner border. Use snow-white heavy rounded sans-serif lettering with a properly thick dark outline (not black-filled letters) and enough size for readability. Keep the main frame deep navy/charcoal with a clear light inset border. Gold is limited to small glints and the single badge. Avoid making every field dark, muddy or the same midtone; text/background contrast should be obvious at a glance.

Increase the seasonal decorations OUTSIDE the UI perimeter, using the user's Christmas reference as inspiration: fuller but tidy snow-covered fir branches along upper and lower side edges, additional small warm fairy lights and a few red/gold hanging ornaments, candy cane near one outer side, one friendly little snowman outside the lower edge. Background remains midnight navy; no blue sky and absolutely no puffy clouds. These are extra environmental decorations, not UI corner flourishes, and must not cover interface text or purchase controls.

Fit the full window, the complete gamepass cards, their icons/prices, and the entire bottom border visibly within a wide 16:9 canvas with margin. The uploaded source crop cuts too much at the bottom; compress internal vertical spacing slightly while retaining the source proportions and hierarchy so nothing is cropped. Keep all section labels and items readable. Do not shrink the whole UI into a tiny center window.

The result should feel like a careful color/contrast/decor refinement of the uploaded v2, keeping its successful composition. Preserve richly rendered casual-game illustrations, crisp outlines, consistent size, clean button alignment, no text/art overlaps. Avoid the unrelated v3 arrangement, excessive pattern noise, giant ornaments, gothic flourishes, generic cloud corners, cyan car-style header, tiny filler copy, and watermark.
```

### Diagnosis
Prompt’da “margin” ve “full bottom border” belirtilse de kompozisyon hâlâ referans crop’ını takip etti. Bir sonraki turda aynı yaklaşım yerine ölçülebilir frame bütçesi veya kontrollü mockup tercih edilmeli.

## V6 — crop sorununu açık height budget ile giderme girişimi

**Sonuç:** V5’teki kırpılma tekrarlandı. Bu gerçek başarısızlık örneği: daha uzun prompt, layout motoru yerine geçmedi.

```text
Create one complete, polished landscape Christmas shop screenshot. Use the user's uploaded Christmas v2 as the preferred composition reference, and the latest v5 only for improved color contrast/decor. Preserve the deep navy background, burgundy-red header, snowman and sleigh products, two category labels, fir branches and hanging ornaments. This time solve the crop: the full gamepass cards and complete bottom border must appear inside the image with visible margin.

COMPOSITION HEIGHT BUDGET (must obey): The output is landscape 16:9. The whole UI frame must occupy only 82% of the canvas height, leaving 8% clear margin above and 10% below. Inside the UI: header = 13% of total canvas height; section heading '~ LIMITED GIFTS ~' = 5%; first offer row = 15%; second offer row = 15%; section heading '~ GAMEPASSES ~' = 5%; gamepass card row = 22%; all gaps, borders and interior padding together = 7%. Sum around 82%. This leaves breathing space and ensures all content is visible. Do not fill the entire height, do not extend the gamepass cards to the image edge. Both complete gamepass cards including title, art, benefit, price button and bottom border must be shown fully.

Use a compact straight-edge window with square 90-degree UI corners. Header: one simple dark cranberry band, small gift/tree icon at left, left-aligned 'CHRISTMAS SHOP' beside it, pink square white-X at far right. No rounded card corners, no cloud decoration, no cyan header. Keep the same header positioning as the user's preferred Christmas v2.

Christmas color rationale visually: cranberry header for a lively seasonal focal point; calm evergreen/dark navy body; pale snowy blue for one offer surface; brighter red/cranberry for the sleigh offer; white text with strong dark outline; a single small gold 'LIMITED' badge only on Snowman Pet, situated in available negative space. No repeated 'LIMITED TIME' on Candy Cane Sleigh. Fir-green and gold ornaments outside the UI increase the festive border decoration; no clouds. Maintain clear foreground/background contrast and do not use similar brightness for text and panel.

Inside: section divider '~ LIMITED GIFTS ~'; below it two compact landscape rectangular offer rows: (1) Snowman Pet, small detailed snowman holding a candy cane, subtitle 'YOUR LITTLE WINTER COMPANION', clean aligned Robux price 40 and cash $350 plus gift control; only one small gold LIMITED badge. (2) Candy Cane Sleigh, small detailed sleigh and reindeer, title and short line 'FASTEST RIDE IN TOWN', price 75 and $30 plus gift control, no limited badge. Item art on left quarter, clear title/subtitle in middle, purchase controls at right. Keep rows shorter than in the source so they fit.

Then centered straight divider '~ GAMEPASSES ~'. Under it two side-by-side gamepass cards of equal height: WINTER FLIGHT with wings and 'INCREASED MOVEMENT SPEED', GIFT LUCK with present and 'GET BETTER GIFTS'; each with a readable Robux hex-icon price button. Full cards and borders are visible, no cropping. No '~ CASH ~' or '~ ROBUX ~' labels near buttons; only category section labels. Accurate simple white outlined hexagonal Robux token, not circle or R$. Dollar sign appears once.

Outside the frame, add more festive seasonal framing than the original v2 but preserve negative space: snowy evergreen sprigs along upper and lower outer edges, warm fairy lights, a few red/gold ornaments, one candy cane and friendly snowman near the side/bottom. These are outside the UI and must not overlap any card or label. Rich detailed 2.5D casual game illustrations like the user's preferred example, crisp outlines, consistent size, careful sizing. Do not create a flat SVG/primitive look. No watermark, no extra offers, no fake tiny copy, and no cropping of any UI element.
```

### Diagnosis
Yükseklik aritmetiği prompt içinde yazılmıştı ama model yine referansın crop’ını takip etti. Tekrarlanan hata sonrası doğru aksiyon: modelden aynı layout’ı daha uzun anlatmak değil, gerçek wireframe/layout’ı ayrı kurmak.

## V8 — header silhouettes / corner decoration, new concept attempt

**Sonuç:** Kullanıcı genel görsel yönünü beğendi. LIMITED arkasındaki sarı text backing konusu daha sonra kullanıcı tarafından sorun/eksik alan olarak ayrıca belirtildi. Alt gamepass crop devam etti.

```text
Design a richly decorated Christmas Shop game UI screenshot, landscape 16:9, with the UI composition of the user's preferred V2: a large straight-edged framed shop window, burgundy single-strip header, two horizontal limited gift offers, then a bottom side-by-side gamepasses section. Make it polished, vibrant hand-painted 2.5D Roblox casual-game art, with the full UI and full bottom border visible. This is a new clean composition; do not reproduce any crop from previous Christmas drafts.

IMPORTANT VISUAL DIRECTION: make the screen feel layered and festively decorated, not plain. Borrow the overlay technique of a polished Halloween game-shop UI: themed low-contrast silhouettes patterned across the header surface, plus large decorative elements overlapping/anchoring the OUTER frame corners. Christmas version: repeat faint burgundy/berry-toned snowman silhouettes, snowflakes, tiny fir trees, and starbursts across the cranberry header background, subtly embossed behind the title without reducing legibility. Build decorative corner overlays around all four outer UI frame corners: snow-loaded fir sprigs, little baubles, ribbon curls, warm fairy lights, small snowflakes and gift-bow accents. These should visibly sit in front of/around the frame edges as intentional layered UI ornaments, like corner brackets, not just distant background props. Upper left header corner can have a dimensional gift/tree emblem overlapping the frame; upper right corner around the square X should have a small fir-and-ornament corner accent that does NOT cover the X. Lower corners can have larger snow/fir overlays. Add subtle translucent snowflake patterns within product cards as secondary texture. Do NOT use clouds.

Keep the V2 hierarchy and large readable proportions, with clean straight 90-degree UI corners and bold outline style. Center the complete window leaving 5% margin at top and 7% at bottom. Fit all content into frame: Header 14% of window height; category title 6%; first offer row 16%; second offer row 16%; second category title 6%; gamepass row 23%; remaining dividers/gaps/borders 19%. Entire window must fit in 84% of canvas height, so full gamepass cards, prices, and bottom border are visible. No cropping, no offscreen content, no card cut-off.

Header text 'CHRISTMAS SHOP', large and left aligned next to a festive gift/tree icon. Square hot-pink X at far right. Pattern of translucent snowmen and snowflakes is clearly visible in header's empty background areas, similar density to a themed silhouette pattern, but low enough contrast behind text. Header remains cranberry red, not cyan.

Below header, centered label '~ LIMITED GIFTS ~'. Two compact landscape rectangular item cards: Snowman Pet with illustrated cheerful snowman and candy cane, subtitle 'YOUR LITTLE WINTER COMPANION'; Candy Cane Sleigh with detailed red sleigh and two reindeer, subtitle 'FASTEST RIDE IN TOWN'. Artwork on left; readable title and brief descriptor middle; aligned Robux and cash purchase buttons plus blue gift icon buttons on right. Pale icy-blue first card with navy edging, rich cranberry-red second card, strong contrast and crisp borders. Add exactly one small gold 'LIMITED' ribbon for Snowman Pet, nestled in available upper-right negative space inside its row; no LIMITED label on the sleigh. Price buttons contain only a white hexagonal Robux icon plus '40' and '75', and cash '$350' and '$30'; do not put section labels above the buttons.

Then centered label '~ GAMEPASSES ~'. Two complete side-by-side cards, each fully inside the frame with bottom border and spacing visible: WINTER FLIGHT, wing art, 'INCREASED MOVEMENT SPEED', Robux 149; GIFT LUCK, festive gift art, 'GET BETTER GIFTS', Robux 99. Dark evergreen + icy blue distinct surfaces, patterned subtly with faint snowflakes. Both price buttons readable. Avoid hidden/cut off prices or text.

Keep decorations concentrated along frame corners/perimeter so the center remains readable. Warm gold lights and ornaments add sparkle. Palette: cranberry, evergreen, midnight navy, snow-white, icy blue, small gold accents. Strong text-to-background contrast, white rounded heavy lettering with a thick dark outline, crisp readable details, UI borders and buttons clearly separated. Maintain professional visual hierarchy and balance; decorative overlays should make it feel intentionally custom and rich without cluttering the purchases. No repeated fake labels, no duplicated dollar signs, no random microtext, no watermark, no clouds, no rounded UI panels, no plain empty header, no bare undecorated corners.
```

**Prompt hindsight:** V8 included guessed gamepass prices (149/99) not present in verified source. A safer prompt must omit unverified values. It also described the badge at upper-right negative space, which later looked awkward; position should be content-aware.

## V9 — local edit of LIMITED backing

**Sonuç:** Yatay sarı backing daha sade oldu; kullanıcı daha sonra çapraz ribbon yönünü tercih etti. Bu, yalnızca texture’ı düzeltmenin konum sorununu çözmediğini gösterir.

```text
Edit only the LIMITED label area in this image. Preserve the full rest of the artwork and layout exactly. Keep a readable yellow/gold background behind the word LIMITED, but make it look like a restrained, well-integrated game UI text badge: a small flat warm-gold plaque with a clean crisp outline, subtle painted texture, compact scale, and enough contrast for the lettering. Remove the oversized rough distressed texture and avoid a big blank yellow bar. Keep the badge positioned in the same open upper-right area of the Snowman Pet row. The word LIMITED stays spelled exactly and readable. Do not add other text or another badge. Do not change colors/layout/decor anywhere else.
```

## V10 — diagonal ribbon + button alignment + crop recovery prompt

**Sonuç:** Kullanıcı tasarım yönünü “başarılı” buldu. Ribbon placement ve Sleigh control alignment korunmalı. Alt Gamepass section yine cropped kaldı, bu nedenle QA’da known defect olarak işaretlendi.

```text
Make a targeted edit of this Christmas Shop UI. Preserve V9's overall visual direction, art, layout, colors, content and decorations. Apply these specific corrections:

1) Snowman Pet LIMITED badge: remove the rectangular yellow label from the empty upper-right area. Replace it with a small, tasteful diagonal golden ribbon/banner placed at the UPPER LEFT area of the Snowman Pet card, behind the snowman's head/upper body like a corner sash, angled about 25 degrees. It should tuck naturally behind the snowman illustration, remain in the background layer, and not cover the snowman's face, product title, subtitle, currency buttons, or frame. Only the word LIMITED on the ribbon. No extra badge anywhere else. Use a thin warm gold strip with restrained red/gold trim; not a large yellow rectangle, not a medal.

2) Candy Cane Sleigh purchase controls: the green cash purchase button and blue gift button in this row currently look oversized and don't align. Reduce their visual size to the same compact height as the purple Robux 75 button; align the vertical centers, top edges and baseline consistently in one clean horizontal row. Give all three buttons consistent corner radii, outlines, weight and visual scale. Keep each button's content centered. No button should be taller than the purple Robux button. Preserve labels and values exactly: Robux hex icon 75, cash $30, gift icon. Also preserve Snowman Pet buttons 40, $350 and gift icon.

3) Fit the whole UI: compress vertical card spacing and move the full UI slightly upward so both full Gamepasses cards and their entire bottom border are visible, with clear margin to the canvas bottom. Show Winter Flight and Gift Luck titles, art, descriptions, prices if present in source, and card bases. Do not crop any element. Keep the frame large and readable rather than shrinking it to a tiny panel.

Do not change other copy, item art, header decorations, header text, or category headings. Keep the hand-drawn colorful game shop feel of this selected concept; do not make it more glossy or more ornate. No new objects or text, no watermark.
```

## Hangi prompt’lar en iyi yeniden kullanım örneği?
- **Yeni tasarım:** `PROMPT_PLAYBOOK.md` → “New-concept prompt template”; verified ledger doldur.
- **Kontrollü lokal değişiklik:** V10 badge/button edit talimatını örnek al; tek turda bir ana hata sınıfı.
- **Crop hatası:** V6 ve V10 prompt’larının başarısızlığını oku; aynı uzunlukta prompt’u tekrar etme. Deterministic wireframe’e geç.
- **Renk/dekor gerekçesi:** `docs/01_DESIGN_SYSTEM_TR.md` ve `examples/christmas_design_tokens.json`.
- **Kayıt eksikleri:** V2/V4 prompt’larını tarihsel olarak uydurma. Yeni benzer UI için template’den *reconstructed/reproducible prompt* oluştur ve bunun exact historical prompt olmadığını etiketle.
