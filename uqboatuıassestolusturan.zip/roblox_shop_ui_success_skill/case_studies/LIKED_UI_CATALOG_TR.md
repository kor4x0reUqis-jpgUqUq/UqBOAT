# Beğenilen UI’ler ve referanslar — durum kataloğu

Bu katalog, farklı ajanların kullanıcı tercihlerini yanlış genişletmesini veya referansı onay sanmasını önler. “Beğenildi”, “bir yönü örnek alındı” ve “durumu bilinmeyen referans” ayrı statülerdir.

## A. Açıkça olumlu bulunan / kabul edilen yönler

### 1) Christmas Shop V2 — kompozisyon yönü tercih edildi
- **Tam görsel:** `images/full/christmas_v2_user_preferred.png`
- **İşaretli tam kopya:** `images/annotated/christmas_v2_user_preferred.png`
- Kullanıcı V2’yi “güzel” ve V3’ten daha başarılı buldu.
- Korunacak: yatay ürün satırlarının ölçeği, ürün/başlık/açıklama/kontrol dengesi, genel pencere kompozisyonu.
- Otomatik olarak kopyalanmayacak kusur: gamepass altının kesilmiş olması; badge tekrarı da sonraki geri bildirimle değiştirilmiştir.
- Durum: `PREFERRED COMPOSITION; ORIGINAL IMAGE HAS CROP DEFECT`.

### 2) Christmas Shop V10 — tasarım yönü başarılı bulundu
- **Tam görsel:** `images/full/christmas_v10_user_accepted_direction.png`
- **İşaretli kopya:** `images/annotated/christmas_v10_user_accepted_direction.png`
- Kullanıcı “tamamdır başarılı” dedi.
- Korunacak: Snowman Pet’te tek çapraz LIMITED şeridi ve sleigh satırında eşit yükseklik/hizada kontrol grubu.
- Bilinen kusur: alt Gamepass kartları görselde kesik. Bu nedenle status `USER-ACCEPTED DIRECTION + KNOWN CROP DEFECT`; tam final/production-ready değildir.

### 3) Halloween dekor/overlay yaklaşımı — teknik olarak beğenildi
- **Halloween V5 konsepti:** `images/full/halloween_v5_overlay_reference.png`
- **Kullanıcıdan gelen Halloween birleşik referansı:** `images/full/halloween_user_reference_combined.png`
- Kullanıcı, Halloween UI’ında dekorasyonun/overlay yaklaşımının başarılı olduğunu örnek verdi; özellikle header motifleri ve köşede UI’a oturan dekor gibi teknikler Christmas’a taşınmalı.
- Bu, Halloween’deki tüm paleti, metinleri, oyun temalarını veya layout’ı Christmas’a kopyalama izni değildir. Sadece beğenilen dekor tekniğini aktar.
- Hangi Halloween görselinin tam olarak “başarılı” diye kastedildiği kesin değilse, ikisini de katalogda tut ama birini açıkça user-approved final diye etiketleme.

## B. Layout/ölçek referansı — stil onayı olarak yorumlama

### Car Shop UI
- **Tam referans:** `images/full/car_shop_layout_reference.png`
- Kullanıcı bunu renk/kontrast/ölçek ve yatay teklif yerleşimi için referans gösterdi; belirgin çerçeve, geniş teklifler, büyük ürün görseli solda, okunaklı başlık/kontroller sağda.
- Do not copy literally: car content, palette, cyan header or exact decoration. This is not the target visual style for Christmas.

## C. Durumu kesin olarak “beğenildi” denmemiş, fakat kullanıcı tarafından verilmiş diğer UI referansları

Aşağıdakiler `images/full/` içinde dosya adlarıyla tutulur. Kullanıcının kesin beğenisi olarak işaretlenmez; ajanlar bunları yalnızca kaynak bağlamı/inceleme örneği olarak görür:
- `reference_shop_christmas_20261023.png`
- `reference_shop_ui_20261027.png`
- `reference_shop_ui_20261111.png`
- `reference_shop_ui_20261112_000003.png`
- `reference_shop_ui_20261112_000014.png`
- `reference_shop_ui_20261112_000031.png`
- `reference_shop_ui_20261112_000043.png`
- `christmas_environment_reference.png`

Yeni kullanıcı geri bildirimi bu statüyü netleştirirse, karar günlüğünde güncelle.

## D. Kullanılmaması gereken örnekler
- Christmas V3: açıkça reddedildi ve kaynak dosyası silindi; sadece hata açıklaması var, yeniden oluşturma veya tasarım referansı olarak kullanma.
- Spider konseptleri: onaylanmış tasarım yok; daha önce kullanıcı tarafından yapay/yanlış bulundu.
- V4–V9 Christmas denemeleri: sadece vaka/hata analizi için paketlenmiştir; kullanıcı onayı olmadan tercih edilen tasarım örneği sayılmaz.
