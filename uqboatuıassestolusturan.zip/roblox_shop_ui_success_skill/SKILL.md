---
name: roblox-shop-ui-design-and-delivery
version: 2.0.0
description: Plan, art-direct, generate, critique, validate, and implement readable, richly decorated Roblox shop UIs from references. Use when a user needs a shop concept, iterative image revisions, an asset set, Roblox ScreenGui implementation, or a reproducible design skill. Preserve explicit user preferences, diagnose image-generation failures, and verify crop/contrast/content before claiming delivery.
---

# Roblox Shop UI: design, visual iteration, QA, and delivery

## 0. Mission and promise
Produce a shop UI that is visually coherent, readable at the intended viewport, faithful to the user's reference hierarchy, and honest about incomplete image-model results. The workflow should be repeatable by another AI: capture decisions, preserve known-good directions, make one controlled correction at a time, inspect every result, and never call an unverified image final.

This skill makes **process and judgment reproducible**, not model pixels deterministic. Different image generators may ignore layout/wording/crop constraints. Use the QA gates below to catch that rather than treating a prompt as a guarantee.

## 1. Read the project state before acting
Before any design action:
1. Read all user-provided context and current-session memory, especially explicit constraints, accepted/rejected versions, and file locations.
2. Inspect the actual reference images and current candidate files; do not rely on filenames or previous summaries alone when they can be opened.
3. Identify the current status: `REFERENCE`, `DRAFT`, `PREFERRED DIRECTION`, `USER-ACCEPTED CONCEPT`, `PRODUCTION-READY`, or `REJECTED`.
4. Read the decision log and failure catalog if they exist.
5. Never revive a deleted/rejected concept unless the user explicitly asks. Never claim an unavailable rejected image is present.

## 2. Hard rules
1. **Reference hierarchy:** the user's explicit direction beats inferred taste; accepted references beat a fresh model invention; rejected versions are not design sources. Maintain a source-of-truth note per project.
2. **Separate layout reference from style reference.** State which properties are borrowed (e.g. offer scale/order) and which are not (e.g. another UI's cyan palette). Never clone a technical repository's visual identity unless explicitly requested.
3. **Preserve exact content.** Create a content ledger for all product names, descriptions, prices, currency icons, limited labels, gift controls, and section headings. Never invent values, add fake microcopy, duplicate currency symbols, or silently delete a purchase option.
4. **Layout before decoration.** Lock frame bounds, header, sections, rows, controls, and bottom safe margin before adding ornaments, patterns, particles, and silhouettes.
5. **Decoration is part of hierarchy.** Surface patterns and corner overlays may add richness, but must not compete with title, item name, price, or action controls. Anchor ornaments to the frame/surface; avoid unexplained floating stickers.
6. **UI geometry follows the reference.** Keep outer frame/card corners crisp if requested. Use a consistent, intentional corner radius for buttons; don't round every shape by habit. Button height, baseline, padding, border weight, and icon scale must align within a row.
7. **Limited badges are contextual.** Do not paste the same badge at the same corner on every card. Place it where the row's negative space and reading order support it. Use one badge only when the item is actually limited. Respect requested badge style, e.g. a diagonal ribbon tucked behind the Snowman Pet illustration, not an unrelated plaque.
8. **Contrast is measured and viewed.** Aim for WCAG 2.2 contrast reference values (4.5:1 normal text; 3:1 large text) where practical; a thick outline is not a substitute for a clear text/background value difference. Inspect at native size and reduced/mobile size.
9. **A prompt is not QA.** Open/read every generated result. Check exact content, clipping, overlaps, ambiguous iconography, bad currency, unreadable text, button alignment, and frame margins.
10. **Full canvas is mandatory.** Count all sections and reserve space for the last row and bottom border. If any required element is cut off, report the image as incomplete even when the user likes its art direction.
11. **One revision = one main variable.** When possible, do not simultaneously change layout, palette, badge, text, and decoration. State what is held fixed and what is changing.
12. **Do not over-explain a failed result.** Admit the miss specifically, use the identified failure to change method, and avoid repeating the same call unchanged.
13. **Do not produce separate asset layers before concept approval** unless the user explicitly requests them. A concept screenshot and an asset package are different deliverables.
14. **No fabricated technical results.** Never invent Roblox IDs, tool responses, file outputs, font licenses, color research, or upload completion. For implementation/upload, follow `implementation/SKILL.md` and its security rules.

## 3. Required workflow with gates

### Gate A — brief and content lock
Create a short design brief using `examples/BRIEF_TEMPLATE_TR.md`:
- game, shop type, screen size/aspect, device priority;
- reference hierarchy: layout, palette, illustration, decoration, typography;
- product/content ledger with exact text and price values;
- intended mood and decoration level;
- explicit do-not-use list;
- user acceptance/rejection state;
- file paths to references/candidates.
Ask only if a material ambiguity blocks work; use a clarifying question for an uncertain badge placement, content, or layout—not for choices already explicit.

### Gate B — visual specification
Write 8–15 concise tokens before generating:
- frame shape and occupied canvas area;
- header geometry and icon/title/X placement;
- section sequence and row count;
- product-art zones and purchase-control zones;
- palette roles and surface contrast;
- font hierarchy/outline strategy;
- line/shading/rendering style;
- decoration layers and safe zones;
- explicit exclusions.
See `docs/01_DESIGN_SYSTEM_TR.md`.

### Gate C — composition wireframe
Calculate or sketch vertical space. Example for a landscape shop: frame/header 14%, section label 6%, two offer rows 16% each, second label 6%, gamepass cards 22%, inter-row spacing/borders 14%, with an outer bottom margin. The exact percentages depend on content; the key is that the sum includes all borders, gaps and safe margins. Verify with a rough wireframe before style detail.

For each row, allocate rectangles for: art, name/description, limited badge (if any), currency controls, gift control. Align buttons by height, vertical center and baseline. Test longest localized labels. Avoid letting the badge claim the right-hand purchase-control zone.

### Gate D — first concept
Use one primary layout reference. Add secondary style references only for explicitly isolated traits (e.g. Halloween's use of faint ghost silhouettes as a technique, but not its palette). Write prompts with:
1. purpose and output aspect;
2. preserved layout and content;
3. palette roles;
4. typography/readability;
5. decorative treatment and where it may overlap;
6. safe zones and exact exclusion list;
7. full-frame/bottom-margin check;
8. negative constraints.
Avoid contradictions (for example: “big rich decoration” and “minimal decoration,” “fill canvas” and “leave large margin”).

### Gate E — inspect and score
Review the actual output—not the prompt. Use the rubric in `docs/04_QA_CHECKLIST_TR.md`. Give scores for content accuracy, composition, contrast, hierarchy, decoration, rendering consistency, and completeness. A required score below threshold blocks final delivery.

### Gate F — user feedback and controlled iteration
- Reflect the user's feedback in one sentence to confirm the intended correction.
- Preserve the parts the user called successful.
- Name the exact defect and location.
- Use an image edit only if it can plausibly alter that local area. For repeated global failures (e.g. model repeatedly crops lower cards), switch to a compact new composition or build a deterministic layout; do not keep resending the same prompt.
- If the user's statement is ambiguous (e.g. whether a yellow badge backing is missing or unwanted), ask a short, specific question instead of guessing.
- After the edit, compare the requested pixels/regions and the whole image; an image edit can unintentionally damage unrelated areas.

### Gate G — acceptance and handoff
Only use `USER-ACCEPTED CONCEPT` when the user indicates approval. Separately mark unresolved defects. Use `PRODUCTION-READY` only after the full-canvas, content, alignment, readability, and target-device checks pass. Keep the approved image, rejected examples, prompts, and decisions in versioned files. Before creating separate production assets, wait for concept approval unless the user asks sooner.

## 4. Exact V2-led Christmas case profile (reference implementation)
This case is an example of preserving a user's taste, not a universal Christmas template.

### Accepted direction
- The user preferred Christmas V2's overall composition over V3: large horizontal offer rows, clear sequence, product art on left, readable title/description, purchase controls to right.
- V3 was explicitly rejected as “very bad”; its design approach must not be reused.
- V10 was later described by the user as successful after moving LIMITED into a diagonal ribbon and correcting the sleigh button sizing/alignment. Treat it as an accepted design direction. It still visibly crops the lower gamepass section, so record it as an accepted direction with a known completeness defect, not as a final shippable full UI.
- V2's full frame and row design are useful references but the original crop cuts off gamepass content; do not repeat that crop.
- Christmas header: one simple burgundy strip, icon left, left-aligned title, square X right. Add quiet snowman/snowflake silhouettes to the header as a surface treatment, and intentional fir/light/ornament overlays at the frame corners. No clouds; no cyan car-style header.
- Use V2 product values exactly when they are sourced: Snowman Pet Robux 40 / cash $350; Candy Cane Sleigh Robux 75 / cash $30. Do not reuse differing values generated in V4 or invent new gamepass prices.
- LIMITED belongs only on the Snowman Pet. A diagonal banner tucked behind/near the snowman at upper position is preferred over a detached yellow plaque floating in negative space.
- In the Candy Cane Sleigh row, green cash and gift controls must be visually sized/aligned with the purple Robux control: common height, centerline, baseline, border weight and readable spacing.
- The user wanted richer frame decoration, but later clarified the chosen illustration direction was good and the specific issue was the yellow background behind LIMITED. Ask whether the background is absent/unwanted if ambiguous; do not infer a full-style rejection.

### Palette logic for this case
Use cranberry as a seasonal focal point, deep navy/evergreen as structural colors, snowy white/icy blue for high contrast and clarity, and small warm gold accents. Red/green/gold/blue/white associations are common design conventions, not universal emotional laws. Keep large background colors distinct in value, not just hue. Avoid allowing every surface to become medium-dark or every button to become neon.

### Decoration logic
Use three depth planes: (1) ambient background snowfall/fir at far edges, (2) frame-attached corners and header string lights, (3) very low-contrast card/header motifs. Keep text and controls on calm zones. Use asymmetry with balance: different corner ornaments can vary in size while weight on left/right remains balanced. Make the frame corner treatment visibly intentional; simply placing trees far behind the panel does not meet a request for UI corner overlays.

## 5. File map and companion docs
- Detailed design rules: `docs/01_DESIGN_SYSTEM_TR.md`
- Iteration process and case decision log: `docs/02_WORKFLOW_AND_DECISIONS_TR.md`
- Full failure catalog and image index: `docs/03_FAILURE_CATALOG_TR.md`
- QA criteria and approval states: `docs/04_QA_CHECKLIST_TR.md`
- Roblox/UI production implementation: `implementation/SKILL.md`
- Prompt templates and reusable prompts: `prompts/PROMPT_PLAYBOOK.md`
- Actual case prompt archive with outputs/failure analysis: `prompts/CASE_PROMPTS_VERBATIM.md`
- Full and annotated case examples: `case_studies/GALLERY.html`
- Explicitly liked/reference-only UI catalog: `case_studies/LIKED_UI_CATALOG_TR.md`
