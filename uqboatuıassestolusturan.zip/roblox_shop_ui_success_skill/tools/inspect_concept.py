#!/usr/bin/env python3
"""Print image metadata for visual concept review.

This script checks file readability, pixel dimensions, aspect ratio and alpha presence.
It DOES NOT detect semantic UI cropping, wrong text, poor alignment, or whether a full
card is visible. Those checks require opening the image and following docs/04_QA_CHECKLIST_TR.md.
"""
from __future__ import annotations
import argparse
from pathlib import Path
from PIL import Image


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("images", nargs="+", help="PNG/JPEG/WebP files to inspect")
    parser.add_argument("--ratio", default="16:9", help="Target aspect ratio, e.g. 16:9")
    parser.add_argument("--ratio-tolerance", type=float, default=0.06,
                        help="Relative tolerance for the target aspect (default 0.06)")
    parser.add_argument("--min-width", type=int, default=1000)
    args = parser.parse_args()
    try:
        rw, rh = (float(x) for x in args.ratio.split(":"))
        expected = rw / rh
    except Exception:
        parser.error("--ratio must look like 16:9")
    failed = False
    for item in args.images:
        path = Path(item)
        try:
            with Image.open(path) as im:
                w, h = im.size
                actual = w / h
                has_alpha = "A" in im.getbands()
                ratio_delta = abs(actual - expected) / expected
                flags = []
                if w < args.min_width:
                    flags.append(f"width<{args.min_width}")
                    failed = True
                if ratio_delta > args.ratio_tolerance:
                    flags.append(f"aspect differs from {args.ratio} by {ratio_delta:.1%}")
                print(f"{path}: {im.format} {w}x{h} ratio={actual:.4f} mode={im.mode} alpha_channel={has_alpha}")
                if flags:
                    print("  WARN: " + "; ".join(flags))
                print("  MANUAL: inspect all four frame edges, exact text/prices, last card, bottom border, alignment and mobile readability.")
        except Exception as exc:
            print(f"ERROR: {path}: {exc}")
            failed = True
    return 1 if failed else 0

if __name__ == "__main__":
    raise SystemExit(main())
